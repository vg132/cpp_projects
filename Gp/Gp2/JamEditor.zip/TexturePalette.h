// TexturePalette.h - header file defining the standard GP2
//					  palette for JAMs.

#ifndef __TEXTURE_PALETTE_H__
#define __TEXTURE_PALETTE_H__

#define GP2_PALETTE_SIZE				256
#define GP2_TRANSPARENT_PALETTE_INDEX	0

////////////////////////////////////////////////////////////////////////
// Class:	CGP2Palette
// Base:	[none]
// Overview:
//    I've had to introduce this class to manage dynamic allocation and
//  destruction of the global palette array because otherwise it was
//  proving impossible to change the contents of the array after it was
//  initialised.
//

class CGP2Palette
{
// Construction / destruction
public:
	CGP2Palette();
	~CGP2Palette();

// Enumerations
public:
	// The types of palette we support. Note: the numbers are
	// chosen to correspond to the indexes of the radio buttons
	// in the Options dialog.
	enum ePaletteType
	{
		PALTYPE_GP2 = 0,
		PALTYPE_GP3 = 1,
		PALTYPE_CUSTOM = 2,
		PALTYPE_FIRST = PALTYPE_GP2,
		PALTYPE_FINAL = PALTYPE_CUSTOM,
	};

// Data members
private:
	// The type of palette we're currently using and the name
	// of the custom one to use should the punter choose that option.
	ePaletteType m_nPaletteType;
	CString m_strPaletteFilename;

	// The palette itself - bow down and worship it!
	RGBQUAD m_Palette[GP2_PALETTE_SIZE];

// Operations
public:
	// An array-access operator so that the outside world
	// can continue to use an object of this class in the
	// same way as it used the old global static array.
	RGBQUAD& operator[] (const int nIndex)
	{
		ASSERT(nIndex >= 0);
		ASSERT(nIndex < GP2_PALETTE_SIZE);
		return m_Palette[nIndex];
	}

	// Get/set palette type.  When setting, load the relevant
	// palette, too, if we're setting to use the custom palette.
	ePaletteType GetPaletteType() const { return m_nPaletteType; }
	BOOL SetPaletteType(const int nPalType, CString strPaletteFilename = "");

	// Get the filename of the external JASC-format palette
	CString GetCustomPalette() const { return m_strPaletteFilename; }

	// Get the colour to use when displaying transparent areas
	COLORREF GetTransparentColor();

// Implementation
protected:
	BOOL LoadStandardPalette(const RGBQUAD palette[]);
	BOOL LoadCustomPalette(const CString& strFilename);

// The one and only CGP2Palette object
public:
	static CGP2Palette thePalette;
};

// F!*& me, this must be THE worst bodge I've ever done.
// I should be ashamed of myself.
#define g_jamPalette	CGP2Palette::thePalette

/////////////////////////////////////////////////////////////////

#endif	// ~__TEXTURE_PALETTE_H__
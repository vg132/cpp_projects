// JamEditorMRUPaths.h - a single point at which the names of operations
//						 storing MRU paths are held.

// Loading a jam/jad
static const TCHAR szOpenJamPath[] = _T("Open Jam");

// Saving a jam/jad
static const TCHAR szSaveJamPath[] = _T("Save Jam");

// Importing a canvas
static const TCHAR szImportCanvasPath[] = _T("Import Canvas");

// Exporting a canvas
static const TCHAR szExportCanvasPath[] = _T("Export Canvas");

// Importing a texture
static const TCHAR szImportTexturePath[] = _T("Import Texture");

// Exporting a texture
static const TCHAR szExportTexturePath[] = _T("Export Texture");


// MainFrame.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "JamEditor.h"

#include "MainFrame.h"
#include "JamTree.h"
#include "Splash.h"

#include "JamTextureFilter.h"
#include "EditableObject.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_VIRTKEY_RETURN, OnVKReturn)
	ON_COMMAND(ID_VIRTKEY_ESCAPE, OnVKEscape)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_COMMAND_EX(ID_VIEW_JAMTREE, CFrameWnd::OnBarCheck)
	ON_UPDATE_COMMAND_UI(ID_VIEW_JAMTREE, CFrameWnd::OnUpdateControlBarMenu)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CMDIFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// Create the toolbar
	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	// Create the status bar
	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// Create the Jam control bar.  NOTE: the actual value of the
	// control bar ID (3rd param) must be the same as the value of
	// its command in the menus, so that we can make use of 
	// CFrameWnd::OnBarCheck and CFrameWnd::OnUpdateControlBarMenu
	if (!m_wndJamBar.Create(this, CSize(200,40), ID_VIEW_JAMTREE, WS_CHILD | WS_VISIBLE | CBRS_LEFT))
	{
		TRACE0("Failed to create Jam control bar\n");
		return -1;      // fail to create
	}

	// Give the toolbar tooltips and make it resizable
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	// Set the window title of the toolbar for when it's floated
	CString strTitle("");
	strTitle.LoadString(IDS_TOOLBAR_TITLE);
	m_wndToolBar.SetWindowText(strTitle);

	// Make the toolbar and jam bar dockable and put them
	// into position
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndJamBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar, AFX_IDW_DOCKBAR_TOP);
	DockControlBar(&m_wndJamBar, AFX_IDW_DOCKBAR_LEFT);

	// Load the positions of the bars if they're in the INI file
	LoadBarState("Docking control bars");

	// CG: The following line was added by the Splash Screen component.
	CSplashWnd::ShowSplashScreen(this);

	return 0;
}

void CMainFrame::OnDestroy() 
{
	// Save the positions of the bars in the INI file
	SaveBarState("Docking control bars");

	CMDIFrameWnd::OnDestroy();
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CMDIFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame Options handlers


/////////////////////////////////////////////////////////////////////////////
// CMainFrame tree operations

void CMainFrame::UpdateTreeAfterOpenDocument(CEditableObject* pObject)
{
	// we will find the tree and pass this on
	if (m_wndJamBar.GetTree())
	{
		// give this to the all jams node
		m_wndJamBar.GetTree()->AddDataToAllJams(pObject); 
	}
}

void CMainFrame::UpdateTreeForCloseDocument(CEditableObject* pObject)
{
	// we will find the tree and pass this on
	if (m_wndJamBar.GetTree())
	{
		// give this to the all jams node
		m_wndJamBar.GetTree()->RemoveJamDoc(pObject); 
	}
}

void CMainFrame::UpdateTreeDataDisplay(CEditableObject* pObject)
{
	// we will find the tree and pass this on
	if (m_wndJamBar.GetTree())
	{
		// give this to the all jams node
		m_wndJamBar.GetTree()->RefreshDataDisplay(pObject); 
	}
}

void CMainFrame::UpdateTreeAfterSelectTexture(CEditableObject* pObject)
{
	// the pObject is the texture itself
	ASSERT(NULL != pObject);
	if (NULL == pObject)
		return;

	// we will find the tree and pass this on
	if (m_wndJamBar.GetTree())
	{
		m_wndJamBar.GetTree()->EnsureVisible(pObject->GetTreeItem());
		m_wndJamBar.GetTree()->SelectItem(pObject->GetTreeItem());
	}
}

void CMainFrame::UpdateTreeAfterAddNewTexture(CEditableObject* pObject)
{
	// the pObject is the texture itself
	ASSERT(NULL != pObject && NULL != pObject->GetParent());
	if (NULL == pObject || NULL == pObject->GetParent())
		return;

	// we will find the tree and pass this on
	if (m_wndJamBar.GetTree())
	{
		// Update the number of textures in the jam
		m_wndJamBar.GetTree()->RefreshDataDisplay(pObject->GetParent()); 

		// Add the new texture
		m_wndJamBar.GetTree()->AddData(pObject, pObject->GetParent()->GetTreeItem());

		// Select it in the tree
		UpdateTreeAfterSelectTexture(pObject);
	}
}

void CMainFrame::UpdateTreeForDeleteTexture(CEditableObject* pObject)
{
	// the pObject is the texture itself
	ASSERT(NULL != pObject && NULL != pObject->GetParent());
	if (NULL == pObject || NULL == pObject->GetParent())
		return;

	// we will find the tree and pass this on
	if (m_wndJamBar.GetTree())
	{
		// Remove the texture (I must rename the RemoveJamDoc
		// function to RemoveData).
		m_wndJamBar.GetTree()->RemoveJamDoc(pObject);
	}
}




////////////////////////////////////////////////////////////
// Fixes to allow handling of keys in the Jam Tree

// The Enter key
void CMainFrame::OnVKReturn()
{
	// Pass the message on to the relevant window
	OnVirtualKey(VK_RETURN);
}

// The Escape key
void CMainFrame::OnVKEscape()
{
	// Pass the message on to the relevant window
	OnVirtualKey(VK_ESCAPE);
}

// Generic function for passing on a keypress
void CMainFrame::OnVirtualKey(const UINT& vkCode)
{
	// Thanks go to Ashley for this code
	CWnd* pFocus = GetFocus();
	if (NULL == pFocus)
		return;

	HWND hwnd = pFocus->m_hWnd;
	if (::IsWindow(hwnd))
	{
		// Pass the message directly to the window with the focus
		pFocus->SendMessage(WM_KEYDOWN, vkCode, 1);

		// The WM_KEYDOWN may have caused the window in focus to
		// disappear, so we need to test for its existence again
		// before we pass it the WM_KEYUP message.
		if (::IsWindow(hwnd))
			pFocus->SendMessage(WM_KEYUP, vkCode, 1);
	}
}

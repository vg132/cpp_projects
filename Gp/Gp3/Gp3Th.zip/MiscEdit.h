#if !defined(AFX_MISCEDIT_H__82E75820_8977_11D4_8FC7_0008C7636E27__INCLUDED_)
#define AFX_MISCEDIT_H__82E75820_8977_11D4_8FC7_0008C7636E27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MiscEdit.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMiscEdit dialog

class CMiscEdit : public CDialog
{
// Construction
public:
	void LoadAids();
	CString m_TempFile;
	CMiscEdit(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMiscEdit)
	enum { IDD = IDD_MISCEDIT };
	CSpinButtonCtrl	m_Spin_RaceLen;
	CStatic	m_Pro8;
	CStatic	m_SemiPro8;
	CStatic	m_SemiPro7;
	CStatic	m_SemiPro6;
	CStatic	m_SemiPro5;
	CStatic	m_SemiPro4;
	CStatic	m_SemiPro3;
	CStatic	m_SemiPro2;
	CStatic	m_SemiPro1;
	CStatic	m_Rookie8;
	CStatic	m_Rookie7;
	CStatic	m_Rookie6;
	CStatic	m_Rookie5;
	CStatic	m_Rookie4;
	CStatic	m_Rookie3;
	CStatic	m_Rookie2;
	CStatic	m_Rookie1;
	CStatic	m_Pro7;
	CStatic	m_Pro6;
	CStatic	m_Pro5;
	CStatic	m_Pro4;
	CStatic	m_Pro3;
	CStatic	m_Pro2;
	CStatic	m_Pro1;
	CStatic	m_Amateur8;
	CStatic	m_Amateur7;
	CStatic	m_Amateur6;
	CStatic	m_Amateur5;
	CStatic	m_Amateur4;
	CStatic	m_Amateur3;
	CStatic	m_Amateur2;
	CStatic	m_Amateur1;
	CStatic	m_Ace7;
	CStatic	m_Ace6;
	CStatic	m_Ace8;
	CStatic	m_Ace5;
	CStatic	m_Ace4;
	CStatic	m_Ace3;
	CStatic	m_Ace2;
	CStatic	m_Ace1;
	BOOL	m_SaveRec;
	int		m_RaceLen;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMiscEdit)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
private:
	int Ace[8];
	int Pro[8];
	int SemiPro[8];
	int Amateur[8];
	int Rookie[8];
// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMiscEdit)
	afx_msg void OnAce1();
	afx_msg void OnAce2();
	afx_msg void OnAce3();
	afx_msg void OnAce4();
	afx_msg void OnAce5();
	afx_msg void OnAce6();
	afx_msg void OnAce7();
	afx_msg void OnAce8();
	afx_msg void OnPro1();
	afx_msg void OnPro2();
	afx_msg void OnPro3();
	afx_msg void OnPro4();
	afx_msg void OnPro5();
	afx_msg void OnPro6();
	afx_msg void OnPro7();
	afx_msg void OnPro8();
	virtual BOOL OnInitDialog();
	afx_msg void OnAmateur1();
	afx_msg void OnAmateur2();
	afx_msg void OnAmateur3();
	afx_msg void OnAmateur4();
	afx_msg void OnAmateur5();
	afx_msg void OnAmateur6();
	afx_msg void OnAmateur7();
	afx_msg void OnAmateur8();
	afx_msg void OnRookie1();
	afx_msg void OnRookie2();
	afx_msg void OnRookie3();
	afx_msg void OnRookie4();
	afx_msg void OnRookie5();
	afx_msg void OnRookie6();
	afx_msg void OnRookie7();
	afx_msg void OnRookie8();
	afx_msg void OnSemipro1();
	afx_msg void OnSemipro2();
	afx_msg void OnSemipro3();
	afx_msg void OnSemipro4();
	afx_msg void OnSemipro5();
	afx_msg void OnSemipro6();
	afx_msg void OnSemipro7();
	afx_msg void OnSemipro8();
	afx_msg void OnCancel();
	afx_msg void OnOk();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MISCEDIT_H__82E75820_8977_11D4_8FC7_0008C7636E27__INCLUDED_)

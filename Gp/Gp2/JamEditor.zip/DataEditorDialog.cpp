// DataEditorDialog.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "DataEditorDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDataEditorDialog dialog


CDataEditorDialog::CDataEditorDialog(CWnd* pParent /*=NULL*/)
	: CDialog(CDataEditorDialog::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDataEditorDialog)
	m_newValue = _T("");
	//}}AFX_DATA_INIT
}


void CDataEditorDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDataEditorDialog)
	DDX_Text(pDX, IDC_NEW_VALUE, m_newValue);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDataEditorDialog, CDialog)
	//{{AFX_MSG_MAP(CDataEditorDialog)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDataEditorDialog message handlers

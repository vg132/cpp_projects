// UnderwaterFilter.cpp - implementation of the CUnderwaterFilter class
//

#include "stdafx.h"
#include "resource.h"

#include "UnderwaterFilter.h"
#include "JamTextureFilterIDs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CUnderwaterFilter

// Constructor
CUnderwaterFilter::CUnderwaterFilter()
	: CTintedFilter(UNDERWATER_FILTER, IDS_FILTER_NAME_UNDERWATER)
{
	SetTintColor(RGB(151,167,223));	// watery blue
	SetTintFactor(70);				// keep 70% of original colour between palettes
}

// Destructor
CUnderwaterFilter::~CUnderwaterFilter()
{
}


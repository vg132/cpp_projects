// Gp3FileInfo.cpp: implementation of the CGp3FileInfo class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Gp3FileInfo.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGp3FileInfo::CGp3FileInfo()
{

}

CGp3FileInfo::~CGp3FileInfo()
{

}

bool CGp3FileInfo::LoadInfo(CString file)
{
HANDLE hFile;
DWORD dwSize;
DWORD dwReadSize;
CFile f;
int check;

	hFile=CreateFile(file,GENERIC_READ,
						FILE_SHARE_READ,
						NULL,OPEN_EXISTING,
						FILE_ATTRIBUTE_NORMAL,
						NULL);

	dwSize=GetFileSize(hFile,NULL);

	char * lpBuffer = (char*)GlobalAlloc(GMEM_FIXED,dwSize );
	ReadFile(hFile,(LPVOID)lpBuffer,dwSize,&dwReadSize,NULL);
	if(dwReadSize==0)
		return(false);
	CloseHandle(hFile);

	i=dwReadSize;
	if(i>0)
	{
		do
		{
			ch=lpBuffer[i];
			m_Gp3Info.Insert(0,ch);
			i--;
		}while(m_Gp3Info.Mid(0,4)!=".jam"&&m_Gp3Info.Mid(0,9)!="#GP3INFO|"&&i>1);
		if(m_Gp3Info.Mid(0,9)=="#GP3INFO|")
		{
			GlobalFree(lpBuffer);
			return(true);
		}
	}
	GlobalFree(lpBuffer);
	f.Open(file,CFile::modeRead,NULL);
	f.SeekToEnd();
	f.Seek(-4,CFile::current);
	f.Read((char*)&check,sizeof(check));
	f.Close();
	if(check==3980530142||check==2728927229)
		return(OrgTrack(0));
	else if(check==831026170||check==2192055089)
		return(OrgTrack(1));
	else if(check==864078580)
		return(OrgTrack(2));
	else if(check==4060019377)
		return(OrgTrack(3));
	else if(check==1494350700||check==2974856851)
		return(OrgTrack(4));
	else if(check==3908405171)
		return(OrgTrack(5));
	else if(check==716266689)
		return(OrgTrack(6));
	else if(check==3284817844)
		return(OrgTrack(7));
	else if(check==1658071651)
		return(OrgTrack(8));
	else if(check==3063787638)
		return(OrgTrack(9));
	else if(check==901838652||check==2800252837)
		return(OrgTrack(10));
	else if(check==1453342024)
		return(OrgTrack(11));
	else if(check==4211399329)
		return(OrgTrack(12));
	else if(check==3550492467)
		return(OrgTrack(13));
	else if(check==418369578)
		return(OrgTrack(14));
	else if(check==2751638719)
		return(OrgTrack(15));
	return(false);
}

CString CGp3FileInfo::GetName()
{
	m_Tmp="";
	i=m_Gp3Info.Find("|Name|",0);
	if(i!=0)
	{
		i+=6;
		while((ch=m_Gp3Info.GetAt(i))!='|')
		{
			m_Tmp+=ch;
			i++;
		}
	}
	return(m_Tmp);
}

CString CGp3FileInfo::GetCountry()
{
	m_Tmp="";
	i=m_Gp3Info.Find("|Country|",0);
	if(i!=0)
	{
		i+=9;
		while((ch=m_Gp3Info.GetAt(i))!='|')
		{
			m_Tmp+=ch;
			i++;
		}
	}
	return(m_Tmp);
}

CString CGp3FileInfo::GetLength()
{
	m_Tmp="";
	i=m_Gp3Info.Find("|LengthMeters|",0);
	if(i!=0)
	{
		i+=14;
		while((ch=m_Gp3Info.GetAt(i))!='|')
		{
			m_Tmp+=ch;
			i++;
		}
	}
	return(m_Tmp);
}

CString CGp3FileInfo::GetLaps()
{
	m_Tmp="";
	i=m_Gp3Info.Find("|Laps|",0);
	if(i!=0)
	{
		i+=6;
		while((ch=m_Gp3Info.GetAt(i))!='|')
		{
			m_Tmp+=ch;
			i++;
		}
	}
	return(m_Tmp);
}

CString CGp3FileInfo::GetSlot()
{
	m_Tmp="";
	i=m_Gp3Info.Find("|Slot|",0);
	if(i!=0)
	{
		i+=6;
		while((ch=m_Gp3Info.GetAt(i))!='|')
		{
			m_Tmp+=ch;
			i++;
		}
	}
	return(m_Tmp);
}

CString CGp3FileInfo::GetWare()
{
	m_Tmp="";
	i=m_Gp3Info.Find("|Tyre|",0);
	if(i!=0)
	{
		i+=6;
		while((ch=m_Gp3Info.GetAt(i))!='|')
		{
			m_Tmp+=ch;
			i++;
		}
	}
	return(m_Tmp);
}

CString CGp3FileInfo::GetDesc()
{
	m_Tmp="";
	i=m_Gp3Info.Find("|Desc|",0);
	if(i!=0)
	{
		i+=6;
		while((ch=m_Gp3Info.GetAt(i))!='|')
		{
			m_Tmp+=ch;
			i++;
		}
	}
	return(m_Tmp);
}

CString CGp3FileInfo::GetQualRec()
{
	m_Tmp="";
	i=m_Gp3Info.Find("|LapRecordQualify|",0);
	if(i!=0)
	{
		i+=18;
		while((ch=m_Gp3Info.GetAt(i))!='|')
		{
			m_Tmp+=ch;
			i++;
		}
	}
	if(m_Tmp=="None Entered")
		m_Tmp="";
	return(m_Tmp);
}

CString CGp3FileInfo::GetRaceRec()
{
	m_Tmp="";
	i=m_Gp3Info.Find("|LapRecord|",0);
	if(i!=0)
	{
		i+=11;
		while((ch=m_Gp3Info.GetAt(i))!='|')
		{
			m_Tmp+=ch;
			i++;
		}
	}
	if(m_Tmp=="None Entered")
		m_Tmp="";
	return(m_Tmp);
}

CString CGp3FileInfo::GetAuthor()
{
	m_Tmp="";
	i=m_Gp3Info.Find("|Author|",0);
	if(i!=0)
	{
		i+=8;
		while((ch=m_Gp3Info.GetAt(i))!='|')
		{
			m_Tmp+=ch;
			i++;
		}
	}
	return(m_Tmp);
}

CString CGp3FileInfo::GetEvent()
{
	m_Tmp="";
	i=m_Gp3Info.Find("|Event|",0);
	if(i!=0)
	{
		i+=7;
		while((ch=m_Gp3Info.GetAt(i))!='|')
		{
			m_Tmp+=ch;
			i++;
		}
	}
	return(m_Tmp);
}

CString CGp3FileInfo::GetYear()
{
	m_Tmp="";
	i=m_Gp3Info.Find("|Year|",0);
	if(i!=0)
	{
		i+=6;
		while((ch=m_Gp3Info.GetAt(i))!='|')
		{
			m_Tmp+=ch;
			i++;
		}
	}
	return(m_Tmp);
}

bool CGp3FileInfo::OrgTrack(int nr)
{
	if(nr==0)
		m_Gp3Info="#GP3INFO|Name|Melbourne|Country|Australia|Created|Created by GP3Track Editor written by Paul Hoad see (License.txt about distributing this track)|Author|Microprose|Year|1998|Event|Formula 1|Desc||Laps|58|Slot|1|Tyre|25000|LengthMeters|5301|LapRecord|1:31.649|LapRecordQualify|1:30.010|";
	else if(nr==1)
		m_Gp3Info="#GP3INFO|Name|Interlagos|Country|Brazil|Created|Created by GP3Track Editor written by Paul Hoad see (License.txt about distributing this track)|Author|Microprose|Year|1998|Event|Formula 1|Desc||Laps|72|Slot|2|Tyre|25000|LengthMeters|4330|LapRecord|1:19.337|LapRecordQualify|1:17.092|";
	else if(nr==2)
		m_Gp3Info="#GP3INFO|Name|Buenos Aires|Country|Argentina|Created|Created by GP3Track Editor written by Paul Hoad see (License.txt about distributing this track)|Author|Microprose|Year|1998|Event|Formula 1|Desc||Laps|72|Slot|3|Tyre|25000|LengthMeters|4257|LapRecord|1:28.179|LapRecordQualify|1:25.852|";
	else if(nr==3)
		m_Gp3Info="#GP3INFO|Name|Imola|Country|San Marino|Created|Created by GP3Track Editor written by Paul Hoad see (License.txt about distributing this track)|Author|Microprose|Year|1998|Event|Formula 1|Desc||Laps|62|Slot|4|Tyre|25000|LengthMeters|4930|LapRecord|1:29.345|LapRecordQualify|1:25.973|";
	else if(nr==4)
		m_Gp3Info="#GP3INFO|Name|Barcelona|Country|Spain|Created|Created by GP3Track Editor written by Paul Hoad see (License.txt about distributing this track)|Author|Microprose|Year|1998|Event|Formula 1|Desc||Laps|65|Slot|5|Tyre|25000|LengthMeters|4725|LapRecord|1:24.275|LapRecordQualify|1:20.262|";
	else if(nr==5)
		m_Gp3Info="#GP3INFO|Name|Monte Carlo|Country|Monaco|Created|Created by GP3Track Editor written by Paul Hoad see (License.txt about distributing this track)|Author|Microprose|Year|1998|Event|Formula 1|Desc||Laps|78|Slot|6|Tyre|25000|LengthMeters|3418|LapRecord|1:22.948|LapRecordQualify|1:19.798|";
	else if(nr==6)
		m_Gp3Info="#GP3INFO|Name|Montreal|Country|Canada|Created|Created by GP3Track Editor written by Paul Hoad see (License.txt about distributing this track)|Author|Microprose|Year|1998|Event|Formula 1|Desc||Laps|69|Slot|7|Tyre|25000|LengthMeters|4418|LapRecord|1:19.379|LapRecordQualify|1:18.213|";
	else if(nr==7)
		m_Gp3Info="#GP3INFO|Name|Magny Cours|Country|France|Created|Created by GP3Track Editor written by Paul Hoad see (License.txt about distributing this track)|Author|Microprose|Year|1998|Event|Formula 1|Desc||Laps|71|Slot|8|Tyre|25000|LengthMeters|4247|LapRecord|1:17.523|LapRecordQualify|1:14.929|";
	else if(nr==8)
		m_Gp3Info="#GP3INFO|Name|Silverstone|Country|United Kingdom|Created|Created by GP3Track Editor written by Paul Hoad see (License.txt about distributing this track)|Author|Microprose|Year|1998|Event|Formula 1|Desc||Laps|70|Slot|9|Tyre|25000|LengthMeters|5174|LapRecord|1:35.704|LapRecordQualify|1:23.271|";
	else if(nr==9)
		m_Gp3Info="#GP3INFO|Name|A1-ring|Country|Austria|Created|Created by GP3Track Editor written by Paul Hoad see (License.txt about distributing this track)|Author|Microprose|Year|1998|Event|Formula 1|Desc||Laps|71|Slot|10|Tyre|25000|LengthMeters|4315|LapRecord|1:12.878|LapRecordQualify|1:29.598|";
	else if(nr==10)
		m_Gp3Info="#GP3INFO|Name|Hockenheim|Country|Germany|Created|Created by GP3Track Editor written by Paul Hoad see (License.txt about distributing this track)|Author|Microprose|Year|1998|Event|Formula 1|Desc||Laps|45|Slot|11|Tyre|25000|LengthMeters|6822|LapRecord|1:46.116|LapRecordQualify|1:41.838|";
	else if(nr==11)
		m_Gp3Info="#GP3INFO|Name|Hungaroring|Country|Hungary|Created|Created by GP3Track Editor written by Paul Hoad see (License.txt about distributing this track)|Author|Microprose|Year|1998|Event|Formula 1|Desc||Laps|77|Slot|12|Tyre|25000|LengthMeters|3969|LapRecord|1:16.973|LapRecordQualify|1:19.286|";
	else if(nr==12)
		m_Gp3Info="#GP3INFO|Name|Spa-Francorchamps|Country|Belgium|Created|Created by GP3Track Editor written by Paul Hoad see (License.txt about distributing this track)|Author|Microprose|Year|1998|Event|Formula 1|Desc||Laps|44|Slot|13|Tyre|25000|LengthMeters|6973|LapRecord|2:03.766|LapRecordQualify|1:48.682|";
	else if(nr==13)
		m_Gp3Info="#GP3INFO|Name|Monza|Country|Italy|Created|Created by GP3Track Editor written by Paul Hoad see (License.txt about distributing this track)|Author|Microprose|Year|1998|Event|Formula 1|Desc||Laps|53|Slot|14|Tyre|25000|LengthMeters|5769|LapRecord|1:25.139|LapRecordQualify|1:25.280|";
	else if(nr==14)
		m_Gp3Info="#GP3INFO|Name|Nurburgring|Country|Germany|Created|Created by GP3Track Editor written by Paul Hoad see (License.txt about distributing this track)|Author|Microprose|Year|1998|Event|Formula 1|Desc||Laps|67|Slot|15|Tyre|25000|LengthMeters|4554|LapRecord|1:20.450|LapRecordQualify|1:18.561|";
	else if(nr==15)
		m_Gp3Info="#GP3INFO|Name|Suzuka|Country|Japan|Created|Created by GP3Track Editor written by Paul Hoad see (License.txt about distributing this track)|Author|Microprose|Year|1998|Event|Formula 1|Desc||Laps|51|Slot|16|Tyre|25000|LengthMeters|5861|LapRecord|1:40.190|LapRecordQualify|1:36.293|";
	return(true);
}

// Gp3 Track HandlerView.cpp : implementation of the CGp3TrackHandlerView class
//

#include "stdafx.h"
#include "Gp3 Track Handler.h"

#include "Gp3 Track HandlerDoc.h"
#include "Gp3 Track HandlerView.h"
#include "Text.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGp3TrackHandlerView

IMPLEMENT_DYNCREATE(CGp3TrackHandlerView, CFormView)

BEGIN_MESSAGE_MAP(CGp3TrackHandlerView, CFormView)
	//{{AFX_MSG_MAP(CGp3TrackHandlerView)
	ON_BN_CLICKED(IDC_BUTTON_IMPORT, OnButtonImport)
	ON_BN_CLICKED(IDC_BUTTON_LIST, OnButtonList)
	ON_BN_CLICKED(IDC_BUTTON_CHANGE, OnButtonChange)
	ON_BN_CLICKED(IDC_BUTTON_SAVE, OnButtonSave)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGp3TrackHandlerView construction/destruction

CGp3TrackHandlerView::CGp3TrackHandlerView()
	: CFormView(CGp3TrackHandlerView::IDD)
{
	//{{AFX_DATA_INIT(CGp3TrackHandlerView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// TODO: add construction code here
}

CGp3TrackHandlerView::~CGp3TrackHandlerView()
{
}

void CGp3TrackHandlerView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGp3TrackHandlerView)
	DDX_Control(pDX, IDC_LIST_TEST, m_List);
	//}}AFX_DATA_MAP
}

BOOL CGp3TrackHandlerView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CGp3TrackHandlerView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

}

/////////////////////////////////////////////////////////////////////////////
// CGp3TrackHandlerView diagnostics

#ifdef _DEBUG
void CGp3TrackHandlerView::AssertValid() const
{
	CFormView::AssertValid();
}

void CGp3TrackHandlerView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CGp3TrackHandlerDoc* CGp3TrackHandlerView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGp3TrackHandlerDoc)));
	return (CGp3TrackHandlerDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGp3TrackHandlerView message handlers

void CGp3TrackHandlerView::OnButtonImport() 
{
CString tmp;
	BeginWaitCursor();
	m_Text.LoadText("e:\\Grand Prix 3\\ldata\\English.str");
	EndWaitCursor();
}

void CGp3TrackHandlerView::OnButtonList() 
{
	int i;
	int tmp=m_List.GetCount();
	for(i=0;i<tmp;i++)
		m_List.DeleteString(0);

	for(i=1;i<17;i++)
	{
		m_List.AddString(m_Text.GetTrackName(i));
		m_List.AddString(m_Text.GetTrackCountry(i));
		m_List.AddString(m_Text.GetTrackAdjective(i));
	}
}

void CGp3TrackHandlerView::OnButtonChange() 
{
	m_Text.SetTrackAdjective("Hej Viktor",1);	
}

void CGp3TrackHandlerView::OnButtonSave() 
{
	BeginWaitCursor();
	m_Text.SaveText("e:\\Grand Prix 3\\ldata\\English.str");	
	EndWaitCursor();
}

// Text.h: interface for the CText class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TEXT_H__DF78CCE0_64D3_11D4_B4A4_0008C7636E27__INCLUDED_)
#define AFX_TEXT_H__DF78CCE0_64D3_11D4_B4A4_0008C7636E27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CText  
{
public:
	int GetTextSize();
	bool SetTrackCountry(CString NewString, int TrackNr);
	bool SetTrackAdjective(CString NewString, int TrackNr);
	bool SetTrackName(CString NewString, int TrackNr);
	CString GetTrackCountry(int TrackNr);
	CString GetTrackAdjective(int TrackNr);
	CString GetTrackName(int TrackNr);
	bool SaveText(CString sFile);
	bool LoadText(CString sFile);
	CText();
	virtual ~CText();

private:
	CStringArray sText;
};

#endif // !defined(AFX_TEXT_H__DF78CCE0_64D3_11D4_B4A4_0008C7636E27__INCLUDED_)

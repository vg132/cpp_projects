// FilePreviewManager.h : header file for the CFilePreviewManager class
//

#ifndef _FILE_PREVIEW_MANAGER_H
#define _FILE_PREVIEW_MANAGER_H

#include "FilePreview.h"

//////////////////////////////////////////////////////////////////
// Class:	CFilePreviewManager
// Base:	[none]
// Created:	28th March 1999 by Mal Ross
// Overview:
//    This class implements a variant of the Prototype design
//  pattern.  It contains a list of different preview types for
//  use in a CPreviewFileDialog and clones these when the dialog
//  asks for a CFilePreview for a given file type.  CFilePreview's
//  CreateNewPreview() method is the Prototype aspect of the
//  design.  This class simply implements a manager/library for
//  the prototypes.  The program is restricted to having a single
//  instance of the class by use of the Singleton pattern.
//

class CFilePreviewManager
{
// Construction/destruction
protected:
	CFilePreviewManager();
	~CFilePreviewManager();

// Attributes
protected:
	// The list of preview types available
	CTypedPtrList<CObList, CFilePreview*> m_lstPreviewTypes;

	// The only instance of the class that should ever exist.
	static CFilePreviewManager* m_pUniqueInstance;

// Operations
public:
	// Singleton-related operations
	static CFilePreviewManager* GetManager();
	static void DestroyManager();	// call this from your ExitInstance

	// Add file types your application supports using this function:
	BOOL AddFilePreview(CFilePreview* pPreviewType);

	// Creation of new preview objects based on a filename
	CFilePreview* CreateFilePreview (const CString& strFilename);

// Implementation
protected:
	// Preview-type retrieval
	CFilePreview* FindPreviewForFile (const CString& strFilename);
};

/////////////////////////////////////////////////////////////////////////////

#endif	// ~_FILE_PREVIEW_MANAGER_H


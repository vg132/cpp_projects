// FileSpec.h - interface of the CFilenameParser class for parsing
//              fully-qualified paths

#ifndef __FILENAME_PARSER_H__
#define __FILENAME_PARSER_H__

//////////////////////////////////////////////////////////////
// Class:	CFilenameParser
// Base:	[none]
// Overview:
//    This class was downloaded from www.codeguru.com and
//  has been modified slightly (mainly a bit more pretty-
//  printing).
//

class CFilenameParser
{
// Enumerations
public:
	enum FP_BUILTINS
	{
		FP_EMPTY,								//	Nothing
		FP_APP,									//  Full application path and name
		FP_APPDIR,								//	Application folder
		FP_CURRDIR,								//	Current working folder
		FP_WINDIR,								//	Windows folder
		FP_SYSDIR,								//	System folder
		FP_TMPDIR,								//	Temporary folder
		FP_DESKTOP,								//	Desktop folder
		FP_FAVOURITES,							//	Favourites folder
		FP_TEMPNAME								//	Create a temporary name
	};

// Construction
public:
	CFilenameParser(FP_BUILTINS spec = FP_EMPTY);
	CFilenameParser(LPCTSTR spec);

//	Operations
public:
	BOOL			Exists() const;
	BOOL			IsOfType(LPCTSTR extension) const;

//	Access functions
	CString&		Drive()				{ return m_drive; }
	CString&		Path()				{ return m_path; }
	CString&		FileName()			{ return m_fileName; }
	CString&		Extension()			{ return m_ext; }
	CString			DriveAndPath(const BOOL bIncludeTrailingSlash = FALSE) const;
	CString			FullPathNoExtension() const;

					operator LPCTSTR()	{ return GetFullSpec(); }          // as a C string

	CString			GetFullSpec() const;
	void			SetFullSpec(LPCTSTR spec);
	void			SetFullSpec(FP_BUILTINS spec = FP_EMPTY);
	
	CString			GetFileNameEx() const;
	void			SetFileNameEx(LPCTSTR spec);

	BOOL			IsFullSpec() const;

// Implementation
protected:
	void			Initialise();
	void			Initialise(FP_BUILTINS spec);
	void			UnLock();
	void			GetShellFolder(LPCTSTR folder);

	CString			m_drive,
					m_path,
					m_fileName,
					m_ext;
};

#endif	// ~__FILENAME_PARSER_H__
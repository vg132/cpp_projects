// JamFilePreview.h - header file for the CJamFilePreview class
//

#ifndef __JAM_FILE_PREVIEW_H__
#define __JAM_FILE_PREVIEW_H__

#include "ImageFilePreview.h"

class CJam;

/////////////////////////////////////////////////////////////////
// Class:	CJamFilePreview
// Base:	CImageFilePreview (abstract)
// Created:	28 March 1999 by Mal Ross
// Overview:
//    A class used to display a preview of a Jam or Jad file
//  in a given DC.  This is intended for use in the Jam Editor's
//  Open File dialog.
//

class CJamFilePreview : public CImageFilePreview
{
	DECLARE_DYNAMIC(CJamFilePreview)

// Construction/destruction
public:
	CJamFilePreview();
	virtual ~CJamFilePreview();

	// Cloning function
	virtual CFilePreview* CreateNewPreview() const;

// Attributes
protected:
	// The bitmap we're previewing
	CJam* m_pJam;

// Operations
public:
	// Information retrieval
	CJam* GetJam() const { return m_pJam; }
	virtual UINT GetImageWidth() const;
	virtual UINT GetImageHeight() const;
	virtual void GetSupportedFileTypes (CStringList& lstFileTypes) const;

// Implementation
protected:
	// Draw the image at 1:1 zoom in the given DC (and at its origin)
	virtual BOOL DrawImageOneToOne(CDC* pDC) const;

	// Loading the file.  Derived classes must override this as
	// they're the only ones who know the format of the file.
	virtual BOOL LoadFile (const CString& strFilename);
	virtual void UnloadFile ();
};

/////////////////////////////////////////////////////////////////

#endif	// ~__JAM_FILE_PREVIEW_H__


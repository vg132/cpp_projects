// SetBuilderView.h : interface of the CSetBuilderView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SETBUILDERVIEW_H__D9C121D5_62E2_4128_B28F_77368DD08915__INCLUDED_)
#define AFX_SETBUILDERVIEW_H__D9C121D5_62E2_4128_B28F_77368DD08915__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "SetHandler.h"

class CSetBuilderView : public CFormView
{
protected: // create from serialization only
	CSetBuilderView();
	DECLARE_DYNCREATE(CSetBuilderView)

public:
	//{{AFX_DATA(CSetBuilderView)
	enum { IDD = IDD_SETBUILDER_FORM };
	CListCtrl	m_TrackList;
	//}}AFX_DATA

// Attributes
public:
	CSetBuilderDoc* GetDocument();

	CString szFile;
	CString szFileTitle;
	CSetHandler TrackSetHandler;
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSetBuilderView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnPrint(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	void GetGp3Dir(char *cGp3Dir);
	void SetTitle(bool saved);
	void PaintListBox();
	virtual ~CSetBuilderView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CSetBuilderView)
	afx_msg void OnFileOpen();
	afx_msg void OnDblclkTrackList(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnFileSave();
	afx_msg void OnFileSaveAs();
	afx_msg void OnFileNew();
	afx_msg void OnKeydownTrackList(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnHelpVgsoftwareonline();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in SetBuilderView.cpp
inline CSetBuilderDoc* CSetBuilderView::GetDocument()
   { return (CSetBuilderDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SETBUILDERVIEW_H__D9C121D5_62E2_4128_B28F_77368DD08915__INCLUDED_)

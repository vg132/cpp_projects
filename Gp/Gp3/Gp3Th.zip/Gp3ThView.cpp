// Gp3ThView.cpp : implementation of the CGp3ThView class
//

#include "stdafx.h"
#include "Gp3Th.h"

#include "Gp3ThDoc.h"
#include "Gp3ThView.h"

#include "TrackData.h"
#include "CPreviewFileDialog.h"
#include "FileHandling.h"
#include "Export.h"
#include "Import.h"
#include "Language.h"
#include "Common.h"
#include "Points.h"
#include "MiscEdit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



/////////////////////////////////////////////////////////////////////////////
// CGp3ThView

IMPLEMENT_DYNCREATE(CGp3ThView, CFormView)

BEGIN_MESSAGE_MAP(CGp3ThView, CFormView)
	//{{AFX_MSG_MAP(CGp3ThView)
	ON_COMMAND(ID_OPTIONS_GRIDLINES, OnOptionsGridlines)
	ON_COMMAND(ID_OPTIONS_FULLROWSELECT, OnOptionsFullrowselect)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_GRIDLINES, OnUpdateOptionsGridlines)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_HOVERSELECT, OnUpdateOptionsHoverselect)
	ON_COMMAND(ID_OPTIONS_HOVERSELECT, OnOptionsHoverselect)
	ON_NOTIFY(NM_DBLCLK, IDC_TRACKLIST, OnDblclkTracklist)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_COMMAND(ID_FILE_EXPORT, OnFileExport)
	ON_NOTIFY(LVN_KEYDOWN, IDC_TRACKLIST, OnKeydownTracklist)
	ON_COMMAND(ID_MOVE_DOWN, OnMoveDown)
	ON_COMMAND(ID_MOVE_UP, OnMoveUp)
	ON_COMMAND(ID_FILE_IMPORT, OnFileImport)
	ON_COMMAND(ID_EDIT_SELECTGP3LANGUAGEFILE, OnEditSelectgp3languagefile)
	ON_COMMAND(ID_EDIT_SETTRACKPATH, OnEditSettrackpath)
	ON_COMMAND(ID_EDIT_GP3PATH, OnEditGp3path)
	ON_COMMAND(ID_TOOLS_POINTEDITOR, OnToolsPointeditor)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_FULLROWSELECT, OnUpdateOptionsFullrowselect)
	ON_COMMAND(ID_HELP_ONLINE_F1GRANDPRIX3NET, OnHelpOnlineF1grandprix3net)
	ON_COMMAND(ID_HELP_ONLINE_GRANDPRIX1COM, OnHelpOnlineGrandprix1com)
	ON_COMMAND(ID_HELP_ONLINE_GRANDPRIX2COM, OnHelpOnlineGrandprix2com)
	ON_COMMAND(ID_HELP_ONLINE_VGSOFTWARE, OnHelpOnlineVgsoftware)
	ON_COMMAND(ID_TOOLS_MISCEDITOR, OnToolsMisceditor)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGp3ThView construction/destruction

CGp3ThView::CGp3ThView()
	: CFormView(CGp3ThView::IDD)
{
	//{{AFX_DATA_INIT(CGp3ThView)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CGp3ThView::~CGp3ThView()
{
	DeleteFile(m_TempFile);
}

void CGp3ThView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGp3ThView)
	DDX_Control(pDX, IDC_TRACKLIST, m_TrackList);
	//}}AFX_DATA_MAP
}

BOOL CGp3ThView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CGp3ThView::OnInitialUpdate()
{
DWORD exStyle=0;
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

	GridLine=true;
	FullRow=true;
	HoverSelect=false;

	exStyle=LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES;
	m_TrackList.SetExtendedStyle(exStyle);

	if(NewFile())
		ShowFile(m_TempFile);
	else
		ShowFile("");

	
	m_Gp3Path=m_Common.RegGetValue(HKEY_CURRENT_USER,"Software\\VG Software\\Gp3 Track Handler\\Settings","Gp3Path");
	if(m_Gp3Path=="")
	{
		m_Gp3Path=m_Common.RegGetValue(HKEY_LOCAL_MACHINE,"Software\\Microprose\\Grand Prix 3\\3.00.000\\Install Dir","Directory");
		if(m_Gp3Path=="")
			OnEditGp3path();
		else
		{
			if(m_Gp3Path.Right(1)=="\\")
				m_Gp3Path=m_Gp3Path.Left(m_Gp3Path.GetLength()-1);
			m_Common.RegSaveValue(HKEY_CURRENT_USER,"Software\\VG Software\\Gp3 Track Handler\\Settings","Gp3Path",m_Gp3Path);
		}
	}
	m_TrackPath=m_Common.RegGetValue(HKEY_CURRENT_USER,"Software\\VG Software\\Gp3 Track Handler\\Settings","TrackPath");
	if(m_Common.RegGetValue(HKEY_CURRENT_USER,"Software\\VG Software\\Gp3 Track Handler\\Settings","Language")=="")
	{
		OnEditSelectgp3languagefile();
	}
}

/////////////////////////////////////////////////////////////////////////////
// CGp3ThView diagnostics

#ifdef _DEBUG
void CGp3ThView::AssertValid() const
{
	CFormView::AssertValid();
}

void CGp3ThView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CGp3ThDoc* CGp3ThView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGp3ThDoc)));
	return (CGp3ThDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGp3ThView message handlers

void CGp3ThView::OnOptionsGridlines() 
{
DWORD exStyle=0;
	if(GridLine==true)
		GridLine=false;
	else
		GridLine=true;

	if(FullRow==true)
		exStyle=(LVS_EX_FULLROWSELECT);
	if(GridLine==true)
		exStyle|=(LVS_EX_GRIDLINES);
	if(HoverSelect==true)
		exStyle|=(LVS_EX_TRACKSELECT);
	m_TrackList.SetExtendedStyle(exStyle);
}

void CGp3ThView::OnUpdateOptionsGridlines(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(GridLine);
}

void CGp3ThView::OnOptionsFullrowselect() 
{
	// TODO: Add your command handler code here
DWORD exStyle=0;
	if(FullRow==true)
		FullRow=false;
	else
		FullRow=true;

	if(FullRow==true)
		exStyle=(LVS_EX_FULLROWSELECT);
	if(GridLine==true)
		exStyle|=(LVS_EX_GRIDLINES);
	if(HoverSelect==true)
		exStyle|=(LVS_EX_TRACKSELECT);
	m_TrackList.SetExtendedStyle(exStyle);
}

void CGp3ThView::OnUpdateOptionsFullrowselect(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(FullRow);
}

void CGp3ThView::OnOptionsHoverselect() 
{
	// TODO: Add your command handler code here
DWORD exStyle=0;
	if(HoverSelect==true)
		HoverSelect=false;
	else
		HoverSelect=true;

	if(FullRow==true)
		exStyle=(LVS_EX_FULLROWSELECT);
	if(GridLine==true)
		exStyle|=(LVS_EX_GRIDLINES);
	if(HoverSelect==true)
		exStyle|=(LVS_EX_TRACKSELECT);
	m_TrackList.SetExtendedStyle(exStyle);
}

void CGp3ThView::OnUpdateOptionsHoverselect(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->SetCheck(HoverSelect);
}
void CGp3ThView::OnDblclkTracklist(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here


	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	m_CurItem=((NM_LISTVIEW *)pNMHDR)->iItem;

	fh.Load(m_TempFile,m_CurItem);
	if(fh.GetFileName()=="")
		AddFile(m_CurItem);
	else
		ShowTrack(m_CurItem);
	*pResult = 0;
}

void CGp3ThView::OnFileOpen() 
{
CString szFile;
char BASED_CODE szFilter[] = "Gp3 Track Handler Files (*.thf)|*.thf|All Files (*.*)|*.*||";
CFileDialog fd(TRUE,
			   "thf",
			   NULL,
			   OFN_FILEMUSTEXIST|OFN_EXTENSIONDIFFERENT|
			   OFN_OVERWRITEPROMPT|OFN_HIDEREADONLY,
			   szFilter,
			   NULL);
	
	fd.DoModal();
	szFile=fd.m_ofn.lpstrFile;
	if(szFile!="")
	{
		NewFile();
		CopyFile(szFile,m_TempFile,FALSE);
		m_CurFile=szFile;
	}
	ShowFile(m_TempFile);
}

bool CGp3ThView::AddFile(int trackNr)
{
CGp3FileInfo fi;
CPreviewFileDialog pfd(TRUE,m_TrackPath);
CString szTmp;

	pfd.DoModal();
	m_TrackPath="";
	szTmp=pfd.m_ofn.lpstrFile;
	if(szTmp!="")
	{
		if(fi.LoadInfo(szTmp))
		{
			fh.SetCountry(fi.GetCountry());
			fh.SetAdjective(FindAdjective(fi.GetCountry()));
			fh.SetName(fi.GetName());
			fh.SetFileName(pfd.m_ofn.lpstrFile);
			fh.SetLaps(fi.GetLaps());
			fh.SetLen(fi.GetLength());
			fh.SetTyreWare(fi.GetWare());
			fh.SetRaceTime(fi.GetRaceRec());
			fh.SetQualTime(fi.GetQualRec());
			fh.Save(m_TempFile,trackNr);
		}
		ShowFile(m_TempFile);
		return(true);
	}
	return(false);
}

void CGp3ThView::ShowTrack(int track)
{
CTrackData td;
	td.tracknr=track;
	td.m_TempFile=m_TempFile;
	td.DoModal();
	ShowFile(m_TempFile);
}

void CGp3ThView::ShowFile(CString file)
{
int nItem;
POSITION pos=m_TrackList.GetFirstSelectedItemPosition();
	if(pos!=NULL)
		nItem=m_TrackList.GetNextSelectedItem(pos);

	m_TrackList.DeleteAllItems();
	for(int cm=0;cm<6;cm++)
		m_TrackList.DeleteColumn(0);
	
	m_TrackList.InsertColumn(0,"Nr",LVCFMT_LEFT,25,-1);
	m_TrackList.InsertColumn(1,"Track Name",LVCFMT_LEFT,100,-1);
	m_TrackList.InsertColumn(2,"Country",LVCFMT_LEFT,100,-1);
	m_TrackList.InsertColumn(3,"Laps",LVCFMT_LEFT,50,-1);
	m_TrackList.InsertColumn(4,"Length (m)",LVCFMT_LEFT,80,-1);
	m_TrackList.InsertColumn(5,"Tyre Ware",LVCFMT_LEFT,80,-1);

	CString szNr;
	char c[1];
	for(int i=0;i<16;i++)
	{
		itoa(i+1,c,10);
		m_TrackList.InsertItem(i,c,NULL);
		if(file!="")
		{
			fh.Load(file,i);
			m_TrackList.SetItem(i,1,LVIF_TEXT ,fh.GetName(),NULL,NULL,NULL,NULL);
			m_TrackList.SetItem(i,2,LVIF_TEXT ,fh.GetCountry(),NULL,NULL,NULL,NULL);
			m_TrackList.SetItem(i,3,LVIF_TEXT ,fh.GetLaps(),NULL,NULL,NULL,NULL);
			m_TrackList.SetItem(i,4,LVIF_TEXT ,fh.GetLen(),NULL,NULL,NULL,NULL);
			m_TrackList.SetItem(i,5,LVIF_TEXT, fh.GetTyreWare(),NULL,NULL,NULL,NULL);
		}
		else
		{
			m_TrackList.SetItem(i,1,LVIF_TEXT ,"-No Track-",NULL,NULL,NULL,NULL);
			m_TrackList.SetItem(i,2,LVIF_TEXT ,"-No Country-",NULL,NULL,NULL,NULL);
			m_TrackList.SetItem(i,3,LVIF_TEXT ,"",NULL,NULL,NULL,NULL);
			m_TrackList.SetItem(i,4,LVIF_TEXT ,"",NULL,NULL,NULL,NULL);
			m_TrackList.SetItem(i,5,LVIF_TEXT,"",NULL,NULL,NULL,NULL);
		}
	}
	m_TrackList.SetItemState(nItem,TVIS_SELECTED ,TVIS_SELECTED );
}

bool CGp3ThView::NewFile()
{
char buf[260];
	GetTempPath(260,buf);
	GetTempFileName(buf,"gpt",0,buf);
	m_TempFile=buf;
	return(true);
}

void CGp3ThView::OnFileNew() 
{
	NewFile();
	ShowFile(m_TempFile);
}

void CGp3ThView::OnFileSaveAs() 
{
CString szFile;
char BASED_CODE szFilter[] = "Gp3 Track Handler Files (*.thf)|*.thf|All Files (*.*)|*.*||";
CFileDialog fd(FALSE,
			   "thf",
			   NULL,
			   OFN_FILEMUSTEXIST|OFN_EXTENSIONDIFFERENT|
			   OFN_OVERWRITEPROMPT|OFN_HIDEREADONLY,
			   szFilter,
			   NULL);
	
	fd.DoModal();
	szFile=fd.m_ofn.lpstrFile;
	if(szFile!="")
	{
		CopyFile(m_TempFile,szFile,FALSE);
		m_CurFile=szFile;
	}	
}
void CGp3ThView::OnFileSave() 
{
	if(m_CurFile!="")
		CopyFile(m_TempFile,m_CurFile,FALSE);
	else
		OnFileSaveAs();
}

void CGp3ThView::OnFileExport() 
{
CExport exp;
	if(m_Gp3Path!="")
	{
		exp.m_TempFile=m_TempFile;
		exp.m_Gp3Path=m_Gp3Path;
		exp.m_StrFile = m_Common.RegGetValue(HKEY_CURRENT_USER,"Software\\VG Software\\Gp3 Track Handler\\Settings","Language");
		if(exp.m_StrFile=="")
			MessageBox("You must first select a language file.","Gp3 Track Handler",NULL);
		else
			exp.DoModal();	
	}
	else
		MessageBox("Please select your Gp3 directory before you export.",NULL,MB_ICONINFORMATION);
}

void CGp3ThView::OnKeydownTracklist(NMHDR* pNMHDR, LRESULT* pResult) 
{
int nItem;
POSITION pos=m_TrackList.GetFirstSelectedItemPosition();
	if(pos==NULL)
		return;
	nItem=m_TrackList.GetNextSelectedItem(pos);

	LV_KEYDOWN* pLVKeyDow = (LV_KEYDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	int i=((LV_KEYDOWN*)pLVKeyDow)->wVKey;
	if(i==VK_DELETE)
	{
		fh.NewItem();
		fh.Save(m_TempFile,nItem);
		ShowFile(m_TempFile);
	}
	*pResult = 0;
}

CString CGp3ThView::FindAdjective(CString country)
{
	country.MakeLower();
	if(country=="argentine")
		return("Argentine");
	else if(country=="argentina")
		return("Argentine");
	else if(country=="australia")
		return("Australian");
	else if(country=="austria")
		return("Austrian");
	else if(country=="belgium")
		return("Belgian");
	else if(country=="brazil")
		return("Brazilian");
	else if(country=="great britain")
		return("British");
	else if(country=="england")
		return("British");
	else if(country=="canada")
		return("Canadian");
	else if(country=="china")
		return("Chinese");
	else if(country=="holland")
		return("Dutch");
	else if(country=="netherlands")
		return("Dutch");
	else if(country=="netherland")
		return("Dutch");
	else if(country=="europe")
		return("European");
	else if(country=="finland")
		return("Finnish");
	else if(country=="france")
		return("French");
	else if(country=="germany")
		return("German");
	else if(country=="hungary")
		return("Hungarian");
	else if(country=="italy")
		return("Italian");
	else if(country=="japan")
		return("Japanese");
	else if(country=="luxembourg")
		return("Luxembourg");
	else if(country=="luxembourg (germany)")
		return("Luxembourg");
	else if(country=="malysia")
		return("Malysian");
	else if(country=="malaysia")
		return("Malysian");
	else if(country=="mexico")
		return("Mexican");
	else if(country=="monaco")
		return("Monaco");
	else if(country=="mother earth")
		return("Mother Earth");
	else if(country=="pacific")
		return("Pacific");
	else if(country=="portugal")
		return("Portuguese");
	else if(country=="san marino")
		return("San Marino");
	else if(country=="south africa")
		return("South African");
	else if(country=="spain")
		return("Spanish");
	else if(country=="sweden")
		return("Swedish");
	else if(country=="schweiz")
		return("Swiss");
	else if(country=="switzerland")
		return("Swiss");
	else if(country=="usa")
		return("USA");
	else if(country=="america")
		return("USA");
	else if(country=="valhalla")
		return("Valhalla");
	else
		return("");
}

void CGp3ThView::OnMoveDown() 
{
CFileHandling tmpFh;
int nItem;
POSITION pos=m_TrackList.GetFirstSelectedItemPosition();
	if(pos==NULL)
		return;
	nItem=m_TrackList.GetNextSelectedItem(pos);
	if(nItem==15)
		return;
	tmpFh.Load(m_TempFile,nItem);
	fh.Load(m_TempFile,nItem+1);
	fh.Save(m_TempFile,nItem);
	fh.SetAdjective(tmpFh.GetAdjective());
	fh.SetCountry(tmpFh.GetCountry());
	fh.SetFileName(tmpFh.GetFileName());
	fh.SetLaps(tmpFh.GetLaps());
	fh.SetLen(tmpFh.GetLen());
	fh.SetName(tmpFh.GetName());
	fh.SetQualDate(tmpFh.GetQualDate());
	fh.SetQualDriver(tmpFh.GetQualDriver());
	fh.SetQualTeam(tmpFh.GetQualTeam());
	fh.SetQualTime(tmpFh.GetQualTime());
	fh.SetRaceDate(tmpFh.GetRaceDate());
	fh.SetRaceDriver(tmpFh.GetRaceDriver());
	fh.SetRaceTeam(tmpFh.GetRaceTeam());
	fh.SetRaceTime(tmpFh.GetRaceTime());
	fh.SetTyreWare(tmpFh.GetTyreWare());
	fh.Save(m_TempFile,nItem+1);
	m_TrackList.SetItemState(nItem+1,TVIS_SELECTED ,TVIS_SELECTED );
	ShowFile(m_TempFile);
}

void CGp3ThView::OnMoveUp() 
{
CFileHandling tmpFh;
int nItem;
POSITION pos=m_TrackList.GetFirstSelectedItemPosition();
	if(pos==NULL)
		return;
	nItem=m_TrackList.GetNextSelectedItem(pos);
	if(nItem==0)
		return;
	tmpFh.Load(m_TempFile,nItem);
	fh.Load(m_TempFile,nItem-1);
	fh.Save(m_TempFile,nItem);
	fh.SetAdjective(tmpFh.GetAdjective());
	fh.SetCountry(tmpFh.GetCountry());
	fh.SetFileName(tmpFh.GetFileName());
	fh.SetLaps(tmpFh.GetLaps());
	fh.SetLen(tmpFh.GetLen());
	fh.SetName(tmpFh.GetName());
	fh.SetQualDate(tmpFh.GetQualDate());
	fh.SetQualDriver(tmpFh.GetQualDriver());
	fh.SetQualTeam(tmpFh.GetQualTeam());
	fh.SetQualTime(tmpFh.GetQualTime());
	fh.SetRaceDate(tmpFh.GetRaceDate());
	fh.SetRaceDriver(tmpFh.GetRaceDriver());
	fh.SetRaceTeam(tmpFh.GetRaceTeam());
	fh.SetRaceTime(tmpFh.GetRaceTime());
	fh.SetTyreWare(tmpFh.GetTyreWare());
	fh.Save(m_TempFile,nItem-1);
	m_TrackList.SetItemState(nItem-1,TVIS_SELECTED ,TVIS_SELECTED );
	ShowFile(m_TempFile);
}

void CGp3ThView::OnFileImport() 
{
CImport imp;
	if(m_Gp3Path!="")
	{
		imp.m_TempFile =m_TempFile;
		imp.m_Gp3Path=m_Gp3Path;
		imp.m_StrFile = m_Common.RegGetValue(HKEY_CURRENT_USER,"Software\\VG Software\\Gp3 Track Handler\\Settings","Language");
		if(imp.m_StrFile=="")
			MessageBox("Please select your Language file before you import.",NULL,MB_ICONINFORMATION);
		else
			imp.DoModal();
		ShowFile(m_TempFile);
	}
	else
		MessageBox("Please select your Gp3 directory before you import.",NULL,MB_ICONINFORMATION);
}

void CGp3ThView::OnEditSelectgp3languagefile() 
{
CLanguage l;
	l.m_Gp3Path =m_Gp3Path;
	l.DoModal();	
}

void CGp3ThView::OnEditSettrackpath() 
{
CString szTmp;
	szTmp=m_Common.BrowseForFolders("Default Track Path",m_hWnd);
	if(szTmp!="")
	{
		m_TrackPath=szTmp;
		m_Common.RegSaveValue(HKEY_CURRENT_USER,"Software\\VG Software\\Gp3 Track Handler\\Settings","TrackPath",m_TrackPath);
	}
}

void CGp3ThView::OnEditGp3path() 
{
CString szTmp;
WIN32_FIND_DATA wfd;
HANDLE hFile;

	szTmp=m_Common.BrowseForFolders("Select your Gp3 directory",m_hWnd);
	if(szTmp!="")
	{
		if(szTmp.Right(1)=="\\")
			szTmp=szTmp.Left(szTmp.GetLength()-1);
		hFile=FindFirstFile(szTmp+"\\gp3.exe",&wfd);
		if(hFile!=(HANDLE)-1)
		{
			m_Gp3Path=szTmp;
			m_Common.RegSaveValue(HKEY_CURRENT_USER,"Software\\VG Software\\Gp3 Track Handler\\Settings","Gp3Path",m_Gp3Path);
		}
		else
		{
			MessageBox("Gp3.exe was not found in this directory, please select your Grand Prix 3 directory.",NULL,MB_ICONINFORMATION);
			OnEditGp3path();
		}
	}
}

void CGp3ThView::OnToolsPointeditor() 
{
CPoints p;
	p.m_TempFile=m_TempFile;
	p.DoModal();
}

void CGp3ThView::OnHelpOnlineF1grandprix3net() 
{
	ShellExecute(m_hWnd,"open","http://www.f1-grandprix3.net/",NULL,NULL,1);
}

void CGp3ThView::OnHelpOnlineGrandprix1com() 
{
	ShellExecute(m_hWnd,"open","http://www.grandprix1.com/",NULL,NULL,1);
}

void CGp3ThView::OnHelpOnlineGrandprix2com() 
{
	ShellExecute(m_hWnd,"open","http://www.grandprix2.com/",NULL,NULL,1);
}

void CGp3ThView::OnHelpOnlineVgsoftware() 
{
	ShellExecute(m_hWnd,"open","http://www.vgsoftware.com/",NULL,NULL,1);
}

void CGp3ThView::OnToolsMisceditor() 
{
CMiscEdit me;
	me.m_TempFile = m_TempFile;
	me.DoModal();
}

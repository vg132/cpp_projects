// PreviewFileDialog.h : header file
//

#ifndef _PREVIEW_FILE_DIALOG_H_
#define _PREVIEW_FILE_DIALOG_H_

#include "FilePreviewStatic.h"

/////////////////////////////////////////////////////////////////////////////
// CPreviewFileDialog dialog

class CPreviewFileDialog : public CFileDialog
{
	DECLARE_DYNAMIC(CPreviewFileDialog)

// Constructors
public:
	CPreviewFileDialog(BOOL bOpenFileDialog, // TRUE for FileOpen, FALSE for FileSaveAs
		LPCTSTR lpszDefExt = NULL,
		LPCTSTR lpszFileName = NULL,
		DWORD dwFlags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		LPCTSTR lpszFilter = NULL,
		CWnd* pParentWnd = NULL);
	~CPreviewFileDialog();

// Attributes
protected:
	// The static that acts as a preview window
	CFilePreviewStatic m_stcPreview;

	// A list of file extensions supported for preview
	// by this dialog
	CStringList m_lstPreviewableFileTypes;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTextureFlagsDlg)
	public:
	virtual int DoModal();
	//}}AFX_VIRTUAL

// Overridables
protected:
	// Specify the dialog template to use for the preview area
	virtual UINT GetPreviewTemplateID () const;

	// Determination of whether a given file can be previewed
	virtual BOOL IsPreviewableFile(const CString& strFileName) const;

// Implementation
protected:
	// Only called back if OFN_EXPLORER is set.  Generally, you
	// shouldn't need to override these.  If you want to intercept
	// changes to the preview, override SetPreviewFile instead,
	// but be sure to call the base class version first.
	virtual void OnFileNameChange();
	virtual void OnFolderChange();
	virtual void OnTypeChange();
	BOOL GetSingleFilterExtension(const int nFilterIndex, CString& strExtension);

	// Show a preview of the given file in the static.  This can
	// be overridden if you want to set other info in the dialog
	// as well as the preview.
	virtual BOOL SetPreviewFile(const CString& strFilename);

	// Internal checking - you shouldn't need to override this,
	// but feel free to call it.  Still, only once the dialog
	// has been created.
	BOOL IsPreviewInUse() const;

	// Determination of the file types that can be previewed by
	// this dialog - valid type are based on the filters
	void ParsePreviewableFileTypes();
	CString GetFiltersForParsing() const;
	BOOL GetFilterExtensions(CString strAllFilters, CStringList& lstFilterExtensions) const;

	//{{AFX_MSG(CPreviewFileDialog)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif	// ~_PREVIEW_FILE_DIALOG_H_

// TreeIconDefs.h - contains the #defines for the types of
//                  icon used in the Jam tree

#ifndef __TREE_ICON_DEFS_H__
#define __TREE_ICON_DEFS_H__

#define JTI_ROOT_NODE			0	// the root node ("All Jams")
#define JTI_JAM_FILE_UNK		1	// a value whose meaning is unknown
#define JTI_JAM_FILE			2	// a single jam file
#define JTI_JAM_TEXTURE_LIST	3	// a list of textures
#define JTI_JAM_TEXTURE			4	// a single texture
#define JTI_JAM_FILE_INFO		5	// any read-only info about a jam
#define JTI_IMAGE_LOCATION		6	// the top and left of a texture
#define JTI_IMAGE_SIZE			7	// the size of a texture
#define JTI_TEXTURE_PALETTE		8	// a texture's palette property
#define JTI_TEXTURE_FLAGS		9	// a binary flag-based property
#define JTI_TEXTURE_FLAG_ON		10	// a flag property that's set
#define JTI_TEXTURE_FLAG_OFF	11	// a flag property that's not set
#define JTI_TEXTURE_SCALING		12	// id5 object scaling values

#endif	// ~__TREE_ICON_DEFS_H__
// TexturePropertiesDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "TexturePropertiesDlg.h"

#include "JamTexture.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTexturePropertiesDlg dialog


CTexturePropertiesDlg::CTexturePropertiesDlg(CJamTexture* pTexture, CWnd* pParent /*=NULL*/)
	: CDialog(CTexturePropertiesDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTexturePropertiesDlg)
	m_nTextureID = 0;
	m_nLeft = 0;
	m_nHeight = 0;
	m_nTop = 0;
	m_nWidth = 0;
	//}}AFX_DATA_INIT

	// Set the texture member
	ASSERT(NULL != pTexture);
	m_pTexture = pTexture;
}


void CTexturePropertiesDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	if (!pDX->m_bSaveAndValidate)
		UpdateTexture(FALSE);

	//{{AFX_DATA_MAP(CTexturePropertiesDlg)
	DDX_Control(pDX, IDC_LIST_FLAGS, m_FlagListBox);
	DDX_Text(pDX, IDC_EDIT_TEXTURE_ID, m_nTextureID);
	DDX_Text(pDX, IDC_LEFT, m_nLeft);
	DDV_MinMaxByte(pDX, m_nLeft, 0, 255);
	DDX_Text(pDX, IDC_HEIGHT, m_nHeight);
	DDV_MinMaxUInt(pDX, m_nHeight, 1, 256);
	DDX_Text(pDX, IDC_TOP, m_nTop);
	DDV_MinMaxByte(pDX, m_nTop, 0, 255);
	DDX_Text(pDX, IDC_WIDTH, m_nWidth);
	DDV_MinMaxUInt(pDX, m_nWidth, 1, 256);
	//}}AFX_DATA_MAP

	if (pDX->m_bSaveAndValidate)
		UpdateTexture(TRUE);
}


BEGIN_MESSAGE_MAP(CTexturePropertiesDlg, CDialog)
	//{{AFX_MSG_MAP(CTexturePropertiesDlg)
	ON_CBN_SELCHANGE(IDC_DISPLAY_USING_LIST, OnSelectDisplayType)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTexturePropertiesDlg message handlers

#define DISPLAY_USING_NAMES		0
#define DISPLAY_USING_DECIMAL	1
#define DISPLAY_USING_HEX		2
#define DISPLAY_USING_BIN		3

BOOL CTexturePropertiesDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// Initialise the checklistbox
	((CComboBox *)GetDlgItem(IDC_DISPLAY_USING_LIST))->SetCurSel(DISPLAY_USING_NAMES);
	OnSelectDisplayType();
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CTexturePropertiesDlg::UpdateTexture(const BOOL bSaveAndValidate, const BOOL bFlagsOnly)
{
	// Only need to do anything if we're actually showing a
	// texture
	if (NULL == m_pTexture)
		return;

	if (!::IsWindow(m_FlagListBox.m_hWnd))
		return;

	if (bSaveAndValidate)
	{
		// Taking the values in the list and putting them
		// into the texture
		int nFlagCount = m_FlagListBox.GetCount();
		for (int nFlagNum = 0; nFlagNum < nFlagCount; nFlagNum++)
			m_pTexture->SetFlag(TF_FIRST_FLAG + nFlagNum, (m_FlagListBox.GetCheck(nFlagNum) != 0));

		// Also, set the other texture properties (ID, etc.)
		if (!bFlagsOnly)
		{
			m_pTexture->SetTextureID(m_nTextureID);
			m_pTexture->SetSize((WORD)m_nWidth, (WORD)m_nHeight);
			m_pTexture->SetTop(m_nTop);
			m_pTexture->SetLeft(m_nLeft);
		}
	}
	else
	{
		// Taking the values in the texture and putting them
		// into the list
		if (m_FlagListBox.GetCount() > 0)
		{
			for (int nFlagNum = TF_FIRST_FLAG; nFlagNum <= TF_LAST_FLAG; nFlagNum++)
				m_FlagListBox.SetCheck(nFlagNum - TF_FIRST_FLAG, m_pTexture->IsFlagSet(nFlagNum) ? 1 : 0);
		}

		// Also, get the texture ID
		if (!bFlagsOnly)
		{
			m_nTextureID = m_pTexture->GetTextureID();
			m_nWidth = m_pTexture->GetWidth();
			m_nHeight = m_pTexture->GetHeight();
			m_nTop = m_pTexture->GetTop();
			m_nLeft = m_pTexture->GetLeft();
		}
	}
}


// The user has selected 
void CTexturePropertiesDlg::OnSelectDisplayType() 
{
	// Only need to do anything if we're actually
	// showing a texture's properties
	if (NULL == m_pTexture)
		return;

	// Get the selection from the combo
	CComboBox* pDisplayAsCombo = (CComboBox *)GetDlgItem(IDC_DISPLAY_USING_LIST);
	ASSERT(NULL != pDisplayAsCombo);
	if (NULL == pDisplayAsCombo)
		return;
	int nDisplayType = pDisplayAsCombo->GetCurSel();

	// Store the texture's current flags as we're going to need
	// to overwrite them during this change
	WORD wTextureFlags = m_pTexture->GetFlags();

	// Put all of the flags as set in the dialog into the
	// texture
	UpdateTexture(TRUE, TRUE);	// *only* the flags

	// Clear the list now that we've made a note of the flag
	// settings in it, and refill it using the new strings
	CString strFlagName("");
	m_FlagListBox.ResetContent();
	for (int nFlagNum = TF_FIRST_FLAG; nFlagNum <= TF_LAST_FLAG; nFlagNum++)
	{
		switch (nDisplayType)
		{
		case DISPLAY_USING_NAMES:
			strFlagName.LoadString(IDS_TEXTURE_FLAG_NAME1 + (nFlagNum - TF_FIRST_FLAG));
			break;
		case DISPLAY_USING_DECIMAL:
			strFlagName.Format("%d", CJamTexture::FlagNumToMask(nFlagNum));
			break;
		case DISPLAY_USING_HEX:
			strFlagName.Format("%#x", CJamTexture::FlagNumToMask(nFlagNum));
			break;
		case DISPLAY_USING_BIN:
			{
				char name[TF_LAST_FLAG+1];
				memset(name, (int)'0', TF_LAST_FLAG);
				name[TF_LAST_FLAG]=0;	// LAST CHAR of string

				// insert a one
				name[TF_LAST_FLAG - nFlagNum]='1';

				strFlagName=name;

			}
			break;
		}
		m_FlagListBox.AddString(strFlagName);
	}
	// Reset the flags as they were last set in the dialog
	UpdateTexture(FALSE, TRUE);	// *only* the flags

	// Reinstate the texture's current flags in case the user cancels
	m_pTexture->SetFlags(wTextureFlags);
}

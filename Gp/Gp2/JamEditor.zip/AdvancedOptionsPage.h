// AdvancedOptionsPage.h : header file
//

#ifndef _ADVANCED_OPTIONS_PAGE_H_
#define _ADVANCED_OPTIONS_PAGE_H_

/////////////////////////////////////////////////////////////////////////////
// CAdvancedOptionsPage dialog

class CAdvancedOptionsPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CAdvancedOptionsPage)

// Construction
public:
	CAdvancedOptionsPage();
	~CAdvancedOptionsPage();

// Dialog Data
	//{{AFX_DATA(CAdvancedOptionsPage)
	enum { IDD = IDD_OPTIONS_ADVANCED };
	CSliderCtrl	m_sdrSpreadFactor;
	CString	m_strSpreadFactor;
	BOOL	m_bProtectTransparency;
	BOOL	m_bGuessTransparency;
	BOOL	m_bGuessNonStandardSizeFlags;
	int		m_nClusterProtection;
	BOOL	m_bGuessNoPalettes;
	//}}AFX_DATA

	// Texture spread factor
	int m_nSpreadFactor;

// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CAdvancedOptionsPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Texture spread factor
	void EnableSpreadFactor(const BOOL bEnable = TRUE);
	void UpdateSpreadFactorText();

	// Generated message map functions
	//{{AFX_MSG(CAdvancedOptionsPage)
	virtual BOOL OnInitDialog();
	afx_msg void OnProtectTransparency();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	virtual void OnOK();
	afx_msg void OnChangeOption();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////

#endif	// !_ADVANCED_OPTIONS_PAGE_H_


// FlagsDialog.h: header file for the CFlagsDialog class
//

#ifndef __FLAGS_DIALOG_H__
#define __FLAGS_DIALOG_H__

#include "FlagsDialogBase.h"

/////////////////////////////////////////////////////////////////////////////
// CFlagsDialog dialog

// NOTE:
//   This is only intended to be a temporary class.  Once the new
//   tree format has been coded (whereby the flags are a sub-list
//   of the main Flags node), this dialog will no longer be used.
//   Therefore, I'm going to let myself off with the code repetition
//   herein. :)  MR 21/03/99
//
//   Well, well, well.  That didn't happen, did it children? ;)  I'm
//   now making the original CTextureFlagsDlg class into a template
//   class able to set flags in any type of flag variable (BYTE, WORD,
//   whatever).  This is because we now believe there to be a BYTE
//   flag in the scaling section.  MR 20/02/00

template <class NUMTYPE>
class CFlagsDialog : public CFlagsDialogBase
{
// Construction
public:
	CFlagsDialog(CWnd* pParent = NULL) : CFlagsDialogBase(pParent) {}   // standard constructor

	// A copy of the flags being edited in this dialog
	NUMTYPE m_nFlags;

// Overrides
protected:
	// Return the first and last bit positions at
	// which the flags are located.
	virtual int GetFirstFlagPosition() const { return 1; }
	virtual int GetLastFlagPosition() const { return (sizeof(NUMTYPE) * 8); }

	// Updating the flags member
	virtual BOOL IsFlagSet(const int& nFlagID) const;
	virtual void SetFlag(const int& nFlagID, const BOOL bOn);
};


/////////////////////////////////////////////////////////////////////////////
// Get/set the flags

template <class NUMTYPE>
BOOL CFlagsDialog<NUMTYPE>::IsFlagSet(const int& nFlagID) const
{
	// Check to make sure the flag ID is valid
	if (nFlagID < GetFirstFlagPosition() ||
		nFlagID > GetLastFlagPosition())
		return FALSE;

	// Calculate the required mask and check m_wFlags
	NUMTYPE nMask = NUMTYPE(1 << (nFlagID - 1));
	return ((m_nFlags & nMask) == nMask);
}

template <class NUMTYPE>
void CFlagsDialog<NUMTYPE>::SetFlag(const int& nFlagID, const BOOL bOn)
{
	// Check to make sure the flag ID is valid
	if (nFlagID < GetFirstFlagPosition() ||
		nFlagID > GetLastFlagPosition())
		return;

	// Calculate the required mask and set/unset
	// it in m_wFlags
	NUMTYPE nMask = NUMTYPE(1 << (nFlagID - 1));
	if (bOn)
		m_nFlags |= nMask;
	else
		m_nFlags &= ~nMask;
}


/////////////////////////////////////////////////////////////////////////////

#endif	// ~__FLAGS_DIALOG_H__

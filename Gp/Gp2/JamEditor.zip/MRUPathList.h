// MRUPathList.h - header file for the CMRUPathList class
//

#ifndef _MRU_PATH_LIST_H_
#define _MRU_PATH_LIST_H_

///////////////////////////////////////////////////////////////
// Class:	CMRUPathList
// Base:	[none]
// Overview:
//    A class to store the path of the most-recently-used (MRU)
//  file for various types of file operation (e.g. File Open and
//  File Save).  Includes functions to load/save these settings
//  to/from the application's INI file.
//

class CMRUPathList
{
// Construction/destruction
public:
	CMRUPathList();
	virtual ~CMRUPathList();

// Data members
protected:
	// The table of operation types and their MRU paths
	CMapStringToString m_MRUPaths;

	// The only instance of this class allowed
	static CMRUPathList* m_pUniqueInstance;

// Operations
public:
	// Creation/destruction of the single instance
	static CMRUPathList* GetPathList();
	static void DestroyPathList();

	// Get/Set the MRU paths
	void SetMRUPath(const CString& strOperationType, const CString& strPath);
	CString GetMRUPath(const CString& strOperationType) const;

	// Load from / save to the INI file
	void StoreProfileSettings() const;
	void LoadProfileSettings();
};

///////////////////////////////////////////////////////////////

#endif	// ~_MRU_PATH_LIST_H_


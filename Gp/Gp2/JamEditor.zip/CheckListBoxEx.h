// CheckListBoxEx.h : header file
//

#ifndef __CHECKLISTBOX_EX_H__
#define __CHECKLISTBOX_EX_H__

/////////////////////////////////////////////////////////////////////////////
// CCheckListBoxEx window

class CCheckListBoxEx : public CCheckListBox
{
// Construction
public:
	CCheckListBoxEx();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCheckListBoxEx)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCheckListBoxEx();

	// Generated message map functions
protected:
	//{{AFX_MSG(CCheckListBoxEx)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif	// ~__CHECKLISTBOX_EX_H__

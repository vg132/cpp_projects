// FilePreview.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "FilePreview.h"

#include "FilenameParser.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFilePreview

IMPLEMENT_DYNAMIC(CFilePreview, CObject)

CFilePreview::CFilePreview()
{
	// Just initialise the preview to indicate that no filename
	// has yet been set
	m_bIsValidFile = FALSE;
	m_strFilename.Empty();
}

CFilePreview::~CFilePreview()
{
	// It would be pointless to put a call to UnloadFile() in here
	// because virtual functions don't work in the usual way during
	// construction and destruction.  Therefore, just make sure you
	// do the proper tidy-up in your own class's destructor.
}



// Getting/setting the name of the file to preview
//

// Function:	SetFilename(strFilename)
// Overview:	Set the name of the file to be previewed.  If the file
//				is of the correct type, the m_strFilename member will
//				be updated and the file will be loaded.
BOOL CFilePreview::SetFilename (const CString& strFilename)
{
	// Check to see whether this file type is supported
	if (!IsSupportedFileType(strFilename))
		return FALSE;

	// Clear out the current file's data
	UnloadFile();

	// Attempt to load the file.  Even if we can't load it, we'll
	// still say the file was successfully assigned to this preview
	m_strFilename = strFilename;
	m_bIsValidFile = LoadFile(m_strFilename);

	return TRUE;
}
// End of function 'SetFilename'


// Function:	GetFilename()
// Overview:	Just get the name of the file being previewed
CString CFilePreview::GetFilename () const
{
	return m_strFilename;
}
// End of function 'GetFilename'


// Function:	UnloadFile()
// Overview:	Clear out the current file's data.  Override this
//				function, but make sure you call the base class, too.
void CFilePreview::UnloadFile()
{
	m_bIsValidFile = FALSE;
	m_strFilename.Empty();
}
// End of function 'UnloadFile'


// Function:	IsSupportedFile(strFilename)
// Overview:	Check to see whether the given file is one that could be
//				loaded by this preview.  Return TRUE if it is, or FALSE
//				otherwise.
BOOL CFilePreview::IsSupportedFile(const CString& strFilename) const
{
	// Check to see whether the file type is in the list of
	// supported types
	CStringList lstSupportedTypes;
	GetSupportedFileTypes(lstSupportedTypes);	// override this

#ifdef _DEBUG
	// Just a quick check to see that you're returning the supported
	// file types in the correct format i.e. *including* the period.
	if (NULL != lstSupportedTypes.GetHeadPosition())
	{
		CString strTestType = lstSupportedTypes.GetHead();
		ASSERT((!strTestType.IsEmpty()) && (strTestType.Left(1) == "."));
	}
#endif

	// Cycle through the list of supported filename extensions,
	// checking each to see whether it matches that of the given
	// file.
	POSITION posFileType = lstSupportedTypes.GetHeadPosition();
	BOOL bSupported = FALSE;
	CFilenameParser fnFile(strFilename);
	while (NULL != posFileType && !bSupported)
		bSupported = fnFile.IsOfType(lstSupportedTypes.GetNext(posFileType));

	// Tidy up
	lstSupportedTypes.RemoveAll();

	return bSupported;
}
// End of function 'IsSupportedFile'


// Function:	IsSupportedFileType(strExtension)
// Overview:	Check to see whether the given file type is one that
//				could be loaded by this preview.  Return TRUE if it
//				is, or FALSE otherwise.
BOOL CFilePreview::IsSupportedFileType(const CString& strExtension) const
{
	// Just create a dummy filename and pass it to IsSupportedFile
	CFilenameParser fnTest("Untitled");
	fnTest.Extension() = strExtension;

	return IsSupportedFile(fnTest.GetFullSpec());
}
// End of function 'IsSupportedFileType'


// Function:	DrawMessage(pDC, rctDraw, strMessage)
// Overview:	Draw the given error message in the middle of the given DC
BOOL CFilePreview::DrawMessage(CDC* pDC, const CRect& rctDraw, const CString& strMessage) const
{
	// We need a valid DC to be able to draw
	ASSERT(NULL != pDC);
	if (NULL == pDC)
		return FALSE;

	// Blank the DC first, using the standard 3D color
	CBrush greyBrush(::GetSysColor(COLOR_3DFACE));
	pDC->FillRect(rctDraw, &greyBrush);
	greyBrush.DeleteObject();

	// Now put the text in there, centred and wrapped
	COLORREF oldTextColor = pDC->SetTextColor(::GetSysColor(COLOR_BTNTEXT));
	int oldBkMode = pDC->SetBkMode(TRANSPARENT);
	CFont* pFont = CFont::FromHandle((HFONT)GetStockObject(DEFAULT_GUI_FONT));
	CFont* pOldFont = pDC->SelectObject(pFont);
	CRect rctText(rctDraw);
	pDC->DrawText(strMessage, rctText, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_NOPREFIX);

	// Tidy up
	pDC->SelectObject(pOldFont);
	pDC->SetTextColor(oldTextColor);
	pDC->SetBkMode(oldBkMode);

	return TRUE;
}
// End of function 'DrawMessage'

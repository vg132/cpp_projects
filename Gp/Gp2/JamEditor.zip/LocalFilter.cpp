// LocalFilter.cpp - implementation of the CLocalFilter class
//

#include "stdafx.h"
#include "resource.h"

#include "LocalFilter.h"

#include "Color.h"
#include "ColorFunctions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CLocalFilter

// Constructor
CLocalFilter::CLocalFilter(const UINT& nFilterID, const UINT& nStringID)
	: CJamTextureFilter(nFilterID, nStringID)
{
	InitialiseMappings();
}

// Destructor
CLocalFilter::~CLocalFilter()
{
}


// Caching functions to speed up mapping of source colours
// to filtered colours

// Function:	InitialiseMappings()
// Overview:	Clear out any existing mappings from source colours to
//				filtered colours.  This function should be called by
//				derived classes any time their parameters are changed.
void CLocalFilter::InitialiseMappings()
{
	// Initialise the mappings
	memset(m_FilterMappings, GP2_TRANSPARENT_PALETTE_INDEX, GP2_PALETTE_SIZE);
}
// End of function 'InitialiseMappings'



// Overridden filtering functions
//

// Function:	CreateNextFilteredBitmap(pbSrcPixels, pbNewPixels, sizImage)
// Overview:	Overridden function to create each filtered image from the 
//				image created using the previous local palette.
BOOL CLocalFilter::CreateNextFilteredBitmap(const BYTE* pbSrcPixels, BYTE*& pbNewPixels, const CSize& sizImage)
{
	try
	{
		// Just take it one pixel at a time, filtering each as we go.
		int nPixelCount = sizImage.cx * sizImage.cy;
		for (int nPixelNum = 0; nPixelNum < nPixelCount; nPixelNum++)
			pbNewPixels[nPixelNum] = FilterSinglePixel(pbSrcPixels[nPixelNum]);
	}
	catch (CException* pExc)
	{
		// Just delete the exception and let the calling function
		// know that we failed
		ASSERT(FALSE);
		pExc->Delete();
		return FALSE;
	}

	// Success! :)
	return TRUE;
}
// End of function 'CreateNextFilteredBitmap'


// Function:	FilterSinglePixel(BYTE nPalIndex)
// Overview:	Filter the colour corresponding to the given
//				palette index and return the index of the colour
//				that best matches the result.
BYTE CLocalFilter::FilterSinglePixel(BYTE nPalIndex)
{
	// Special check for transparency colour - don't change it if
	// the user wants to protect transparent areas.
	if (s_bProtectTransparency &&
		nPalIndex == GP2_TRANSPARENT_PALETTE_INDEX)
		return GP2_TRANSPARENT_PALETTE_INDEX;

	// First check to see whether we've done this transition
	// before.  If we have, pass back the stored result.
	BYTE nNewIndex = m_FilterMappings[nPalIndex];
	if (nNewIndex != GP2_TRANSPARENT_PALETTE_INDEX)
		return nNewIndex;

	// Get the RGB value from the GP2 palette for this index
	COLORREF rgbInitial = RGB(g_jamPalette[nPalIndex].rgbRed,
							  g_jamPalette[nPalIndex].rgbGreen,
							  g_jamPalette[nPalIndex].rgbBlue);

	// Now do the conversion
	CColor color(rgbInitial);
	FilterColor(color);		// override this!

	// Next, convert back to RGB and find the nearest colour
	// to it in the GP2 palette
	RGBQUAD quadFinal;
	quadFinal.rgbRed = (BYTE)color.GetRed();
	quadFinal.rgbGreen = (BYTE)color.GetGreen();
	quadFinal.rgbBlue = (BYTE)color.GetBlue();
	quadFinal.rgbReserved = 0;
	nNewIndex = GetNearestColorIndex(quadFinal);

	// Before we give the new palette index back to the caller,
	// keep a record of this transition
	m_FilterMappings[nPalIndex] = nNewIndex;

	return nNewIndex;
}
// End of function 'FilterSinglePixel'



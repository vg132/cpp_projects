// JamTextureAnimation.h - header file for the CJamTextureAnimation class
//

#ifndef __JAM_TEXTURE_ANIMATION_H__
#define __JAM_TEXTURE_ANIMATION_H__

#include "PaletteImageSource.h"
#include "JamConstants.h"
#include "GP2Bitmap.h"

///////////////////////////////////////////////////////////////////
// Class:	CJamTextureAnimation
// Base:	CPaletteImageSource
// Created:	14Jan00 by Mal Ross
// Overview:
//    This class is a simple override of CPaletteImageSource to
//  give access to the 4 bitmaps specified by the user to use as
//  the 4 pallete-images of a given texture.
//

class CJamTextureAnimation : public CPaletteImageSource
{
// Construction and destruction
public:
	CJamTextureAnimation();
	virtual ~CJamTextureAnimation();

// Attributes
protected:
	// An array of bitmaps, loaded when SetFilenames is called.
	CGP2Bitmap m_arrBitmaps[NUM_LOCAL_PALETTES_PER_TEXTURE];
	CPixelBufferArray m_UnpaddedBuffers;
	CSize m_sizAnimation;

	// Have the bitmaps been loaded yet?
	BOOL m_bLoaded;

// Operations
public:
	// Set the files to use as the frames of the animation,
	// loading them into m_arrBitmaps
	BOOL SetFiles(const CStringList& lstFiles);

	// Get the size of the frames in the loaded animation
	CSize GetFrameSize() const { return m_sizAnimation; }

// Overrides
public:
	// The function to retrieve the pixel buffers to the four
	// bitmaps this object provides.
	virtual BOOL GetBitmaps(CPixelBufferArray& pixelBuffers, CSize& sizImage);
};

/////////////////////////////////////////////////////////////////////

#endif	// ~__JAM_TEXTURE_ANIMATION_H__

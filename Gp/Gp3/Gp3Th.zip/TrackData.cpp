// TrackData.cpp : implementation file
//

#include "stdafx.h"
#include "Gp3Th.h"
#include "TrackData.h"
#include "SimpleDate.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTrackData dialog


CTrackData::CTrackData(CWnd* pParent /*=NULL*/)
	: CDialog(CTrackData::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTrackData)
	m_Laps = 0;
	m_FilePath = _T("");
	m_Length = 0;
	m_Qual_Date = _T("");
	m_Qual_Driver = _T("");
	m_Qual_Team = _T("");
	m_Qual_Time = _T("");
	m_Race_Date = _T("");
	m_Race_Driver = _T("");
	m_Race_Team = _T("");
	m_Race_Time = _T("");
	m_Country = _T("");
	m_Name = _T("");
	m_Ware = 0;
	m_Adjective = _T("");
	//}}AFX_DATA_INIT
}


void CTrackData::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTrackData)
	DDX_Control(pDX, IDC_SPIN_TYREWARE, m_Spin_TyreWare);
	DDX_Control(pDX, IDC_SPIN_LENGTH, m_Spin_Length);
	DDX_Control(pDX, IDC_SPIN_LAPS, m_Spin_Laps);
	DDX_Text(pDX, IDC_LAPS, m_Laps);
	DDV_MinMaxInt(pDX, m_Laps, 3, 127);
	DDX_Text(pDX, IDC_FILEPATH, m_FilePath);
	DDV_MaxChars(pDX, m_FilePath, 260);
	DDX_Text(pDX, IDC_LENGTH, m_Length);
	DDV_MinMaxInt(pDX, m_Length, 0, 9999);
	DDX_Text(pDX, IDC_QUAL_DATE, m_Qual_Date);
	DDV_MaxChars(pDX, m_Qual_Date, 10);
	DDX_Text(pDX, IDC_QUAL_DRIVER, m_Qual_Driver);
	DDV_MaxChars(pDX, m_Qual_Driver, 23);
	DDX_Text(pDX, IDC_QUAL_TEAM, m_Qual_Team);
	DDV_MaxChars(pDX, m_Qual_Team, 13);
	DDX_Text(pDX, IDC_QUAL_TIME, m_Qual_Time);
	DDV_MaxChars(pDX, m_Qual_Time, 8);
	DDX_Text(pDX, IDC_RACE_DATE, m_Race_Date);
	DDV_MaxChars(pDX, m_Race_Date, 10);
	DDX_Text(pDX, IDC_RACE_DRIVER, m_Race_Driver);
	DDV_MaxChars(pDX, m_Race_Driver, 23);
	DDX_Text(pDX, IDC_RACE_TEAM, m_Race_Team);
	DDV_MaxChars(pDX, m_Race_Team, 13);
	DDX_Text(pDX, IDC_RACE_TIME, m_Race_Time);
	DDV_MaxChars(pDX, m_Race_Time, 8);
	DDX_Text(pDX, IDC_TRACKCOUNTRY, m_Country);
	DDV_MaxChars(pDX, m_Country, 30);
	DDX_Text(pDX, IDC_TRACKNAME, m_Name);
	DDV_MaxChars(pDX, m_Name, 30);
	DDX_Text(pDX, IDC_TYREWARE, m_Ware);
	DDV_MinMaxInt(pDX, m_Ware, 0, 65535);
	DDX_CBString(pDX, IDC_ADJECTIVE, m_Adjective);
	DDV_MaxChars(pDX, m_Adjective, 30);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTrackData, CDialog)
	//{{AFX_MSG_MAP(CTrackData)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTrackData message handlers

int CTrackData::DoModal() 
{
	// TODO: Add your specialized code here and/or call the base class
	GetDataFromFile();

	return CDialog::DoModal();
}

void CTrackData::GetDataFromFile()
{
CSimpleDate s("01/01/1978",1);

	//Load all date from the ini file and
	//calculate/format the date and time
	fh.Load(m_TempFile,tracknr);
	m_Adjective=(fh.GetAdjective());
	m_Country=fh.GetCountry();
	m_FilePath=fh.GetFileName();
	m_Laps=atoi(fh.GetLaps());
	m_Length=atoi(fh.GetLen());
	m_Ware=atoi(fh.GetTyreWare());
	m_Name=fh.GetName();
	if(fh.GetQualTime()!="")
		m_Qual_Time=s.GetTime(atoi(fh.GetQualTime()));
	m_Qual_Team=fh.GetQualTeam();
	m_Qual_Driver=fh.GetQualDriver();
	if(fh.GetQualDate()!="")
	{
		s.AddDays(atoi(fh.GetQualDate()));
		m_Qual_Date=s.GetFullDateString();
		s.SubtractDays(atoi(fh.GetQualDate()));
	}
	if(fh.GetRaceTime()!="")
		m_Race_Time=s.GetTime(atoi(fh.GetRaceTime()));
	m_Race_Team=fh.GetRaceTeam();
	m_Race_Driver=fh.GetRaceDriver();
	if(fh.GetRaceDate()!="")
	{
		s.AddDays(atoi(fh.GetRaceDate()));
		m_Race_Date=s.GetFullDateString();
	}
}

void CTrackData::OnOK() 
{
	// TODO: Add extra validation here
char buf[80];
CSimpleDate s;

	UpdateData(TRUE);
	fh.SetCountry(m_Country);
	fh.SetAdjective(m_Adjective);
	fh.SetFileName(m_FilePath);
	fh.SetLaps(itoa(m_Laps,buf,10));
	fh.SetLen(itoa(m_Length,buf,10));
	fh.SetTyreWare(itoa(m_Ware,buf,10));
	fh.SetName(m_Name);
	fh.SetQualTime(m_Qual_Time);
	fh.SetQualTeam(m_Qual_Team);
	fh.SetQualDriver(m_Qual_Driver);
	fh.SetQualDate(m_Qual_Date);
	fh.SetRaceTime(m_Race_Time);
	fh.SetRaceTeam(m_Race_Team);
	fh.SetRaceDriver(m_Race_Driver);


	s=CSimpleDate(m_Race_Date,1);
	itoa(s.GetDays(),buf,10);
	fh.SetRaceDate(buf);

	s=CSimpleDate(m_Qual_Date,1);
	itoa(s.GetDays(),buf,10);
	fh.SetQualDate(buf);

	fh.Save(m_TempFile,tracknr);

	CDialog::OnOK();
}

void CTrackData::SetSpin()
{
	m_Spin_Laps.SetRange(3,127);
	m_Spin_Length.SetRange(0,9999);
	m_Spin_TyreWare.SetRange32(0,65535);
}

BOOL CTrackData::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	SetSpin();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

// ImportAnimationDlg.h : header file
//

#ifndef __IMPORT_ANIMATION_DLG_H__
#define __IMPORT_ANIMATION_DLG_H__

#include "FilePreviewStatic.h"
#include "JamConstants.h"

/////////////////////////////////////////////////////////////////////////////
// CImportAnimationDlg dialog

class CImportAnimationDlg : public CDialog
{
// Construction
public:
	CImportAnimationDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CImportAnimationDlg)
	enum { IDD = IDD_IMPORT_ANIMATION };
	CFilePreviewStatic	m_stcPreview;
	int m_nCurrentFrameNum;	// 1-based
	//}}AFX_DATA

// Data members
public:
	// The height and width of the texture we're importing the
	// animation into
	UINT m_nReqWidth;
	UINT m_nReqHeight;

protected:
	// A structure for holding information about a single frame
	struct AnimationFrame
	{
		CString m_strFilename;
		CSize m_sizFrame;
	};

	// Details of the animation frames
	AnimationFrame m_Frames[NUM_LOCAL_PALETTES_PER_TEXTURE];
	UINT m_nFrameInterval;	// gap between frames in animation
	UINT m_nCycleInterval;	// gap between animations

// Operations
public:
	// Retrieval of the selected filenames
	void GetFilenames(CStringList& lstFilenames) const;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CImportAnimationDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void OnSelectFrame(const int nFrameIndex);

	// Generated message map functions
	//{{AFX_MSG(CImportAnimationDlg)
	afx_msg void OnSelectFrame1();
	afx_msg void OnSelectFrame2();
	afx_msg void OnSelectFrame3();
	afx_msg void OnSelectFrame4();
	virtual void OnOK();
	afx_msg void OnTimer(UINT nIDEvent);
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


#endif	// ~__IMPORT_ANIMATION_DLG_H__

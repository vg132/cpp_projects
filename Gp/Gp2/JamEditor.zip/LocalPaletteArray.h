// LocalPaletteArray.h - header file for the CLocalPaletteArray class
//

#ifndef __LOCAL_PALETTE_ARRAY_H__
#define __LOCAL_PALETTE_ARRAY_H__

///////////////////////////////////////////////////////////////////
// Class:	CLocalPaletteArray
// Base:	CTypedPtrArray<CPtrArray, BYTE*>
// Created:	07Feb99 by Mal Ross
// Overview:
//    This is used in the bitmap-filtering process for storing
//  the local palettes being produced.
//

class CLocalPaletteArray : public CTypedPtrArray<CPtrArray, BYTE*>
{
// Construction and destruction
public:
	CLocalPaletteArray();
	virtual ~CLocalPaletteArray();

// Attributes
public:
	// Should the palettes be deleted when this object is destroyed?
	BOOL m_bDeleteOnDestroy;

protected:
	// We need to keep track of the size of the palettes we
	// store, even if just for others to read
	UINT m_nPaletteSize;

// Operations
public:
	// Retrieval of the palette size
	UINT GetPaletteSize() const { return m_nPaletteSize; }

	// Create palettes of the given size
	BOOL CreatePalettes(const UINT& nPaletteSize);

// Implementation
protected:
	// Deletion of dynamically allocated palettes
	void DeletePalettes();
};

/////////////////////////////////////////////////////////////////////

#endif	// ~__LOCAL_PALETTE_ARRAY_H__

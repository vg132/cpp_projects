// Gp3ThView.h : interface of the CGp3ThView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_GP3THVIEW_H__759164CC_72EF_11D4_8FC7_0008C7636E27__INCLUDED_)
#define AFX_GP3THVIEW_H__759164CC_72EF_11D4_8FC7_0008C7636E27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FileHandling.h"
#include "Common.h"

class CGp3ThView : public CFormView
{
protected: // create from serialization only
	CGp3ThView();
	DECLARE_DYNCREATE(CGp3ThView)

public:
	//{{AFX_DATA(CGp3ThView)
	enum { IDD = IDD_GP3TH_FORM };
	CListCtrl	m_TrackList;
	//}}AFX_DATA
	
// Attributes
public:
	CGp3ThDoc* GetDocument();

// Operations
public:
	CString m_CurFile;
	CString m_TempFile;
	CString m_Gp3Path;
	CString m_TrackPath;
	CCommon m_Common;
	bool FullRow;
	bool GridLine;
	bool HoverSelect;
	CFileHandling fh;
	int m_CurItem;
	int iItem;
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGp3ThView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	CString FindAdjective(CString country);
	bool NewFile();
	void ShowFile(CString file);
	void ShowTrack(int track);
	bool AddFile(int trackNr);
	virtual ~CGp3ThView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CGp3ThView)
	afx_msg void OnOptionsGridlines();
	afx_msg void OnOptionsFullrowselect();
	afx_msg void OnUpdateOptionsGridlines(CCmdUI* pCmdUI);
	afx_msg void OnUpdateOptionsHoverselect(CCmdUI* pCmdUI);
	afx_msg void OnOptionsHoverselect();
	afx_msg void OnDblclkTracklist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnFileOpen();
	afx_msg void OnFileNew();
	afx_msg void OnFileSaveAs();
	afx_msg void OnFileSave();
	afx_msg void OnFileExport();
	afx_msg void OnKeydownTracklist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnMoveDown();
	afx_msg void OnMoveUp();
	afx_msg void OnFileImport();
	afx_msg void OnEditSelectgp3languagefile();
	afx_msg void OnEditSettrackpath();
	afx_msg void OnEditGp3path();
	afx_msg void OnToolsPointeditor();
	afx_msg void OnUpdateOptionsFullrowselect(CCmdUI* pCmdUI);
	afx_msg void OnHelpOnlineF1grandprix3net();
	afx_msg void OnHelpOnlineGrandprix1com();
	afx_msg void OnHelpOnlineGrandprix2com();
	afx_msg void OnHelpOnlineVgsoftware();
	afx_msg void OnToolsMisceditor();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in Gp3ThView.cpp
inline CGp3ThDoc* CGp3ThView::GetDocument()
   { return (CGp3ThDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GP3THVIEW_H__759164CC_72EF_11D4_8FC7_0008C7636E27__INCLUDED_)

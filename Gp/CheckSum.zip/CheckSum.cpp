// GpChecksum.cpp : Defines the entry point for the DLL application.
//

#include "fstream.h"

bool _stdcall CheckSum(char* file)
{

long datasize;
unsigned short sum=0,cycle=0;
unsigned char c;

ifstream f;
ofstream of;

	//open track file for reading
	f.open(file,ios::in|ios::out|ios::binary);

	//seek to end-4
	f.seekg(-4,ios::end);
	
	//get pos end-4
	datasize=f.tellg();
	
	//seek to begin of file
	f.seekg(0,ios::beg);

	//loop and calculate checksum
	while (datasize--) 
	{
		f.read((char*)&c,sizeof(c));
		sum += c;
		cycle = (cycle<<3)+(cycle>>13);
		cycle += c;
	}
	//close file
	f.close();

	//open file for writing
	of.open(file,ios::in|ios::out);
	//seek to end-4
	of.seekp(-4,ios::end);
	
	//write checksum at curpos
	of.write((char*)&sum,sizeof(sum));
	of.write((char*)&cycle,sizeof(cycle));
	//close file
	of.close();
	//return true
	return(true);
}
// DullFilter.h - header file for the CDullFilter class
//

#ifndef __DULL_FILTER_H__
#define __DULL_FILTER_H__

#include "LocalFilter.h"
class CColor;

///////////////////////////////////////////////////////////////////
// Class:	CDullFilter
// Base:	CLocalFilter
// Created:	25May99 by Mal Ross
// Overview:
//    This filter produces 4 decoded textures from which the
//  colour gradually fades, thus creating the effect of driving
//  in overcast conditions.  With any luck. :)  This idea is
//  taken from GP2JAM's code.
//

class CDullFilter : public CLocalFilter
{
// Construction and destruction
public:
	CDullFilter();
	virtual ~CDullFilter();

// Attributes
protected:
	// How much colour should each subsequent decoded texture have,
	// in terms of a fraction of the colour in its predecessor.
	float m_fFadeFactor;

// Implementation
protected:
	// Just reduce the saturation of the given colour by
	// the factor in m_fFadeFactor
	virtual void FilterColor(CColor& color);
};

/////////////////////////////////////////////////////////////////////

#endif	// ~__DULL_FILTER_H__

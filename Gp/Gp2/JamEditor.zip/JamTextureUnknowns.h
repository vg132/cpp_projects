// Jam Texture Unknowns

// A list of the unknowns in a Jam Texture

// this object will merely front the list in the
// tree - the contents of the list will be set by the jam texture


#ifndef JAM_TEXTURE_UNKNOWNS_H
#define JAM_TEXTURE_UNKNOWNS_H

#include "EditableTypedPtrList.h"
#include "TreeIconDefs.h"

class CJamTextureUnknowns : public CEditableTypedPtrList
{
public:
	// constructions
	CJamTextureUnknowns(CEditableObject* pParent) : CEditableTypedPtrList(pParent) {};

	// necessary overrides
	virtual UINT	GetIconID() { return JTI_JAM_FILE_UNK; }			// return the ID for the icon in the tree for this item
	virtual CString GetFullDescription() { return "Unknowns"; }	// return name and value

	// list functions.
	using CEditableTypedPtrList::AddTail;
	POSITION	AddTail(CEditableNumber<BYTE>* pNumber) { return CEditableTypedPtrList::AddTail( (CEditableObject*)pNumber ); }
	POSITION	AddTail(CEditableNumber<WORD>* pNumber) { return CEditableTypedPtrList::AddTail( (CEditableObject*)pNumber ); }
};


#endif
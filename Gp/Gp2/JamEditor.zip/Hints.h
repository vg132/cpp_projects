// Hints.h - contains hint IDs used with CDocument::UpdateAllViews
//

// Changed the properties of a texture in the document's JAM
#define HINT_TEXTURE_PROPERTIES_CHANGED		1

// Imported a bitmap as a canvas
#define HINT_IMPORTED_CANVAS_BITMAP			2

// Imported a bitmap into the selected texture
#define HINT_IMPORTED_TEXTURE_BITMAP		3

// Selected or deselected a texture
#define HINT_SELECTED_TEXTURE				4
#define HINT_DESELECTED_TEXTURE				5

// Selected a different palette to use when displaying the Jam
#define HINT_SELECTED_PALETTE				6

// Added a new texture to the JAM
#define HINT_ADDED_TEXTURE					7

// Deleted a texture from the JAM
#define HINT_DELETED_TEXTURE				8

// Changed one of the low-detail colours
#define HINT_CHANGED_LOW_DETAIL_COLOUR		9

// Edited the local palette values in a texture
#define HINT_EDITED_LOCAL_PALETTE			10

// Automatically fixed any textures with invalid raw pixels
#define HINT_AUTOFIXED_TEXTURE_PIXELS		11

// Loaded a new set of colours into the global palette
#define HINT_CHANGED_GLOBAL_PALETTE			12



// DrivingConditionsDlg.h : header file
//

#ifndef _DRIVING_CONDITIONS_DLG_H_
#define _DRIVING_CONDITIONS_DLG_H_

class CJamTextureFilter;

/////////////////////////////////////////////////////////////////////////////
// CDrivingConditionsDlg dialog

class CDrivingConditionsDlg : public CDialog
{
// Construction
public:
	CDrivingConditionsDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDrivingConditionsDlg)
	enum { IDD = IDD_DRIVING_CONDITIONS };
	int		m_nFilterIndex;
	BOOL	m_bApplyToAll;
	BOOL	m_bProtectTransparency;
	//}}AFX_DATA

	// The ID of the selected import filter
	UINT m_nFilterID;

	// Reporting of the chosen import filter
	CJamTextureFilter* GetSelectedFilter();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDrivingConditionsDlg)
	public:
	virtual int DoModal();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Selection-update functions
	void UpdateOptionsButton();

	// Generated message map functions
	//{{AFX_MSG(CDrivingConditionsDlg)
	afx_msg void OnOptions();
	virtual BOOL OnInitDialog();
	afx_msg void OnSelectFilter();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif	// ~_DRIVING_CONDITIONS_DLG_H_

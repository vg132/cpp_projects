// Jam Size front end
// a wee class to wrap the tree item which
// expresses the size of image of the jam

#include "stdafx.h"
#include "resource.h"

#include "JamSizeFrontEnd.h"
#include "TreeIconDefs.h"
#include "Jam.h"

CJamSizeFrontEnd::CJamSizeFrontEnd(CJam* pJam, CEditableObject* pParent) : CEditableObject(pParent)
{
	// store parent jam
	m_pJam=pJam;

	ASSERT(m_pJam);	// shouldn't be null!
}

UINT CJamSizeFrontEnd::GetIconID()
{
	return JTI_IMAGE_SIZE;	// it's a property of a file

}

CString CJamSizeFrontEnd::GetFullDescription()
{
	if (!m_pJam)
	{
		return "Error: not connected to file - NO SIZE";
	}
	else
	{
		// the title is the size in Y of the area of the jam
		CString title;
		title.Format(IDS_NODE_CANVAS_HEIGHT, m_pJam->GetSize().cy);

		return title;
	}
}

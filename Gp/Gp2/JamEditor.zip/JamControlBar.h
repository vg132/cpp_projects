// JamControlBar.h : header file for the CJamControlBar class
//

#ifndef _JAM_CONTROL_BAR_H_
#define _JAM_CONTROL_BAR_H_

#include "sizecbar.h"

class CJamTree;

/////////////////////////////////////////////////////////////////////////////
// CJamControlBar window
//   All this class is concerned with is creating, destroying, and
//  resizing the jam tree held within it.
//

class CJamControlBar : public CSizingControlBar
{
// Construction
public:
	CJamControlBar();

// Attributes
protected:
	// The tree object we keep in the bar
	CJamTree* m_pJamTree;

// Operations
public:
	CJamTree* GetTree() const { return m_pJamTree; }

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJamControlBar)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CJamControlBar();

	// The tree needs to be repositioned/resized when the control
	// bar is resized by the user
	void RepositionTree(const CRect& rctClient);

	// Generated message map functions
protected:
	//{{AFX_MSG(CJamControlBar)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif	// ~_JAM_CONTROL_BAR_H_

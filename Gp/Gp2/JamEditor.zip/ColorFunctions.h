// ColorFunctions.h - header file for the jam colour-related functions
//

#ifndef __COLOR_FUNCTIONS_H__
#define __COLOR_FUNCTIONS_H__


// A function to determine the closeness of two colours.  The return
// value is between 0 (opposite colours) and 1 (identical colours).
double GetColorMatchFactor(RGBQUAD quadFirst, RGBQUAD quadSecond);
double GetColorMatchFactor(int idxFirst, int idxSecond);

// A function to find the palette index of the jam colour that's
// the closest match to the given colour
BYTE GetNearestColorIndex(RGBQUAD quadColor);
BYTE GetNearestColorIndex(int nColorIndex);
BYTE GetNearestNeighbourIndex(RGBQUAD quadColor, BYTE* pbNeighbourArray, int nNumNeighbours);

#endif	// ~__COLOR_FUNCTIONS_H__
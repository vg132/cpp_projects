// JamTexture.cpp - implementation of the CJamTexture class
//

#include "stdafx.h"
#include "resource.h"

#include "JamTexture.h"
#include "JamConstants.h"

#include "TexturePalette.h"
#include "GP2Bitmap.h"

#include "JamTextureUnknowns.h"
#include "JamTextureScalingInfo.h"
#include "JamTextureDimension.h"
#include "JamTextureLowDetailColors.h"
#include "TreeIconDefs.h"
#include "Hints.h"
#include "EditableFlags.h"

// Pixel copying
#include "PixelBlitter.h"

// Filtering
#include "JamTextureFilter.h"
#include "NullFilter.h"
#include "JamTextureFilterIDs.h"
#include "LocalPaletteArray.h"
#include "PaletteImageSource.h"
#include "PaletteImageCombiner.h"
#include "JamTextureAnimation.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CJamTexture

// Contents:
//  1. construction and destruction
//  2. serialization
//  3. attributes
//  4. drawing
//  5. texture extraction
//  6. bitmap import
//  7. bitmap export

// Construction and destruction
//

BOOL CJamTexture::s_bGuessTransparency = TRUE;
BOOL CJamTexture::s_bGuessNonStandardSizeFlags = TRUE;
BOOL CJamTexture::s_bGuessNoPalettes = TRUE;

BOOL CJamTexture::s_bShowInvalidPixels = FALSE;
COLORREF CJamTexture::s_clrSelected = RGB(255,0,0);
COLORREF CJamTexture::s_clrNotSelected = RGB(255,255,0);
COLORREF CJamTexture::s_clrInvalidPixels = RGB(0,255,255);

// Constructor
CJamTexture::CJamTexture(CJamTextureList* pParent) : CJamTextureProperties(this, (CEditableObject*)pParent	)
{
	// Initialise the header information
	m_pTextureInfo = NULL;

	// Initialise the palettes
	m_pPalette1 = m_pPalette2 = m_pPalette3 = m_pPalette4 = NULL;

	// Initialise the pixels
	m_pbRawTexturePixels = m_pbDecodedTexturePixels = NULL;
	m_nLastPaletteUsed = PAL_REBUILD_TEXTURE;

	// Textures are not selected by default
	m_bSelected = FALSE;

	// No problem pixels by default
	m_bInvalidPixels = FALSE;
}

CJamTexture::CJamTexture(const CSize& sizTexture, CJamTextureList* pParent) : CJamTextureProperties(this, (CEditableObject*)pParent	)
{
	// Initialise the header information
	m_pTextureInfo = new JAM_TEXTURE;
	VERIFY(NULL != m_pTextureInfo);
	memset(m_pTextureInfo, 0, sizeof(JAM_TEXTURE));
	m_pTextureInfo->m_wWidth = (WORD)max(1, min(sizTexture.cx, 256));
	m_pTextureInfo->m_wHeight = (WORD)max(1, min(sizTexture.cy, 256));
	if (s_bGuessNonStandardSizeFlags)
		GuessNonStandardSizeFlags();

	// Initialise the palettes to flash the image black and white
	m_pTextureInfo->m_wLocalPaletteSize = 1;
	m_pPalette1 = new BYTE[1];
	*m_pPalette1 = (BYTE)1;
	m_pPalette2 = new BYTE[1];
	*m_pPalette2 = (BYTE)31;
	m_pPalette3 = new BYTE[1];
	*m_pPalette3 = (BYTE)1;
	m_pPalette4 = new BYTE[1];
	*m_pPalette4 = (BYTE)31;

	// Initialise the pixels
	int nNumPixels = m_pTextureInfo->m_wWidth * m_pTextureInfo->m_wHeight;
	m_pbRawTexturePixels = new BYTE[nNumPixels];
	VERIFY(NULL != m_pbRawTexturePixels);
	memset(m_pbRawTexturePixels, 0, nNumPixels);
	m_pbDecodedTexturePixels = NULL;
	m_nLastPaletteUsed = PAL_REBUILD_TEXTURE;

	// Create the editable object stuff
	CreateEditableObjects();

	// Textures are not selected by default
	m_bSelected = FALSE;

	// No problem pixels by default
	m_bInvalidPixels = FALSE;
}

// Destructor
CJamTexture::~CJamTexture()
{
	// Just destroy all of our dynamically allocated data
	Destroy();
}

// Function:	Destroy()
// Overview:	Delete all of the dynamically allocated data in
//				this object
void CJamTexture::Destroy()
{
	// Delete the extracted textures
	if (NULL != m_pbRawTexturePixels)
	{
		delete[] m_pbRawTexturePixels;
		m_pbRawTexturePixels = NULL;
	}
	if (NULL != m_pbDecodedTexturePixels)
	{
		delete[] m_pbDecodedTexturePixels;
		m_pbDecodedTexturePixels = NULL;
	}

	// Delete the jam texture structure
	if (NULL != m_pTextureInfo)
	{
		delete m_pTextureInfo;
		m_pTextureInfo = NULL;
	}

	// Delete the palettes
	DestroyPalettes();
}
// End of function 'Destroy'


// Function:	Destroy()
// Overview:	Delete all of the palettes
void CJamTexture::DestroyPalettes()
{
	// Delete the palettes
	if (NULL != m_pPalette1)
	{
		delete m_pPalette1;
		m_pPalette1 = NULL;
	}
	if (NULL != m_pPalette2)
	{
		delete m_pPalette2;
		m_pPalette2 = NULL;
	}
	if (NULL != m_pPalette3)
	{
		delete m_pPalette3;
		m_pPalette3 = NULL;
	}
	if (NULL != m_pPalette4)
	{
		delete m_pPalette4;
		m_pPalette4 = NULL;
	}
}
// End of function 'DestroyPalettes'



// Serialization
//

// Loading/saving (not intended to CObject-type of Serialize -
// just a general load/save from/to archive)
void CJamTexture::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// Check to see that this object is actually valid before
		// trying to save!!
		if (!IsValid())
			AfxThrowArchiveException(CArchiveException::generic,
				ar.GetFile()->GetFilePath());

		// Save the structure as is
		ar.Write(m_pTextureInfo, sizeof(JAM_TEXTURE));
	}
	else
	{
		// Create the JAM_TEXTURE member if it doesn't already
		// exist
		if (NULL == m_pTextureInfo)
			m_pTextureInfo = new JAM_TEXTURE;
		if (NULL == m_pTextureInfo)
			AfxThrowArchiveException(CArchiveException::generic,
				ar.GetFile()->GetFilePath());

		// Save the structure as is
		ar.Read(m_pTextureInfo, sizeof(JAM_TEXTURE));

		CreateEditableObjects();
	}
}
// End of function 'Serialize'


// Function:	SerializePalettes(arJam)
// Overview:	Load or save the palettes for this texture.  Note that
//				the palettes are stored in JAM files at the end of the
//				section containing the JAM_TEXTURE structures, so they
//				have to be serialized separately.
void CJamTexture::SerializePalettes(CArchive& arJam)
{
	// We don't need to do anything if the palette size is zero
	int nPaletteSize = GetPaletteSize();
	if (nPaletteSize == 0)
		return;

	if (arJam.IsStoring())
	{
		// Save the current palette entries
		for (int nPalNum = 1; nPalNum <= NUM_LOCAL_PALETTES_PER_TEXTURE; nPalNum++)
		{
			// Get the pointer to the current palette
			BYTE*& pPalette = GetPalette(nPalNum);

			// Save the palette data (if we have local palettes)
			arJam.Write(pPalette, nPaletteSize);
		}
	}
	else
	{
		// Load the palette entries
		for (int nPalNum = 1; nPalNum <= NUM_LOCAL_PALETTES_PER_TEXTURE; nPalNum++)
		{
			// Get the pointer to the current palette
			BYTE*& pPalette = GetPalette(nPalNum);

			// Allocate the memory for the palette, if need be
			if (NULL == pPalette)
			{
				// Allocate the memory and check again...
				pPalette = new BYTE[nPaletteSize];
				if (NULL == pPalette)
					AfxThrowArchiveException(CArchiveException::generic,
						arJam.GetFile()->GetFilePath());
			}

			// Read in the palette data
			arJam.Read(pPalette, nPaletteSize);
		}
	}
}
// End of function 'SerializePalettes'


// Function:	SerializePixels(ar&)
// Overview:	Save or load the raw pixels to or from the given
//				archive.  NOTE: this function is to be used only
//				for cut/copy/paste.
void CJamTexture::SerializePixels(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// Store the current version number
		UINT nVersion = JAMTEXTURE_PIXELS_CLIPBRD_VERSION;
		ar << nVersion;

		// Store the pixels to the archive
		UINT nNumTextureBytes = GetNumTextureBytes();
		ar.Write(m_pbRawTexturePixels, nNumTextureBytes);
	}
	else
	{
		// Load and check the version number
		UINT nVersion = 0;
		ar >> nVersion;
		if (nVersion == 0 || nVersion > JAMTEXTURE_PIXELS_CLIPBRD_VERSION)
			AfxThrowArchiveException(CArchiveException::badSchema,
				ar.GetFile()->GetFilePath());

		// Check to make sure this object's been initialised
		ASSERT(NULL != m_pTextureInfo && NULL == m_pbRawTexturePixels);
		if ((NULL == m_pTextureInfo) || (NULL != m_pbRawTexturePixels))
			AfxThrowArchiveException(CArchiveException::generic, ar.GetFile()->GetFilePath());

		// Create the buffer to store the pixels for the Jam entry
		UINT nNumTextureBytes = GetNumTextureBytes();
		m_pbRawTexturePixels = new BYTE[nNumTextureBytes];
		if (NULL == m_pbRawTexturePixels)
			AfxThrowArchiveException(CArchiveException::generic, ar.GetFile()->GetFilePath());

		// Load the pixels from the archive
		ar.Read(m_pbRawTexturePixels, nNumTextureBytes);
		CheckForInvalidPixels();
	}
}
// End of function 'SerializePixels'


void CJamTexture::CreateEditableObjects()
{
	ASSERT(NULL != m_pTextureInfo);
	if (NULL == m_pTextureInfo)
		return;

	// here is a sexy moment
	// all we have to do is add the editable numbers
	// to our list - which we are derived from
	// the list will take care of the objects
	// so we can wantonly create them thus:
	AddTail(new CEditableNumber<BYTE>(&(m_pTextureInfo->m_byLeft), TRUE, "Left", this, JTI_IMAGE_LOCATION));
	AddTail(new CEditableNumber<WORD>(&(m_pTextureInfo->m_wTop), TRUE, "Top", this, JTI_IMAGE_LOCATION));
	AddTail(new CJamTextureDimension(CJamTextureDimension::DIM_WIDTH, this));
	AddTail(new CJamTextureDimension(CJamTextureDimension::DIM_HEIGHT, this));
	AddTail(new CEditableFlags<WORD>(&(m_pTextureInfo->m_wFlags), "Flags", IDS_TEXTURE_FLAG_NAME1, this));

	// add the id5 object-scaling properties
	CJamTextureScalingInfo* pScalingInfo = new CJamTextureScalingInfo(this);
	AddTail((CEditableObject*)pScalingInfo);
	pScalingInfo->AddTail(new CEditableNumber<BYTE>(&(m_pTextureInfo->m_byID5ScaleFactor), TRUE, "Scale factor", this, JTI_IMAGE_SIZE));
	pScalingInfo->AddTail(new CEditableNumber<SBYTE>(&(m_pTextureInfo->m_byID5HorzShift), TRUE, "Origin (x)", this, JTI_IMAGE_LOCATION));
	pScalingInfo->AddTail(new CEditableNumber<SBYTE>(&(m_pTextureInfo->m_byID5VertShift), TRUE, "Origin (y)", this, JTI_IMAGE_LOCATION));
	pScalingInfo->AddTail(new CEditableFlags<BYTE>(&(m_pTextureInfo->m_byID5ScaleFlags), "Flags(?)", IDS_SCALING_FLAG_NAME1, this));

	// add the low-detail colours
	CJamTextureLowDetailColors* pColors = new CJamTextureLowDetailColors(this);
	AddTail((CEditableObject*)pColors);
	pColors->AddTail(new CEditableNumber<BYTE>(&(m_pTextureInfo->m_byLowDetailColour1), TRUE, "Primary", (CEditableObject*)pColors, JTI_TEXTURE_PALETTE));
	pColors->AddTail(new CEditableNumber<BYTE>(&(m_pTextureInfo->m_byLowDetailColour2), TRUE, "Secondary", (CEditableObject*)pColors, JTI_TEXTURE_PALETTE));

	// and we prepare the group of unknowns too
	CJamTextureUnknowns* pUnk=new CJamTextureUnknowns(this);
	AddTail((CEditableObject*)pUnk);

	// add the unknowns to the list
	pUnk->AddTail(new CEditableNumber<BYTE>(&(m_pTextureInfo->m_byUnk03), TRUE, "IDX_03", this, JTI_JAM_FILE_UNK));
	pUnk->AddTail(new CEditableNumber<WORD>(&(m_pTextureInfo->m_wUnk0E), TRUE, "IDX_0E", this, JTI_JAM_FILE_UNK));

	// do the unk 18 array
	for (int i=0; i<8; i++)
	{
		CString name;
		name.Format("IDX_18 [%d]", i);
		pUnk->AddTail(new CEditableNumber<BYTE>(&(m_pTextureInfo->m_byUnk18[i]), TRUE, name, this, JTI_JAM_FILE_UNK));
	}
}



// Attributes
//

// A very simple check to test the validity of this object
BOOL CJamTexture::IsValid() const
{
	// Base our decision on whether or not we've
	// created a texture header yet
	return (NULL != m_pTextureInfo);
}

// The texture ID
UINT CJamTexture::GetTextureID() const
{
	// Check to see whether the texture is loaded yet
	if (!IsValid())
		return 0;

	// Return the texture ID member of the JAM_TEXTURE
	return m_pTextureInfo->m_wTextureID;
}

void CJamTexture::SetTextureID(const UINT& nID)
{
	// Check to see whether the texture is loaded yet
	if (!IsValid())
		return;

	// Make sure it's a valid value
	if (0 == nID)
		return;

	// Set the new value
	m_pTextureInfo->m_wTextureID = (WORD)nID;
}


///////////////////////////////////////////////////////////////////////
// Texture property flags

UINT CJamTexture::FlagNumToMask(const int& nFlagID)
{
	// Check to make sure the flag ID is valid
	if (nFlagID < TF_FIRST_FLAG || nFlagID > TF_LAST_FLAG)
		return 0;

	// Calculate the mask
	return UINT(1 << (nFlagID - 1));
}

WORD CJamTexture::GetFlags() const
{
	// Check to see whether the texture is loaded yet
	if (!IsValid())
		return 0;

	return m_pTextureInfo->m_wFlags;
}

void CJamTexture::SetFlags(const WORD& wFlags)
{
	// Check to see whether the texture is loaded yet
	if (!IsValid())
		return;

	m_pTextureInfo->m_wFlags = wFlags;
}

BOOL CJamTexture::IsFlagSet(const int& nFlagID) const
{
	// Check to see whether the texture is loaded yet
	if (!IsValid())
		return FALSE;

	// Check to make sure the flag ID is valid
	if (nFlagID < TF_FIRST_FLAG || nFlagID > TF_LAST_FLAG)
		return FALSE;

	// Calculate the required mask and check m_wFlags
	WORD wMask = WORD(1 << (nFlagID - 1));
	return ((m_pTextureInfo->m_wFlags & wMask) == wMask);
}

void CJamTexture::SetFlag(const int& nFlagID, const BOOL bOn)
{
	// Check to see whether the texture is loaded yet
	if (!IsValid())
		return;

	// Check to make sure the flag ID is valid
	if (nFlagID < TF_FIRST_FLAG || nFlagID > TF_LAST_FLAG)
		return;

	// Calculate the required mask and set/unset
	// it in m_wFlags
	WORD wMask = WORD(1 << (nFlagID - 1));
	if (bOn)
		m_pTextureInfo->m_wFlags |= wMask;
	else
		m_pTextureInfo->m_wFlags &= ~wMask;
}


///////////////////////////////////////////////////////////////////////
// Texture area information

WORD CJamTexture::GetTop() const
{
	// Check to see whether the texture is loaded yet
	if (NULL == m_pTextureInfo)
		return 0;
	else
		return m_pTextureInfo->m_wTop;
}

BYTE CJamTexture::GetLeft() const
{
	// Check to see whether the texture is loaded yet
	if (NULL == m_pTextureInfo)
		return 0;
	else
		return m_pTextureInfo->m_byLeft;
}

void CJamTexture::SetTop(const WORD nTop)
{
	ASSERT(NULL != m_pTextureInfo);
	if (NULL == m_pTextureInfo)
		return;

	m_pTextureInfo->m_wTop = nTop;
}

void CJamTexture::SetLeft(const BYTE nLeft)
{
	ASSERT(NULL != m_pTextureInfo);
	if (NULL == m_pTextureInfo)
		return;

	m_pTextureInfo->m_byLeft = nLeft;
}

CRect CJamTexture::GetRect() const
{
	// Check to see whether the texture is loaded yet
	if (!IsValid())
		return CRect(0,0,0,0);

	// Return the area of the overall canvas in which the
	// texture lies
	return CRect(CPoint(m_pTextureInfo->m_byLeft, m_pTextureInfo->m_wTop),
				 CSize(m_pTextureInfo->m_wWidth, m_pTextureInfo->m_wHeight));
}

WORD CJamTexture::GetWidth() const
{
	// Check to see whether the texture is loaded yet
	if (NULL == m_pTextureInfo)
		return 0;
	else
		return m_pTextureInfo->m_wWidth;
}

WORD CJamTexture::GetHeight() const
{
	// Check to see whether the texture is loaded yet
	if (NULL == m_pTextureInfo)
		return 0;
	else
		return m_pTextureInfo->m_wHeight;
}

BOOL CJamTexture::SetWidth(const WORD& wWidth)
{
	// Make sure there's texture info in this object
	if (NULL == m_pTextureInfo)
		return FALSE;

	// Make sure the width is within the limits for
	// textures in JAM files
	if (wWidth > JAM_CANVAS_WIDTH)
		return FALSE;

	return SetSize(wWidth, GetHeight());
}

BOOL CJamTexture::SetHeight(const WORD& wHeight)
{
	// Make sure there's texture info in this object
	if (NULL == m_pTextureInfo)
		return FALSE;

	// Make sure the height is within the limits for
	// textures in JAM files
	if (wHeight > MAX_JAM_CANVAS_HEIGHT)
		return FALSE;

	return SetSize(GetWidth(), wHeight);
}

BOOL CJamTexture::SetSize(const WORD wWidth, const WORD wHeight)
{
	// Make sure there's texture info in this object
	if (NULL == m_pTextureInfo || NULL == m_pbRawTexturePixels)
		return FALSE;

	// Make sure the height and width are within the limits
	// for textures in JAM files
	if (wHeight > MAX_JAM_CANVAS_HEIGHT || wWidth > JAM_CANVAS_WIDTH ||
		wHeight == 0 || wWidth == 0)
		return FALSE;

	// Determine whether we need to do anything at all
	CSize sizCurrent(GetWidth(), GetHeight());
	CSize sizNew(wWidth, wHeight);
	if (sizNew == sizCurrent)
		return TRUE;	// no change, so just exit with success

	// Determine which pixels we want to keep and which we
	// want to ditch by performing an intersection on the new
	// and old rectangles
	CRect rctCurrent(CPoint(0,0), sizCurrent);
	CRect rctNew(CPoint(0,0), sizNew);
	CRect rctCopy(0,0,0,0);
	if (!rctCopy.IntersectRect(rctCurrent, rctNew))
	{
		ASSERT(FALSE);
		return FALSE;
	}

	// We'll keep the existing palette seeing as we don't want to
	// ruin anything by re-filtering.  NOTE: this is only the first
	// stage of design.  Later we will use the same technique as is
	// used for importing animations by creating the 4 decoded
	// textures (at the new size) and re-determining the palettes
	// from them.
	BYTE* pbNewTexturePixels = new BYTE[wHeight * wWidth];
	if (NULL == pbNewTexturePixels)
		return FALSE;
	memset(pbNewTexturePixels, 0, wHeight * wWidth);

	// Copy the pixels from the current texture
	CPixelBlitter blitter;
	blitter.CopyPixels(m_pbRawTexturePixels, sizCurrent, rctCopy,
		pbNewTexturePixels, sizNew, CPoint(0,0));

	// Replace the old pixels with the new ones
	delete[] m_pbRawTexturePixels;
	m_pbRawTexturePixels = pbNewTexturePixels;
	m_pTextureInfo->m_wWidth = wWidth;
	m_pTextureInfo->m_wHeight = wHeight;

	// Set the height and width optimisations correctly if the
	// option for this has been set
	if (s_bGuessNonStandardSizeFlags)
		GuessNonStandardSizeFlags();

	// Now just make sure the decoded version is correct (or at
	// least will be correct the next time it's used
	if (NULL != m_pbDecodedTexturePixels)
	{
		delete[] m_pbDecodedTexturePixels;
		m_pbDecodedTexturePixels = NULL;
	}
	m_nLastPaletteUsed = PAL_REBUILD_TEXTURE;

	return TRUE;
}
// End of function 'SetSize'


// Function:	GuessNonStandardSizeFlags()
// Overview:	Attempt to work out the correct values for flags
//				9 and 10, based upon the size of the texture.
void CJamTexture::GuessNonStandardSizeFlags()
{
	// Just set the flags according to the verdict of the very handy
	// IsNonStandardSize function.
	SetFlag(TF_NON_STANDARD_HEIGHT, IsNonStandardSize(m_pTextureInfo->m_wHeight));
	SetFlag(TF_NON_STANDARD_WIDTH, IsNonStandardSize(m_pTextureInfo->m_wWidth));
}
// End of function 'GuessNonStandardSizeFlags'


// Function:	IsNonStandardSize(wSize)
// Overview:	Function to check whether the given dimension size is a
//				'standard' size.  By standard I mean "is it part of the
//				exponential series of 2?" (i.e. 1, 2, 4, 8, 16, etc.).
BOOL CJamTexture::IsNonStandardSize(WORD wSize) const
{
	// Count the number of bits set in the number by repeatedly
	// shifting it downwards until there can't possibly be any
	// bits remaining set in it.
	for (int nNumBitsSet = 0; (wSize != 0) && (nNumBitsSet < 2); wSize >>= 1)
		if ((wSize & 1) == 1) nNumBitsSet++;

	// The size is a 'standard' one iff just *one* of the bits
	// was set, otherwise it is indeed non-standard
	return (1 != nNumBitsSet);
}
// End of function 'IsNonStandardSize'



///////////////////////////////////////////////////////////////////////
// Palette information and checking

// Size of each of the local palettes
UINT CJamTexture::GetPaletteSize() const
{
	// Check to see whether the texture is loaded yet
	if (!IsValid())
		return 0;

	return m_pTextureInfo->m_wLocalPaletteSize;
}

// Set the position of this texture's palettes in the JAM,
// after the header info
BOOL CJamTexture::SetPalettePos(const UINT& nPalettePos)
{
	// Check to see whether the texture is loaded yet
	if (!IsValid())
		return FALSE;

	m_pTextureInfo->m_wPalettePos = (WORD)nPalettePos;

	return TRUE;
}

// Pixel and palette-checking.
void CJamTexture::CheckForInvalidPixels()
{
	// Check to see whether the texture is loaded yet
	ASSERT(IsValid());
	if (!IsValid())
		return;

	// If there are no palettes, then the raw pixel
	// values must be fine
	if (0 == GetPaletteSize())
	{
		m_bInvalidPixels = FALSE;
		return;
	}

	// Just look through all of the raw pixels for values
	// outside the range of local palette indices.
	UINT nNumBytes = GetNumTextureBytes();
	BOOL bValid = TRUE;
	for (UINT nPixelNum = 0; (nPixelNum < nNumBytes) && bValid; nPixelNum++)
		bValid = (m_pbRawTexturePixels[nPixelNum] < GetPaletteSize());

	// Keep a record of whether or not the pixels are valid
	m_bInvalidPixels = !bValid;
}

// Get the number of pixel bytes in the texture
UINT CJamTexture::GetNumTextureBytes() const
{
	// Check to see whether the texture is loaded yet
	if (!IsValid())
		return 0;

	return m_pTextureInfo->m_wWidth * m_pTextureInfo->m_wHeight;
}




// Drawing functions
//

// Function:	DrawTexture(pDC, nPaletteNum)
// Overview:	1:1 drawing of texture in the given DC, using the given
//				palette.  Return TRUE if successful, FALSE otherwise.
BOOL CJamTexture::DrawTexture(CDC* pDC, const int& nPaletteNum)
{
	// Check to see whether the texture is loaded yet
	if (!IsValid() || NULL == m_pbRawTexturePixels)
		return FALSE;

	// Decode the raw texture pixels using the given palette
	if (!DecodePixels(nPaletteNum))
	{
		ASSERT(FALSE);
		return FALSE;
	}

	// Create a bitmap and put the decoded pixels into it
	CGP2Bitmap gp2BitmapMaker;
	if (!gp2BitmapMaker.CreateFromJamPixels(m_pTextureInfo->m_wWidth, m_pTextureInfo->m_wHeight,
		m_pbDecodedTexturePixels))
		return FALSE;

	CBitmap bmpTexture;
	gp2BitmapMaker.CreateDIB(bmpTexture);

	// Now use BitBlt between DCs to draw the texture into the DC
	// we've been given
	CDC memDC;
	memDC.CreateCompatibleDC(pDC);
	CBitmap* pOldBitmap = memDC.SelectObject(&bmpTexture);
	pDC->BitBlt(m_pTextureInfo->m_byLeft, m_pTextureInfo->m_wTop, m_pTextureInfo->m_wWidth, m_pTextureInfo->m_wHeight,
		&memDC, 0, 0, SRCCOPY);

	// Tidy up
	memDC.SelectObject(pOldBitmap);
	bmpTexture.DeleteObject();
	memDC.DeleteDC();

	return TRUE;
}
// End of function 'DrawTexture'


// Function:	DrawOutline(pDC, dZoomFactor)
// Overview:	Draw the outline and label of the texture.
BOOL CJamTexture::DrawOutline(CDC* pDC, const double& dZoomFactor)
{
	// Make sure the caller has passed in a valid pointer
	ASSERT(NULL != pDC);
	if (NULL == pDC)
		return FALSE;

	// Make sure the texture info is valid
	if (NULL == m_pTextureInfo)
		return FALSE;

	// To draw a rectangular outline, we need to make sure the
	// current brush is the NULL_BRUSH as this will be used to
	// fill the interior of the rectangle
	CBrush* pOldBrush = (CBrush *)pDC->SelectStockObject(NULL_BRUSH);

	// TODO: Create and select a pen of the current colour
	// specified by the user
	COLORREF clrOutline = GetOutlineColor();
	CPen penOutline(PS_SOLID, 1, clrOutline);
	CPen* pOldPen = (CPen *)pDC->SelectObject(&penOutline);

	// Draw the rectangle, scaled to account for the zoom factor
	int nLeft = int(dZoomFactor * m_pTextureInfo->m_byLeft);
	int nTop = int(dZoomFactor * m_pTextureInfo->m_wTop);
	int nRight = nLeft + int(dZoomFactor * m_pTextureInfo->m_wWidth);
	int nBottom = nTop + int(dZoomFactor * m_pTextureInfo->m_wHeight);
	CRect rctOutline(nLeft, nTop, nRight, nBottom);
	pDC->Rectangle(rctOutline);

#ifdef _DEBUG
	// Draw the corner handles and texture-origin, if selected
	if (m_bSelected)
	{
		// Work out the points upon which the handles are centered
		const int nHandleSize = 4;
		CSize sizHandle(nHandleSize,nHandleSize);
		CRect rctHandles[4];
		rctHandles[0] = CRect(CPoint(rctOutline.left, rctOutline.top), sizHandle);
		rctHandles[1] = CRect(CPoint(rctOutline.right-nHandleSize, rctOutline.top), sizHandle);
		rctHandles[2] = CRect(CPoint(rctOutline.left, rctOutline.bottom-nHandleSize), sizHandle);
		rctHandles[3] = CRect(CPoint(rctOutline.right-nHandleSize, rctOutline.bottom-nHandleSize), sizHandle);

		// Now create and select the brush to use
		CBrush handleBrush(clrOutline);
		CBrush* pPrevBrush = pDC->SelectObject(&handleBrush);

		// Now draw the handles
		for (int nHandle = 0; nHandle < 4; nHandle++)
			pDC->Rectangle(rctHandles[nHandle]);

		// Only draw the origin if it's not (0,0)
		if ((m_pTextureInfo->m_byID5HorzShift != 0) || (m_pTextureInfo->m_byID5VertShift != 0))
		{
			// Work out where the origin is in the zoomed coords
			int nOriginX = int(dZoomFactor * (m_pTextureInfo->m_byLeft + m_pTextureInfo->m_byID5HorzShift));
			int nOriginY = int(dZoomFactor * (m_pTextureInfo->m_wTop + m_pTextureInfo->m_byID5VertShift));
			CRect rctOrigin(CPoint(nOriginX - (nHandleSize/2), nOriginY - (nHandleSize/2)),
							CSize(nHandleSize, nHandleSize));

			// And now draw it
			pDC->Rectangle(rctOrigin);
		}

		// Tidy up
		pDC->SelectObject(pPrevBrush);
		handleBrush.DeleteObject();
	}
#endif
	
	// Reselect the old GDI objects
	pDC->SelectObject(pOldBrush);
	pDC->SelectObject(pOldPen);

	// Delete unwanted GDI objects
	penOutline.DeleteObject();

	return TRUE;
}
// End of function 'DrawOutline'


// Function:	GetOutlineColor()
// Overview:	Get the colour to use when drawing the texture's
//				outline.
COLORREF CJamTexture::GetOutlineColor() const
{
	COLORREF clrOutline = RGB(0,0,0);
	if (m_bSelected)
	{
		// Red when selected
		clrOutline = s_clrSelected;
	}
	else if (!s_bShowInvalidPixels)
	{
		// Yellow when not selected
		clrOutline = s_clrNotSelected;
	}
	else
	{
		if (!AreRawPixelsValid())
		{
			// Aqua when not selected and has *invalid* pixels
			clrOutline = s_clrInvalidPixels;
		}
		else
		{
			// Yellow when not selected and has *valid* pixels
			clrOutline = s_clrNotSelected;
		}
	}

	return clrOutline;
}
// End of function 'GetOutlineColor'



// Hit-testing code
//

// Function:	HitTest(pixelInfo&)
// Overview:	Fill the given CJamPixelInfo object with information
//				relating to the pixel under the point in the JAM it
//				represents.
BOOL CJamTexture::HitTest(CJamPixelInfo& pixelInfo) const
{
	// Check to see that this object has been created
	ASSERT(IsValid() && NULL != m_pbRawTexturePixels);
	if (!IsValid())
		return FALSE;

	// Determine whether the point in the Jam represented by the
	// pixelInfo parameter is in this texture
	CRect rctTexture = GetRect();
	CPoint ptInJam = pixelInfo.GetPointInJam();
	BOOL bHit = rctTexture.PtInRect(ptInJam);
	if (bHit)
	{
		// Set the texture ID
		pixelInfo.m_pTexture = this;

		// Set the position of the pixel relative to the top-left
		// of the texture
		CPoint ptInTexture = ptInJam - rctTexture.TopLeft();
		pixelInfo.m_ptPixelInTexture = ptInTexture;

		// Set the raw value of the pixel
		pixelInfo.m_rawPixelValue = m_pbRawTexturePixels[ptInTexture.y * rctTexture.Width() + ptInTexture.x];

		// Finally, calculate the decoded pixel values
		if (GetPaletteSize() > 0)
		{
			// Get the values from the local palettes
			pixelInfo.m_decPixelValues[0] = BYTE(m_pPalette1[pixelInfo.m_rawPixelValue]);
			pixelInfo.m_decPixelValues[1] = BYTE(m_pPalette2[pixelInfo.m_rawPixelValue]);
			pixelInfo.m_decPixelValues[2] = BYTE(m_pPalette3[pixelInfo.m_rawPixelValue]);
			pixelInfo.m_decPixelValues[3] = BYTE(m_pPalette4[pixelInfo.m_rawPixelValue]);
		}
		else
		{
			// Each of the decoded values is just the same as the
			// raw value, as there are no local palettes
			pixelInfo.m_decPixelValues[0] = BYTE(pixelInfo.m_rawPixelValue);
			pixelInfo.m_decPixelValues[1] = BYTE(pixelInfo.m_rawPixelValue);
			pixelInfo.m_decPixelValues[2] = BYTE(pixelInfo.m_rawPixelValue);
			pixelInfo.m_decPixelValues[3] = BYTE(pixelInfo.m_rawPixelValue);
		}
	}

	// Return TRUE/FALSE to indicate whether there was a texture
	// under the position of the pixelInfo's m_ptPixelInJam member
	return bHit;
}
// End of function 'HitTest'



// Extraction of the texture from, and insertion of the texture
// into, the overall JAM's pixels
//

// Function:	ExtractRawPixelsFromCanvas(pbCanvasPixels)
// Overview:	Extract the area of the overall canvas's pixels used
//				by this texture.  However, don't adjust the palette
//				yet.  Return TRUE on success, FALSE otherwise.
BOOL CJamTexture::ExtractRawPixelsFromCanvas(BYTE* pbCanvasPixels, const CSize& sizCanvas)
{
	// Check to see that the pointer to the canvas pixels
	// passed in is at least not NULL
	ASSERT(NULL != pbCanvasPixels);
	if (NULL == pbCanvasPixels)
		return FALSE;

	// Check to make sure this object's been initialised
	ASSERT(NULL != m_pTextureInfo);
	if (NULL == m_pTextureInfo)
		return FALSE;

	// If we've already got some raw pixels, just return now,
	// failing the function
	if (NULL != m_pbRawTexturePixels)
		return FALSE;

	// Create the buffer to store the pixels for the Jam entry
	m_pbRawTexturePixels = new BYTE[GetNumTextureBytes()];
	if (NULL == m_pbRawTexturePixels)
		return FALSE;

	// Use a blitter to copy the pixels across
	CPixelBlitter pixelBlitter;
	BOOL bSuccess = pixelBlitter.CopyPixels(pbCanvasPixels, sizCanvas, GetRect(), m_pbRawTexturePixels, GetRect().Size(), CPoint(0,0));
	if (bSuccess)
		CheckForInvalidPixels();

	return bSuccess;
}
// End of function 'ExtractRawPixelsFromCanvas'


// Function:	InsertRawPixelsIntoCanvas(pbCanvasPixels)
// Overview:	Insert the texture's pixels into the correct location within
//				the overall canvas's pixels.
BOOL CJamTexture::InsertRawPixelsIntoCanvas(BYTE* pbCanvasPixels, const CSize& sizCanvas)
{
	// Check to see that the pointer to the canvas pixels
	// passed in is at least not NULL
	ASSERT(NULL != pbCanvasPixels);
	if (NULL == pbCanvasPixels)
		return FALSE;

	// Check to make sure this object's been initialised
	ASSERT(NULL != m_pTextureInfo);
	if (NULL == m_pTextureInfo)
		return FALSE;

	// Make sure we've actually got some raw pixels.  If not, just
	// return now, failing the function
	ASSERT(NULL != m_pbRawTexturePixels);
	if (NULL == m_pbRawTexturePixels)
		return FALSE;

	// Use a blitter to copy the pixels across
	CPixelBlitter pixelBlitter;
	return pixelBlitter.CopyPixels(m_pbRawTexturePixels, GetRect().Size(), CRect(CPoint(0,0), GetRect().Size()),
		pbCanvasPixels, sizCanvas, GetRect().TopLeft());
}
// End of function 'InsertRawPixelsIntoCanvas'


// Function:	DecodePixels(nCurrPalEntry)
// Overview:	Convert the raw pixels to use the local palette indicated
//				by nCurrPalEntry.  Return TRUE on success, FALSE otherwise.
BOOL CJamTexture::DecodePixels(const int& nCurrPalEntry)
{
	// If we've already got the decoded pixels using the given
	// palette, just return successfully
	if (nCurrPalEntry == m_nLastPaletteUsed)
		return TRUE;

	// If we've not got the raw pixels yet, just return now,
	// failing the function
	ASSERT(NULL != m_pbRawTexturePixels);
	if (NULL == m_pbRawTexturePixels)
		return FALSE;

	// If we haven't previously decoded the texture's raw pixels,
	// create a byte array for them now.  Otherwise, we'll just
	// overwrite what we've already allocated.  NOTE: if the
	// texture changes size, the decoded pixels MUST be destroyed.
	if (NULL == m_pbDecodedTexturePixels)
		m_pbDecodedTexturePixels = new BYTE[GetNumTextureBytes()];
	if (NULL == m_pbDecodedTexturePixels)
		return FALSE;

	// Check to see whether we're just drawing as the texture
	// would be seen in low detail (i.e. backround colour only)
	if (PAL_LOW_DETAIL_COLOR == nCurrPalEntry)
	{
		// Just set all pixels to the low-detail colour (previously
		// thought to be dependent upon the transparent flag).
		BYTE byLowDetailColour = m_pTextureInfo->m_byLowDetailColour1;
		memset(m_pbDecodedTexturePixels, byLowDetailColour, GetNumTextureBytes());

		// Keep a note of the which palette was used to produce these
		// decoded pixel values
		m_nLastPaletteUsed = PAL_LOW_DETAIL_COLOR;
	}
	else
	{
		// Get the palette we're going to use to decode the raw pixel
		// values.
		BYTE*& pPalette = GetPalette(nCurrPalEntry);

		// Now just convert each pixel of the raw pixels (if the
		// palette actually exists)
		if (NULL != pPalette && m_pTextureInfo->m_wLocalPaletteSize > 0)
		{
			// Copy the pixels using the palette indexes from the local palette
			UINT nNumBytes = GetNumTextureBytes();
			for (UINT nPixelNum = 0; nPixelNum < nNumBytes; nPixelNum++)
			{
				if (m_pbRawTexturePixels[nPixelNum] < m_pTextureInfo->m_wLocalPaletteSize)
					m_pbDecodedTexturePixels[nPixelNum] = BYTE(pPalette[m_pbRawTexturePixels[nPixelNum]]);
				else	// correct Paul's dodgy JAMs if we haven't do so already
					m_pbDecodedTexturePixels[nPixelNum] = BYTE(m_pbRawTexturePixels[nPixelNum]);
			}

			// Keep a note of the which palette was used to produce these
			// decoded pixel values
			m_nLastPaletteUsed = nCurrPalEntry;
		}
		else
		{
			// The palette doesn't exist, so just perform a straight
			// copy of the pixels
			memcpy(m_pbDecodedTexturePixels, m_pbRawTexturePixels, GetNumTextureBytes());

			// Keep a note of the which palette was used to produce these
			// decoded pixel values
			m_nLastPaletteUsed = PAL_REBUILD_TEXTURE;
		}
	}

	return TRUE;
}
// End of function 'DecodePixels'


// Function:	GetPalette(nPaletteNumber)
// Overview:	Get a pointer to the specified palette.  Return TRUE if
//				able to return a pointer to the specified palette (even
//				if that palette is currently NULL), or FALSE if not.
BYTE*& CJamTexture::GetPalette(const int nPaletteNumber)
{
	// Just select the palette from one of the four we store...
	switch (nPaletteNumber)
	{
	case 4:
		return m_pPalette4;
		break;
	case 3:
		return m_pPalette3;
		break;
	case 2:
		return m_pPalette2;
		break;
	case 1:
		return m_pPalette1;
		break;
	default:
		ASSERT(FALSE);
		return m_pPalette1;	// we've got to return something!
		break;
	}
}
// End of function 'GetPalette'



// Import/export of bitmaps
//

// Function:	CopyTexturePixels(pbSrc, bSrcIsCanvas, rctCopyArea, pbDest, bDestIsCanvas, ptCopyTo)
// Overview:	Copying pixels from one location in a byte buffer to
//				another location in a separate byte buffer.  This is
//				one of the most useful functions in the class.
BOOL CJamTexture::CopyTexturePixels(BYTE* pbSrc, BOOL bSrcIsCanvas, BYTE* pbDest, BOOL bDestIsCanvas)
{
	// This function is not intended for copying between
	// identical locations.  For texture-to-texture copies
	// you should just use memcpy.  For canvas-to-canvas
	// copies you... hang on.  Why would you want a canvas-
	// to-canvas copy?!
	ASSERT(bSrcIsCanvas != bDestIsCanvas);

	// First, we need to decide what needs copying where
	CRect rctTexture(GetRect());
	CRect rctCopyArea(rctTexture);
	CPoint ptCopyTo(rctTexture.TopLeft());
	CSize sizSrc(rctTexture.Size());
	CSize sizDest(sizSrc);

	// All locations/sizes have been initialised using texture
	// location/size, so adjust those which need adjusting
	if (bSrcIsCanvas)
		sizSrc = CSize(JAM_CANVAS_WIDTH, rctTexture.top + rctTexture.Height());
	else
		rctCopyArea.OffsetRect(-rctTexture.TopLeft());

	if (bDestIsCanvas)
		sizDest = CSize(JAM_CANVAS_WIDTH, rctTexture.top + rctTexture.Height());
	else
		ptCopyTo = CPoint(0,0);

	// Use a blitter to copy the pixels across
	CPixelBlitter pixelBlitter;
	return pixelBlitter.CopyPixels(pbSrc, sizSrc, rctCopyArea, pbDest, sizDest, ptCopyTo);
}
// End of function 'CopyTexturePixels'


// Function:	ImportPixelsFromCanvasBitmap(pbBitmapPixels, pFilter)
// Overview:	Import and filter pixels from a bitmap representing
//				a whole canvas.  Return TRUE upon success, FALSE
//				otherwise.
BOOL CJamTexture::ImportPixelsFromCanvasBitmap(BYTE* pbBitmapPixels, CJamTextureFilter* pFilter)
{
	// Check to see that the pointer to the canvas pixels
	// passed in is at least not NULL
	ASSERT(NULL != pbBitmapPixels);
	if (NULL == pbBitmapPixels)
		return FALSE;

	// Check to make sure this object's been initialised
	ASSERT(NULL != m_pTextureInfo);
	if (NULL == m_pTextureInfo)
		return FALSE;

	// Create the buffer to store the pixels for the Jam entry
	BYTE* pbTextureBitmapPixels = new BYTE[GetNumTextureBytes()];
	if (NULL == pbTextureBitmapPixels)
		return FALSE;

	// Copy the pixels out of the bitmap and import them using
	// the filter we've been passed
	BOOL bSuccess = CopyTexturePixels(pbBitmapPixels, TRUE, pbTextureBitmapPixels, FALSE);
	if (bSuccess)
		bSuccess = ImportPixelsFromTextureBitmap(pbTextureBitmapPixels, pFilter);

	// Tidy up before returning
	delete[] pbTextureBitmapPixels;
	pbTextureBitmapPixels = NULL;

	return bSuccess;
}
// End of function 'ImportPixelsFromCanvasBitmap'


// Function:	ImportPixelsFromTextureBitmap(pbBitmapPixels, pFilter)
// Overview:	Import and filter pixels from a bitmap representing
//				only this texture.  Return TRUE upon success, FALSE
//				otherwise.
BOOL CJamTexture::ImportPixelsFromTextureBitmap(BYTE* pbBitmapPixels, CJamTextureFilter* pFilter)
{
	// Just use the FilterPixels with these pixels
	if (!FilterPixels(pbBitmapPixels, pFilter))
		return FALSE;

	// Set the transparency of the texture based on whether the
	// new texture uses the transparent palette index, but only if
	// the relevant option has been selected.
	if (s_bGuessTransparency)
		GuessTransparency();

	return TRUE;
}
// End of function 'ImportPixelsFromTextureBitmap'


// Function:	ExportPixelsToCanvasBitmap(pbBitmapPixels)
// Overview:	Put the current decoded pixels into the given buffer,
//				in the correct place (as designated by the rect defined
//				in the texture header) for exporting to a bitmap file.
BOOL CJamTexture::ExportPixelsToCanvasBitmap(BYTE* pbBitmapPixels)
{
	// Make sure the bitmap buffer has been allocated
	ASSERT(NULL != pbBitmapPixels);
	if (NULL == pbBitmapPixels)
		return FALSE;

	// Make sure we've got a decoded texture to export
	if (NULL == m_pbDecodedTexturePixels)
		DecodePixels(1);	// default to palette 1, if necessary
	if (NULL == m_pbDecodedTexturePixels)
		return FALSE;

	// Copy the decoded pixels into the bitmap
	BOOL bSuccess = CopyTexturePixels(m_pbDecodedTexturePixels, FALSE, pbBitmapPixels, TRUE);

	// Make sure the texture is _drawn_ properly next time
	m_nLastPaletteUsed = PAL_REBUILD_TEXTURE;

	return bSuccess;
}
// End of function 'ExportPixelsToCanvasBitmap'


// Function:	ExportPixelsToTextureBitmap(pbBitmapPixels)
// Overview:	Copy the current decoded pixels to the given buffer,
//				for exporting to a bitmap file.
BOOL CJamTexture::ExportPixelsToTextureBitmap(BYTE* pbBitmapPixels)
{
	// Make sure the bitmap buffer has been allocated
	ASSERT(NULL != pbBitmapPixels);
	if (NULL == pbBitmapPixels)
		return FALSE;

	// Make sure we've got a decoded texture to export
	if (NULL == m_pbDecodedTexturePixels)
		DecodePixels(1);	// default to palette 1, if necessary
	if (NULL == m_pbDecodedTexturePixels)
		return FALSE;

	// Simple stuff, assuming the buffer is of the correct size
	memcpy(pbBitmapPixels, m_pbDecodedTexturePixels, GetNumTextureBytes());

	return TRUE;
}
// End of function 'ExportPixelsToTextureBitmap'



// Filtering and animating
//

// Function:	ImportAnimation(animation)
// Overview:	Put the given animation frames into the 4 palettes
//				of this texture.  Return TRUE upon success, or FALSE
//				otherwise.
BOOL CJamTexture::ImportAnimation(CJamTextureAnimation& animation)
{
	// So simple, I love it.
	const BOOL bEmptyPalettesIfPoss = (GetPaletteSize() == 0);
	return CombinePaletteImages(&animation, bEmptyPalettesIfPoss);
}
// End of function 'ImportAnimation'


// Function:	ApplyFilter(pFilter)
// Overview:	Recreate the palettes and raw pixels for this texture
//				using the given filter.  Return TRUE if successful,
//				or FALSE otherwise.
BOOL CJamTexture::ApplyFilter(CJamTextureFilter* pFilter)
{
	// To re-apply a filter, we first need to get the original
	// bitmap pixels back.  We do this by simply decoding the pixels
	// using palette #1
	if (!DecodePixels(1))
		return FALSE;

	// Then we can use the usual FilterPixels with these pixels
	return FilterPixels(m_pbDecodedTexturePixels, pFilter);
}
// End of function 'ApplyFilter'


// Function:	FilterPixels(pFilter)
// Overview:	Create the palettes and raw pixels for this texture
//				using the given filter.  Return TRUE if successful,
//				or FALSE otherwise.
BOOL CJamTexture::FilterPixels(BYTE* pbBitmapPixels, CJamTextureFilter* pFilter)
{
	// Make sure we've not been passed a duff pointer to the filter
	if (NULL == pFilter)
		return FALSE;

	// Set up the filter with the pixels we've been given
	BOOL bSuccess = pFilter->PrepareFilter(pbBitmapPixels, GetRect().Size());
	if (!bSuccess)
		return FALSE;

	// OK, I *hate* hard-coding like this, but I'm being lazy here.
	// I'd rather hard-code than the pollute the interface of all
	// of the filters...

	// If we're using the one filter type that will produce empty
	// (or meaningless) local palettes, check to see whether the
	// user has the option set to produce palettes, remove the
	// palettes, or keep the texture in its current palette form.
	BOOL bEmptyPalettesIfPoss = FALSE;
	if (pFilter->GetFilterID() == NULL_FILTER)
	{
		switch ((int)CNullFilter::s_nPalettePreservation)
		{
		case CNullFilter::REMOVE_PALETTE:
			bEmptyPalettesIfPoss = TRUE;
			break;
		case CNullFilter::CREATE_PALETTE:
			bEmptyPalettesIfPoss = FALSE;
			break;
		case CNullFilter::MAINTAIN_PALETTE:
		default:
			bEmptyPalettesIfPoss = (GetPaletteSize() == 0);
			break;
		}
	}

	// Now do the funky image-combining thing
	return CombinePaletteImages(pFilter, bEmptyPalettesIfPoss);
}
// End of function 'FilterPixels'


// Function:	CombinePaletteImages(pSource)
// Overview:	Combine the palette images provided by the given source
//				into a new set of raw texture pixels.  Return TRUE upon
//				success, or FALSE if we fail.
BOOL CJamTexture::CombinePaletteImages(CPaletteImageSource* pSource,
									   const BOOL bEmptyPalettesIfPoss)
{
	// Check that we've been passed a valid source
	ASSERT(NULL != pSource);
	if (NULL == pSource)
		return FALSE;

	// Get on with actually combining the palette images into a
	// new set of raw texture pixels.
	CLocalPaletteArray localPalettes;
	BYTE* pbRawTexturePixels = NULL;
	CPaletteImageCombiner combiner;
	BOOL bSuccess = combiner.CombineBitmaps(*pSource, pbRawTexturePixels, localPalettes, bEmptyPalettesIfPoss);

	// Check to see that everything went ok before continuing
	if (!bSuccess)
	{
		// Get rid of any pixels which may have been created
		if (NULL != pbRawTexturePixels)
		{
			delete[] pbRawTexturePixels;
			pbRawTexturePixels = NULL;
		}

		// Make sure the texture is fully redrawn
		m_nLastPaletteUsed = PAL_REBUILD_TEXTURE;

		return FALSE;
	}

	// For simplicity, we'll just keep the palettes made in
	// the filtering process rather than copying them
	localPalettes.m_bDeleteOnDestroy = FALSE;
	DestroyPalettes();
	m_pPalette1 = localPalettes[0];
	m_pPalette2 = localPalettes[1];
	m_pPalette3 = localPalettes[2];
	m_pPalette4 = localPalettes[3];
	m_pTextureInfo->m_wLocalPaletteSize = (WORD)localPalettes.GetPaletteSize();

	// Guess flag 8?
	if (s_bGuessNoPalettes)
		SetFlag(TF_NO_LOCAL_PALETTES, (0 == m_pTextureInfo->m_wLocalPaletteSize));

	// Now just copy the raw texture pixels
	if (NULL != m_pbRawTexturePixels)
		delete[] m_pbRawTexturePixels;
	m_pbRawTexturePixels = pbRawTexturePixels;

	// Now set the texture to be fully decoded again
	m_nLastPaletteUsed = PAL_REBUILD_TEXTURE;

	// No problem pixels any more :)
	m_bInvalidPixels = FALSE;

	return TRUE;
}
// End of function 'CombinePaletteImages'


// Function:	GuessTransparency()
// Overview:	Set the transparency flag according to whether or not the
//				transparency palette index is used.
void CJamTexture::GuessTransparency()
{
	BOOL bTransparent = FALSE;
	UINT nPalSize = GetPaletteSize();
	if (nPalSize > 0)
	{
		// The local palettes will indicate whether we use the
		// transparency colour
		for (int nPalNum = 1; !bTransparent && nPalNum <= NUM_LOCAL_PALETTES_PER_TEXTURE; nPalNum++)
		{
			BYTE*& palette = GetPalette(nPalNum);
			for (UINT nPalIndex = 0; !bTransparent && nPalIndex < nPalSize; nPalIndex++)
				bTransparent = (GP2_TRANSPARENT_PALETTE_INDEX == palette[nPalIndex]);
		}
	}
	else
	{
		// No local palettes, so we must look through the actual
		// pixels to determine whether the transparency colour
		// is used.
		int nImageSize = GetNumTextureBytes();
		for (int nPixelNum = 0; !bTransparent && nPixelNum < nImageSize; nPixelNum++)
			bTransparent = (GP2_TRANSPARENT_PALETTE_INDEX == m_pbRawTexturePixels[nPixelNum]);
	}

	// Set the new transparency value
	SetFlag(TF_TRANSPARENT, bTransparent);
}
// End of function 'GuessTransparency'

	
// validate and perhaps apply the new value
BOOL CJamTexture::ChangeDataFromEdit(CString newData)
{
	// basically, we change our ID!
	m_pTextureInfo->m_wTextureID=(WORD)atoi(newData);

	// and then we announce change
	DataHasChanged(NULL, HINT_TEXTURE_PROPERTIES_CHANGED, NULL);

	return TRUE;
}

// Tree interaction
BOOL CJamTexture::HandleSelect ()
{
	// Don't select this texture yet - let the document do that
	// as it can also remove the previous selection
	DataHasChanged(NULL, HINT_SELECTED_TEXTURE, this);

	return TRUE;
}

void CJamTexture::DataHasChanged(CView* pView, LPARAM lHint, CObject* pHint)
{
	// We may need to rebuild our decoded pixels if one of
	// the low-detail colours was being set
	if ((PAL_LOW_DETAIL_COLOR == m_nLastPaletteUsed) &&
		(HINT_CHANGED_LOW_DETAIL_COLOUR == lHint))
		m_nLastPaletteUsed = PAL_REBUILD_TEXTURE;

	// Now just call the base class
	CJamTextureProperties::DataHasChanged(pView, lHint, pHint);
}

// Gp3Setup.cpp
// Copyright � Viktor Gars 2000


#include "fstream.h"
#include "io.h"
#include "string.h"

bool CheckSum(char file[255]);
bool Convert(char* file);
bool ConverAll(void);
void Help(void);

void main(int argc, char* argv[])
{
	if(argc!=1)
	{
		if(*argv[1]=='*')
			ConverAll();
		else if(*argv[1]=='?')
			Help();
		else
			Convert(argv[1]);
	}
	else
	{
		Help();
	}
}

bool Convert(char* file)
{
char ch[80];
ifstream f;
ofstream of;
char gp3file[255];
int i;

	f.open(file,ios::in|ios::binary|ios::nocreate);	
	if(f.is_open()!=1)
	{
		cout<<"Error, the file '"<<file<<"' could not be opend";
		return(false);
	}

	//make new file name
	for(i=0;i<strlen(file)-4;i++)
		gp3file[i]=file[i];
	gp3file[i]='G';
	gp3file[i+1]='P';
	gp3file[i+2]='3';
	for(i;i<strlen(file);i++)
		gp3file[i+3]=file[i];
	gp3file[i+3]='\0';


	of.open(gp3file,ios::out|ios::trunc|ios::binary);
	f.seekg(0,ios::beg);
	f.read(ch,sizeof(ch));
	of.seekp(0,ios::beg);
	of.write((char*)&ch,sizeof(ch));
	f.close();
	i=33751042;
	of.write((char*)&i,sizeof(i));
	i=16930;
	of.write((char*)&i,sizeof(i));
	i=0;
	of.write((char*)&i,sizeof(i));
	of.close();
	CheckSum(gp3file);
	cout<<"Gp2 Setup file '"<<file<<"' Converted to Gp3 setup file '"<<gp3file<<"'\n";
	return(true);
}

bool CheckSum(char file[255])
{

long datasize;
unsigned short sum=0,cycle=0;
unsigned char c;

ifstream f;
ofstream of;

	//open track file for reading
	f.open(file,ios::in|ios::out|ios::binary);

	//seek to end-4
	f.seekg(-4,ios::end);
	
	//get pos end-4
	datasize=f.tellg();
	
	//seek to begin of file
	f.seekg(0,ios::beg);

	//loop and calculate checksum
	while (datasize--) 
	{
		f.read((char*)&c,sizeof(c));
		sum += c;
		cycle = (cycle<<3)+(cycle>>13);
		cycle += c;
	}
	//close file
	f.close();

	//open file for writing
	of.open(file,ios::in|ios::out);
	//seek to end-4
	of.seekp(-4,ios::end);
	
	//write checksum at curpos
	of.write((char*)&sum,sizeof(sum));
	of.write((char*)&cycle,sizeof(cycle));
	//close file
	of.close();
	//return true
	return(true);
}

bool ConverAll(void)
{
struct _finddata_t c_file;
long hFile;

	/* Find first .c file in current directory */
	if( (hFile = _findfirst( "*.cs*", &c_file )) == -1L )
		cout<<"No '*.cs*' files in current directory!\n";
	else
	{
		if(c_file.size==84)
			Convert(c_file.name);
		/* Find the rest of the .c files */
		while( _findnext( hFile, &c_file ) == 0 )
		{
			if(c_file.size==84)
				Convert(c_file.name);
		}
		_findclose( hFile );
	}
	return(true);
}

void Help(void)
{
	cout<<"\nGp3 Car Setup Converter v1.0 by Viktor Gars 2000\n";
	cout<<"Homepage: http://www.vgsoftware.com/\ne-mail: viktor.gars@telia.com\n\n";
	cout<<"Usage: Gp3Set [<filename>] [*]\n\n";
	cout<<"<filename>   Convert the Gp2 setup file to a Gp3 setup file.\n";
	cout<<"*            Convert all Gp2 setup files in the current directory to\n";
	cout<<"             Gp3 setup files.\n";
}
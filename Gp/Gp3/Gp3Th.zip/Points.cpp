// Points.cpp : implementation file
//

#include "stdafx.h"
#include "Gp3Th.h"
#include "Points.h"
#include "FileHandling.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPoints dialog


CPoints::CPoints(CWnd* pParent /*=NULL*/)
	: CDialog(CPoints::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPoints)
	m_Edit1 = 0;
	m_Edit10 = 0;
	m_Edit11 = 0;
	m_Edit12 = 0;
	m_Edit13 = 0;
	m_Edit9 = 0;
	m_Edit8 = 0;
	m_Edit7 = 0;
	m_Edit6 = 0;
	m_Edit5 = 0;
	m_Edit4 = 0;
	m_Edit26 = 0;
	m_Edit3 = 0;
	m_Edit21 = 0;
	m_Edit22 = 0;
	m_Edit23 = 0;
	m_Edit24 = 0;
	m_Edit25 = 0;
	m_Edit20 = 0;
	m_Edit2 = 0;
	m_Edit16 = 0;
	m_Edit15 = 0;
	m_Edit14 = 0;
	m_Edit17 = 0;
	m_Edit18 = 0;
	m_Edit19 = 0;
	//}}AFX_DATA_INIT
}


void CPoints::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPoints)
	DDX_Control(pDX, IDC_SPIN9, m_Spin9);
	DDX_Control(pDX, IDC_SPIN8, m_Spin8);
	DDX_Control(pDX, IDC_SPIN7, m_Spin7);
	DDX_Control(pDX, IDC_SPIN6, m_Spin6);
	DDX_Control(pDX, IDC_SPIN5, m_Spin5);
	DDX_Control(pDX, IDC_SPIN4, m_Spin4);
	DDX_Control(pDX, IDC_SPIN3, m_Spin3);
	DDX_Control(pDX, IDC_SPIN26, m_Spin26);
	DDX_Control(pDX, IDC_SPIN25, m_Spin25);
	DDX_Control(pDX, IDC_SPIN24, m_Spin24);
	DDX_Control(pDX, IDC_SPIN23, m_Spin23);
	DDX_Control(pDX, IDC_SPIN22, m_Spin22);
	DDX_Control(pDX, IDC_SPIN21, m_Spin21);
	DDX_Control(pDX, IDC_SPIN20, m_Spin20);
	DDX_Control(pDX, IDC_SPIN2, m_Spin2);
	DDX_Control(pDX, IDC_SPIN19, m_Spin19);
	DDX_Control(pDX, IDC_SPIN18, m_Spin18);
	DDX_Control(pDX, IDC_SPIN17, m_Spin17);
	DDX_Control(pDX, IDC_SPIN16, m_Spin16);
	DDX_Control(pDX, IDC_SPIN15, m_Spin15);
	DDX_Control(pDX, IDC_SPIN14, m_Spin14);
	DDX_Control(pDX, IDC_SPIN13, m_Spin13);
	DDX_Control(pDX, IDC_SPIN12, m_Spin12);
	DDX_Control(pDX, IDC_SPIN11, m_Spin11);
	DDX_Control(pDX, IDC_SPIN1, m_Spin1);
	DDX_Control(pDX, IDC_SPIN10, m_Spin10);
	DDX_Text(pDX, IDC_EDIT1, m_Edit1);
	DDV_MinMaxInt(pDX, m_Edit1, 0, 99);
	DDX_Text(pDX, IDC_EDIT10, m_Edit10);
	DDV_MinMaxInt(pDX, m_Edit10, 0, 99);
	DDX_Text(pDX, IDC_EDIT11, m_Edit11);
	DDV_MinMaxInt(pDX, m_Edit11, 0, 99);
	DDX_Text(pDX, IDC_EDIT12, m_Edit12);
	DDV_MinMaxInt(pDX, m_Edit12, 0, 99);
	DDX_Text(pDX, IDC_EDIT13, m_Edit13);
	DDV_MinMaxInt(pDX, m_Edit13, 0, 99);
	DDX_Text(pDX, IDC_EDIT9, m_Edit9);
	DDV_MinMaxInt(pDX, m_Edit9, 0, 99);
	DDX_Text(pDX, IDC_EDIT8, m_Edit8);
	DDV_MinMaxInt(pDX, m_Edit8, 0, 99);
	DDX_Text(pDX, IDC_EDIT7, m_Edit7);
	DDV_MinMaxInt(pDX, m_Edit7, 0, 99);
	DDX_Text(pDX, IDC_EDIT6, m_Edit6);
	DDV_MinMaxInt(pDX, m_Edit6, 0, 99);
	DDX_Text(pDX, IDC_EDIT5, m_Edit5);
	DDV_MinMaxInt(pDX, m_Edit5, 0, 99);
	DDX_Text(pDX, IDC_EDIT4, m_Edit4);
	DDV_MinMaxInt(pDX, m_Edit4, 0, 99);
	DDX_Text(pDX, IDC_EDIT26, m_Edit26);
	DDV_MinMaxInt(pDX, m_Edit26, 0, 99);
	DDX_Text(pDX, IDC_EDIT3, m_Edit3);
	DDV_MinMaxInt(pDX, m_Edit3, 0, 99);
	DDX_Text(pDX, IDC_EDIT21, m_Edit21);
	DDV_MinMaxInt(pDX, m_Edit21, 0, 99);
	DDX_Text(pDX, IDC_EDIT22, m_Edit22);
	DDV_MinMaxInt(pDX, m_Edit22, 0, 99);
	DDX_Text(pDX, IDC_EDIT23, m_Edit23);
	DDV_MinMaxInt(pDX, m_Edit23, 0, 99);
	DDX_Text(pDX, IDC_EDIT24, m_Edit24);
	DDV_MinMaxInt(pDX, m_Edit24, 0, 99);
	DDX_Text(pDX, IDC_EDIT25, m_Edit25);
	DDV_MinMaxInt(pDX, m_Edit25, 0, 99);
	DDX_Text(pDX, IDC_EDIT20, m_Edit20);
	DDV_MinMaxInt(pDX, m_Edit20, 0, 99);
	DDX_Text(pDX, IDC_EDIT2, m_Edit2);
	DDV_MinMaxInt(pDX, m_Edit2, 0, 99);
	DDX_Text(pDX, IDC_EDIT16, m_Edit16);
	DDV_MinMaxInt(pDX, m_Edit16, 0, 99);
	DDX_Text(pDX, IDC_EDIT15, m_Edit15);
	DDV_MinMaxInt(pDX, m_Edit15, 0, 99);
	DDX_Text(pDX, IDC_EDIT14, m_Edit14);
	DDV_MinMaxInt(pDX, m_Edit14, 0, 99);
	DDX_Text(pDX, IDC_EDIT17, m_Edit17);
	DDV_MinMaxInt(pDX, m_Edit17, 0, 99);
	DDX_Text(pDX, IDC_EDIT18, m_Edit18);
	DDV_MinMaxInt(pDX, m_Edit18, 0, 99);
	DDX_Text(pDX, IDC_EDIT19, m_Edit19);
	DDV_MinMaxInt(pDX, m_Edit19, 0, 99);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPoints, CDialog)
	//{{AFX_MSG_MAP(CPoints)
	ON_BN_CLICKED(IDC_CART, OnCart)
	ON_BN_CLICKED(IDC_FORMULAONE, OnFormulaone)
	ON_BN_CLICKED(IDC_ALL, OnAll)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPoints message handlers

void CPoints::SetSpin()
{
	m_Spin1.SetRange(0,99);
	m_Spin2.SetRange(0,99);
	m_Spin3.SetRange(0,99);
	m_Spin4.SetRange(0,99);
	m_Spin5.SetRange(0,99);
	m_Spin6.SetRange(0,99);
	m_Spin7.SetRange(0,99);
	m_Spin8.SetRange(0,99);
	m_Spin9.SetRange(0,99);
	m_Spin10.SetRange(0,99);
	m_Spin11.SetRange(0,99);
	m_Spin12.SetRange(0,99);
	m_Spin13.SetRange(0,99);
	m_Spin14.SetRange(0,99);
	m_Spin15.SetRange(0,99);
	m_Spin16.SetRange(0,99);
	m_Spin17.SetRange(0,99);
	m_Spin18.SetRange(0,99);
	m_Spin19.SetRange(0,99);
	m_Spin20.SetRange(0,99);
	m_Spin21.SetRange(0,99);
	m_Spin22.SetRange(0,99);
	m_Spin23.SetRange(0,99);
	m_Spin24.SetRange(0,99);
	m_Spin25.SetRange(0,99);
	m_Spin26.SetRange(0,99);
}

BOOL CPoints::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// TODO: Add extra initialization here
	SetSpin();
CFileHandling fh;
	fh.LoadMisc(m_TempFile);
	m_Edit1=atoi(fh.GetPoints(0));
	m_Edit2=atoi(fh.GetPoints(1));
	m_Edit3=atoi(fh.GetPoints(2));
	m_Edit4=atoi(fh.GetPoints(3));
	m_Edit5=atoi(fh.GetPoints(4));
	m_Edit6=atoi(fh.GetPoints(5));
	m_Edit7=atoi(fh.GetPoints(6));
	m_Edit8=atoi(fh.GetPoints(7));
	m_Edit9=atoi(fh.GetPoints(8));
	m_Edit10=atoi(fh.GetPoints(9));
	m_Edit11=atoi(fh.GetPoints(10));
	m_Edit12=atoi(fh.GetPoints(11));
	m_Edit13=atoi(fh.GetPoints(12));
	m_Edit14=atoi(fh.GetPoints(13));
	m_Edit15=atoi(fh.GetPoints(14));
	m_Edit16=atoi(fh.GetPoints(15));
	m_Edit17=atoi(fh.GetPoints(16));
	m_Edit18=atoi(fh.GetPoints(17));
	m_Edit19=atoi(fh.GetPoints(18));
	m_Edit20=atoi(fh.GetPoints(19));
	m_Edit21=atoi(fh.GetPoints(20));
	m_Edit22=atoi(fh.GetPoints(21));
	m_Edit23=atoi(fh.GetPoints(22));
	m_Edit24=atoi(fh.GetPoints(23));
	m_Edit25=atoi(fh.GetPoints(24));
	m_Edit26=atoi(fh.GetPoints(25));

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPoints::OnCart() 
{
	m_Edit1=20;
	m_Edit2=16;
	m_Edit3=14;
	m_Edit4=12;
	m_Edit5=10;
	m_Edit6=8;
	m_Edit7=6;
	m_Edit8=5;
	m_Edit9=4;
	m_Edit10=3;
	m_Edit11=2;
	m_Edit12=1;
	m_Edit13=0;
	m_Edit14=0;
	m_Edit15=0;
	m_Edit16=0;
	m_Edit17=0;
	m_Edit18=0;
	m_Edit19=0;
	m_Edit20=0;
	m_Edit21=0;
	m_Edit22=0;
	m_Edit23=0;
	m_Edit24=0;
	m_Edit25=0;
	m_Edit26=0;
	UpdateData(FALSE);
}

void CPoints::OnFormulaone() 
{
	m_Edit1=10;
	m_Edit2=6;
	m_Edit3=4;
	m_Edit4=3;
	m_Edit5=2;
	m_Edit6=1;
	m_Edit7=0;
	m_Edit8=0;
	m_Edit9=0;
	m_Edit10=0;
	m_Edit11=0;
	m_Edit12=0;
	m_Edit13=0;
	m_Edit14=0;
	m_Edit15=0;
	m_Edit16=0;
	m_Edit17=0;
	m_Edit18=0;
	m_Edit19=0;
	m_Edit20=0;
	m_Edit21=0;
	m_Edit22=0;
	m_Edit23=0;
	m_Edit24=0;
	m_Edit25=0;
	m_Edit26=0;
	UpdateData(FALSE);
}

void CPoints::OnOK() 
{
CFileHandling fh;
CString p;
char ch[20];

	UpdateData(TRUE);
	fh.LoadMisc(m_TempFile);

	itoa(m_Edit1,ch,10);
	p=ch;
	p+="|";
	itoa(m_Edit2,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit3,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit4,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit5,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit6,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit7,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit8,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit9,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit10,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit11,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit12,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit13,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit14,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit15,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit16,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit17,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit18,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit19,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit20,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit21,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit22,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit23,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit24,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit25,ch,10);
	p+=ch;
	p+="|";
	itoa(m_Edit26,ch,10);
	p+=ch;
	p+="|";
	fh.SetPoints(p);
	fh.SaveMisc(m_TempFile);

	CDialog::OnOK();
}

void CPoints::OnAll() 
{
	m_Edit1=26;
	m_Edit2=25;
	m_Edit3=24;
	m_Edit4=23;
	m_Edit5=22;
	m_Edit6=21;
	m_Edit7=20;
	m_Edit8=19;
	m_Edit9=18;
	m_Edit10=17;
	m_Edit11=16;
	m_Edit12=15;
	m_Edit13=14;
	m_Edit14=13;
	m_Edit15=12;
	m_Edit16=11;
	m_Edit17=10;
	m_Edit18=9;
	m_Edit19=8;
	m_Edit20=7;
	m_Edit21=6;
	m_Edit22=5;
	m_Edit23=4;
	m_Edit24=3;
	m_Edit25=2;
	m_Edit26=1;
	UpdateData(FALSE);	
}

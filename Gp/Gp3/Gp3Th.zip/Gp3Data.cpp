// Gp3Data.cpp: implementation of the Gp3Data class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Gp3Th.h"
#include "Gp3Data.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW/
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Gp3Data::Gp3Data()
{

}

Gp3Data::~Gp3Data()
{

}

bool Gp3Data::LoadData(CString file)
{
CFile f;
int i;
WIN32_FIND_DATA wfd;
HANDLE hFile;
char buf[23];

	hFile=FindFirstFile(file+"\\gp3.exe",&wfd);
	if(hFile!=(HANDLE)-1)
	{
		f.Open(file+"\\gp3.exe",CFile::modeRead,NULL);
		
		//Points
		f.Seek(7582806,CFile::begin);
		for(i=0;i<26;i++)
			f.Read((char*)&m_Points[i],sizeof(byte));

		//Laps
		f.Seek(1325694,CFile::begin);
		for(i=0;i<16;i++)
			f.Read((char*)&m_Laps[i],sizeof(byte));
		
		//Length
		f.Seek(7582646,CFile::begin);
		for(i=0;i<16;i++)
		{
			f.Read((char*)&m_Length[i][0],sizeof(short int));
			f.Read((char*)&m_Length[i][1],sizeof(short int));
			f.Seek(6,CFile::current);
		}
		f.Close();
	}
	else
	{
		AfxMessageBox("Gp3.exe not found in your Gp3 directory, "+file+".");
		return(false);
	}
	hFile=FindFirstFile(file+"\\f1gstate.sav",&wfd);
	if(hFile!=(HANDLE)-1)
	{
		f.Open(file+"\\f1gstate.sav",CFile::modeRead,NULL);
		f.Seek(1558,CFile::begin);
		int tmp=0;
		for(i=0;i<32;i++)
		{
			f.Read((char*)&buf,24);
			m_Driver[i]=buf;
			f.Read((char*)&buf,14);
			m_Team[i]=buf;
			f.Read((char*)&m_Time[i],sizeof(m_Time[i]));
			f.Read((char*)&m_Date[i],sizeof(m_Date[i]));
			if(tmp==1)
			{
				f.Seek(1,CFile::current);
				tmp=0;
			}
			else
				tmp++;
		}
		f.Close();
	}
	else
	{
		AfxMessageBox("f1gstate.sav was not found in your Gp3 directory, "+file+".");
	}
	return(true);
}

bool Gp3Data::SaveData(CString file)
{
CFile f;
int i;
	f.Open(file,CFile::modeWrite,NULL);

	//Points
	f.Seek(7582806,CFile::begin);
	for(i=0;i<26;i++)
		f.Write((char*)&m_Points[i],sizeof(byte));

	//Laps
	f.Seek(1325694,CFile::begin);
	for(i=0;i<16;i++)
		f.Write((char*)&m_Laps[i],sizeof(byte));
	
	//Length
	f.Seek(7582646,CFile::begin);
	for(i=0;i<16;i++)
	{
		f.Write((char*)&m_Length[i][0],sizeof(short int));
		f.Write((char*)&m_Length[i][1],sizeof(short int));
		f.Seek(6,CFile::current);
	}

	return(true);
}

void Gp3Data::SetLaps(int track,CString laps)
{
int i;
	i=atoi(laps);
	if(i>=3&&i<=127)
		m_Laps[track]=i;
	else if(i>127)
		m_Laps[track]=127;
	else if(i<3)
		m_Laps[track]=3;
}

CString Gp3Data::GetLaps(int track)
{
char ch[20];
	itoa(m_Laps[track],ch,10);
	return(ch);
}

void Gp3Data::SetLength(int track, CString length)
{
	m_Length[track][0]=atoi(length);
	m_Length[track][1]=(int)(atoi(length)/0.30480);
}

CString Gp3Data::GetLength(int track)
{
char ch[20];
	itoa(m_Length[track][0],ch,10);
	return(ch);
}

void Gp3Data::SetWare(int track, CString ware)
{
	m_Ware[track]=atoi(ware);
}

CString Gp3Data::GetWare(int track)
{
char ch[20];
	itoa(m_Ware[track],ch,10);
	return(ch);
}

void Gp3Data::SetPoint(int pos,CString points)
{
	m_Points[pos]=atoi(points);
}

CString Gp3Data::GetPoint(int pos)
{
char ch[20];
	itoa(m_Points[pos],ch,10);
	return(ch);
}

void Gp3Data::SetQualDriver(int track,CString name)
{
	m_Driver[track*2]=name;
}

CString Gp3Data::GetQualDriver(int track)
{
	return(m_Driver[track*2]);
}

void Gp3Data::SetRaceDriver(int track, CString name)
{
	m_Driver[(track*2)+1]=name;
}

CString Gp3Data::GetRaceDriver(int track)
{
	return(m_Driver[(track*2)+1]);
}

void Gp3Data::SetQualTeam(int track, CString team)
{
	m_Team[track*2]=team;
}

CString Gp3Data::GetQualTeam(int track)
{
	return(m_Team[track*2]);
}

void Gp3Data::SetRaceTeam(int track, CString team)
{
	m_Team[(track*2)+1]=team;
}

CString Gp3Data::GetRaceTeam(int track)
{
	return(m_Team[(track*2)+1]);
}

void Gp3Data::SetQualDate(int track, CString days)
{
	m_Date[track*2]=atoi(days);
}

CString Gp3Data::GetQualDate(int track)
{
char buf[260];
	itoa(m_Date[track*2],buf,10);
	return(buf);
}

void Gp3Data::SetRaceDate(int track, CString days)
{
	m_Date[(track*2)+1]=atoi(days);
}

CString Gp3Data::GetRaceDate(int track)
{
char buf[260];
	itoa(m_Date[(track*2)+1],buf,10);
	return(buf);
}

void Gp3Data::SetQualTime(int track, CString time)
{
	m_Time[track*2]=atoi(time);
}

CString Gp3Data::GetQualTime(int track)
{
char buf[260];
	itoa(m_Time[track*2],buf,10);
	return(buf);
}

void Gp3Data::SetRaceTime(int track, CString time)
{
	m_Time[(track*2)+1]=atoi(time);
}

CString Gp3Data::GetRaceTime(int track)
{
char buf[260];
	itoa(m_Time[(track*2)+1],buf,10);
	return(buf);
}

// NightFilterDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "NightFilterDlg.h"

#include "NightFilter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNightFilterDlg dialog


CNightFilterDlg::CNightFilterDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNightFilterDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNightFilterDlg)
	m_strCurrentTime = _T("");
	//}}AFX_DATA_INIT
}


void CNightFilterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNightFilterDlg)
	DDX_Control(pDX, IDC_TIME_SLIDER, m_sdrTimeSlider);
	DDX_Text(pDX, IDC_CURRENT_TIME, m_strCurrentTime);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNightFilterDlg, CDialog)
	//{{AFX_MSG_MAP(CNightFilterDlg)
	ON_WM_HSCROLL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNightFilterDlg message handlers

BOOL CNightFilterDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// Set up the slider to allow only those values accepted
	// by CNightFilter.
	m_sdrTimeSlider.SetRange(CNightFilter::MIN_TIME_INDEX,
							 CNightFilter::MAX_TIME_INDEX);
	m_sdrTimeSlider.SetPos(m_nTimeIndex);

	UpdateCurrentTimeText();

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CNightFilterDlg::OnOK() 
{
	// The only control in the dialog has a strictly-controlled range,
	// so we don't really need to validate anything, but we do need
	// to store the values, so...
	if (!UpdateData(TRUE))
		return;

	CDialog::OnOK();
}


// Function:	OnHScroll(nSBCode, nPos, pScrollBar)
// Overview:	Horizontal scrollbar handler, used to intercept messages
//				from the dialog's slider control.
void CNightFilterDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// Make sure it's the slider we're after
	if (NULL != pScrollBar &&
		pScrollBar->GetSafeHwnd() == m_sdrTimeSlider.GetSafeHwnd())
	{
		// Figure out where the slider's position currently is
		if (SB_THUMBPOSITION == nSBCode || SB_THUMBTRACK == nSBCode)
			m_nTimeIndex = (int)nPos;
		else
			m_nTimeIndex = ((CSliderCtrl *)pScrollBar)->GetPos();

		// Update the text indicator to say what the currently
		// selected time is.
		UpdateCurrentTimeText();
	}

	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}
// End of function 'OnHScroll'


// Function:	UpdateCurrentTimeText()
// Overview:	Update the static indicator showing the currently
//				selected time of evening.
void CNightFilterDlg::UpdateCurrentTimeText()
{
	// Work out the time, starting from 7pm and adding 15mins
	// for each increment on the slider.
	CTime timeFilter(2000, 1, 1, 19, 0, 0);	// 01/Jan/00 19:00
	const int nHours = m_nTimeIndex / 4;
	const int nMinutes = (m_nTimeIndex % 4) * 15;
	CTimeSpan timeAfter7pm(0, nHours, nMinutes, 0);
	timeFilter += timeAfter7pm;

	// Format the time in h:mm format and append 'pm'
	m_strCurrentTime.Format("%spm", timeFilter.Format("%#I:%M"));
	CDataExchange dx(this, FALSE);
	try
	{
		DDX_Text(&dx, IDC_CURRENT_TIME, m_strCurrentTime);
	}
	catch (CException* pExc)
	{
		// Somehow the exchange of data to the text control failed! :(
		ASSERT(FALSE);

		// Never mind - just get on with things as best we can.
		pExc->Delete();
	}
}
// End of function 'UpdateCurrentTimeText'


// Set the integer value representing the number of quarter-hours
// past 7pm that the Night Filter simulates
BOOL CNightFilterDlg::SetTimeIndex(const int nTimeIndex)
{
	// Make sure the value we're being given is in the valid range
	if ((nTimeIndex < CNightFilter::MIN_TIME_INDEX) ||
		(nTimeIndex > CNightFilter::MAX_TIME_INDEX))
		return FALSE;

	// Store the new value
	m_nTimeIndex = nTimeIndex;

	return TRUE;
}

// Get the integer value representing the number of quarter-hours
// past 7pm that the Night Filter simulates
int CNightFilterDlg::GetTimeIndex() const
{
	return m_nTimeIndex;
}


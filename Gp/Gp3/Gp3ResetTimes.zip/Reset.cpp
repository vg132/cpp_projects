// Reset.cpp

// Copyright � Viktor Gars 2000

#include "fstream.h"
#include "io.h"

bool reset(void);
bool CheckSum(char* file);


int three=180000;
ofstream fout;

void main()
{
	cout <<"\nGp3 Reset Record v1.0\n";
	cout <<"(C) 2000 by Viktor Gars <http://www.vgsoftware.com/> or <viktor.gars@telia.com>\n";
	cout <<"This program will reset all track records in Gp3 to 3 minutes\n";

	if(!reset())
		cout<<"\nError when reseting records!\n";
	else
		cout<<"\nAll records reseted to 3 minutes\n";
}

bool reset(void)
{
int i;
	fout.open("f1gstate.sav",ios::in|ios::out|ios::nocreate);
	i=fout.is_open();
	if(i==1)
	{
		fout.seekp(1596,ios::beg);
		for(i=0;i<17;i++)
		{
			fout.write((char*)&three,sizeof(three));
			fout.seekp(1596+(i*89),ios::beg);
		}

		fout.seekp(1640,ios::beg);
		for(i=0;i<17;i++)
		{
			fout.write((char*)&three,sizeof(three));
			fout.seekp(1640+(i*89),ios::beg);
		}


		fout.close();
		if(!CheckSum("f1gstate.sav"))
			cout<<"\nError when writing checksum!\n";
		return(true);
	}
	else
	{
		cout<<"\nf1gstate.sav was not found in this directory\nYou must run this program in your Gp3 directory.";
	}
	return(false);
}

bool CheckSum(char* file)
{

long datasize;
unsigned short sum=0,cycle=0;
unsigned char c;

ifstream f;
ofstream of;

	//open track file for reading
	f.open(file,ios::in|ios::out|ios::binary);

	//seek to end-4
	f.seekg(-4,ios::end);
	
	//get pos end-4
	datasize=f.tellg();
	
	//seek to begin of file
	f.seekg(0,ios::beg);

	//loop and calculate checksum
	while (datasize--) 
	{
		f.read((char*)&c,sizeof(c));
		sum += c;
		cycle = (cycle<<3)+(cycle>>13);
		cycle += c;
	}
	//close file
	f.close();

	//open file for writing
	of.open(file,ios::in|ios::out);
	//seek to end-4
	of.seekp(-4,ios::end);
	
	//write checksum at curpos
	of.write((char*)&sum,sizeof(sum));
	of.write((char*)&cycle,sizeof(cycle));
	//close file
	of.close();
	//return true
	return(true);
}

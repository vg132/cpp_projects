// JamTextureAnimation.cpp - implementation of the CJamTextureAnimation class
//

#include "stdafx.h"
#include "resource.h"

#include "JamTextureAnimation.h"

#include "PixelBlitter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CJamTextureAnimation

// Constructor
CJamTextureAnimation::CJamTextureAnimation()
{
	// Not yet loaded the images
	m_bLoaded = FALSE;
	m_sizAnimation = CSize(-1,-1);

	// Prepare the unpadded buffers
	m_UnpaddedBuffers.SetSize(NUM_LOCAL_PALETTES_PER_TEXTURE);
	for (int nPalNum = 0; nPalNum < NUM_LOCAL_PALETTES_PER_TEXTURE; nPalNum++)
		m_UnpaddedBuffers[nPalNum] = NULL;
}

// Destructor
CJamTextureAnimation::~CJamTextureAnimation()
{
	// Destroy any unpadded buffers we allocated
	for (int nPalNum = 0; nPalNum < NUM_LOCAL_PALETTES_PER_TEXTURE; nPalNum++)
	{
		if (m_UnpaddedBuffers[nPalNum] != NULL)
			delete[] m_UnpaddedBuffers[nPalNum];
	}
}


// Function:	SetFiles(lstFiles)
// Overview:	Set the files to use as the frames of the animation,
//				loading them into m_arrBitmaps.  Return FALSE if any
//				of the bitmaps is invalid or if they are not all the
//				same size, otherwise return TRUE.
BOOL CJamTextureAnimation::SetFiles(const CStringList& lstFiles)
{
	// Prevent reuse of thi object if we've already
	// loaded an animation
	ASSERT(!m_bLoaded);
	if (m_bLoaded)
		return FALSE;

	// Check to see that there are the correct number of
	// files in the list
	ASSERT(NUM_LOCAL_PALETTES_PER_TEXTURE == lstFiles.GetCount());
	if (NUM_LOCAL_PALETTES_PER_TEXTURE != lstFiles.GetCount())
		return FALSE;

	// Loop through the filenames in the list, loading each into
	// the relevant GP2Bitmap in turn
	int nPaletteNum = 0;
	BOOL bFailedToLoad = FALSE;
	BOOL bDifferentSizes = FALSE;
	POSITION posFilename = lstFiles.GetHeadPosition();
	while (NULL != posFilename && !bFailedToLoad && !bDifferentSizes)
	{
		// Attempt to load the next file
		CString strFilename = lstFiles.GetNext(posFilename);
		bFailedToLoad = !m_arrBitmaps[nPaletteNum].LoadFile(strFilename);
		if (bFailedToLoad)
			continue;

		// Make sure it's the same size as all of the others
		if (m_sizAnimation == CSize(-1,-1))
			m_sizAnimation = m_arrBitmaps[nPaletteNum].GetSize();
		else
			bDifferentSizes = (m_sizAnimation != m_arrBitmaps[nPaletteNum].GetSize());

		// Move onto the next one
		nPaletteNum++;
	}

	// If the bitmaps are different sizes, report it here (if they
	// failed to load, CGP2Bitmap::LoadFile will already have told
	// the user this).
	if (bDifferentSizes)
		AfxMessageBox(IDS_ERR_ANIMATION_BMPS_DIFF_SIZES);

	// If it's all worked, record the fact that we now have a
	// valid set of images and copied the pixels into unpadded
	// buffers
	m_bLoaded = !(bFailedToLoad || bDifferentSizes);
	if (m_bLoaded)
	{
		CPixelBlitter blitter;
		CSize sizPaddedBitmap(m_arrBitmaps[0].GetPaddedWidth(), m_sizAnimation.cy);
		for (int nPalNum = 0; nPalNum < NUM_LOCAL_PALETTES_PER_TEXTURE; nPalNum++)
		{
			// Get the pixels from the bitmap, BUT DON'T get any padding
			// pixels required by the bitmap format!
			m_UnpaddedBuffers[nPalNum] = new BYTE[m_arrBitmaps[nPalNum].GetWidth() * m_arrBitmaps[nPalNum].GetHeight()];
			blitter.CopyPixels(m_arrBitmaps[nPalNum].GetPixels(), sizPaddedBitmap, CRect(CPoint(0,0), m_sizAnimation),
							   m_UnpaddedBuffers[nPalNum], m_sizAnimation, CPoint(0,0));
		}
		
	}

	// Return indicating success or failure
	return m_bLoaded;
}
// End of function 'SetFiles'


// Function:	GetBitmaps(pixelBuffers, sizImage)
// Overview:	Overridden function to retrieve the pixel buffers to
//				the 4 bitmaps this object provides.
BOOL CJamTextureAnimation::GetBitmaps(CPixelBufferArray& pixelBuffers, CSize& sizImage)
{
	// Make sure we've got a valid set of bitmaps loaded
	ASSERT(m_bLoaded);
	if (!m_bLoaded)
		return FALSE;

	// Check to see that there are the correct number of
	// buffers in the array we've been passed
	ASSERT(NUM_LOCAL_PALETTES_PER_TEXTURE == pixelBuffers.GetSize());
	if (NUM_LOCAL_PALETTES_PER_TEXTURE != pixelBuffers.GetSize())
		return FALSE;

	// Loop through the unpadded versions of the bitmaps we've got, copying
	// the pixel buffers into the array we've been passed.
	for (int nPalNum = 0; nPalNum < NUM_LOCAL_PALETTES_PER_TEXTURE; nPalNum++)
	{
		ASSERT(NULL == pixelBuffers[nPalNum]);
		pixelBuffers[nPalNum] = new BYTE[m_sizAnimation.cx * m_sizAnimation.cy];
		memcpy(pixelBuffers[nPalNum], m_UnpaddedBuffers[nPalNum], m_sizAnimation.cx * m_sizAnimation.cy);
	}
	sizImage = m_sizAnimation;

	return TRUE;
}
// End of function 'GetBitmaps'


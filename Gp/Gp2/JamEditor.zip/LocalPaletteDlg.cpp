// LocalPaletteDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "LocalPaletteDlg.h"

#include "JamTexture.h"
#include "JamConstants.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLocalPaletteDlg dialog

int CLocalPaletteDlg::s_nLastIndexEdited = 0;

CLocalPaletteDlg::CLocalPaletteDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLocalPaletteDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLocalPaletteDlg)
	m_nPaletteIndex = -1;
	m_nPalette2 = 0;
	m_nPalette1 = 0;
	m_nPalette3 = 0;
	m_nPalette4 = 0;
	//}}AFX_DATA_INIT

	// Don't create our copy of the palettes until we've got the
	// texture and we're about to show the dialog
	m_pbPalettes = NULL;
}

CLocalPaletteDlg::~CLocalPaletteDlg()
{
	// Delete our copy of the local palettes
	if (NULL != m_pbPalettes)
	{
		for (int nPalNum = 0; nPalNum < NUM_LOCAL_PALETTES_PER_TEXTURE; nPalNum++)
			delete[] m_pbPalettes[nPalNum];
		delete[] m_pbPalettes;
	}
}

void CLocalPaletteDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLocalPaletteDlg)
	DDX_Control(pDX, IDC_SPIN_PALETTE4, m_spnPalette4);
	DDX_Control(pDX, IDC_SPIN_PALETTE3, m_spnPalette3);
	DDX_Control(pDX, IDC_SPIN_PALETTE2, m_spnPalette2);
	DDX_Control(pDX, IDC_SPIN_PALETTE1, m_spnPalette1);
	DDX_Control(pDX, IDC_PALETTE_INDEX, m_cboPaletteIndices);
	DDX_CBIndex(pDX, IDC_PALETTE_INDEX, m_nPaletteIndex);
	DDX_Text(pDX, IDC_EDIT_PALETTE2, m_nPalette2);
	DDV_MinMaxUInt(pDX, m_nPalette2, 0, 255);
	DDX_Text(pDX, IDC_EDIT_PALETTE1, m_nPalette1);
	DDV_MinMaxUInt(pDX, m_nPalette1, 0, 255);
	DDX_Text(pDX, IDC_EDIT_PALETTE3, m_nPalette3);
	DDV_MinMaxUInt(pDX, m_nPalette3, 0, 255);
	DDX_Text(pDX, IDC_EDIT_PALETTE4, m_nPalette4);
	DDV_MinMaxUInt(pDX, m_nPalette4, 0, 255);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLocalPaletteDlg, CDialog)
	//{{AFX_MSG_MAP(CLocalPaletteDlg)
	ON_CBN_SELCHANGE(IDC_PALETTE_INDEX, OnSelectPaletteIndex)
	ON_EN_KILLFOCUS(IDC_EDIT_PALETTE1, OnConfirmPaletteValue)
	ON_EN_KILLFOCUS(IDC_EDIT_PALETTE2, OnConfirmPaletteValue)
	ON_EN_KILLFOCUS(IDC_EDIT_PALETTE3, OnConfirmPaletteValue)
	ON_EN_KILLFOCUS(IDC_EDIT_PALETTE4, OnConfirmPaletteValue)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLocalPaletteDlg message handlers

BOOL CLocalPaletteDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// Refuse to show the dialog if we've not been given a texture
	ASSERT(NULL != m_pTexture);
	if (NULL == m_pTexture)
	{
		EndDialog(-1);
		return TRUE;
	}

	// Refuse to show the dialog if the texture has no local palettes
	UINT nPaletteSize = m_pTexture->GetPaletteSize();
	if (0 == nPaletteSize)
	{
		EndDialog(IDCANCEL);
		AfxMessageBox(IDS_ERR_NO_LOCAL_PALETTES_TO_EDIT);
		return TRUE;
	}

	// Make a copy of the palettes to edit in the dialog.  Having
	// a copy allows us to cancel the whole operation very easily.
	ASSERT(NULL == m_pbPalettes);
	m_pbPalettes = new BYTE*[NUM_LOCAL_PALETTES_PER_TEXTURE];
	ASSERT(NULL != m_pbPalettes);
	if (NULL == m_pbPalettes)
	{
		EndDialog(-1);
		return TRUE;
	}
	for (int nPalNum = 0; nPalNum < NUM_LOCAL_PALETTES_PER_TEXTURE; nPalNum++)
	{
		m_pbPalettes[nPalNum] = new BYTE[nPaletteSize];
		ASSERT(NULL != m_pbPalettes[nPalNum]); // to hell with a proper check!
		memcpy(m_pbPalettes[nPalNum], m_pTexture->GetPalette(nPalNum+1), nPaletteSize);
	}

	// Fill the drop-down list with an entry for each local palette index
	CString strIndexEntry("");
	for (UINT nIndex = 0; nIndex < nPaletteSize; nIndex++)
	{
		strIndexEntry.Format("%d", nIndex);
		m_cboPaletteIndices.AddString(strIndexEntry);
	}

	// Set the correct ranges on the spin controls
	m_spnPalette1.SetRange(0, 255);
	m_spnPalette2.SetRange(0, 255);
	m_spnPalette3.SetRange(0, 255);
	m_spnPalette4.SetRange(0, 255);

	// Now just set the initial palette index to be the same as the
	// last time the dialog was used (if possible)
	m_nPaletteIndex = min((int)nPaletteSize-1, max(0, s_nLastIndexEdited));
	UpdatePaletteValues();

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CLocalPaletteDlg::OnSelectPaletteIndex() 
{
	// Get the latest selected palette index
	if (!UpdateData(TRUE))
		return;

	// Show the palette values for this local palette index
	// in the other controls of the dialog
	UpdatePaletteValues();
}

void CLocalPaletteDlg::UpdatePaletteValues() 
{
	// Check the palette index before we go and look
	// into our palettes at that index
	ASSERT((m_nPaletteIndex >= 0) &&
		   (m_nPaletteIndex < (int)m_pTexture->GetPaletteSize()));
	if ((m_nPaletteIndex < 0) ||
		   (m_nPaletteIndex >= (int)m_pTexture->GetPaletteSize()))
		return;

	// Show the values of the local palettes at the new index
	m_nPalette1 = (int)m_pbPalettes[0][m_nPaletteIndex];
	m_nPalette2 = (int)m_pbPalettes[1][m_nPaletteIndex];
	m_nPalette3 = (int)m_pbPalettes[2][m_nPaletteIndex];
	m_nPalette4 = (int)m_pbPalettes[3][m_nPaletteIndex];

	UpdateData(FALSE);
}

void CLocalPaletteDlg::OnOK() 
{
	// Get the latest data from the dialog
	if (!UpdateData(TRUE))
		return;

	// Put our palettes back into the texture's palettes
	UINT nPaletteSize = m_pTexture->GetPaletteSize();
	for (int nPalNum = 0; nPalNum < NUM_LOCAL_PALETTES_PER_TEXTURE; nPalNum++)
		memcpy(m_pTexture->GetPalette(nPalNum+1), m_pbPalettes[nPalNum], nPaletteSize);

	// Remember the last palette index we edited
	s_nLastIndexEdited = m_nPaletteIndex;
	
	CDialog::OnOK();
}

void CLocalPaletteDlg::OnConfirmPaletteValue() 
{
	// Validate all values in the edit boxes
	if (!UpdateData(TRUE))
		return;

	// Put the new palette values into our copy of the 
	// texture's palettes.
	m_pbPalettes[0][m_nPaletteIndex] = (BYTE)m_nPalette1;
	m_pbPalettes[1][m_nPaletteIndex] = (BYTE)m_nPalette2;
	m_pbPalettes[2][m_nPaletteIndex] = (BYTE)m_nPalette3;
	m_pbPalettes[3][m_nPaletteIndex] = (BYTE)m_nPalette4;
}

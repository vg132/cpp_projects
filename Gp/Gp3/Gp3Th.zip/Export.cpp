// Export.cpp : implementation file
//

#include "stdafx.h"
#include "Gp3Th.h"
#include "Export.h"

#include "Gp3MenuText.h"
#include "FileHandling.h"
#include "Gp3Data.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CExport dialog


CExport::CExport(CWnd* pParent /*=NULL*/)
	: CDialog(CExport::IDD, pParent)
{
	//{{AFX_DATA_INIT(CExport)
	m_Gp3Edit = FALSE;
	m_Lap = FALSE;
	m_LapTimes = FALSE;
	m_Len = FALSE;
	m_MenuPic = FALSE;
	m_Misc = FALSE;
	m_Name = FALSE;
	m_Points = FALSE;
	m_QualSetup = FALSE;
	m_RaceSetup = FALSE;
	m_Track = FALSE;
	m_Track1 = FALSE;
	m_Track11 = FALSE;
	m_Track10 = FALSE;
	m_Track12 = FALSE;
	m_Track13 = FALSE;
	m_Track14 = FALSE;
	m_Track15 = FALSE;
	m_Track16 = FALSE;
	m_Track2 = FALSE;
	m_Track3 = FALSE;
	m_Track4 = FALSE;
	m_Track5 = FALSE;
	m_Track6 = FALSE;
	m_Track7 = FALSE;
	m_Track8 = FALSE;
	m_Track9 = FALSE;
	m_Ware = FALSE;
	//}}AFX_DATA_INIT
}


void CExport::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CExport)
	DDX_Check(pDX, IDC_GP3EDIT, m_Gp3Edit);
	DDX_Check(pDX, IDC_LAP, m_Lap);
	DDX_Check(pDX, IDC_LAPTIMES, m_LapTimes);
	DDX_Check(pDX, IDC_LEN, m_Len);
	DDX_Check(pDX, IDC_MENUPIC, m_MenuPic);
	DDX_Check(pDX, IDC_MISC, m_Misc);
	DDX_Check(pDX, IDC_NAME, m_Name);
	DDX_Check(pDX, IDC_POINTS, m_Points);
	DDX_Check(pDX, IDC_QUALSETUP, m_QualSetup);
	DDX_Check(pDX, IDC_RACESETUP, m_RaceSetup);
	DDX_Check(pDX, IDC_TRACK, m_Track);
	DDX_Check(pDX, IDC_TRACK1, m_Track1);
	DDX_Check(pDX, IDC_TRACK11, m_Track11);
	DDX_Check(pDX, IDC_TRACK10, m_Track10);
	DDX_Check(pDX, IDC_TRACK12, m_Track12);
	DDX_Check(pDX, IDC_TRACK13, m_Track13);
	DDX_Check(pDX, IDC_TRACK14, m_Track14);
	DDX_Check(pDX, IDC_TRACK15, m_Track15);
	DDX_Check(pDX, IDC_TRACK16, m_Track16);
	DDX_Check(pDX, IDC_TRACK2, m_Track2);
	DDX_Check(pDX, IDC_TRACK3, m_Track3);
	DDX_Check(pDX, IDC_TRACK4, m_Track4);
	DDX_Check(pDX, IDC_TRACK5, m_Track5);
	DDX_Check(pDX, IDC_TRACK6, m_Track6);
	DDX_Check(pDX, IDC_TRACK7, m_Track7);
	DDX_Check(pDX, IDC_TRACK8, m_Track8);
	DDX_Check(pDX, IDC_TRACK9, m_Track9);
	DDX_Check(pDX, IDC_WARE, m_Ware);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CExport, CDialog)
	//{{AFX_MSG_MAP(CExport)
	ON_BN_CLICKED(IDC_TRACK1, OnTrack1)
	ON_BN_CLICKED(IDC_TRACK2, OnTrack2)
	ON_BN_CLICKED(IDC_TRACK, OnTrack)
	ON_BN_CLICKED(IDC_TRACK10, OnTrack10)
	ON_BN_CLICKED(IDC_TRACK11, OnTrack11)
	ON_BN_CLICKED(IDC_TRACK12, OnTrack12)
	ON_BN_CLICKED(IDC_TRACK13, OnTrack13)
	ON_BN_CLICKED(IDC_TRACK14, OnTrack14)
	ON_BN_CLICKED(IDC_TRACK15, OnTrack15)
	ON_BN_CLICKED(IDC_TRACK16, OnTrack16)
	ON_BN_CLICKED(IDC_TRACK3, OnTrack3)
	ON_BN_CLICKED(IDC_TRACK4, OnTrack4)
	ON_BN_CLICKED(IDC_TRACK5, OnTrack5)
	ON_BN_CLICKED(IDC_TRACK6, OnTrack6)
	ON_BN_CLICKED(IDC_TRACK7, OnTrack7)
	ON_BN_CLICKED(IDC_TRACK8, OnTrack8)
	ON_BN_CLICKED(IDC_TRACK9, OnTrack9)
	ON_BN_CLICKED(IDC_WARE, OnWare)
	ON_BN_CLICKED(IDC_RACESETUP, OnRacesetup)
	ON_BN_CLICKED(IDC_QUALSETUP, OnQualsetup)
	ON_BN_CLICKED(IDC_POINTS, OnPoints)
	ON_BN_CLICKED(IDC_NAME, OnName)
	ON_BN_CLICKED(IDC_MISC, OnMisc)
	ON_BN_CLICKED(IDC_MENUPIC, OnMenupic)
	ON_BN_CLICKED(IDC_LEN, OnLen)
	ON_BN_CLICKED(IDC_LAPTIMES, OnLaptimes)
	ON_BN_CLICKED(IDC_LAP, OnLap)
	ON_BN_CLICKED(IDC_GP3EDIT, OnGp3edit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CExport message handlers

void CExport::OnTrack1() 
{
	UpdateData(TRUE);
	if(m_Track1==TRUE)
	{
		m_Checked[0]=0;
		m_Track1=FALSE;
	}
	else
	{
		m_Checked[0]=1;
		m_Track1=TRUE;
	}
	UpdateData(FALSE);
}

void CExport::OnTrack2() 
{
	UpdateData(TRUE);
	if(m_Track2==TRUE)
	{
		m_Checked[1]=0;
		m_Track2=FALSE;
	}
	else
	{
		m_Checked[1]=1;
		m_Track2=TRUE;
	}
	UpdateData(FALSE);
}

void CExport::OnTrack() 
{
	UpdateData(TRUE);
	if(m_Track==TRUE)
		m_Track=FALSE;
	else
		m_Track=TRUE;
	UpdateData(FALSE);
}

void CExport::OnTrack10() 
{
	UpdateData(TRUE);
	if(m_Track10==TRUE)
	{
		m_Checked[9]=0;
		m_Track10=FALSE;
	}
	else
	{
		m_Checked[9]=1;
		m_Track10=TRUE;
	}
	UpdateData(FALSE);
}

void CExport::OnTrack11() 
{
	UpdateData(TRUE);
	if(m_Track11==TRUE)
	{
		m_Checked[10]=0;
		m_Track11=FALSE;
	}
	else
	{
		m_Checked[10]=1;
		m_Track11=TRUE;
	}
	UpdateData(FALSE);
}

void CExport::OnTrack12() 
{
	UpdateData(TRUE);
	if(m_Track12==TRUE)
	{
		m_Checked[11]=0;
		m_Track12=FALSE;
	}
	else
	{
		m_Checked[11]=1;
		m_Track12=TRUE;
	}
	UpdateData(FALSE);
}

void CExport::OnTrack13() 
{
	UpdateData(TRUE);
	if(m_Track13==TRUE)
	{
		m_Checked[12]=0;
		m_Track13=FALSE;
	}
	else
	{
		m_Checked[12]=1;
		m_Track13=TRUE;
	}
	UpdateData(FALSE);
}

void CExport::OnTrack14() 
{
	UpdateData(TRUE);
	if(m_Track14==TRUE)
	{
		m_Checked[13]=0;
		m_Track14=FALSE;
	}
	else
	{
		m_Checked[13]=1;
		m_Track14=TRUE;
	}
	UpdateData(FALSE);
}

void CExport::OnTrack15() 
{
	UpdateData(TRUE);
	if(m_Track15==TRUE)
	{
		m_Checked[14]=0;
		m_Track15=FALSE;
	}
	else
	{
		m_Checked[14]=1;
		m_Track15=TRUE;
	}
	UpdateData(FALSE);
}

void CExport::OnTrack16() 
{
	UpdateData(TRUE);
	if(m_Track16==TRUE)
	{
		m_Checked[15]=0;
		m_Track16=FALSE;
	}
	else
	{
		m_Checked[15]=1;
		m_Track16=TRUE;
	}
	UpdateData(FALSE);
}

void CExport::OnTrack3() 
{
	UpdateData(TRUE);
	if(m_Track3==TRUE)
	{
		m_Checked[2]=0;
		m_Track3=FALSE;
	}
	else
	{
		m_Checked[2]=1;
		m_Track3=TRUE;
	}
	UpdateData(FALSE);
}

void CExport::OnTrack4() 
{
	UpdateData(TRUE);
	if(m_Track4==TRUE)
	{
		m_Checked[3]=0;
		m_Track4=FALSE;
	}
	else
	{
		m_Checked[3]=1;
		m_Track4=TRUE;
	}
	UpdateData(FALSE);
}
void CExport::OnTrack5() 
{
	UpdateData(TRUE);
	if(m_Track5==TRUE)
	{
		m_Checked[4]=0;
		m_Track5=FALSE;
	}
	else
	{
		m_Checked[4]=1;
		m_Track5=TRUE;
	}
	UpdateData(FALSE);
}

void CExport::OnTrack6() 
{
	UpdateData(TRUE);
	if(m_Track6==TRUE)
	{
		m_Checked[5]=0;
		m_Track6=FALSE;
	}
	else
	{
		m_Checked[5]=1;
		m_Track6=TRUE;
	}
	UpdateData(FALSE);
}

void CExport::OnTrack7() 
{
	UpdateData(TRUE);
	if(m_Track7==TRUE)
	{
		m_Checked[6]=0;
		m_Track7=FALSE;
	}
	else
	{
		m_Checked[6]=1;
		m_Track7=TRUE;
	}
	UpdateData(FALSE);
}

void CExport::OnTrack8() 
{
	UpdateData(TRUE);
	if(m_Track8==TRUE)
	{
		m_Checked[7]=0;
		m_Track8=FALSE;
	}
	else
	{
		m_Checked[7]=1;
		m_Track8=TRUE;
	}
	UpdateData(FALSE);
}

void CExport::OnTrack9() 
{
	UpdateData(TRUE);
	if(m_Track9==TRUE)
	{
		m_Checked[8]=0;
		m_Track9=FALSE;
	}
	else
	{
		m_Checked[8]=1;
		m_Track9=TRUE;
	}
	UpdateData(FALSE);
}

void CExport::OnWare() 
{
	UpdateData(TRUE);
	if(m_Ware==TRUE)
		m_Ware=FALSE;
	else
		m_Ware=TRUE;
	UpdateData(FALSE);
}

void CExport::OnRacesetup() 
{
	UpdateData(TRUE);
	if(m_RaceSetup==TRUE)
		m_RaceSetup=FALSE;
	else
		m_RaceSetup=TRUE;
	UpdateData(FALSE);
}

void CExport::OnQualsetup() 
{
	UpdateData(TRUE);
	if(m_QualSetup==TRUE)
		m_QualSetup=FALSE;
	else
		m_QualSetup=TRUE;
	UpdateData(FALSE);
}

void CExport::OnPoints() 
{
	UpdateData(TRUE);
	if(m_Points==TRUE)
		m_Points=FALSE;
	else
		m_Points=TRUE;
	UpdateData(FALSE);
}

void CExport::OnName() 
{
	UpdateData(TRUE);
	if(m_Name==TRUE)
		m_Name=FALSE;
	else
		m_Name=TRUE;
	UpdateData(FALSE);
}

void CExport::OnMisc() 
{
	UpdateData(TRUE);
	if(m_Misc==TRUE)
		m_Misc=FALSE;
	else
		m_Misc=TRUE;
	UpdateData(FALSE);
}

void CExport::OnMenupic() 
{
	UpdateData(TRUE);
	if(m_MenuPic==TRUE)
		m_MenuPic=FALSE;
	else
		m_MenuPic=TRUE;
	UpdateData(FALSE);
}

void CExport::OnLen() 
{
	UpdateData(TRUE);
	if(m_Len==TRUE)
		m_Len=FALSE;
	else
		m_Len=TRUE;
	UpdateData(FALSE);
}

void CExport::OnLaptimes() 
{
	UpdateData(TRUE);
	if(m_LapTimes==TRUE)
		m_LapTimes=FALSE;
	else
		m_LapTimes=TRUE;
	UpdateData(FALSE);
}

void CExport::OnLap() 
{
	UpdateData(TRUE);
	if(m_Lap==TRUE)
		m_Lap=FALSE;
	else
		m_Lap=TRUE;
	UpdateData(FALSE);
}

void CExport::OnGp3edit() 
{
	UpdateData(TRUE);
	if(m_Gp3Edit==TRUE)
		m_Gp3Edit=FALSE;
	else
		m_Gp3Edit=TRUE;
	UpdateData(FALSE);
}
void CExport::OnOK() 
{
CGp3MenuText text;
CFileHandling fh;
Gp3Data gpData;
CString sztfile;
CString szFile;
char ch;
int i;
	BeginWaitCursor();
	UpdateData(TRUE);
	if(m_StrFile!="english.str")
		text.SetLanguageDiff(8);
	else
		text.SetLanguageDiff(0);
	text.LoadText(m_Gp3Path+"\\ldata\\"+m_StrFile);
	gpData.LoadData(m_Gp3Path);
	for(i=0;i<16;i++)
	{
		//Exportera if the track is selected
		if(m_Checked[i]==1)
		{
			fh.Load(m_TempFile,i);
			if(m_Name==TRUE)
			{
				if(fh.GetName()!="")
					text.SetTrackName(fh.GetName(),i);
				if(fh.GetCountry()!="")
					text.SetTrackCountry(fh.GetCountry(),i);
				if(fh.GetAdjective()!="")
					text.SetTrackAdjective(fh.GetAdjective(),i);
			}	
			if(m_Lap==TRUE)
				gpData.SetLaps(i,fh.GetLaps());
			if(m_Len==TRUE)
				gpData.SetLength(i,fh.GetLen());
			if(m_Track==TRUE&&fh.GetFileName()!="")
			{
				if(i<9)
				{
					sztfile=m_Gp3Path+"\\circuits\\f1ct0";
					itoa(i+1,&ch,10);
				}
				else
				{
					sztfile=m_Gp3Path + "\\circuits\\f1ct1";
					itoa(i-9,&ch,10);
				}
				sztfile+=ch;
				sztfile+=".dat";
				szFile=fh.GetFileName();
				CopyFile(szFile,sztfile,FALSE);
			}
		}
	}
	if(m_Points==TRUE)
	{
		fh.LoadMisc(m_TempFile);
		for(i=0;i<26;i++)
			gpData.SetPoint(i,fh.GetPoints(i));
	}
	text.SaveText(m_Gp3Path+"\\ldata\\"+m_StrFile);
	gpData.SaveData(m_Gp3Path+"\\gp3.exe");
	EndWaitCursor();
	CDialog::OnOK();
}

BOOL CExport::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	for(int i=0;i<16;i++)
		m_Checked[i]=1;

	m_Track1=TRUE;
	m_Track2=TRUE;
	m_Track3=TRUE;
	m_Track4=TRUE;
	m_Track5=TRUE;
	m_Track6=TRUE;
	m_Track7=TRUE;
	m_Track8=TRUE;
	m_Track9=TRUE;
	m_Track10=TRUE;
	m_Track11=TRUE;
	m_Track12=TRUE;
	m_Track13=TRUE;
	m_Track14=TRUE;
	m_Track15=TRUE;
	m_Track16=TRUE;
	m_Name=TRUE;
	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

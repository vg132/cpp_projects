// FogFilterDlg.h : header file
//

#ifndef __FOG_FILTER_DLG_H__
#define __FOG_FILTER_DLG_H__

/////////////////////////////////////////////////////////////////////////////
// CFogFilterDlg dialog

class CFogFilterDlg : public CDialog
{
// Construction
public:
	CFogFilterDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFogFilterDlg)
	enum { IDD = IDD_FOG_FILTER };
	CSliderCtrl	m_sdrFogginess;
	CString	m_strRating;
	//}}AFX_DATA

	// Get/set the time index
	BOOL SetFogRating(const int nRating);
	int GetFogRating() const;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFogFilterDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// The value representing the visibility rating
	int m_nFogRating;

	void UpdateRatingText();

	// Generated message map functions
	//{{AFX_MSG(CFogFilterDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

#endif	// ~__FOG_FILTER_DLG_H__

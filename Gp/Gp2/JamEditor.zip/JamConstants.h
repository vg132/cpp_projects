// JamConstants.h - a file containing various constant values relating
//					to JAM files and the textures within them

// The width of each JAM file's canvas
#define JAM_CANVAS_WIDTH		256

// The maximum possible height of a JAM file's canvas
#define MAX_JAM_CANVAS_HEIGHT	65535

// The default height of a jam cnavas
#define DEFAULT_JAM_CANVAS_HEIGHT	192

// The number of local palettes each texture has
#define NUM_LOCAL_PALETTES_PER_TEXTURE		4

// The value used to indicate that a given texture ID is invalid
#define TEXTURE_ID_NONE			-1

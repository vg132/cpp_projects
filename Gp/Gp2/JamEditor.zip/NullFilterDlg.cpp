// NullFilterDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "NullFilterDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNullFilterDlg dialog


CNullFilterDlg::CNullFilterDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNullFilterDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNullFilterDlg)
	m_nPaletteType = -1;
	//}}AFX_DATA_INIT
}


void CNullFilterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNullFilterDlg)
	DDX_Radio(pDX, IDC_MAINTAIN_PALETTE, m_nPaletteType);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNullFilterDlg, CDialog)
	//{{AFX_MSG_MAP(CNullFilterDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNullFilterDlg message handlers

void CNullFilterDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();
}

BOOL CNullFilterDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

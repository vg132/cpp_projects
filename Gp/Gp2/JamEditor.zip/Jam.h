// Jam.h - header file for the CJam class
//

#ifndef __JAM_H__
#define __JAM_H__

#include "JamConstants.h"
#include "JamTexture.h"
#include "JamPixelInfo.h"
#include "JamTextureList.h"
#include "EditableNumber.h"

class CJamTextureFilter;
class CJamSizeFrontEnd;
class CJamEditorDoc;

// Each JAM file comprises a header detailing the number of textures
// in the file and its total size, followed by an array of texture
// entries, their palettes, and finally the full image's pixels.

typedef struct
{
	WORD m_wNumTextures;		// number of textures defined in JAM
	WORD m_wJamImageHeight;		// total height of JAM image in pixels
} JAM_HEADER;


///////////////////////////////////////////////////////////////////
// Class:	CJam
// Base:	[none]
// Created:	10 Jan 1999 by Mal Ross
// Overview:
//    This class represents a single JAM file.  It abstracts
//  away the detail of the internals of the JAM file format to
//  a large extent, allowing users to concentrate on what how
//  a JAM file can actually be edited.  Hopefully. :)  Note that
//  the actual pixels of the bitmap forming the JAM file are
//  stored in the aggregated CJamTextures (stored in a list).
//

class CJam
{
// Construction and destruction
public:
	CJam(CJamEditorDoc* pDoc);
	virtual ~CJam();

// Data members
protected:
	// The list of textures in this JAM file
	CJamTextureList m_Textures;

	// The numbers of rows of pixel data in the JAM, each row
	// being CANVAS_WIDTH pixels wide
	UINT m_nTotalImageHeight;

	// The canvas itself.  Note: this is only being kept here as
	// well as in the texture objects so that I can see what pixels
	// are in the texture-free areas of the canvas.
	BYTE* m_pbCanvasPixels;

	// pointer to the document owning this jam
	CJamEditorDoc* m_pDoc;

public:
	// A flag to say whether or not we should attempt to fix invalid
	// texture pixels
	static BOOL s_bFixInvalidPixels;

	// a data front end to represent the list of textures in
	// this jam
	CEditableNumber<UINT>* m_pJamSizeObject;

// Operations
public:
	// Return the overall size of the image (in pixels, X and Y)
	CSize GetSize () const { return CSize(JAM_CANVAS_WIDTH, m_nTotalImageHeight); }

	// The main drawing function
	BOOL Draw(CDC* pDC, const int& nPaletteNum, const double dZoomFactor);

	// Serialization (although not in the MFC style - it's just
	// simple load/save here)
	void Serialize(CArchive& ar);
	void SerializeNoEncryption(CArchive& ar);
	void SerializeSelection(CArchive& ar);	// for cut/copy/paste

	// Import/export the whole canvas or individual textures
	BOOL ExportCanvas(const CString& strBitmapFile);
	BOOL ImportCanvas(const CString& strBitmapFile, CJamTextureFilter* pFilter);
	BOOL ExportTexture(const CString& strBitmapFile, const UINT nTextureID);
	BOOL ImportTexture(const CString& strBitmapFile, const UINT nTextureID, CJamTextureFilter* pFilter);
	BOOL ImportAnimation(const CStringList& lstBitmapFiles, const UINT nTextureID);

	// Addition/removal of textures
	BOOL AddNewTexture(const CString& strBitmapFile, CJamTextureFilter* pFilter);
	BOOL DeleteTexture(CJamTexture*& pTexture);

	// Filter application
	BOOL ApplyFilter(CJamTextureFilter* pFilter, const BOOL bAllTextures = TRUE);

	// Hit-testing and sanity-checking
	BOOL HitTest(CJamPixelInfo& pixelInfo) const;
	CJamTexture* GetSelectedTexture() const;
	BOOL AreTexturesOverlapped() const;
	int FixAnyInvalidTexturePixels();	// returns # of textures fixed

	// Texture retrieval
	int GetNumTextures() const { return m_Textures.GetCount(); }
	CJamTexture* GetTexture(const UINT& nTextureID) const;
	POSITION GetFirstTexturePos() const;
	CJamTexture* GetNextTexture(POSITION& posTexture) const;

	// access to front end of texture
	// via editable object
	CEditableObject* GetTextureListFrontEnd() { return (CEditableObject*)(&m_Textures); }

// Implementation
protected:
	// Various drawing functions
	BOOL DrawTextures(CDC* pDC, const int& nPaletteNum, const double dZoomFactor);
	BOOL DrawCanvas(CDC* pDC);	// always at 1:1
	BOOL DrawOutlines(CDC* pDC, const double dZoomFactor);

	// Getting/setting the pixels in the textures
	BOOL GetRawJamPixels(BYTE* pbRawJamPixels);
	BOOL SetRawJamPixels(BYTE* pbRawJamPixels);

	// Update of palette positions required after bitmap import
	// and re-filtering
	void UpdatePalettePositions();

	// Encryption/decryption and general loading/saving
	void EncryptDecrypt(BYTE* pbJamData, int nNumBytes);
	enum eJamSerializationVersion
	{
		JAM_CLIPBRD_VERSION = 1
	};
};


/////////////////////////////////////////////////////////////////////

#endif	// ~__JAM_H__
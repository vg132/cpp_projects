#if !defined(AFX_TRACKDATA_H__6E2ACEC0_7389_11D4_8FC7_0008C7636E27__INCLUDED_)
#define AFX_TRACKDATA_H__6E2ACEC0_7389_11D4_8FC7_0008C7636E27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TrackData.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CTrackData dialog

#include "FileHandling.h"

class CTrackData : public CDialog
{
// Construction
public:
	void SetSpin();

	void GetDataFromFile();
	CTrackData(CWnd* pParent = NULL);   // standard constructor
	CFileHandling fh;
	int tracknr;
	CString m_TempFile;
// Dialog Data
	//{{AFX_DATA(CTrackData)
	enum { IDD = IDD_TRACKDATA };
	CSpinButtonCtrl	m_Spin_TyreWare;
	CSpinButtonCtrl	m_Spin_Length;
	CSpinButtonCtrl	m_Spin_Laps;
	int		m_Laps;
	CString	m_FilePath;
	int		m_Length;
	CString	m_Qual_Date;
	CString	m_Qual_Driver;
	CString	m_Qual_Team;
	CString	m_Qual_Time;
	CString	m_Race_Date;
	CString	m_Race_Driver;
	CString	m_Race_Team;
	CString	m_Race_Time;
	CString	m_Country;
	CString	m_Name;
	int		m_Ware;
	CString	m_Adjective;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTrackData)
	public:
	virtual int DoModal();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CTrackData)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRACKDATA_H__6E2ACEC0_7389_11D4_8FC7_0008C7636E27__INCLUDED_)

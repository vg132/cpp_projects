// PixelProfileCluster.cpp - implementation of the CPixelProfileCluster class
//

#include "stdafx.h"

#include "PixelProfileCluster.h"

#include "PixelProfile.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CPixelProfileCluster construction/destruction

CPixelProfileCluster::CPixelProfileCluster(CPixelProfile* pFirstProfile)
{
	m_Matrix = NULL;
	m_dClusterFactor = 0.0f;
	m_posMasterProfile = NULL;

	// Add the profile to our list and set the cluster's
	// match factor info
	m_lstProfiles.AddTail(pFirstProfile);

	InitClusterMatrix();
	CalcAllClusterFactors();
	UpdateMasterProfile();
}

CPixelProfileCluster::CPixelProfileCluster(const CPixelProfileCluster& firstCluster, const CPixelProfileCluster& secondCluster)
{
	// First just initialise members and copy the profiles of the two
	// clusters into this one
	m_Matrix = NULL;
	m_dClusterFactor = 0.0f;
	m_posMasterProfile = NULL;

	// Copy the profiles from the first cluster
	POSITION posProfile = firstCluster.m_lstProfiles.GetHeadPosition();
	CPixelProfile* pProfile = NULL;
	while (NULL != posProfile)
	{
		pProfile = firstCluster.m_lstProfiles.GetNext(posProfile);
		if (NULL == m_lstProfiles.Find(pProfile))
			m_lstProfiles.AddTail(pProfile);
	}

	// Now copy the profiles from the second cluster
	posProfile = secondCluster.m_lstProfiles.GetHeadPosition();
	while (NULL != posProfile)
	{
		pProfile = secondCluster.m_lstProfiles.GetNext(posProfile);
		if (NULL == m_lstProfiles.Find(pProfile))
			m_lstProfiles.AddTail(pProfile);
	}

	// Set up the size of our match-factor matrix
	InitClusterMatrix();
	int nFirstProfileCount = firstCluster.m_lstProfiles.GetCount(),
		nSecondProfileCount = secondCluster.m_lstProfiles.GetCount();

	// Copy across all of the match factors from the two profiles...
	int nRow = 0, nCol = 0;
	for (nRow = 0; nRow < nFirstProfileCount; nRow++)
		for (nCol = 0; nCol < nFirstProfileCount; nCol++)
			m_Matrix[nRow][nCol] = firstCluster.m_Matrix[nRow][nCol];
	for (nRow = 0; nRow < nSecondProfileCount; nRow++)
		for (nCol = 0; nCol < nSecondProfileCount; nCol++)
			m_Matrix[nRow+nFirstProfileCount][nCol+nFirstProfileCount] = secondCluster.m_Matrix[nRow][nCol];

	// ...and fill in the gaps
	CalcAllClusterFactors();
	UpdateMasterProfile();
}

CPixelProfileCluster::~CPixelProfileCluster()
{
	// Clear out the list of profiles
	int nNumProfiles = m_lstProfiles.GetCount();
	m_lstProfiles.RemoveAll();

	// Clear out the profile similarity matrix
	for (int nRow = 0; nRow < nNumProfiles; nRow++)
	{
		delete[] m_Matrix[nRow];
	}
	delete[] m_Matrix;
}



/////////////////////////////////////////////////////////////////////////////
// Cluster factor functions

// Function:	CalcAllClusterFactors()
// Overview:	Calculate the degree of closeness in this cluster.
void CPixelProfileCluster::CalcAllClusterFactors()
{
	// We're going to have to match each profile to every other
	// profile to work out all of the match factors.  However,
	// we'll save ourselves the bother of doing each pair twice by
	// only matching the profiles after the one we're currently
	// looking at.
	POSITION posCurrProfile = m_lstProfiles.GetHeadPosition();
	int nRow = 0;
	while (NULL != posCurrProfile)
	{
		// Get the next texture in the list
		CPixelProfile* pCurrProfile = m_lstProfiles.GetNext(posCurrProfile);
		ASSERT(NULL != pCurrProfile);
		if (NULL == pCurrProfile)
		{
			nRow++;
			continue;
		}

		// Match the profile to all profiles after it in the list
		POSITION posTestProfile = posCurrProfile;
		int nCol = nRow+1;
		while (NULL != posTestProfile)
		{
			// Get the next texture to test from the list and
			// see whether it overlaps the current texture
			CPixelProfile* pTestProfile = m_lstProfiles.GetNext(posTestProfile);
			ASSERT(NULL != pTestProfile);
			if (NULL == pTestProfile)
			{
				nCol++;
				continue;
			}

			// Calculate the match factor if it hasn't been calculated already
			if (m_Matrix[nRow][nCol] == PROFILE_MATCH_FACTOR_UNDEFINED)
			{
				double dMatch = pCurrProfile->GetMatchFactor(*pTestProfile);
				m_Matrix[nRow][nCol] = dMatch;
				m_Matrix[nCol][nRow] = dMatch;
			}

			// Increment the column counter
			nCol++;
		}

		// Set the match factor for this profile matching to itself
		m_Matrix[nRow][nRow] = 1.0f;

		// Increment the row counter
		nRow++;
	}
}
// End of function 'CalcAllClusterFactors'


// Function:	UpdateMasterProfile()
// Overview:	
void CPixelProfileCluster::UpdateMasterProfile()
{
	// Cycle through the rows in the match matrix, looking for
	// the line with the highest average match factor.  This
	// will be the master profile for the cluster
	POSITION posCurrProfile = m_lstProfiles.GetHeadPosition();
	POSITION posMaster = posCurrProfile;
	int nCurrProfile = 0;
	int nNumProfiles = m_lstProfiles.GetCount();
	double dHighestMatchFactor = 0.0f;
	// Vars taken outside of the loop - begin
	double dTotal = 0.0f;
	int nTestProfile = 0;
	double dAverage = 0.0f;
	// Vars taken outside of the loop - end
	while (NULL != posCurrProfile)
	{
		// Get the next texture in the list
		CPixelProfile* pCurrProfile = m_lstProfiles.GetAt(posCurrProfile);
		ASSERT(NULL != pCurrProfile);
		if (NULL == pCurrProfile)
		{
			nCurrProfile++;
			continue;
		}

		// Find the average of all cluster factors associated with the
		// current profile
		dTotal = 0.0f;
		for (nTestProfile = 0; nTestProfile < nNumProfiles; nTestProfile++)
			dTotal += m_Matrix[nCurrProfile][nTestProfile];
		dAverage = dTotal / (double)nNumProfiles;

		// Store this as the representative if it has the highest
		// average match factor found so far
		if (dAverage > dHighestMatchFactor)
		{
			dHighestMatchFactor = dAverage;
			posMaster = posCurrProfile;
		}

		m_lstProfiles.GetNext(posCurrProfile);
		nCurrProfile++;
	}

	// Store the results of our search
	m_dClusterFactor = dHighestMatchFactor;
	m_posMasterProfile = posMaster;
}
// End of function 'UpdateMasterProfile'


// Function:	InitClusterMatrix()
// Overview:	Initialise the sluter matrix of match factors,
//				making it the right size and setting all match
//				factors as undefined.
void CPixelProfileCluster::InitClusterMatrix()
{
	// Make sure the cluster matrix is empty first
	ASSERT(NULL == m_Matrix);

	// Now set the proper number of rows and columns
	int nNumProfiles = m_lstProfiles.GetCount();

	// Finally, initialise the values in the matrix
	m_Matrix = new double*[nNumProfiles];
	int nRow = 0, nCol = 0;
	for (nRow = 0; nRow < nNumProfiles; nRow++)
	{
		m_Matrix[nRow] = new double[nNumProfiles];
		for (nCol = 0; nCol < nNumProfiles; nCol++)
			m_Matrix[nRow][nCol] = PROFILE_MATCH_FACTOR_UNDEFINED;
	}
}
// End of function 'InitClusterMatrix'



/////////////////////////////////////////////////////////////////////////////
// Storing the cluster info

// Function:	AssignClusterInfoToProfiles(nClusterIndex)
// Overview:	Actually store the information about this cluster in
//				the indexes of each of the profiles.
BOOL CPixelProfileCluster::AssignClusterInfoToProfiles(const BYTE nClusterIndex)
{
	// Get the necessary information about the master profile first
	CPixelProfile* pMaster = m_lstProfiles.GetAt(m_posMasterProfile);
	if (NULL == pMaster)
		return FALSE;
	int nMasterIndex = pMaster->GetProfileIndex();

	// Now just go through all profiles in this cluster and
	// assign their cluster and master indexes.
	POSITION posProfile = m_lstProfiles.GetHeadPosition();
	CPixelProfile* pProfile = NULL;
	while(NULL != posProfile)
	{
		// Get the next profile from the list and make sure
		// the pointer to it is valid (if not, just do the best
		// we can by carrying on with the one after it).
		pProfile = m_lstProfiles.GetNext(posProfile);
		ASSERT(NULL != pProfile);
		if (NULL == pProfile)
			continue;

		// Set the relevant indexes
		pProfile->SetClusterIndex(nClusterIndex);
		pProfile->SetMasterIndex(nMasterIndex);
	}

	return TRUE;
}
// End of function 'AssignClusterInfoToProfiles'


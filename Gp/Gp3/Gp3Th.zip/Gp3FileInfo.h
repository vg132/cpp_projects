// Gp3FileInfo.h: interface for the CGp3FileInfo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GP3FILEINFO_H__357FAA64_7DEC_11D4_8FC7_0008C7636E27__INCLUDED_)
#define AFX_GP3FILEINFO_H__357FAA64_7DEC_11D4_8FC7_0008C7636E27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CGp3FileInfo  
{
public:
	bool OrgTrack(int nr);
	CString GetYear();
	CString GetEvent();
	CString GetAuthor();
	CString GetRaceRec();
	CString GetQualRec();
	CString GetDesc();
	CString GetWare();
	CString GetSlot();
	CString GetLaps();
	CString GetLength();
	CString GetCountry();
	CString GetName();
	bool LoadInfo(CString file);
	CGp3FileInfo();
	virtual ~CGp3FileInfo();
	CString m_Gp3Info;
	CString m_Tmp;
	char ch;
	int i;
};

#endif // !defined(AFX_GP3FILEINFO_H__357FAA64_7DEC_11D4_8FC7_0008C7636E27__INCLUDED_)

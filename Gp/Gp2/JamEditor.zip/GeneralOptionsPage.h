// GeneralOptionsPage.h : header file
//

#ifndef _GENERAL_OPTIONS_PAGE_H_
#define _GENERAL_OPTIONS_PAGE_H_

/////////////////////////////////////////////////////////////////////////////
// CGeneralOptionsPage dialog

class CGeneralOptionsPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CGeneralOptionsPage)

// Construction
public:
	CGeneralOptionsPage();
	~CGeneralOptionsPage();

// Dialog Data
	//{{AFX_DATA(CGeneralOptionsPage)
	enum { IDD = IDD_OPTIONS_GENERAL };
	CSpinButtonCtrl	m_spnMRUSize;
	UINT	m_nMRULength;
	BOOL	m_bIgnoreInvalidPalettes;
	CString	m_strPaletteFilename;
	int		m_nPaletteType;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CGeneralOptionsPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Flag to avoid EN_CHANGE problems when doing initial UpdateData(FALSE);
	BOOL m_bCreated;

	// Enable or disable the palette file controls according to
	// whether or not the custom palette option is selected.
	void EnableCustomPaletteOptions(const BOOL bEnable = TRUE);

	// Generated message map functions
	//{{AFX_MSG(CGeneralOptionsPage)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnStandardPalette();
	afx_msg void OnCustomPalette();
	afx_msg void OnFindPalette();
	afx_msg void OnChangeOption();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

/////////////////////////////////////////////////////////////////////////////

#endif	// !_GENERAL_OPTIONS_PAGE_H_


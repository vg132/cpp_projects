// PaletteImageCombiner.h - header file for the CPaletteImageCombiner class
//

#ifndef __PALETTE_IMAGE_COMBINER_H__
#define __PALETTE_IMAGE_COMBINER_H__

class CPaletteImageSource;
class CLocalPaletteArray;

///////////////////////////////////////////////////////////////////
// Class:	CPaletteImageCombiner
// Base:	[none]
// Created:	14Jan00 by Mal Ross
// Overview:
//    This class has been created by taking the CombineFilteredBitmaps
//  function out of the CJamTextureFilter class.  This was done
//  because the combining of bitmaps into a single texture is an
//  operation that is used not only in filtering.  It is also needed
//  when importing animations, and so it made sense to have it in a
//  separate reusable class.
//

class CPaletteImageCombiner
{
// Construction and destruction
public:
	CPaletteImageCombiner() {}
	virtual ~CPaletteImageCombiner() {}

// Operations
public:
	// Combine the filtered bitmaps into a single raw texture and a
	// set of palettes that will reproduce the original bitmaps
	BOOL CombineBitmaps(CPaletteImageSource& source, BYTE*& pbTexturePixels,
		CLocalPaletteArray& localPalettes, const BOOL bEmptyPalettesIfPoss);
};

/////////////////////////////////////////////////////////////////////

#endif	// ~__PALETTE_IMAGE_COMBINER_H__

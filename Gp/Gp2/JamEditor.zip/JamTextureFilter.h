// JamTextureFilter.h - header file for the CJamTextureFilter class
//

#ifndef __JAM_TEXTURE_FILTER_H__
#define __JAM_TEXTURE_FILTER_H__

#include "PaletteImageSource.h"

///////////////////////////////////////////////////////////////////
// Class:	CJamTextureFilter
// Base:	[none]
// Created:	06Feb99 by Mal Ross
// Overview:
//    This class is to be used as a base class for the different
//  types of filter that can be applied to a bitmap being imported
//  into a texture.
//

class CJamTextureFilter : public CPaletteImageSource
{
// Construction and destruction
public:
	CJamTextureFilter(const UINT& nFilterID, const UINT& nStringID);
	virtual ~CJamTextureFilter();

// Attributes
protected:
	// Filter# and name for the UI
	UINT m_nFilterID;
	CString m_strFilterName;

	// The image that's about to be filtered.  Yes, I realise this
	// two-stage process is a poor design, but by the time I realised
	// it, most of it was already coded.  I can't be bothered to go
	// back and do it again, although CJamTextureFilter should never
	// have to *store( any bitmaps - it should just be a tool.
	BYTE* m_pbOriginalPixels;
	CSize m_sizImage;	// the dimensions of the above buffer

public:
	// When filtering a given pixel, should it be left alone if
	// it is the GP2 transparent colour?
	static BOOL s_bProtectTransparency;

// Operations
public:
	// Get filter attributes
	UINT GetFilterID() const { return m_nFilterID; }
	CString GetFilterName() const { return m_strFilterName; }

	// User-configuration of the filter's parameters
	virtual BOOL IsConfigurable() const { return FALSE; }
	virtual void Configure() {}

	// This function prepares the filter for a forthcoming call to
	// GetBitmaps, which will be made by an instance of the
	// CPaletteImageCombiner class.  As soon as that call is made
	// the filter object can ditch its record of the bitmap being
	// filtered.
	BOOL PrepareFilter(const BYTE* pbOriginalPixels, const CSize& sizImage);

	// The function to retrieve the pixel buffers to the four
	// bitmaps this object provides.
	virtual BOOL GetBitmaps(CPixelBufferArray& pixelBuffers, CSize& sizImage);

// Implementation
protected:
	// Create all four of the filtered bitmaps, putting them into
	// the pixel buffers passed in.
	BOOL CreateFilteredBitmaps(CPixelBufferArray& pixelBuffers, CSize& sizImage);

	// Create the decoded version of the texture as seen when using
	// palette #1.  This is simply a copy of the actual bitmap pixels
	// we're importing/filtering, so as to allow repeated filtering.
	virtual BOOL CreateFirstFilteredBitmap(const BYTE* pbBitmapPixels, BYTE*& pbNewPixels, const CSize& sizImage);

	// KEY FUNCTION:
	// This is probably the only function you'll need to override -
	// if you're creating each filtered image from the image created
	// using the previous local palette...
	virtual BOOL CreateNextFilteredBitmap(const BYTE* pbSrcPixels, BYTE*& pbNewPixels, const CSize& sizImage) = 0;

	// Handle with care!  This function is to be used to make
	// tidying up the filtered bitmaps easier when something
	// goes wrong.
	void DeleteFilteredBitmaps(CPixelBufferArray& pixelBuffers);
	void ClearOutTemporaryStorage();	// clear out m_pbOriginalPixels
};

/////////////////////////////////////////////////////////////////////

#endif	// ~__JAM_TEXTURE_FILTER_H__

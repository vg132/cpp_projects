// LocalFilter.h - header file for the CLocalFilter class
//

#ifndef __LOCAL_FILTER_H__
#define __LOCAL_FILTER_H__

#include "JamTextureFilter.h"
#include "TexturePalette.h"
class CColor;

///////////////////////////////////////////////////////////////////
// Class:	CLocalFilter
// Base:	CJamTextureFilter
// Created:	28 April 99 by Mal Ross
// Overview:
//    This filter produces 4 decoded textures in which each
//  pixel is based solely on the same pixel in the previous
//  decoded texture i.e. no neighbourhood filtering.  This
//  will allow classes to be derived to produce effects such
//  as night-driving, driving in fog, fading colours, etc.
//

class CLocalFilter : public CJamTextureFilter
{
// Construction and destruction
public:
	CLocalFilter(const UINT& nFilterID, const UINT& nStringID);
	virtual ~CLocalFilter();

// Attributes
protected:
	// For efficiency, keep a record of what each pixel maps to.
	BYTE m_FilterMappings[GP2_PALETTE_SIZE];

// Operations
public:

// Implementation
protected:
	// Clear out any existing mappings from source colours to
	// filtered colours.
	void InitialiseMappings();

	// Overridden to create each filtered image from the 
	// image created using the previous local palette.
	virtual BOOL CreateNextFilteredBitmap(const BYTE* pbSrcPixels, BYTE*& pbNewPixels, const CSize& sizImage);

	// Filter the colour at the given palette index and return
	// the index of the closest match to the result.
	virtual BYTE FilterSinglePixel(BYTE nPalIndex);
	virtual void FilterColor(CColor& color) = 0;
};

/////////////////////////////////////////////////////////////////////

#endif	// ~__LOCAL_FILTER_H__

// Import.cpp : implementation file
//

#include "stdafx.h"
#include "Gp3Th.h"
#include "Import.h"
#include "FileHandling.h"
#include "Gp3Data.h"
#include "Gp3MenuText.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CImport dialog


CImport::CImport(CWnd* pParent /*=NULL*/)
	: CDialog(CImport::IDD, pParent)
{
	//{{AFX_DATA_INIT(CImport)
	m_Laps = FALSE;
	m_LapTime = FALSE;
	m_Len = FALSE;
	m_Misc = FALSE;
	m_Name = FALSE;
	m_Points = FALSE;
	m_Track1 = FALSE;
	m_Track10 = FALSE;
	m_Track11 = FALSE;
	m_Track12 = FALSE;
	m_Track13 = FALSE;
	m_Track14 = FALSE;
	m_Track15 = FALSE;
	m_Track16 = FALSE;
	m_Track2 = FALSE;
	m_Track3 = FALSE;
	m_Track4 = FALSE;
	m_Track5 = FALSE;
	m_Track6 = FALSE;
	m_Track7 = FALSE;
	m_Track8 = FALSE;
	m_Track9 = FALSE;
	m_Ware = FALSE;
	//}}AFX_DATA_INIT
}


void CImport::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CImport)
	DDX_Check(pDX, IDC_LAP, m_Laps);
	DDX_Check(pDX, IDC_LAPTIMES, m_LapTime);
	DDX_Check(pDX, IDC_LEN, m_Len);
	DDX_Check(pDX, IDC_MISC, m_Misc);
	DDX_Check(pDX, IDC_NAME, m_Name);
	DDX_Check(pDX, IDC_POINTS, m_Points);
	DDX_Check(pDX, IDC_TRACK1, m_Track1);
	DDX_Check(pDX, IDC_TRACK10, m_Track10);
	DDX_Check(pDX, IDC_TRACK11, m_Track11);
	DDX_Check(pDX, IDC_TRACK12, m_Track12);
	DDX_Check(pDX, IDC_TRACK13, m_Track13);
	DDX_Check(pDX, IDC_TRACK14, m_Track14);
	DDX_Check(pDX, IDC_TRACK15, m_Track15);
	DDX_Check(pDX, IDC_TRACK16, m_Track16);
	DDX_Check(pDX, IDC_TRACK2, m_Track2);
	DDX_Check(pDX, IDC_TRACK3, m_Track3);
	DDX_Check(pDX, IDC_TRACK4, m_Track4);
	DDX_Check(pDX, IDC_TRACK5, m_Track5);
	DDX_Check(pDX, IDC_TRACK6, m_Track6);
	DDX_Check(pDX, IDC_TRACK7, m_Track7);
	DDX_Check(pDX, IDC_TRACK8, m_Track8);
	DDX_Check(pDX, IDC_TRACK9, m_Track9);
	DDX_Check(pDX, IDC_WARE, m_Ware);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CImport, CDialog)
	//{{AFX_MSG_MAP(CImport)
	ON_BN_CLICKED(IDC_TRACK1, OnTrack1)
	ON_BN_CLICKED(IDC_TRACK10, OnTrack10)
	ON_BN_CLICKED(IDC_TRACK11, OnTrack11)
	ON_BN_CLICKED(IDC_TRACK12, OnTrack12)
	ON_BN_CLICKED(IDC_TRACK13, OnTrack13)
	ON_BN_CLICKED(IDC_TRACK14, OnTrack14)
	ON_BN_CLICKED(IDC_TRACK15, OnTrack15)
	ON_BN_CLICKED(IDC_TRACK16, OnTrack16)
	ON_BN_CLICKED(IDC_TRACK2, OnTrack2)
	ON_BN_CLICKED(IDC_TRACK3, OnTrack3)
	ON_BN_CLICKED(IDC_TRACK4, OnTrack4)
	ON_BN_CLICKED(IDC_TRACK5, OnTrack5)
	ON_BN_CLICKED(IDC_TRACK6, OnTrack6)
	ON_BN_CLICKED(IDC_TRACK7, OnTrack7)
	ON_BN_CLICKED(IDC_TRACK8, OnTrack8)
	ON_BN_CLICKED(IDC_TRACK9, OnTrack9)
	ON_BN_CLICKED(IDC_LAP, OnLap)
	ON_BN_CLICKED(IDC_LEN, OnLen)
	ON_BN_CLICKED(IDC_POINTS, OnPoints)
	ON_BN_CLICKED(IDC_NAME, OnName)
	ON_BN_CLICKED(IDC_LAPTIMES, OnLaptimes)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CImport message handlers

void CImport::OnTrack1() 
{
	UpdateData(TRUE);
	if(m_Track1==TRUE)
	{
		m_Checked[0]=0;
		m_Track1=FALSE;
	}
	else
	{
		m_Checked[0]=1;
		m_Track1=TRUE;
	}
	UpdateData(FALSE);
}

void CImport::OnTrack2() 
{
	UpdateData(TRUE);
	if(m_Track2==TRUE)
	{
		m_Checked[1]=0;
		m_Track2=FALSE;
	}
	else
	{
		m_Checked[1]=1;
		m_Track2=TRUE;
	}
	UpdateData(FALSE);
}

void CImport::OnTrack10() 
{
	UpdateData(TRUE);
	if(m_Track10==TRUE)
	{
		m_Checked[9]=0;
		m_Track10=FALSE;
	}
	else
	{
		m_Checked[9]=1;
		m_Track10=TRUE;
	}
	UpdateData(FALSE);
}

void CImport::OnTrack11() 
{
	UpdateData(TRUE);
	if(m_Track11==TRUE)
	{
		m_Checked[10]=0;
		m_Track11=FALSE;
	}
	else
	{
		m_Checked[10]=1;
		m_Track11=TRUE;
	}
	UpdateData(FALSE);
}

void CImport::OnTrack12() 
{
	UpdateData(TRUE);
	if(m_Track12==TRUE)
	{
		m_Checked[11]=0;
		m_Track12=FALSE;
	}
	else
	{
		m_Checked[11]=1;
		m_Track12=TRUE;
	}
	UpdateData(FALSE);
}

void CImport::OnTrack13() 
{
	UpdateData(TRUE);
	if(m_Track13==TRUE)
	{
		m_Checked[12]=0;
		m_Track13=FALSE;
	}
	else
	{
		m_Checked[12]=1;
		m_Track13=TRUE;
	}
	UpdateData(FALSE);
}

void CImport::OnTrack14() 
{
	UpdateData(TRUE);
	if(m_Track14==TRUE)
	{
		m_Checked[13]=0;
		m_Track14=FALSE;
	}
	else
	{
		m_Checked[13]=1;
		m_Track14=TRUE;
	}
	UpdateData(FALSE);
}

void CImport::OnTrack15() 
{
	UpdateData(TRUE);
	if(m_Track15==TRUE)
	{
		m_Checked[14]=0;
		m_Track15=FALSE;
	}
	else
	{
		m_Checked[14]=1;
		m_Track15=TRUE;
	}
	UpdateData(FALSE);
}

void CImport::OnTrack16() 
{
	UpdateData(TRUE);
	if(m_Track16==TRUE)
	{
		m_Checked[15]=0;
		m_Track16=FALSE;
	}
	else
	{
		m_Checked[15]=1;
		m_Track16=TRUE;
	}
	UpdateData(FALSE);
}

void CImport::OnTrack3() 
{
	UpdateData(TRUE);
	if(m_Track3==TRUE)
	{
		m_Checked[2]=0;
		m_Track3=FALSE;
	}
	else
	{
		m_Checked[2]=1;
		m_Track3=TRUE;
	}
	UpdateData(FALSE);
}

void CImport::OnTrack4() 
{
	UpdateData(TRUE);
	if(m_Track4==TRUE)
	{
		m_Checked[3]=0;
		m_Track4=FALSE;
	}
	else
	{
		m_Checked[3]=1;
		m_Track4=TRUE;
	}
	UpdateData(FALSE);
}
void CImport::OnTrack5() 
{
	UpdateData(TRUE);
	if(m_Track5==TRUE)
	{
		m_Checked[4]=0;
		m_Track5=FALSE;
	}
	else
	{
		m_Checked[4]=1;
		m_Track5=TRUE;
	}
	UpdateData(FALSE);
}

void CImport::OnTrack6() 
{
	UpdateData(TRUE);
	if(m_Track6==TRUE)
	{
		m_Checked[5]=0;
		m_Track6=FALSE;
	}
	else
	{
		m_Checked[5]=1;
		m_Track6=TRUE;
	}
	UpdateData(FALSE);
}

void CImport::OnTrack7() 
{
	UpdateData(TRUE);
	if(m_Track7==TRUE)
	{
		m_Checked[6]=0;
		m_Track7=FALSE;
	}
	else
	{
		m_Checked[6]=1;
		m_Track7=TRUE;
	}
	UpdateData(FALSE);
}

void CImport::OnTrack8() 
{
	UpdateData(TRUE);
	if(m_Track8==TRUE)
	{
		m_Checked[7]=0;
		m_Track8=FALSE;
	}
	else
	{
		m_Checked[7]=1;
		m_Track8=TRUE;
	}
	UpdateData(FALSE);
}

void CImport::OnTrack9() 
{
	UpdateData(TRUE);
	if(m_Track9==TRUE)
	{
		m_Checked[8]=0;
		m_Track9=FALSE;
	}
	else
	{
		m_Checked[8]=1;
		m_Track9=TRUE;
	}
	UpdateData(FALSE);
}

void CImport::OnOK() 
{
Gp3Data gpData;
CGp3MenuText gpText;
CFileHandling fh;
int i;
CString sztfile;
char ch;

	BeginWaitCursor();
	UpdateData(TRUE);
	m_StrFile.MakeLower();
	if(m_StrFile!="english.str")
		gpText.SetLanguageDiff(8);
	else
		gpText.SetLanguageDiff(0);
	gpData.LoadData(m_Gp3Path);
	gpText.LoadText(m_Gp3Path+"\\ldata\\"+m_StrFile);

	for(i=0;i<16;i++)
	{
		if(m_Checked[i]==1)
		{
			fh.Load(m_TempFile,i);
			if(m_Name==TRUE)
			{
				fh.SetCountry(gpText.GetTrackCountry(i));
				fh.SetAdjective(gpText.GetTrackAdjective(i));
				fh.SetName(gpText.GetTrackName(i));
			}
			if(m_Laps==TRUE)
				fh.SetLaps(gpData.GetLaps(i));
			if(m_Len==TRUE)
				fh.SetLen(gpData.GetLength(i));

			if(i<9)
				sztfile=m_Gp3Path+"\\circuits\\f1ct0";
			else
				sztfile=m_Gp3Path+"\\circuits\\f1ct1";
			sztfile+=itoa(i+1,&ch,10);
			sztfile+=".dat";	

			if(m_LapTime==TRUE)
			{
				fh.SetQualDriver(gpData.GetQualDriver(i));
				fh.SetRaceDriver(gpData.GetRaceDriver(i));
				fh.SetQualTeam(gpData.GetQualTeam(i));
				fh.SetRaceTeam(gpData.GetRaceTeam(i));
				fh.SetQualDate(gpData.GetQualDate(i));
				fh.SetRaceDate(gpData.GetRaceDate(i));
				fh.SetQualTime(gpData.GetQualTime(i));
				fh.SetRaceTime(gpData.GetRaceTime(i));
			}

			fh.SetFileName(sztfile);
			fh.Save(m_TempFile,i);
		}
	}
	if(m_Points==TRUE)
	{
		sztfile="";
		fh.LoadMisc(m_TempFile);
		for(i=0;i<26;i++)
		{
			sztfile+=gpData.GetPoint(i);
			sztfile+="|";
		}
		fh.SetPoints(sztfile);
		fh.SaveMisc(m_TempFile);
	}

	EndWaitCursor();
	CDialog::OnOK();
}

BOOL CImport::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	for(int i=0;i<16;i++)
		m_Checked[i]=1;
	m_Track1=TRUE;
	m_Track2=TRUE;
	m_Track3=TRUE;
	m_Track4=TRUE;
	m_Track5=TRUE;
	m_Track6=TRUE;
	m_Track7=TRUE;
	m_Track8=TRUE;
	m_Track9=TRUE;
	m_Track10=TRUE;
	m_Track11=TRUE;
	m_Track12=TRUE;
	m_Track13=TRUE;
	m_Track14=TRUE;
	m_Track15=TRUE;
	m_Track16=TRUE;
	
	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CImport::OnLap() 
{
	UpdateData(TRUE);	
	if(m_Laps==TRUE)
		m_Laps=FALSE;
	else
		m_Laps=TRUE;
	UpdateData(FALSE);
}

void CImport::OnLen() 
{
	UpdateData(TRUE);	
	if(m_Len==TRUE)
		m_Len=FALSE;
	else
		m_Len=TRUE;
	UpdateData(FALSE);	
}

void CImport::OnPoints() 
{
	UpdateData(TRUE);	
	if(m_Points==TRUE)
		m_Points=FALSE;
	else
		m_Points=TRUE;
	UpdateData(FALSE);
}

void CImport::OnName() 
{
	UpdateData(TRUE);	
	if(m_Name==TRUE)
		m_Name=FALSE;
	else
		m_Name=TRUE;
	UpdateData(FALSE);
}

void CImport::OnLaptimes() 
{
	UpdateData(TRUE);
	if(m_LapTime==TRUE)
		m_LapTime=FALSE;
	else
		m_LapTime=TRUE;
	UpdateData(FALSE);
}

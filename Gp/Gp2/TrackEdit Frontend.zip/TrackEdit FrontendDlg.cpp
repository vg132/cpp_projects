// TrackEdit FrontendDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TrackEdit Frontend.h"
#include "TrackEdit FrontendDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTrackEditFrontendDlg dialog

CTrackEditFrontendDlg::CTrackEditFrontendDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTrackEditFrontendDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTrackEditFrontendDlg)
	m_Author = _T("");
	m_Country = _T("");
	m_Event = _T("");
	m_Laps = _T("");
	m_Len = _T("");
	m_Name = _T("");
	m_Misc = _T("");
	m_Slot = _T("");
	m_Tyre = _T("");
	m_Year = _T("");
	m_Status = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDI_Logo);
}

void CTrackEditFrontendDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTrackEditFrontendDlg)
	DDX_Control(pDX, IDC_SortItems, m_SortItems);
	DDX_Control(pDX, IDC_Icon, m_Icon);
	DDX_Control(pDX, IDC_List, m_List);
	DDX_Control(pDX, IDC_ListEx, m_ListEx);
	DDX_Control(pDX, IDC_Drive, m_Drive);
	DDX_Control(pDX, IDC_UpOneLevel, m_UpOneLevel);
	DDX_Control(pDX, IDC_Explorer, m_FileList);
	DDX_Text(pDX, IDC_Author, m_Author);
	DDX_Text(pDX, IDC_Country, m_Country);
	DDX_Text(pDX, IDC_Event, m_Event);
	DDX_Text(pDX, IDC_Laps, m_Laps);
	DDX_Text(pDX, IDC_Length, m_Len);
	DDX_Text(pDX, IDC_Name, m_Name);
	DDX_Text(pDX, IDC_Misc, m_Misc);
	DDX_Text(pDX, IDC_Slot, m_Slot);
	DDX_Text(pDX, IDC_Tyre, m_Tyre);
	DDX_Text(pDX, IDC_Year, m_Year);
	DDX_Text(pDX, IDC_Status, m_Status);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTrackEditFrontendDlg, CDialog)
	//{{AFX_MSG_MAP(CTrackEditFrontendDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_UpOneLevel, OnUpOneLevel)
	ON_NOTIFY(NM_DBLCLK, IDC_Explorer, OnDblclkExplorer)
	ON_CBN_SELCHANGE(IDC_Drive, OnSelchangeDrive)
	ON_NOTIFY(NM_CLICK, IDC_Explorer, OnClickExplorer)
	ON_BN_CLICKED(IDC_Start, OnStart)
	ON_COMMAND(IDC_SetTrackPath, OnSetTrackPath)
	ON_COMMAND(IDC_SetTrackEdit, OnSetTrackEdit)
	ON_BN_CLICKED(IDC_List, OnList)
	ON_BN_CLICKED(IDC_ListEx, OnListEx)
	ON_BN_CLICKED(IDC_Icon, OnIcon)
	ON_COMMAND(IDC_MenuExit, OnMenuExit)
	ON_NOTIFY(HDN_ITEMCLICK, IDC_Explorer, OnItemclickExplorer)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_Explorer, OnItemchangedExplorer)
	ON_WM_CREATE()
	ON_COMMAND(IDC_MenuAbout, OnMenuAbout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTrackEditFrontendDlg message handlers

BOOL CTrackEditFrontendDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
CTrackEditFrontendApp* pApp;
	//Make a image list
	UpdateData(TRUE);
	pApp = (CTrackEditFrontendApp *)AfxGetApp();
	m_pImageList=new CImageList();
	m_pImageList->Create(16, 16, ILC_MASK, 2, 2);
	m_pImageList->Add(pApp->LoadIcon(IDI_Track));//		0
	m_pImageList->Add(pApp->LoadIcon(IDI_Folder));//	1
	m_pImageList->Add(pApp->LoadIcon(IDI_Drive));//		2
	m_pImageList->Add(pApp->LoadIcon(IDI_Net));//		3	
	m_pImageList->Add(pApp->LoadIcon(IDI_Ram));//		4
	m_pImageList->Add(pApp->LoadIcon(IDI_Remove));//	5
	m_pImageList->Add(pApp->LoadIcon(IDI_CD));//		6
	m_pImageList->Add(pApp->LoadIcon(IDI_Question));//	7	

	m_pLargeList=new CImageList();
	m_pLargeList->Create(32, 32, ILC_MASK, 2, 2);
	m_pLargeList->Add(pApp->LoadIcon(IDI_Track));
	m_pLargeList->Add(pApp->LoadIcon(IDI_Folder));
	m_pLargeList->Add(pApp->LoadIcon(IDI_Drive));
	m_pLargeList->Add(pApp->LoadIcon(IDI_Net));
	m_pLargeList->Add(pApp->LoadIcon(IDI_Ram));
	m_pLargeList->Add(pApp->LoadIcon(IDI_Remove));
	m_pLargeList->Add(pApp->LoadIcon(IDI_CD));
	m_pLargeList->Add(pApp->LoadIcon(IDI_Question));

	//Set big and small image list
	m_FileList.SetImageList(m_pImageList,LVSIL_SMALL);
	m_FileList.SetImageList(m_pLargeList,LVSIL_NORMAL);

	//add columns
	m_FileList.InsertColumn(0,"Name",LVCFMT_LEFT,250,-1);
	m_FileList.InsertColumn(1,"File Size",LVCFMT_LEFT,120,-1);
	m_SortItems.InsertColumn(0,"Name",LVCFMT_LEFT,250,-1);
	m_SortItems.InsertColumn(1,"File Size",LVCFMT_LEFT,120,-1);

	m_Drive.SetImageList(m_pImageList);

	//Set button bitmaps
HBITMAP hBmp;
	hBmp=::LoadBitmap(AfxGetApp()->m_hInstance,MAKEINTRESOURCE(IDB_Up1lvl));
	m_UpOneLevel.SetBitmap(hBmp);
	hBmp=::LoadBitmap(AfxGetApp()->m_hInstance,MAKEINTRESOURCE(IDB_List));
	m_List.SetBitmap(hBmp);
	hBmp=::LoadBitmap(AfxGetApp()->m_hInstance,MAKEINTRESOURCE(IDB_ListEx));
	m_ListEx.SetBitmap(hBmp);
	hBmp=::LoadBitmap(AfxGetApp()->m_hInstance,MAKEINTRESOURCE(IDB_Icons));
	m_Icon.SetBitmap(hBmp);

	//Set Button state
	m_List.SetState(1);
	m_ListEx.SetState(0);
	m_Icon.SetState(0);

	cEditFile=RegGetValue("Software\\VG Software\\GP2 Track Edit","");
	cPath=RegGetValue("Software\\VG Software\\GP2 Track Edit","Track Path");
	if (cPath=="")
	{
		cPath="c:\\";
	}
	AddDrivers();
	UpdateList(cPath);

	UpdateData(FALSE);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTrackEditFrontendDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTrackEditFrontendDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTrackEditFrontendDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTrackEditFrontendDlg::UpdateList(CString Dir)
{
BOOL bFound=FALSE;
CString cFile;
CString cFileExt;
int iFile;
int iFolder;
int i;
char FileName[260];
char FileSize[20];
int iCurPos;
DWORD dwFileSize;
WIN32_FIND_DATA wfd;

	hFile=(HANDLE)-1;
	m_FileList.DeleteAllItems();
	iFile=1000;
	iFolder=0;
	//Check if it ends with "\"
	if (Dir.Right(1)!="\\")
	{
		Dir+="\\";
	}

	//Only find *.dat files
	if (Dir.Right(3)!="*.dat")
	{
		Dir+="*.dat";
	}
	//Find first file
	hFile=FindFirstFile(Dir,&wfd);
	while(!bFound)
	{
		//Set cFile to filename
		cFile=wfd.cFileName;
		cFile.MakeLower();
		//Check if it's a directory, if it's a dir then exit
		if (wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
		{
		}
		else
		{
			//If not a dir then a *.dat file! NOT!
			if (cFile.Right(3)=="dat")
			{
				//Add item to m_SortItems for sort
				iCurPos=m_SortItems.InsertItem(NULL,wfd.cFileName,NULL);
				//Get file size
				dwFileSize=wfd.nFileSizeLow;
				i=dwFileSize/1000;
				_itoa(i,FileSize,10);
				cFile=FileSize;
				cFile+=" kb";
				//Set file size as sub item in m_SortItems
				m_SortItems.SetItemText(iCurPos,1,cFile);
				iFile+=1;
			}
		}
		//Find next file
		bFound = !FindNextFile(hFile,&wfd);
    }
	//Reset bFound
	bFound=FALSE;
	//Count found items
	iFile=m_SortItems.GetItemCount();
	//loop every item in m_SortItems
	for (i=0;i<iFile;i++)
	{
		//Get first items
		m_SortItems.GetItemText(i,0,FileName,sizeof(FileName));
		//write first items
		iCurPos=m_FileList.InsertItem(i+1000,FileName,0);
		//get file size for items
		m_SortItems.GetItemText(i,1,FileSize,sizeof(FileSize));
		//write file size for item
		m_FileList.SetItemText(iCurPos,1,FileSize);
	}
	//clear m_SortItems
	m_SortItems.DeleteAllItems();

	//Change to find all files
	iFile=Dir.GetLength();
	iFile=iFile-3;
	Dir.Delete(iFile,3);
	Dir+="*";
	//Reset hFile
	hFile=(HANDLE)-1;
	hFile=FindFirstFile(Dir,&wfd);
	while(!bFound)
	{
		cFile=wfd.cFileName;
		//if its a dir then continue
		if (wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
		{
			//If it's NOT "." or ".." then it's a dir and show it!
			if (cFile.Left(1)!=".")
			{
				//Add dir to m_SortItems
				m_SortItems.InsertItem(NULL,cFile,NULL);
				iFolder+=1;
			}
		}
		bFound=!FindNextFile(hFile,&wfd);
	}
	//??
	m_Status="Bra";
	UpdateData(FALSE);

	iFile=m_SortItems.GetItemCount();
	for (i=0;i<iFile;i++)
	{
		m_SortItems.GetItemText(i,0,FileName,sizeof(FileName));
		m_FileList.InsertItem(i,FileName,1);
	}
	m_SortItems.DeleteAllItems();
}

void CTrackEditFrontendDlg::OnUpOneLevel() 
{

CString cCur;
int iPos;

	iPos=cPath.GetLength();
	if (cPath.GetLength()==3)
	{
		ListDrivers();
	}
	else
	{
		iPos=cPath.GetLength()-2;
		for(int i=iPos;i>=1;i--)
		{
			if (cPath.Mid(i,1)=="\\")
			{
				cPath=cPath.Left(i+1);
				break;
			}
		}
		UpdateList(cPath);
	}
}

void CTrackEditFrontendDlg::OnDblclkExplorer(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
CString cItem;
POSITION pos;
int iItem;
BOOL bFound=FALSE;
WIN32_FIND_DATA wfd;
int iStr;

	hFile=(HANDLE)-1;	
	BeginWaitCursor();
	GetDlgItem(IDC_Start)->EnableWindow(FALSE);
	pos=m_FileList.GetFirstSelectedItemPosition();
	iItem=m_FileList.GetNextSelectedItem(pos);
	cItem=m_FileList.GetItemText(iItem,0);
	if (cItem!="")
	{
		iStr=0;
		iStr=cItem.Find("\\",0);
		if (iStr==2)
		{
			cPath=cItem.Mid(0,3);
			m_Drive.SetCurSel(iItem);
			UpdateList(cPath);
		}
		else
		{
			hFile=FindFirstFile(cPath+cItem,&wfd);
			if (wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			{
				cPath+=cItem+"\\";
				UpdateList(cPath);
			}
			else
			{
				cItem=cPath+cItem;
				ReadGP2Info(cItem);
				EditTrack();
			}
		}
	}
	EndWaitCursor();
	*pResult = 0;
}

void CTrackEditFrontendDlg::ListDrivers()
{
DWORD dwDrivers;
DWORD dwBuffer;
char Drivers[260];
CString cDrive;
int Temp;
char VolName[20];
DWORD dwVolNum;
char FileSys[20];
DWORD Test;
CString cVolName;

	m_Status="Dligt";
	UpdateData(FALSE);
	m_FileList.DeleteAllItems();
	dwBuffer=260;
	dwDrivers=GetLogicalDriveStrings(dwBuffer,Drivers);
	dwDrivers/=4;
	for (int i=1;i<=dwDrivers;i++)
	{	
		Temp=(i-1)*4;
		cDrive=Drivers[Temp];
		cDrive+=Drivers[Temp+1];
		Temp=GetDriveType(cDrive);
		cDrive+="\\";
		if (Temp!=DRIVE_REMOVABLE)
		{
			GetVolumeInformation(cDrive,VolName,20,&dwVolNum,&Test,NULL,FileSys,20);
			cVolName=VolName;
			if (cVolName.GetLength()!=0)
			{
				cDrive+=" [";
				cDrive+=cVolName;
				cDrive+="]";
			}
		}

		if (Temp==DRIVE_FIXED)
		{
			m_FileList.InsertItem(i,cDrive,2);
		}
		else if (Temp==DRIVE_UNKNOWN)
		{
			m_FileList.InsertItem(NULL,cDrive,7);
		}
		else if (Temp==DRIVE_NO_ROOT_DIR)
		{
			m_FileList.InsertItem(i,cDrive,2);
		}
		else if (Temp==DRIVE_REMOVABLE)
		{
			m_FileList.InsertItem(i,cDrive,5);
		}
		else if (Temp==DRIVE_REMOTE)
		{
			m_FileList.InsertItem(i,cDrive,3);
		}
		else if (Temp==DRIVE_CDROM)
		{
			m_FileList.InsertItem(i,cDrive,6);
		}
		else if (Temp==DRIVE_RAMDISK)
		{
			m_FileList.InsertItem(i,cDrive,4);
		}
	}
}

void CTrackEditFrontendDlg::AddDrivers()
{
DWORD dwDrivers;
DWORD dwBuffer;
char Drivers[260];
CString cDrive;
int Temp;
char VolName[20];
DWORD dwVolNum;
char FileSys[20];
DWORD Test;
CString cVolName;
CString cTempDrive;
int iSelItem;
COMBOBOXEXITEMA cbi;

	cTempDrive=cPath.Mid(0,2);
	cTempDrive.MakeLower();
	m_FileList.DeleteAllItems();
	dwBuffer=260;
	dwDrivers=GetLogicalDriveStrings(dwBuffer,Drivers);
	dwDrivers/=4;
	for (int i=1;i<=dwDrivers;i++)
	{	
		Temp=(i-1)*4;
		cDrive=Drivers[Temp];
		cDrive+=Drivers[Temp+1];
		Temp=GetDriveType(cDrive);
		cDrive+="\\";
		if (Temp!=DRIVE_REMOVABLE)
		{
			GetVolumeInformation(cDrive,VolName,20,&dwVolNum,&Test,NULL,FileSys,20);
			cVolName=VolName;
			if (cVolName.GetLength()!=0)
			{
				cDrive+=" [";
				cDrive+=cVolName;
				cDrive+="]";
			}
		}
		
		
		cbi.iItem=-1;
		cDrive.Format(_T(cDrive), i);
		cbi.pszText=(LPTSTR)(LPCTSTR)cDrive;
		cbi.iIndent=0;
		cbi.cchTextMax=cDrive.GetLength();
		cbi.mask = CBEIF_IMAGE | CBEIF_INDENT | CBEIF_TEXT | CBEIF_SELECTEDIMAGE;

		if (Temp==DRIVE_FIXED)
		{
			cbi.iImage=2;
			cbi.iSelectedImage=2;
			iSelItem=m_Drive.InsertItem(&cbi);
			cDrive.MakeLower();
			if (cTempDrive==cDrive.Mid(0,2))
			{
				m_Drive.SetCurSel(iSelItem);
			}
		}
		else if (Temp==DRIVE_UNKNOWN)
		{
			cbi.iImage=7;
			cbi.iSelectedImage=7;
			iSelItem=m_Drive.InsertItem(&cbi);
			cDrive.MakeLower();
			if (cTempDrive==cDrive.Mid(0,2))
			{
				m_Drive.SetCurSel(iSelItem);
			}
		}
		else if (Temp==DRIVE_NO_ROOT_DIR)
		{
			cbi.iImage=2;
			cbi.iSelectedImage=2;
			iSelItem=m_Drive.InsertItem(&cbi);
			cDrive.MakeLower();
			if (cTempDrive==cDrive.Mid(0,2))
			{
				m_Drive.SetCurSel(iSelItem);
			}
		}
		else if (Temp==DRIVE_REMOVABLE)
		{
			cbi.iImage=5;
			cbi.iSelectedImage=5;
			iSelItem=m_Drive.InsertItem(&cbi);
			cDrive.MakeLower();
			if (cTempDrive==cDrive.Mid(0,2))
			{
				m_Drive.SetCurSel(iSelItem);
			}
		}
		else if (Temp==DRIVE_REMOTE)
		{
			cbi.iImage=3;
			cbi.iSelectedImage=3;
			iSelItem=m_Drive.InsertItem(&cbi);
			cDrive.MakeLower();
			if (cTempDrive==cDrive.Mid(0,2))
			{
				m_Drive.SetCurSel(iSelItem);
			}
		}
		else if (Temp==DRIVE_CDROM)
		{
			cbi.iImage=6;
			cbi.iSelectedImage=6;
			iSelItem=m_Drive.InsertItem(&cbi);
			cDrive.MakeLower();
			if (cTempDrive==cDrive.Mid(0,2))
			{
				m_Drive.SetCurSel(iSelItem);
			}
		}
		else if (Temp==DRIVE_RAMDISK)
		{
			cbi.iImage=4;
			cbi.iSelectedImage=4;
			iSelItem=m_Drive.InsertItem(&cbi);
			cDrive.MakeLower();
			if (cTempDrive==cDrive.Mid(0,2))
			{
				m_Drive.SetCurSel(iSelItem);
			}
		}
		UpdateData(FALSE);
	}
}

void CTrackEditFrontendDlg::OnSelchangeDrive() 
{
CString cDrive;
	m_Drive.GetWindowText(cDrive);
	cPath=cDrive.Mid(0,3);
	UpdateList(cPath);
}

void CTrackEditFrontendDlg::ReadGP2Info(CString FilePath)
{
char Check[8];
char GetData[4000];
CString cData;
int iStart;
int iStopp;

	CFile fTrackFile;
	fTrackFile.Open(FilePath,CFile::modeRead,NULL);
	fTrackFile.Read(Check,sizeof(Check));
	cData=Check;
	cData=cData.Left(8);
	if (cData=="#GP2INFO")
	{
		fTrackFile.Read(GetData,sizeof(GetData));
		cData=GetData;
		iStart=cData.Find("Name|",0);
		if (iStart!=-1)
		{
			iStart=iStart+5;
			iStopp=cData.Find("|",iStart+5);
			iStopp-=iStart;
			m_Name=cData.Mid(iStart,iStopp);
		}
		iStart=cData.Find("Country|",0);
		if (iStart!=-1)
		{
			iStart=iStart+8;
			iStopp=cData.Find("|",iStart);
			iStopp-=iStart;
			m_Country=cData.Mid(iStart,iStopp);
		}
		iStart=cData.Find("Author|",0);
		if (iStart!=-1)
		{
			iStart=iStart+7;
			iStopp=cData.Find("|",iStart);
			iStopp-=iStart;
			m_Author=cData.Mid(iStart,iStopp);
		}
		iStart=cData.Find("Year|",0);
		if (iStart!=-1)
		{
			iStart=iStart+5;
			iStopp=cData.Find("|",iStart);
			iStopp-=iStart;
			m_Year=cData.Mid(iStart,iStopp);
		}
		iStart=cData.Find("Event|",0);
		if (iStart!=-1)
		{
			iStart=iStart+6;
			iStopp=cData.Find("|",iStart);
			iStopp-=iStart;
			m_Event=cData.Mid(iStart,iStopp);
		}
		iStart=cData.Find("Desc|",0);
		if (iStart!=-1)
		{
			iStart=iStart+5;
			iStopp=cData.Find("|",iStart);
			iStopp-=iStart;
			m_Misc=cData.Mid(iStart,iStopp);
		}
		iStart=cData.Find("Laps|",0);
		if (iStart!=-1)
		{
			iStart=iStart+5;
			iStopp=cData.Find("|",iStart);
			iStopp-=iStart;
			m_Laps=cData.Mid(iStart,iStopp);
		}
		iStart=cData.Find("Slot|",0);
		if (iStart!=-1)
		{
			iStart=iStart+5;
			iStopp=cData.Find("|",iStart);
			iStopp-=iStart;
			m_Slot=cData.Mid(iStart,iStopp);
		}
		iStart=cData.Find("Tyre|",0);
		if (iStart!=-1)
		{
			iStart=iStart+5;
			iStopp=cData.Find("|",iStart);
			iStopp-=iStart;
			m_Tyre=cData.Mid(iStart,iStopp);
		}
		iStart=cData.Find("LengthMeters|",0);
		if (iStart!=-1)
		{
			iStart=iStart+13;
			iStopp=cData.Find("|",iStart);
			iStopp-=iStart;
			m_Len=cData.Mid(iStart,iStopp);
		}
		UpdateData(FALSE);
	}	
	GetDlgItem(IDC_Start)->EnableWindow(TRUE);
	fTrackFile.Close();
}

void CTrackEditFrontendDlg::OnClickExplorer(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
CString cItem;
POSITION pos;
int iItem;
BOOL bFound=FALSE;
WIN32_FIND_DATA wfd;

	hFile=(HANDLE)-1;	
	BeginWaitCursor();
	GetDlgItem(IDC_Start)->EnableWindow(FALSE);
	UpdateData(TRUE);
	pos=m_FileList.GetFirstSelectedItemPosition();
	iItem=m_FileList.GetNextSelectedItem(pos);
	cItem=m_FileList.GetItemText(iItem,0);
	if (cItem!="")
	{
		if (m_Status=="Bra")
		{
			hFile=FindFirstFile(cPath+cItem,&wfd);
			if (wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			{
			}
			else
			{
				cItem=cPath+cItem;
				ReadGP2Info(cItem);
			}
		}	
	}
	EndWaitCursor();
	*pResult = 0;
}

void CTrackEditFrontendDlg::OnStart() 
{
	EditTrack();
}

void CTrackEditFrontendDlg::OnSetTrackPath() 
{
CString cTrackPath;
	cTrackPath=BrowseForFolders("Select Track Path");
	if (cTrackPath!="")
	{
		
		if (cTrackPath.Right(1)!="\\")
		{
			cTrackPath+="\\";
		}
		
		RegSaveValue("Software\\VG Software\\GP2 Track Edit","Track Path",cTrackPath);
		cPath=cTrackPath;
		UpdateList(cPath);
	}
}

void CTrackEditFrontendDlg::GetPath()
{
int iPos;

	iPos=cEditFile.GetLength();
	for(int i=iPos;i>=1;i--)
	{
		if (cEditFile.Mid(i,1)=="\\")
		{
			cEditPath=cEditFile.Left(i);
			break;
		}
	}
}

void CTrackEditFrontendDlg::OnSetTrackEdit() 
{
TCHAR szFilter[]=_T("Track Edit Exe file (*.exe)\0*.exe\0\0");
HKEY hKey;

	CFileDialog fDialog(FALSE, NULL, NULL, OFN_HIDEREADONLY | OFN_EXPLORER, NULL, NULL);
	fDialog.m_ofn.lpstrFilter=szFilter;
	fDialog.m_ofn.lpstrTitle="Select Track Editor";
	int iReturn = fDialog.DoModal();
	if(iReturn ==  IDOK)
	{
		cEditFile=fDialog.m_ofn.lpstrFile;
		GetPath();
		hKey=HKEY_CURRENT_USER;
		RegSetValue(hKey,"Software\\VG Software\\GP2 Track Edit",REG_SZ,cEditFile,cEditFile.GetLength());
		RegCloseKey(hKey);
	}	
}

void CTrackEditFrontendDlg::GetListItems()
{
CStringArray cArray;
char cFile[260];
CString cItem;
int i;
	cArray.SetSize(m_FileList.GetItemCount());
	for (i=0;i<m_FileList.GetItemCount();++i)
	{
		m_FileList.GetItemText(i,0,cFile,260);
		cArray.SetAt(i,cFile);
	}
	for (i=0;i<cArray.GetSize();++i)
	{
		m_FileList.InsertItem(NULL,cArray.GetAt(i),NULL);
	}
}

void CTrackEditFrontendDlg::OnList() 
{
	m_FileList.ModifyStyle(LVS_TYPEMASK, LVS_LIST & LVS_TYPEMASK);
	m_List.SetState(1);
	m_ListEx.SetState(0);
	m_Icon.SetState(0);
}

void CTrackEditFrontendDlg::OnListEx() 
{
	m_FileList.ModifyStyle(LVS_TYPEMASK, LVS_REPORT & LVS_TYPEMASK);
	m_ListEx.SetState(1);
	m_List.SetState(0);
	m_Icon.SetState(0);
}

void CTrackEditFrontendDlg::OnIcon() 
{
	m_FileList.ModifyStyle(LVS_TYPEMASK, LVS_ICON & LVS_TYPEMASK);
	m_Icon.SetState(1);
	m_ListEx.SetState(0);
	m_List.SetState(0);
}

CString CTrackEditFrontendDlg::RegGetValue(CString cKey,CString cValue)
{
HKEY hKey;
char lpBuffer[260];
int RetVal;
unsigned long lwSize=260;
CString Conv;

	hKey=HKEY_CURRENT_USER;
	if (RegOpenKey(hKey,cKey,&hKey)==ERROR_SUCCESS)
	{
		RetVal=RegQueryValueEx(hKey,cValue,NULL,0,(LPBYTE)lpBuffer,&lwSize);
	}
	Conv=lpBuffer;
	if (Conv.GetLength()==267)
	{
		Conv="";
	}
	return(Conv);
}

void CTrackEditFrontendDlg::RegSaveValue(CString cKey,CString cValue,CString cData)
{
HKEY hKey;
TCHAR szData[260];

	lstrcpy(szData, TEXT(cData));     
	hKey=HKEY_CURRENT_USER;
	if (RegOpenKey(hKey,cKey,&hKey)==ERROR_SUCCESS)
	{
		RegSetValueEx(hKey,cValue,NULL,1,(LPBYTE)szData,sizeof(szData)+1);
	}
}

CString CTrackEditFrontendDlg::BrowseForFolders(CString szTitle)
{
//Browse for folders
char szPath[260];
BROWSEINFO bff;
LPITEMIDLIST pidl;
CString cDir="";

bff.hwndOwner		=m_hWnd;
bff.iImage			=0;
bff.lParam			=0;
bff.lpszTitle		=szTitle;
bff.pidlRoot		=NULL;
bff.ulFlags			=BIF_RETURNONLYFSDIRS;
bff.pszDisplayName	=szPath;
bff.lpfn			=NULL;

	//Show Browse for folders
	pidl=SHBrowseForFolder(&bff);
	if (pidl)
	{
		//Get Selected path
		SHGetPathFromIDList(pidl,szPath);
		cDir=szPath;
	}
	return(cDir);
}

void CTrackEditFrontendDlg::OnMenuExit() 
{
	OnOK();	
}

void CTrackEditFrontendDlg::OnItemclickExplorer(NMHDR* pNMHDR, LRESULT* pResult) 
{
	HD_NOTIFY *phdn = (HD_NOTIFY *) pNMHDR;
	MessageBox("HEj",NULL,NULL);	
	*pResult = 0;
}

void CTrackEditFrontendDlg::OnItemchangedExplorer(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	
POSITION pos;
int RetVal;
CString cItem;
HANDLE hFile;
WIN32_FIND_DATA wfd;

	pos=m_FileList.GetFirstSelectedItemPosition();
	RetVal=m_FileList.GetNextSelectedItem(pos);
	cItem=m_FileList.GetItemText(RetVal,0);
	if (cItem!="")
	{
		if (m_Status=="Bra")
		{
			hFile=FindFirstFile(cPath+cItem,&wfd);
			if (wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			{
			}
			else
			{
				cItem=cPath+cItem;
				ReadGP2Info(cItem);
			}
		}	
	}
	*pResult = 0;
}

void CTrackEditFrontendDlg::EditTrack()
{
POSITION pos;
int iItem;
CString cFile;
char ShortFile[260];
	pos=m_FileList.GetFirstSelectedItemPosition();
	iItem=m_FileList.GetNextSelectedItem(pos);
	cFile=m_FileList.GetItemText(iItem,0);	
	cFile=cPath+cFile;
	GetShortPathName(cFile,ShortFile,260);
	cFile=ShortFile;
	ShellExecute(m_hWnd,"open",cEditFile,cFile,cEditPath,1);
}

void CTrackEditFrontendDlg::OnMenuAbout() 
{
	CAboutDlg dlg;
	dlg.DoModal();
}

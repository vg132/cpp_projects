// JamTextureTracker.h: header file for the CJamTextureTracker class
//

#ifndef __JAM_TEXTURE_TRACKER_H__
#define __JAM_TEXTURE_TRACKER_H__

/////////////////////////////////////////////////////////////////
// Class:	CJamTextureTracker
// Base:	CRectTracker
// Created:	28 March 1999 by Mal Ross
// Overview:
//    A class used to manage the manipulation of jam textures in
//  the Jam View.
//

class CJamTextureTracker : public CRectTracker
{
// Construction/destruction
public:
	CJamTextureTracker();
	virtual ~CJamTextureTracker();

// Attributes
protected:
	// The granularity of the snap-to-grid grid
	CSize m_sizSnapToGrid;

// Operations
public:

	// Overridables
public:
	// Overridden from CRectTracker to allow snap-to-grid and
	// zoom-factor stuff.
//	virtual void AdjustRect(int nHandle, LPRECT lpRect);

// Implementation
protected:
	// Coordinate conversion routines
//	virtual void ClientToJam(CPoint& point);
//	virtual void JamToClient(CPoint& point);
};

/////////////////////////////////////////////////////////////////

#endif	// ~__JAM_TEXTURE_TRACKER_H__


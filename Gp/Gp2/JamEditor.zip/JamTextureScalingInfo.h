// Jam Texture scaling for id5 objects

// A list of properties involved in the definition of scaling when the
// texture is used for an id5 object.  FYI, id5 objects are those that
// consist of nothing but a single texture and always face the camera.
// For example, trees and flag men are often defined as id5 objects.

// This object will merely front the list in the tree - the contents
// of the list will be set by the jam texture


#ifndef JAM_TEXTURE_SCALING_INFO_H
#define JAM_TEXTURE_SCALING_INFO_H

#include "EditableTypedPtrList.h"
#include "TreeIconDefs.h"

class CJamTextureScalingInfo : public CEditableTypedPtrList
{
public:
	// constructions
	CJamTextureScalingInfo(CEditableObject* pParent) : CEditableTypedPtrList(pParent) {};

	// necessary overrides
	virtual UINT	GetIconID() { return JTI_TEXTURE_SCALING; }		// return the ID for the icon in the tree for this item
	virtual CString GetFullDescription() { return "Scaling info."; }	// return name and value

	// list functions.
	using CEditableTypedPtrList::AddTail;
	POSITION	AddTail(CEditableNumber<SBYTE>* pNumber) { return CEditableTypedPtrList::AddTail( (CEditableObject*)pNumber ); }
	POSITION	AddTail(CEditableNumber<BYTE>* pNumber) { return CEditableTypedPtrList::AddTail( (CEditableObject*)pNumber ); }
	POSITION	AddTail(CEditableNumber<WORD>* pNumber) { return CEditableTypedPtrList::AddTail( (CEditableObject*)pNumber ); }
};


#endif	// ~JAM_TEXTURE_SCALING_INFO_H
// PixelProfile.h - header file for the CPixelProfile class
//

#ifndef __PIXEL_PROFILE_H__
#define __PIXEL_PROFILE_H__


///////////////////////////////////////////////////////////////////
// Class:	CPixelProfile
// Base:	[none]
// Created:	07Feb99 by Mal Ross
// Overview:
//    This class represents how a particular pixel in the raw
//  texture appears in the different local palettes
//

class CPixelProfile
{
// Construction and destruction
public:
	CPixelProfile(const UINT& nNumPalettes);
	CPixelProfile(const CPixelProfile& copyProfile);
	~CPixelProfile();

// Attributes
protected:
	// an array of pixels, to be of the size passed into
	// the constructor, and representing the colour of a
	// given pixel
	BYTE* m_pbPixels;	
	UINT m_nNumPalettes;

	// Various profile/palette indexes
	// Key:
	//   ProfileIndex == index of profile in original, unclustered
	//                   list of profiles
	//   ClusterIndex == index of cluster to which this profile
	//                   belongs.  This will be the eventual palette
	//                   index in the texture.
	//   MasterIndex  == ProfileIndex of the parent cluster's
	//                   representative pixel profile
	int m_nProfileIndex;
	BYTE m_nClusterIndex;
	int m_nMasterIndex;

// Operations
public:
	// Getting/setting the pixel values
	BOOL SetPalettePixel(const UINT& nPaletteNum, const BYTE& pixelValue);
	BYTE GetPalettePixel(const UINT& nPaletteNum) const;

	// Getting/setting the profile/palette indexes
	void SetProfileIndex(const int& nIndex) { m_nProfileIndex = nIndex; }
	void SetClusterIndex(const BYTE& byIndex) { m_nClusterIndex = byIndex; }
	void SetMasterIndex(const int& nIndex) { m_nMasterIndex = nIndex; }
	int GetProfileIndex() const { return m_nProfileIndex; }
	BYTE GetClusterIndex() const { return m_nClusterIndex; }
	int GetMasterIndex() const { return m_nMasterIndex; }

	// Equality operator (FOR PIXEL VALUES ONLY)
	BOOL operator== (const CPixelProfile& other) const;

	// A test to see whether the pixel colour varies across
	// the palettes
	BOOL VariesAcrossPalettes() const;

	// A function to calculate the similarity of this profile to
	// another one (0 == opposite, 1 == identical)
	double GetMatchFactor(const CPixelProfile& other) const;

// Implementation - caching of profile similarities
protected:
	// The match factors of the various pixel profiles
	static double** s_CacheMatrix;
	static int s_nCacheMatrixSize;

public:
	// Cache management functions
	static void ClearCache();
	static void PrepareCache(const int nNumProfiles);
};

typedef CTypedPtrList<CPtrList, CPixelProfile*> CTypedProfileList;

typedef CTypedPtrList<CObList, CTypedProfileList*> CSeparatedProfileList;

#define	PROFILE_MATCH_FACTOR_UNDEFINED	-1.0f

/////////////////////////////////////////////////////////////////////

#endif	// ~__PIXEL_PROFILE_H__

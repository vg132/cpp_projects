// Timers.h  - constant definitions for timers used in the program
//

#ifndef _TIMERS_H_
#define _TIMERS_H_


// A timer to hide the splash screen after having been displayed
// for a while
#define TMR_HIDE_SPLASH_SCREEN			1

// A timer to step the animation in the Import Animation dialog
// onto the next frame
#define TMR_CYCLE_ANIMATION				2


#endif	// ~_TIMERS_H_

// NeighbourFilter.h - header file for the CNeighbourFilter class
//

#ifndef __NEIGHBOUR_FILTER_H__
#define __NEIGHBOUR_FILTER_H__

#include "JamTextureFilter.h"

///////////////////////////////////////////////////////////////////
// Class:	CNeighbourFilter (abstract)
// Base:	CJamTextureFilter (abstract)
// Created:	28 April 99 by Mal Ross
// Overview:
//    This filter class is a base for all filters that operate
//  on a local neighbourhood of pixels.  In other words, the
//  resultant value for each pixel is a function of those around
//  it.  All you need to override is FilterNeighbourhood to filter
//  the neighbourhood of a single pixel.
//

class CNeighbourFilter : public CJamTextureFilter
{
// Construction and destruction
public:
	CNeighbourFilter(const UINT& nFilterID, const UINT& nStringID);
	virtual ~CNeighbourFilter();

// Data members
protected:
	// The size of the neighbourhood (the current pixel is the
	// central one in the matrix)
	CSize m_sizFilter;

	// The neighbourhood itself - stored as a member to avoid
	// repeated calls to new and delete during filtering.
	BYTE* m_pbNeighbourhood;

	//   The spread factor determines the percentage of pixels in a
	// neighbourhood that must be non-transparent for the pixel at
	// the centre to be made non-transparent.  It's represented as
	// an integer to the user, but as a double internally.  It needs
	// to be a fraction of the pixels around the current one rather
	// than a specific number of pixels, as pixels at the edge of a
	// texture don't all have 8 surrounding pixels.
	//   The spread factor is presented to the user as an integer
	// for the sake of having a simpler UI.  The value they select
	// will actually translate to e.g. 10% of surrounding pixels,
	// 20%, 30%, etc.
	static int s_nSpreadFactor;
	static double s_dSpreadThreshold;

public:
	// Spread factor attributes
	enum eTextureSpreadFactors
	{
		MIN_SPREAD_FACTOR = 1,
		MAX_SPREAD_FACTOR = 10,
		DEFAULT_SPREAD_FACTOR = 6
	};

	static int GetSpreadFactor() { return s_nSpreadFactor; }
	static BOOL SetSpreadFactor(const int nSpread)
	{
		// Just a quick dumb-programmer test first to catch
		// a potential divide-by-zero.
		ASSERT(MAX_SPREAD_FACTOR != MIN_SPREAD_FACTOR);

		// Make sure the new value's in the valid range
		if (nSpread < MIN_SPREAD_FACTOR ||
			nSpread > MAX_SPREAD_FACTOR)
			return FALSE;

		// Store the new spread factor in user's terms
		s_nSpreadFactor = nSpread;

		// Convert the value the user chose between MIN_SPREAD_FACTOR
		// and MAX_SPREAD_FACTOR to a fraction (between 0 and 1) that
		// represents how many surrounding pixels must be non-
		// transparent for the given pixel to become non-transparent.
		s_dSpreadThreshold = double(nSpread - MIN_SPREAD_FACTOR) /
							 double(MAX_SPREAD_FACTOR - MIN_SPREAD_FACTOR);
		// The (1.0f - value) is needed because a high spread factor
		// corresponds to a low fraction of the surrounding pixels.
		s_dSpreadThreshold = 1.0f - s_dSpreadThreshold;

		return TRUE;
	}

// Implementation
protected:
	// Overridden to create each filtered image from the 
	// image created using the previous local palette.
	virtual BOOL CreateNextFilteredBitmap(const BYTE* pbSrcPixels, BYTE*& pbNewPixels, const CSize& sizImage);

	// The function to filter a single neighbourhood
	virtual BYTE FilterNeighbourhood(BYTE *pbNeighbourArray, int nNumNeighbours) = 0;
};


/////////////////////////////////////////////////////////////////////

#endif	// ~__NEIGHBOUR_FILTER_H__

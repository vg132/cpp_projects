// JamFilePreview.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "JamFilePreview.h"

#include "Jam.h"
#include "FilenameParser.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJamFilePreview construction

IMPLEMENT_DYNAMIC(CJamFilePreview, CImageFilePreview)

// Constructor
CJamFilePreview::CJamFilePreview()
{
	// No file loaded yet
	m_pJam = NULL;
}

// Cloning function
CFilePreview* CJamFilePreview::CreateNewPreview() const
{
	return new CJamFilePreview;
}

// Destructor
CJamFilePreview::~CJamFilePreview()
{
	// Get rid of our jam (if it had been loaded)
	UnloadFile();
}


/////////////////////////////////////////////////////////////////////////////
// CJamFilePreview properties

// Information retrieval
UINT CJamFilePreview::GetImageWidth() const
{
	// Make sure we've got a bitmap loaded first
	if (NULL == m_pJam)
		return 0;

	return m_pJam->GetSize().cx;
}

UINT CJamFilePreview::GetImageHeight() const
{
	// Make sure we've got a bitmap loaded first
	if (NULL == m_pJam)
		return 0;

	return m_pJam->GetSize().cy;
}

void CJamFilePreview::GetSupportedFileTypes (CStringList& lstFileTypes) const
{
	// Just make sure the list's empty first
	lstFileTypes.RemoveAll();

	// Then add our extensions
	lstFileTypes.AddTail(".JAM");
	lstFileTypes.AddTail(".JAD");
	lstFileTypes.AddTail(".JIP");
}


/////////////////////////////////////////////////////////////////////////////
// CJamFilePreview drawing

// Draw the image at 1:1 zoom in the given DC (and at its origin)
BOOL CJamFilePreview::DrawImageOneToOne(CDC* pDC) const
{
	// Make sure the file is loaded ok
	if (NULL == m_pJam)
		return FALSE;

	// Just ask the Jam to draw itself
	const int nPaletteNum = 1;
	const double dZoomFactor = 1.0f;
	return m_pJam->Draw(pDC, nPaletteNum, dZoomFactor);
}


/////////////////////////////////////////////////////////////////////////////
// CJamFilePreview file loading/unloading

// Function:	UnloadFile()
// Overview:	Clear out the current file's data.
void CJamFilePreview::UnloadFile()
{
	// Call the base class to clear out any other members
	CImageFilePreview::UnloadFile();

	// Get rid of our bitmap (if it had been loaded)
	if (NULL != m_pJam)
	{
		delete m_pJam;
		m_pJam = NULL;
	}
}
// End of function 'UnloadFile'


// Function:	LoadFile(strFilename)
// Overview:	Load the given file.  Return TRUE upon success, or
//				FALSE otherwise.
BOOL CJamFilePreview::LoadFile(const CString& strFilename)
{
	// Just load into our current bitmap (or create a new
	// one if it doesn't exist yet)
	if (NULL == m_pJam)
		m_pJam = new CJam(NULL);
	if (NULL == m_pJam)
		return FALSE;

	// Open the file and create an archive from it
	CFile fileJamJad;
	if (!fileJamJad.Open(strFilename, CFile::modeRead | CFile::shareDenyWrite))
		return FALSE;
	CArchive arJamJad(&fileJamJad, CArchive::load);

	// Check to see whether we need to decrypt it
	CFilenameParser fnJamJad(strFilename);
	BOOL bNeedToDecrypt = fnJamJad.IsOfType(".JAM") || fnJamJad.IsOfType(".JIP");

	// Attempt to load the file
	BOOL bSuccess = TRUE;
	try
	{
		if (bNeedToDecrypt)
			m_pJam->Serialize(arJamJad);
		else
			m_pJam->SerializeNoEncryption(arJamJad);
	}
	catch (CException* pExc)
	{
		// Probably an invalid jam file, so just
		// fail gracefully
		bSuccess = FALSE;
		pExc->Delete();

		// Get rid of the Jam
		delete m_pJam;
		m_pJam = NULL;
	}

	// Close the file and archive before we finish
	arJamJad.Close();
	fileJamJad.Close();

	return bSuccess;
}
// End of function 'LoadFile'

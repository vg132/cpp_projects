// PreviewFileDialog.cpp : implementation file
//

#include "stdafx.h"
#include "CPreviewFileDialog.h"
#include "Gp3FileInfo.h"		

#define NAME		1100
#define	COUNTRY		1101
#define LAPS		1102
#define LEN			1103
#define	QUALREC		1104
#define RACEREC		1105
#define YEAR		1106
#define SLOT		1107
#define WARE		1108
#define EVENT		1109
#define AUTHOR		1110
#define DESC		1111
#define FRAME		1112

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



/////////////////////////////////////////////////////////////////////////////
// CPreviewFileDialog

IMPLEMENT_DYNAMIC(CPreviewFileDialog, CFileDialog)


CPreviewFileDialog::CPreviewFileDialog(BOOL bOpenFileDialog, LPCTSTR initDir, LPCTSTR lpszDefExt, LPCTSTR lpszFileName,
		DWORD dwFlags, LPCTSTR lpszFilter, CWnd* pParentWnd) :
		CFileDialog(bOpenFileDialog, lpszDefExt, lpszFileName, dwFlags, lpszFilter, pParentWnd)
{
	m_ofn.Flags |= OFN_ENABLETEMPLATE|OFN_FILEMUSTEXIST|OFN_EXTENSIONDIFFERENT|OFN_ALLOWMULTISELECT;
	m_ofn.lpstrDefExt="dat";
	m_ofn.lpstrFilter="Gp3 Tracks (*.dat)\0*.dat\0All Files (*.*)\0*.*\0\0";
	m_ofn.hInstance = AfxGetInstanceHandle();
	m_ofn.lpTemplateName = "FILEOPEN_TEMPLATE";
	m_ofn.lpstrInitialDir = initDir;
}


BEGIN_MESSAGE_MAP(CPreviewFileDialog, CFileDialog)
	//{{AFX_MSG_MAP(CPreviewFileDialog)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CPreviewFileDialog::OnInitDialog() 
{
	CFileDialog::OnInitDialog();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

BOOL CPreviewFileDialog::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult)
{
	ASSERT(pResult != NULL);

	// allow message map to override

	OFNOTIFY* pNotify = (OFNOTIFY*)lParam;
	switch(pNotify->hdr.code)
	{
	case CDN_SELCHANGE:
		OnFileNameChange();
		return TRUE;
	case CDN_FOLDERCHANGE:
		OnFolderChange();
		return TRUE;
	}
	return CFileDialog::OnNotify(wParam, lParam, pResult);
}

void CPreviewFileDialog::OnFileNameChange()
{
CString tmp;
	tmp=CFileDialog::GetFolderPath();
	if(tmp.Right(1)!="\\")
		tmp+="\\";
	tmp+=CFileDialog::GetFileName();
	Test(tmp);
}

void CPreviewFileDialog::OnFolderChange()
{
	Test("");
}

void CPreviewFileDialog::Test(CString file)
{
CString cf;
CString tm;

	CWnd *pWnd=GetDlgItem(FRAME);
	pWnd->SetWindowText("Track File Info");

	if(file.Right(4)==".dat")
	{
		if(m_FileInfo.LoadInfo(file)==true)
		{
			pWnd=GetDlgItem(NAME);
			pWnd->SetWindowText(m_FileInfo.GetName());

			pWnd=GetDlgItem(COUNTRY);
			pWnd->SetWindowText(m_FileInfo.GetCountry());

			pWnd=GetDlgItem(LAPS);
			pWnd->SetWindowText(m_FileInfo.GetLaps());

			pWnd=GetDlgItem(LEN);
			pWnd->SetWindowText(m_FileInfo.GetLength());

			pWnd=GetDlgItem(SLOT);
			pWnd->SetWindowText(m_FileInfo.GetSlot());

			pWnd=GetDlgItem(YEAR);
			pWnd->SetWindowText(m_FileInfo.GetYear());

			pWnd=GetDlgItem(EVENT);
			pWnd->SetWindowText(m_FileInfo.GetEvent());

			pWnd=GetDlgItem(AUTHOR);
			pWnd->SetWindowText(m_FileInfo.GetAuthor());

			pWnd=GetDlgItem(RACEREC);
			pWnd->SetWindowText(m_FileInfo.GetRaceRec());

			pWnd=GetDlgItem(QUALREC);
			pWnd->SetWindowText(m_FileInfo.GetQualRec());

			pWnd=GetDlgItem(DESC);
			pWnd->SetWindowText(m_FileInfo.GetDesc());

			pWnd=GetDlgItem(WARE);
			pWnd->SetWindowText(m_FileInfo.GetWare());
		}
		else
			ClearText();
	}
	else
		ClearText();
}

void CPreviewFileDialog::ClearText()
{

CWnd* pWnd;
CString tm="";
	pWnd=GetDlgItem(NAME);
	pWnd->SetWindowText(tm);

	pWnd=GetDlgItem(COUNTRY);
	pWnd->SetWindowText(tm);

	pWnd=GetDlgItem(LAPS);
	pWnd->SetWindowText(tm);

	pWnd=GetDlgItem(LEN);
	pWnd->SetWindowText(tm);

	pWnd=GetDlgItem(SLOT);
	pWnd->SetWindowText(tm);

	pWnd=GetDlgItem(YEAR);
	pWnd->SetWindowText(tm);

	pWnd=GetDlgItem(EVENT);
	pWnd->SetWindowText(tm);

	pWnd=GetDlgItem(AUTHOR);
	pWnd->SetWindowText(tm);

	pWnd=GetDlgItem(RACEREC);
	pWnd->SetWindowText(tm);

	pWnd=GetDlgItem(QUALREC);
	pWnd->SetWindowText(tm);

	pWnd=GetDlgItem(DESC);
	pWnd->SetWindowText(tm);

	pWnd=GetDlgItem(WARE);
	pWnd->SetWindowText(tm);
}

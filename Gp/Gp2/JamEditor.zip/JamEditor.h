// Jam Editor.h : main header file for the JAM EDITOR application
//

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "TexturePalette.h"

/////////////////////////////////////////////////////////////////////////////
// CJamEditorApp:
// See Jam Editor.cpp for the implementation of this class
//

class CJamEditorApp : public CWinApp
{
public:
	CJamEditorApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJamEditorApp)
	public:
	virtual BOOL InitInstance();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Data members
private:
	// The length of the MRU list
	int m_nMRULength;

// Operations
public:
	// Set the length of MRU list to appear in the File menu
	BOOL SetMRULength(const int nMaxMRU);
	UINT GetMRULength() const { return m_nMRULength; }

	// Global palette changes
	void OnChangedGlobalPalette();

// Overridables
protected:
	// Why on earth doesn't CWinApp have these functions?!
	virtual void LoadProfileSettings();
	virtual void SaveProfileSettings();

// Implementation
protected:
	// Tip of the Day
	void ShowTipAtStartup();

	// Colour-depth checking
	void CheckColourCapability();

	//{{AFX_MSG(CJamEditorApp)
	afx_msg void OnAppAbout();
	afx_msg void OnTipOfTheDay();
	afx_msg void OnFileSaveAll();
	afx_msg void OnFileSaveAllAsJAM();
	afx_msg void OnFileSaveAllAsJAD();
	afx_msg void OnViewOptions();
	afx_msg void OnFindFlags();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	afx_msg void OnSelectGlobalPalette(UINT nID);
	afx_msg void OnUpdateSelectGlobalPalette(CCmdUI* pCmdUI);
	int CommandIDToGlobalPaletteType(const int nCommandID) const;

	// Save All As JAM/JAD function
	BOOL SaveAllFilesAs(CString strExtension);
};


/////////////////////////////////////////////////////////////////////////////

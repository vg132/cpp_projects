// FlagsDialogBase.h: header file for the CFlagsDialogBase class
//

#ifndef __FLAGS_DIALOG_BASE_H__
#define __FLAGS_DIALOG_BASE_H__

#include "CheckListBoxEx.h"

/////////////////////////////////////////////////////////////////////////////
// Class:	CFlagsDialogBase
// Base:	CDialog
// Overview:
//    A base class for the templatised version of the flags dialog, used to
//  get around Microsoft's problems with template classes and message maps.
//  I hate those bastards.
//

class CFlagsDialogBase : public CDialog
{
// Construction
public:
	CFlagsDialogBase(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFlagsDialogBase)
	enum { IDD = IDD_TEXTURE_FLAGS };
	CCheckListBoxEx	m_FlagListBox;
	//}}AFX_DATA

	// This is the string table ID of the first flag's name
	int m_nFirstFlagNameID;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFlagsDialogBase)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Pure virtuals
protected:
	// Return the first and last bit positions at
	// which the flags are located.
	virtual int GetFirstFlagPosition() const = 0;
	virtual int GetLastFlagPosition() const = 0;

	// Get/set the flags
	virtual BOOL IsFlagSet(const int& nFlagID) const = 0;
	virtual void SetFlag(const int& nFlagID, const BOOL bOn) = 0;

// Implementation
protected:
	// Naming of the flags
	virtual int GetFirstFlagNameID() const { return m_nFirstFlagNameID; }

	// Updating the flags member
	void StoreFlags(const BOOL bSaveAndValidate);
	UINT FlagNumToMask(const int& nFlagID) const;

	// Generated message map functions
	//{{AFX_MSG(CFlagsDialogBase)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelectDisplayType();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif	// ~__FLAGS_DIALOG_H__

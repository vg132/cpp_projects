// FogFilterDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "FogFilterDlg.h"

#include "FogFilter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFogFilterDlg dialog


CFogFilterDlg::CFogFilterDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFogFilterDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFogFilterDlg)
	m_strRating = _T("");
	//}}AFX_DATA_INIT
}


void CFogFilterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFogFilterDlg)
	DDX_Control(pDX, IDC_FOGGINESS_SLIDER, m_sdrFogginess);
	DDX_Text(pDX, IDC_FOG_RATING, m_strRating);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFogFilterDlg, CDialog)
	//{{AFX_MSG_MAP(CFogFilterDlg)
	ON_WM_HSCROLL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFogFilterDlg message handlers

BOOL CFogFilterDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// Set up the slider to allow only those values accepted
	// by CFogFilter.
	m_sdrFogginess.SetRange(CFogFilter::MIN_FOG_RATING,
							CFogFilter::MAX_FOG_RATING);
	m_sdrFogginess.SetPos(m_nFogRating);

	UpdateRatingText();

	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CFogFilterDlg::OnOK() 
{
	// The only control in the dialog has a strictly-controlled range,
	// so we don't really need to validate anything, but we do need
	// to store the values, so...
	if (!UpdateData(TRUE))
		return;

	CDialog::OnOK();
}


// Function:	OnHScroll(nSBCode, nPos, pScrollBar)
// Overview:	Horizontal scrollbar handler, used to intercept messages
//				from the dialog's slider control.
void CFogFilterDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// Make sure it's the slider we're after
	if (NULL != pScrollBar &&
		pScrollBar->GetSafeHwnd() == m_sdrFogginess.GetSafeHwnd())
	{
		// Figure out where the slider's position currently is
		if (SB_THUMBPOSITION == nSBCode || SB_THUMBTRACK == nSBCode)
			m_nFogRating = (int)nPos;
		else
			m_nFogRating = ((CSliderCtrl *)pScrollBar)->GetPos();

		// Update the text indicator to say what the currently
		// selected time is.
		UpdateRatingText();
	}

	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}
// End of function 'OnHScroll'


// Function:	UpdateRatingText()
// Overview:	Update the static indicator showing the currently
//				selected fogginess rating.
void CFogFilterDlg::UpdateRatingText()
{
	// Format the rating for display in the dialog
	m_strRating.Format("Rating: %d", m_nFogRating);
	CDataExchange dx(this, FALSE);
	try
	{
		DDX_Text(&dx, IDC_FOG_RATING, m_strRating);
	}
	catch (CException* pExc)
	{
		// Somehow the exchange of data to the text control failed! :(
		ASSERT(FALSE);

		// Never mind - just get on with things as best we can.
		pExc->Delete();
	}
}
// End of function 'UpdateRatingText'


// Set the integer value representing the somewhat arbitarily-chosen
// fogginess rating that the "Rainy or misty" filter simulates
BOOL CFogFilterDlg::SetFogRating(const int nRating)
{
	// Make sure the value we're being given is in the valid range
	if ((nRating < CFogFilter::MIN_FOG_RATING) ||
		(nRating > CFogFilter::MAX_FOG_RATING))
		return FALSE;

	// Store the new value
	m_nFogRating = nRating;

	return TRUE;
}

// Get the integer value representing the somewhat arbitarily-chosen
// visibility rating that the "Rainy or misty" filter simulates
int CFogFilterDlg::GetFogRating() const
{
	return m_nFogRating;
}


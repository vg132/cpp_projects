// LocalPaletteArray.cpp - implementation of the CLocalPaletteArray class
//

#include "stdafx.h"

#include "LocalPaletteArray.h"
#include "JamConstants.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CLocalPaletteArray

// Constructor
CLocalPaletteArray::CLocalPaletteArray()
{
	// Default to creating an empty set of 4 palettes
	SetSize(NUM_LOCAL_PALETTES_PER_TEXTURE);
	for (int nPalNum = 0; nPalNum < NUM_LOCAL_PALETTES_PER_TEXTURE; nPalNum++)
		SetAt(nPalNum, NULL);

	// For safety, we'll default to deleting palettes when we're destroyed
	m_bDeleteOnDestroy = TRUE;
}

// Destructor
CLocalPaletteArray::~CLocalPaletteArray()
{
	// Delete the palettes we're storing
	if (m_bDeleteOnDestroy)
		DeletePalettes();
	RemoveAll();
}


// Function:	DeletePalettes()
// Overview:	Just delete the palettes we're storing (if they
//				actually exist) and set them to NULL
void CLocalPaletteArray::DeletePalettes()
{
	// Go through the palettes we're storing and delete them
	for (int nPalNum = 0; nPalNum < GetSize(); nPalNum++)
	{
		if (NULL != GetAt(nPalNum) && m_nPaletteSize > 0)
		{
			delete[] GetAt(nPalNum);
			SetAt(nPalNum, NULL);
		}
	}
}
// End of function 'DeletePalettes'


// Function:	CreatePalettes(nPaletteSize)
// Overview:	Create a set of empty palettes of the given
//				size.  Return TRUE upon success, FALSE otherwise.
BOOL CLocalPaletteArray::CreatePalettes(const UINT& nPaletteSize)
{
	// First, get rid of our current palettes
	DeletePalettes();

	if (nPaletteSize > 0)
	{
		// Create the empty palettes of the size required to hold
		// the relevant value from each of our profiles
		int nNumPalettes = GetSize();
		for (int nPalNum = 0; nPalNum < nNumPalettes; nPalNum++)
		{
			// Create the new palette and set it in our array
			BYTE* pbNewPalette = new BYTE[nPaletteSize];
			if (NULL == pbNewPalette)
				return FALSE;
			memset(pbNewPalette, 0, nPaletteSize);
			SetAt(nPalNum, pbNewPalette);
		}
	}

	// Store the new palette size
	m_nPaletteSize = nPaletteSize;

	return TRUE;
}
// End of function 'CreatePalettes'




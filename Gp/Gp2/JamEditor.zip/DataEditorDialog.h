// DataEditorDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDataEditorDialog dialog

class CDataEditorDialog : public CDialog
{
// Construction
public:
	CDataEditorDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDataEditorDialog)
	enum { IDD = IDD_DATA_EDITOR };
	CString	m_newValue;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDataEditorDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDataEditorDialog)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

// JamEditorDoc.h : interface of the CJamEditorDoc class
//
/////////////////////////////////////////////////////////////////////////////

#ifndef __JAM_EDITOR_DOC_H__
#define __JAM_EDITOR_DOC_H__

#include "EditableObject.h"

class CJam;

class CJamEditorDoc : public CDocument, public CEditableObject
{
protected: // create from serialization only
	CJamEditorDoc();
	DECLARE_DYNCREATE(CJamEditorDoc)

// Enumerations
protected:
	enum eDocumentVersions
	{
		JAMEDITOR_DOC_CLIPBRD_VERSION = 1
	};

// Attributes
protected:
	// The jam file
	CJam* m_pJam;

	// The current palette being used to display the JAM
	int m_nPaletteNum;

public:
	// overrides of the CEditableObject class
	// that make this document provide the editable object
	// functionality
	virtual UINT	GetIconID();			// return the ID for the icon in the tree for this item
	virtual CString GetFullDescription();	// return name and value - in this case filename
	virtual CString	GetValueToEdit();		// will return empty - we cannot edit this one

	virtual void	DataHasChanged(CView* pView, LPARAM lHint, CObject* pHint);		// we will respond by updating our view

	virtual POSITION GetFirstSubItemPosition();
	virtual	CEditableObject* GetNextSubItem(POSITION&);

// Operations
public:
	// Get a pointer to the loaded JAM
	CJam* GetJam() const { return m_pJam; }

	// Retrieval of palette number
	int GetPaletteNum() const { return m_nPaletteNum; }
	BOOL CanEditLocalPalettes() const;

	// Exposed for use by clipboarding in the view
	BOOL DeleteCurrentTexture();
	void SerializeSelection(CArchive& ar);

	// Update the views to use the new global palette
	void OnChangedGlobalPalette();

public:
	// we will intercept UpdateAllViews calls to do
	// update of tree if necessary
	// WARNING: this function isn't virtual so you must
	// call it on a CJamEditorDoc, not just a CDocument
	void UpdateAllViews(CView* pSender=NULL, LPARAM lHint=NULL, CObject* pHint=NULL);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJamEditorDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual void DeleteContents();	
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual void OnCloseDocument();
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CJamEditorDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	// Convert a palette-selection command ID to the
	// corresponding palette number
	int CommandIDToPaletteNum(const int nCommandID);

// Generated message map functions
protected:
	//{{AFX_MSG(CJamEditorDoc)
	afx_msg void OnImportCanvas();
	afx_msg void OnExportCanvas();
	afx_msg void OnExportTexture();
	afx_msg void OnUpdateExportTexture(CCmdUI* pCmdUI);
	afx_msg void OnImportTexture();
	afx_msg void OnUpdateImportTexture(CCmdUI* pCmdUI);
	afx_msg void OnEditDrivingConditions();
	afx_msg void OnUpdateDrivingConditions(CCmdUI* pCmdUI);
	afx_msg void OnAddNewTexture();
	afx_msg void OnFileSaveAs();
	afx_msg void OnNextPalette();
	afx_msg void OnPreviousPalette();
	afx_msg void OnDeleteTexture();
	afx_msg void OnUpdateDeleteTexture(CCmdUI* pCmdUI);
	afx_msg void OnEditLocalPalettes();
	afx_msg void OnUpdateEditLocalPalettes(CCmdUI* pCmdUI);
	afx_msg void OnImportAnimation();
	afx_msg void OnUpdateImportAnimation(CCmdUI* pCmdUI);
	//}}AFX_MSG
	afx_msg void OnSelectPalette(UINT nID);
	afx_msg void OnUpdateSelectPalette(CCmdUI* pCmdUI);
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif	// ~__JAM_EDITOR_DOC_H__

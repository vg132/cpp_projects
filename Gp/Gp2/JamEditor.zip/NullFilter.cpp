// NullFilter.cpp - implementation of the CNullFilter class
//

#include "stdafx.h"
#include "resource.h"

#include "NullFilter.h"

#include "NullFilterDlg.h"

#include "PixelProfile.h"
#include "JamTextureFilterIDs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CNullFilter

// By default, maintain the existing palette type (i.e. empty vs non-empty)
CNullFilter::ePalettePreservation CNullFilter::s_nPalettePreservation = CNullFilter::MAINTAIN_PALETTE;

// Constructor
CNullFilter::CNullFilter()
	: CJamTextureFilter(NULL_FILTER, IDS_FILTER_NAME_NULL)
{
}

// Destructor
CNullFilter::~CNullFilter()
{
}


// Overridden configuration functions
//

// Function:	Configure()
// Overview:	Display a dialog box to allow the user to set the filter's
//				options.  In this case, it's only the ability to specify
//				local palettes or no local palettes that the user gets.
void CNullFilter::Configure()
{
	// Just let the Null Filter dialog do the talking
	CNullFilterDlg dlg;
	dlg.m_nPaletteType = s_nPalettePreservation;
	if (IDOK == dlg.DoModal())
	{
		dlg.m_nPaletteType = max(PALETTE_PRESERVATION_MIN, min(PALETTE_PRESERVATION_MAX, dlg.m_nPaletteType));
		s_nPalettePreservation = (CNullFilter::ePalettePreservation)dlg.m_nPaletteType;
	}
}
// End of function 'Configure'


// Overridden filtering functions
//

// Function:	CreateNextFilteredBitmap(pbSrcPixels, pbNewPixels, sizImage)
// Overview:	Overridden function to create each filtered image from the 
//				image created using the previous local palette.
BOOL CNullFilter::CreateNextFilteredBitmap(const BYTE* pbSrcPixels, BYTE*& pbNewPixels, const CSize& sizImage)
{
	try
	{
		// Just do a straight memcpy from the bitmap into the
		// first decoded texture
		memcpy(pbNewPixels, pbSrcPixels, sizImage.cx * sizImage.cy);
	}
	catch (CException* pExc)
	{
		// Just delete the exception and let the calling function
		// know that we failed
		ASSERT(FALSE);
		pExc->Delete();
		return FALSE;
	}

	// Success! :)
	return TRUE;
}
// End of function 'CreateNextFilteredBitmap'

// EnhancedTreeCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "EnhancedTreeCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEnhancedTreeCtrl

CEnhancedTreeCtrl::CEnhancedTreeCtrl()
{
}

CEnhancedTreeCtrl::~CEnhancedTreeCtrl()
{
}


BEGIN_MESSAGE_MAP(CEnhancedTreeCtrl, CTreeCtrl)
	//{{AFX_MSG_MAP(CEnhancedTreeCtrl)
	ON_NOTIFY_REFLECT(TVN_BEGINLABELEDIT, OnBeginlabeledit)
	ON_NOTIFY_REFLECT(TVN_ENDLABELEDIT, OnEndlabeledit)
	ON_NOTIFY_REFLECT(NM_DBLCLK, OnDblclk)
	ON_NOTIFY_REFLECT(TVN_SELCHANGED, OnSelchanged)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEnhancedTreeCtrl message handlers




// Tree maintenance
//

// My own variants of InsertItem (note, I've renamed the function to avoid
// accidentally 'hiding' with the base class versions)

HTREEITEM CEnhancedTreeCtrl::InsertNode(UINT nStringID, UINT nIconID, HTREEITEM hParent,
							   HTREEITEM hInsertAfter, DWORD dwItemData)
{
	// Load the string resource
	CString strItemText;
	if (0 == strItemText.LoadString(nStringID))
		return NULL;

	// Call the other overload
	return InsertNode(strItemText, nIconID, hParent, hInsertAfter, dwItemData);
}

HTREEITEM CEnhancedTreeCtrl::InsertNode(const CString& strItemText, UINT nIconID, HTREEITEM hParent,
							   HTREEITEM hInsertAfter, DWORD dwItemData)
{
	// Insert the new item into the tree
	HTREEITEM hNewNode = InsertItem(strItemText, nIconID, nIconID, hParent, hInsertAfter);
	if (NULL == hNewNode)
		return NULL;

	// Set the item data
	if (NULL != dwItemData)
		SetItemData(hNewNode, dwItemData);

	return hNewNode;
}

void CEnhancedTreeCtrl::OnBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_DISPINFO* pTVDispInfo = (TV_DISPINFO*)pNMHDR;

	ASSERT (pTVDispInfo);
	if (!pTVDispInfo)
		return;

	// we're being asked to start in-place editing on a tree item

	// let's give the tree the chance to replace the displayed value with
	// something more editable and also give it the chance to veto the edit

	CString replaceLabel;
	if (CanEditLabelOf(pTVDispInfo->item.hItem, replaceLabel))
	{
		// we are allowed to edit

		if (!replaceLabel.IsEmpty())
		{
			// we are to replace label

			CEdit* pEdit=GetEditControl();

			if (pEdit)
			{
				pEdit->SetWindowText(replaceLabel);
			}

			// and we had better get the tree
			// to replace the text underneath the edit control
			SetItemText(pTVDispInfo->item.hItem, replaceLabel);
		}

		// we're accepting editing
		*pResult = 0;
	}
	else
	{
		// we're declining the edit
		*pResult = 1;
	}
}

void CEnhancedTreeCtrl::OnEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult) 
{
	TV_DISPINFO* pTVDispInfo = (TV_DISPINFO*)pNMHDR;

	ASSERT (pTVDispInfo);
	if (!pTVDispInfo)
		return;

	// was editing cancelled?
	if (pTVDispInfo->item.pszText)
	{
		// there was not a cancellation
		CString newLabel = pTVDispInfo->item.pszText;

		// allow our subclass to handle the change of label
		HandleLabelChanged(pTVDispInfo->item.hItem, newLabel);
	}
	else
	{
		// allow our subclass to handle the cancel of editing
		HandleLabelChangeCancelled(pTVDispInfo->item.hItem);
	}
	
	// if you want the label, then you change it yourself
	// we're suppressing the auto change stuff
	*pResult = 0;
}


BOOL CEnhancedTreeCtrl::CanEditLabelOf(HTREEITEM hItem, CString& replacementText)
{
	// do you want to allow editing of hItem, if so you may specify a different bit of text than the existing one to be edited
	UNUSED_ALWAYS(hItem);
	UNUSED_ALWAYS(replacementText);

	return TRUE;	// base class is easy!
}

void CEnhancedTreeCtrl::HandleLabelChanged(HTREEITEM hItem, CString newLabel)
{
	// we've changed the label for the given tree item - you must validate and replace label in item if you like it
	UNUSED_ALWAYS(hItem);
	UNUSED_ALWAYS(newLabel);
}

void CEnhancedTreeCtrl::HandleLabelChangeCancelled(HTREEITEM hItem)
{
	// the in-place edit on hItem was cancelled - deal with it
	UNUSED_ALWAYS(hItem);
}

void CEnhancedTreeCtrl::HandleSelchanged(HTREEITEM hItem)
{
	UNUSED_ALWAYS(hItem);
}

void CEnhancedTreeCtrl::HandleDblclk(HTREEITEM hItem)
{
	UNUSED_ALWAYS(hItem);
}


void CEnhancedTreeCtrl::OnDblclk(NMHDR* pNMHDR, LRESULT* pResult) 
{
	HTREEITEM TreeNode = GetSelectedItem();

	// call our virtual function to pass on nice version of double click
	HandleDblclk(TreeNode);

	*pResult = 0;
}

void CEnhancedTreeCtrl::OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	ASSERT(pNMTreeView);
	if (!pNMTreeView)
		return;
		
	// call our virtual function to pass on selchanged in more simple way
	HandleSelchanged(pNMTreeView->itemNew.hItem);

	*pResult = 0;
}

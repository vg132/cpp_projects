// NullFilePreview.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "NullFilePreview.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CNullFilePreview construction

IMPLEMENT_DYNAMIC(CNullFilePreview, CFilePreview)

// Constructor
CNullFilePreview::CNullFilePreview()
{
}

// Cloning function
CFilePreview* CNullFilePreview::CreateNewPreview() const
{
	return new CNullFilePreview;
}

// Desctructor
CNullFilePreview::~CNullFilePreview()
{
}


/////////////////////////////////////////////////////////////////////////////
// CNullFilePreview drawing

// Draw the preview in the given DC
BOOL CNullFilePreview::DrawPreview(CDC* pDC, const CRect& rctDraw) const
{
	// We need a valid DC to be able to draw
	ASSERT(NULL != pDC);
	if (NULL == pDC)
		return FALSE;

	// Just show the "Preview not available" message
	CString strMessage("");
	strMessage.LoadString(IDS_PREVIEW_NOT_AVAILABLE);
	return DrawMessage(pDC, rctDraw, strMessage);
}


/////////////////////////////////////////////////////////////////////////////
// CNullFilePreview file type-checking and loading

BOOL CNullFilePreview::IsSupportedFile (const CString& strFilename) const
{
	UNUSED_ALWAYS(strFilename);

	// Just accept it
	return TRUE;
}

BOOL CNullFilePreview::IsSupportedFileType (const CString& strExtension) const
{
	UNUSED_ALWAYS(strExtension);

	// Just accept it
	return TRUE;
}

void CNullFilePreview::GetSupportedFileTypes (CStringList& lstFileTypes) const
{
	UNUSED_ALWAYS(lstFileTypes);
}

// Loading the file.
BOOL CNullFilePreview::LoadFile (const CString& strFilename)
{
	UNUSED_ALWAYS(strFilename);

	// Just say we managed it
	return TRUE;
}

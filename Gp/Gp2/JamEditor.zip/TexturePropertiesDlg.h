// TexturePropertiesDlg.h : header file
//

#ifndef __TEXTURE_PROPERTIES_DLG_H__
#define __TEXTURE_PROPERTIES_DLG_H__

#include "CheckListBoxEx.h"
class CJamTexture;

/////////////////////////////////////////////////////////////////////////////
// CTexturePropertiesDlg dialog

class CTexturePropertiesDlg : public CDialog
{
// Construction
public:
	CTexturePropertiesDlg(CJamTexture* pTexture, CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CTexturePropertiesDlg)
	enum { IDD = IDD_TEXTURE_PROPERTIES };
	CCheckListBoxEx	m_FlagListBox;
	UINT	m_nTextureID;
	BYTE	m_nLeft;
	UINT	m_nHeight;
	BYTE	m_nTop;
	UINT	m_nWidth;
	//}}AFX_DATA

	// A pointer to the Jam texture whose properties are
	// being edited in this dialog
	CJamTexture* m_pTexture;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTexturePropertiesDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Updating the actual texture
	void UpdateTexture(const BOOL bSaveAndValidate, const BOOL bFlagsOnly = FALSE);

	// Generated message map functions
	//{{AFX_MSG(CTexturePropertiesDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelectDisplayType();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


#endif	// ~__TEXTURE_PROPERTIES_DLG_H__

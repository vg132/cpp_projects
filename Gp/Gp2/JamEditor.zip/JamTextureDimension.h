// Jam Texture Dimension

// A simple extension of a CEditableNumber, allowing us to display
// a more meaningful dialog than the simple Data Editor


#ifndef JAM_TEXTURE_DIMENSION_H
#define JAM_TEXTURE_DIMENSION_H

#include "EditableObject.h"
#include "TreeIconDefs.h"

class CJamTexture;

class CJamTextureDimension : public CEditableObject
{
public:
	// constructions
	CJamTextureDimension(int nDimensionType, CJamTexture* pParent);
	virtual ~CJamTextureDimension();

// Enumerations
public:
	enum eDimensionType
	{
		DIM_WIDTH,
		DIM_HEIGHT,
	};

// Attributes
protected:
	// Height or width?
	int m_nDimensionType;

// Operations
public:
	// Functions overridden from CEditableObject
	virtual UINT GetIconID() { return JTI_IMAGE_SIZE; }
	virtual BOOL CanEdit() { return TRUE; }
	virtual CString GetFullDescription();
	virtual CString	GetValueToEdit();
	virtual BOOL ChangeDataFromEdit(CString string);
};


#endif
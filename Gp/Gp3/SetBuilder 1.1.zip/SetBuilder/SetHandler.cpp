// SetHandler.cpp: implementation of the CSetHandler class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SetBuilder.h"
#include "SetHandler.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSetHandler::CSetHandler()
{

}

CSetHandler::~CSetHandler()
{

}

bool CSetHandler::LoadFile(CString file)
{
char buf[260];
CString szName("");

	for(int i=0;i<16;i++)
	{
		if(i+1<10)
			szName="f1ct0";
		else
			szName="f1ct";
		szName+=itoa(i+1,buf,10);
		GetPrivateProfileString("TrackFiles",szName,"",buf,260,file);
		strcpy(SetData[i],buf);
	}
	return(true);
}

bool CSetHandler::SaveFile(CString file)
{
char buf[260];
CString szName("");

	for(int i=0;i<16;i++)
	{
		if(i+1<10)
			szName="f1ct0";
		else
			szName="f1ct";
		szName+=itoa(i+1,buf,10);
		WritePrivateProfileString("TrackFiles",szName,SetData[i], file);
	}
	return(true);
}

void CSetHandler::GetTrack(int nr, char *file)
{
	strcpy(file,SetData[nr]);
}

void CSetHandler::SetTrack(int nr, char *file)
{
	strcpy(SetData[nr],file);
}

void CSetHandler::NewFile()
{
	for(int i=0;i<16;i++)
		SetData[i][0] = '\0';
}

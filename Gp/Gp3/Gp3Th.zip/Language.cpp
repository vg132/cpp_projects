// Language.cpp : implementation file
//

#include "stdafx.h"
#include "Gp3Th.h"
#include "Language.h"
#include "Common.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLanguage dialog


CLanguage::CLanguage(CWnd* pParent /*=NULL*/)
	: CDialog(CLanguage::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLanguage)
	//}}AFX_DATA_INIT
}


void CLanguage::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLanguage)
	DDX_Control(pDX, IDC_LANGUAGE, m_Language);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLanguage, CDialog)
	//{{AFX_MSG_MAP(CLanguage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLanguage message handlers

BOOL CLanguage::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	GetAllFiles();
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CLanguage::GetAllFiles()
{
WIN32_FIND_DATA	wfd;
CString szPath;
HANDLE hFile;
CCommon m_Common;
CString szLanguage;

	szPath=m_Gp3Path+"\\ldata\\*.str";
	hFile=FindFirstFile(szPath,&wfd);
	if(hFile!=(HANDLE)-1)
		m_Language.AddString(wfd.cFileName);
	while(FindNextFile(hFile,&wfd))
		m_Language.AddString(wfd.cFileName);

	szLanguage = m_Common.RegGetValue(HKEY_CURRENT_USER,"Software\\VG Software\\Gp3 Track Handler\\Settings","Language");

	m_Language.SetCurSel(m_Language.FindString(0,szLanguage));
	
	UpdateData(FALSE);
}

void CLanguage::OnOK() 
{
CCommon m_Common;
CString szLanguage;
	if(m_Language.GetCurSel()!=-1)
	{
		m_Language.GetText(m_Language.GetCurSel(),szLanguage);
		m_Common.RegSaveValue(HKEY_CURRENT_USER,"Software\\VG Software\\Gp3 Track Handler\\Settings","Language",szLanguage);
		CDialog::OnOK();
	}
	else
		MessageBox("You must select a language.","Gp3 Track Handler",MB_OK|MB_ICONEXCLAMATION);
}

void CLanguage::OnCancel() 
{
CCommon m_Common;
CString szLanguage;

	szLanguage = m_Common.RegGetValue(HKEY_CURRENT_USER,"Software\\VG Software\\Gp3 Track Handler\\Settings","Language");
	if(szLanguage==""&&m_Language.GetCount()>0)
		MessageBox("You must select a language.","Gp3 Track Handler",MB_OK|MB_ICONEXCLAMATION);
	else
		CDialog::OnCancel();
}

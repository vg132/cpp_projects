// CEditableNumber
// a template class for allowing
// access to a BYTE, WORD - any atomic type
// via a memory pointer

#ifndef EDITABLE_NUMBER_H
#define EDITABLE_NUMBER_H

#include "EditableObject.h"
#include "TreeIconDefs.h"
#include "Hints.h"

template <class NUM_TYPE>
class CEditableNumber : public CEditableObject
{
public:
	// construction
	CEditableNumber(NUM_TYPE* pNumber, BOOL bEditable, CString name, CEditableObject* pParent, UINT nIcon=JTI_JAM_FILE_INFO)  : CEditableObject(pParent)
	{
		m_pNumber=pNumber;
		m_bCanEdit=bEditable;

		m_description=name;

		m_nIcon=nIcon;

		m_bRangeIsSet=FALSE;
		m_nMinVal=m_nMaxVal=0;
	}
	CEditableNumber(NUM_TYPE* pNumber, BOOL bEditable, CString name, CEditableObject* pParent, NUM_TYPE nMinVal, NUM_TYPE nMaxVal, UINT nIcon=JTI_JAM_FILE_INFO)  : CEditableObject(pParent)
	{
		m_pNumber=pNumber;
		m_bCanEdit=bEditable;

		m_description=name;

		m_nIcon=nIcon;

		m_bRangeIsSet=TRUE;
		m_nMinVal=nMinVal;
		m_nMaxVal=nMaxVal;
	}


	// overrides of CEditable object
	virtual UINT	GetIconID() { return m_nIcon; }			// return the ID for the icon in the tree for this item
	virtual CString GetFullDescription()	// return name and value
	{
		if (!m_pNumber)
		{
			ASSERT(FALSE);
			return "Error - bad reference";
		}

		// compose description thus:
		CString description;
		description.Format("%s: %d", m_description, *m_pNumber);

		return description;
	}

	virtual CString	GetValueToEdit()
	{
		if (!m_pNumber)
		{
			ASSERT(FALSE);
			return "Error";
		}

		CString value;
		value.Format("%d", *m_pNumber);

		return value;
	}

	virtual NUM_TYPE GetNumber()
	{
		if (NULL != m_pNumber)
			return *m_pNumber;
		else
			return (NUM_TYPE)0;
	}
	virtual BOOL SetNumber(NUM_TYPE number)
	{
		BOOL bSet = FALSE;
		if (NULL != m_pNumber)
		{
			if (!m_bRangeIsSet || ((number >= m_nMinVal) && (number <= m_nMaxVal)))
			{
				*m_pNumber = number;
				bSet = TRUE;

				DataHasChanged(NULL, HINT_TEXTURE_PROPERTIES_CHANGED, NULL); 
			}
		}

		return bSet;
	}

	virtual BOOL	CanEdit() { return m_bCanEdit; }	// whether we can enter editing mode for this item

	virtual BOOL	ChangeDataFromEdit(CString string)
	{ 
		// assign number with new value
		return SetNumber((NUM_TYPE)atoi(string));
	};


private:
	CEditableNumber() {};	// hide default constructor

	// data
	BOOL		m_bCanEdit;
	NUM_TYPE*	m_pNumber;
	BOOL		m_bRangeIsSet;
	NUM_TYPE	m_nMinVal;
	NUM_TYPE	m_nMaxVal;
	CString		m_description;	// what sort of field this is

	UINT		m_nIcon;
};

#endif
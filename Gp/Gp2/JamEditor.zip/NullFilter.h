// NullFilter.h - header file for the CNullFilter class
//

#ifndef __NULL_FILTER_H__
#define __NULL_FILTER_H__

#include "JamTextureFilter.h"

///////////////////////////////////////////////////////////////////
// Class:	CNullFilter
// Base:	CJamTextureFilter
// Created:	06Feb99 by Mal Ross
// Overview:
//    This filter simply produces 4 identical decoded textures
//  and palettes.
//

class CNullFilter : public CJamTextureFilter
{
// Construction and destruction
public:
	CNullFilter();
	virtual ~CNullFilter();

// Options
public:
	// When filtering a texture, should we create a set of
	// local palettes, leave them empty, or just leave them
	// as they are?
	enum ePalettePreservation
	{
		MAINTAIN_PALETTE = 0,		// note: these numbers have been
		REMOVE_PALETTE = 1,			// chosen to be identical to the
		CREATE_PALETTE = 2,			// order of the dialog's radios.
		PALETTE_PRESERVATION_MIN = MAINTAIN_PALETTE,
		PALETTE_PRESERVATION_MAX = CREATE_PALETTE,
	};
	static ePalettePreservation s_nPalettePreservation;

// Operations
public:
	// User-configuration of the filter's parameters
	virtual BOOL IsConfigurable() const { return TRUE; }
	virtual void Configure();

// Implementation
protected:
	// Overridden to create each filtered image from the 
	// image created using the previous local palette.
	virtual BOOL CreateNextFilteredBitmap(const BYTE* pbSrcPixels, BYTE*& pbNewPixels, const CSize& sizImage);
};

/////////////////////////////////////////////////////////////////////

#endif	// ~__NULL_FILTER_H__

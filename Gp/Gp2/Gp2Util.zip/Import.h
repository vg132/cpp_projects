// Import.h: interface for the CImport class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IMPORT_H__820637A1_44B2_11D4_A39C_0008C7636E27__INCLUDED_)
#define AFX_IMPORT_H__820637A1_44B2_11D4_A39C_0008C7636E27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CImport  
{
public:
	CImport();
	virtual ~CImport();

};

#endif // !defined(AFX_IMPORT_H__820637A1_44B2_11D4_A39C_0008C7636E27__INCLUDED_)

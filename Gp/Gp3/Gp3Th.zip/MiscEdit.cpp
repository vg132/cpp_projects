// MiscEdit.cpp : implementation file
//

#include "stdafx.h"
#include "Gp3Th.h"
#include "MiscEdit.h"
#include "FileHandling.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMiscEdit dialog


CMiscEdit::CMiscEdit(CWnd* pParent /*=NULL*/)
	: CDialog(CMiscEdit::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMiscEdit)
	m_SaveRec = FALSE;
	m_RaceLen = 0;
	//}}AFX_DATA_INIT
}


void CMiscEdit::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMiscEdit)
	DDX_Control(pDX, IDC_SPIN_RACELENGTH, m_Spin_RaceLen);
	DDX_Control(pDX, IDC_PRO8, m_Pro8);
	DDX_Control(pDX, IDC_SEMIPRO8, m_SemiPro8);
	DDX_Control(pDX, IDC_SEMIPRO7, m_SemiPro7);
	DDX_Control(pDX, IDC_SEMIPRO6, m_SemiPro6);
	DDX_Control(pDX, IDC_SEMIPRO5, m_SemiPro5);
	DDX_Control(pDX, IDC_SEMIPRO4, m_SemiPro4);
	DDX_Control(pDX, IDC_SEMIPRO3, m_SemiPro3);
	DDX_Control(pDX, IDC_SEMIPRO2, m_SemiPro2);
	DDX_Control(pDX, IDC_SEMIPRO1, m_SemiPro1);
	DDX_Control(pDX, IDC_ROOKIE8, m_Rookie8);
	DDX_Control(pDX, IDC_ROOKIE7, m_Rookie7);
	DDX_Control(pDX, IDC_ROOKIE6, m_Rookie6);
	DDX_Control(pDX, IDC_ROOKIE5, m_Rookie5);
	DDX_Control(pDX, IDC_ROOKIE4, m_Rookie4);
	DDX_Control(pDX, IDC_ROOKIE3, m_Rookie3);
	DDX_Control(pDX, IDC_ROOKIE2, m_Rookie2);
	DDX_Control(pDX, IDC_ROOKIE1, m_Rookie1);
	DDX_Control(pDX, IDC_PRO7, m_Pro7);
	DDX_Control(pDX, IDC_PRO6, m_Pro6);
	DDX_Control(pDX, IDC_PRO5, m_Pro5);
	DDX_Control(pDX, IDC_PRO4, m_Pro4);
	DDX_Control(pDX, IDC_PRO3, m_Pro3);
	DDX_Control(pDX, IDC_PRO2, m_Pro2);
	DDX_Control(pDX, IDC_PRO1, m_Pro1);
	DDX_Control(pDX, IDC_AMATEUR8, m_Amateur8);
	DDX_Control(pDX, IDC_AMATEUR7, m_Amateur7);
	DDX_Control(pDX, IDC_AMATEUR6, m_Amateur6);
	DDX_Control(pDX, IDC_AMATEUR5, m_Amateur5);
	DDX_Control(pDX, IDC_AMATEUR4, m_Amateur4);
	DDX_Control(pDX, IDC_AMATEUR3, m_Amateur3);
	DDX_Control(pDX, IDC_AMATEUR2, m_Amateur2);
	DDX_Control(pDX, IDC_AMATEUR1, m_Amateur1);
	DDX_Control(pDX, IDC_ACE7, m_Ace7);
	DDX_Control(pDX, IDC_ACE6, m_Ace6);
	DDX_Control(pDX, IDC_ACE8, m_Ace8);
	DDX_Control(pDX, IDC_ACE5, m_Ace5);
	DDX_Control(pDX, IDC_ACE4, m_Ace4);
	DDX_Control(pDX, IDC_ACE3, m_Ace3);
	DDX_Control(pDX, IDC_ACE2, m_Ace2);
	DDX_Control(pDX, IDC_ACE1, m_Ace1);
	DDX_Check(pDX, IDC_SAVEREC, m_SaveRec);
	DDX_Text(pDX, IDC_RACELENGTH, m_RaceLen);
	DDV_MinMaxInt(pDX, m_RaceLen, 0, 100);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMiscEdit, CDialog)
	//{{AFX_MSG_MAP(CMiscEdit)
	ON_BN_CLICKED(IDC_ACE1, OnAce1)
	ON_BN_CLICKED(IDC_ACE2, OnAce2)
	ON_BN_CLICKED(IDC_ACE3, OnAce3)
	ON_BN_CLICKED(IDC_ACE4, OnAce4)
	ON_BN_CLICKED(IDC_ACE5, OnAce5)
	ON_BN_CLICKED(IDC_ACE6, OnAce6)
	ON_BN_CLICKED(IDC_ACE7, OnAce7)
	ON_BN_CLICKED(IDC_ACE8, OnAce8)
	ON_BN_CLICKED(IDC_PRO1, OnPro1)
	ON_BN_CLICKED(IDC_PRO2, OnPro2)
	ON_BN_CLICKED(IDC_PRO3, OnPro3)
	ON_BN_CLICKED(IDC_PRO4, OnPro4)
	ON_BN_CLICKED(IDC_PRO5, OnPro5)
	ON_BN_CLICKED(IDC_PRO6, OnPro6)
	ON_BN_CLICKED(IDC_PRO7, OnPro7)
	ON_BN_CLICKED(IDC_PRO8, OnPro8)
	ON_BN_CLICKED(IDC_AMATEUR1, OnAmateur1)
	ON_BN_CLICKED(IDC_AMATEUR2, OnAmateur2)
	ON_BN_CLICKED(IDC_AMATEUR3, OnAmateur3)
	ON_BN_CLICKED(IDC_AMATEUR4, OnAmateur4)
	ON_BN_CLICKED(IDC_AMATEUR5, OnAmateur5)
	ON_BN_CLICKED(IDC_AMATEUR6, OnAmateur6)
	ON_BN_CLICKED(IDC_AMATEUR7, OnAmateur7)
	ON_BN_CLICKED(IDC_AMATEUR8, OnAmateur8)
	ON_BN_CLICKED(IDC_ROOKIE1, OnRookie1)
	ON_BN_CLICKED(IDC_ROOKIE2, OnRookie2)
	ON_BN_CLICKED(IDC_ROOKIE3, OnRookie3)
	ON_BN_CLICKED(IDC_ROOKIE4, OnRookie4)
	ON_BN_CLICKED(IDC_ROOKIE5, OnRookie5)
	ON_BN_CLICKED(IDC_ROOKIE6, OnRookie6)
	ON_BN_CLICKED(IDC_ROOKIE7, OnRookie7)
	ON_BN_CLICKED(IDC_ROOKIE8, OnRookie8)
	ON_BN_CLICKED(IDC_SEMIPRO1, OnSemipro1)
	ON_BN_CLICKED(IDC_SEMIPRO2, OnSemipro2)
	ON_BN_CLICKED(IDC_SEMIPRO3, OnSemipro3)
	ON_BN_CLICKED(IDC_SEMIPRO4, OnSemipro4)
	ON_BN_CLICKED(IDC_SEMIPRO5, OnSemipro5)
	ON_BN_CLICKED(IDC_SEMIPRO6, OnSemipro6)
	ON_BN_CLICKED(IDC_SEMIPRO7, OnSemipro7)
	ON_BN_CLICKED(IDC_SEMIPRO8, OnSemipro8)
	ON_BN_CLICKED(IDC_CANCEL, OnCancel)
	ON_BN_CLICKED(IDC_OK, OnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMiscEdit message handlers

void CMiscEdit::OnAce1() 
{
CBitmap chb;
	if(Ace[0]==0)
	{
		Ace[0]=1;
		chb.LoadBitmap(109);
	}
	else
	{
		Ace[0]=0;
		chb.LoadBitmap(101);
	}
	m_Ace1.SetBitmap((HBITMAP)chb);
	m_Ace1.RedrawWindow();
}

void CMiscEdit::OnAce2() 
{
CBitmap chb;
	if(Ace[1]==0)
	{
		Ace[1]=1;
		chb.LoadBitmap(110);
	}
	else
	{
		Ace[1]=0;
		chb.LoadBitmap(102);
	}
	m_Ace2.SetBitmap((HBITMAP)chb);
	m_Ace2.RedrawWindow();
}

void CMiscEdit::OnAce3() 
{
CBitmap chb;
	if(Ace[2]==0)
	{
		Ace[2]=1;
		chb.LoadBitmap(111);
	}
	else
	{
		Ace[2]=0;
		chb.LoadBitmap(103);
	}
	m_Ace3.SetBitmap((HBITMAP)chb);
	m_Ace3.RedrawWindow();
}

void CMiscEdit::OnAce4() 
{
CBitmap chb;
	if(Ace[3]==0)
	{
		Ace[3]=1;
		chb.LoadBitmap(112);
	}
	else
	{
		Ace[3]=0;
		chb.LoadBitmap(104);
	}
	m_Ace4.SetBitmap((HBITMAP)chb);
	m_Ace4.RedrawWindow();
}

void CMiscEdit::OnAce5() 
{
CBitmap chb;
	if(Ace[4]==0)
	{
		Ace[4]=1;
		chb.LoadBitmap(113);
	}
	else
	{
		Ace[4]=0;
		chb.LoadBitmap(105);
	}
	m_Ace5.SetBitmap((HBITMAP)chb);
	m_Ace5.RedrawWindow();
}

void CMiscEdit::OnAce6() 
{
CBitmap chb;
	if(Ace[5]==0)
	{
		Ace[5]=1;
		chb.LoadBitmap(114);
	}
	else
	{
		Ace[5]=0;
		chb.LoadBitmap(106);
	}
	m_Ace6.SetBitmap((HBITMAP)chb);
	m_Ace6.RedrawWindow();
}

void CMiscEdit::OnAce7() 
{
CBitmap chb;
	if(Ace[6]==0)
	{
		Ace[6]=1;
		chb.LoadBitmap(115);
	}
	else
	{
		Ace[6]=0;
		chb.LoadBitmap(107);
	}
	m_Ace7.SetBitmap((HBITMAP)chb);
	m_Ace7.RedrawWindow();
}

void CMiscEdit::OnAce8() 
{
CBitmap chb;
	if(Ace[7]==0)
	{
		Ace[7]=1;
		chb.LoadBitmap(116);
	}
	else
	{
		Ace[7]=0;
		chb.LoadBitmap(108);
	}
	m_Ace8.SetBitmap((HBITMAP)chb);
	m_Ace8.RedrawWindow();
}

void CMiscEdit::OnPro1() 
{
CBitmap chb;
	if(Pro[0]==0)
	{
		Pro[0]=1;
		chb.LoadBitmap(109);
	}
	else
	{
		Pro[0]=0;
		chb.LoadBitmap(101);
	}
	m_Pro1.SetBitmap((HBITMAP)chb);
	m_Pro1.RedrawWindow();
}

void CMiscEdit::OnPro2() 
{
CBitmap chb;
	if(Pro[1]==0)
	{
		Pro[1]=1;
		chb.LoadBitmap(110);
	}
	else
	{
		Pro[1]=0;
		chb.LoadBitmap(102);
	}
	m_Pro2.SetBitmap((HBITMAP)chb);
	m_Pro2.RedrawWindow();
}

void CMiscEdit::OnPro3() 
{
CBitmap chb;
	if(Pro[2]==0)
	{
		Pro[2]=1;
		chb.LoadBitmap(111);
	}
	else
	{
		Pro[2]=0;
		chb.LoadBitmap(103);
	}
	m_Pro3.SetBitmap((HBITMAP)chb);
	m_Pro3.RedrawWindow();
}

void CMiscEdit::OnPro4() 
{
CBitmap chb;
	if(Pro[3]==0)
	{
		Pro[3]=1;
		chb.LoadBitmap(112);
	}
	else
	{
		Pro[3]=0;
		chb.LoadBitmap(104);
	}
	m_Pro4.SetBitmap((HBITMAP)chb);
	m_Pro4.RedrawWindow();
}

void CMiscEdit::OnPro5() 
{
CBitmap chb;
	if(Pro[4]==0)
	{
		Pro[4]=1;
		chb.LoadBitmap(113);
	}
	else
	{
		Pro[4]=0;
		chb.LoadBitmap(105);
	}
	m_Pro5.SetBitmap((HBITMAP)chb);
	m_Pro5.RedrawWindow();
}

void CMiscEdit::OnPro6() 
{
CBitmap chb;
	if(Pro[5]==0)
	{
		Pro[5]=1;
		chb.LoadBitmap(114);
	}
	else
	{
		Pro[5]=0;
		chb.LoadBitmap(106);
	}
	m_Pro6.SetBitmap((HBITMAP)chb);
	m_Pro6.RedrawWindow();
}

void CMiscEdit::OnPro7() 
{
CBitmap chb;
	if(Pro[6]==0)
	{
		Pro[6]=1;
		chb.LoadBitmap(115);
	}
	else
	{
		Pro[6]=0;
		chb.LoadBitmap(107);
	}
	m_Pro7.SetBitmap((HBITMAP)chb);
	m_Pro7.RedrawWindow();
}

void CMiscEdit::OnPro8() 
{
CBitmap chb;
	if(Pro[7]==0)
	{
		Pro[7]=1;
		chb.LoadBitmap(116);
	}
	else
	{
		Pro[7]=0;
		chb.LoadBitmap(108);
	}
	m_Pro8.SetBitmap((HBITMAP)chb);
	m_Pro8.RedrawWindow();
}

BOOL CMiscEdit::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	CDialog::ShowWindow(SW_SHOW);
	LoadAids();

	m_Spin_RaceLen.SetRange(0,100);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CMiscEdit::OnAmateur1() 
{
CBitmap chb;
	if(Amateur[0]==0)
	{
		Amateur[0]=1;
		chb.LoadBitmap(109);
	}
	else
	{
		Amateur[0]=0;
		chb.LoadBitmap(101);
	}
	m_Amateur1.SetBitmap((HBITMAP)chb);
	m_Amateur1.RedrawWindow();
}

void CMiscEdit::OnAmateur2() 
{
CBitmap chb;
	if(Amateur[1]==0)
	{
		Amateur[1]=1;
		chb.LoadBitmap(110);
	}
	else
	{
		Amateur[1]=0;
		chb.LoadBitmap(102);
	}
	m_Amateur2.SetBitmap((HBITMAP)chb);
	m_Amateur2.RedrawWindow();
}

void CMiscEdit::OnAmateur3() 
{
CBitmap chb;
	if(Amateur[2]==0)
	{
		Amateur[2]=1;
		chb.LoadBitmap(111);
	}
	else
	{
		Amateur[2]=0;
		chb.LoadBitmap(103);
	}
	m_Amateur3.SetBitmap((HBITMAP)chb);
	m_Amateur3.RedrawWindow();
}

void CMiscEdit::OnAmateur4() 
{
CBitmap chb;
	if(Amateur[3]==0)
	{
		Amateur[3]=1;
		chb.LoadBitmap(112);
	}
	else
	{
		Amateur[3]=0;
		chb.LoadBitmap(104);
	}
	m_Amateur4.SetBitmap((HBITMAP)chb);
	m_Amateur4.RedrawWindow();
}

void CMiscEdit::OnAmateur5() 
{
CBitmap chb;
	if(Amateur[4]==0)
	{
		Amateur[4]=1;
		chb.LoadBitmap(113);
	}
	else
	{
		Amateur[4]=0;
		chb.LoadBitmap(105);
	}
	m_Amateur5.SetBitmap((HBITMAP)chb);
	m_Amateur5.RedrawWindow();
}

void CMiscEdit::OnAmateur6() 
{
CBitmap chb;
	if(Amateur[5]==0)
	{
		Amateur[5]=1;
		chb.LoadBitmap(114);
	}
	else
	{
		Amateur[5]=0;
		chb.LoadBitmap(106);
	}
	m_Amateur6.SetBitmap((HBITMAP)chb);
	m_Amateur6.RedrawWindow();
}

void CMiscEdit::OnAmateur7() 
{
CBitmap chb;
	if(Amateur[6]==0)
	{
		Amateur[6]=1;
		chb.LoadBitmap(115);
	}
	else
	{
		Amateur[6]=0;
		chb.LoadBitmap(107);
	}
	m_Amateur7.SetBitmap((HBITMAP)chb);
	m_Amateur7.RedrawWindow();
}

void CMiscEdit::OnAmateur8() 
{
CBitmap chb;
	if(Amateur[7]==0)
	{
		Amateur[7]=1;
		chb.LoadBitmap(116);
	}
	else
	{
		Amateur[7]=0;
		chb.LoadBitmap(108);
	}
	m_Amateur8.SetBitmap((HBITMAP)chb);
	m_Amateur8.RedrawWindow();
}

void CMiscEdit::OnRookie1() 
{
CBitmap chb;
	if(Rookie[0]==0)
	{
		Rookie[0]=1;
		chb.LoadBitmap(109);
	}
	else
	{
		Rookie[0]=0;
		chb.LoadBitmap(101);
	}
	m_Rookie1.SetBitmap((HBITMAP)chb);
	m_Rookie1.RedrawWindow();
}

void CMiscEdit::OnRookie2() 
{
CBitmap chb;
	if(Rookie[1]==0)
	{
		Rookie[1]=1;
		chb.LoadBitmap(110);
	}
	else
	{
		Rookie[1]=0;
		chb.LoadBitmap(102);
	}
	m_Rookie2.SetBitmap((HBITMAP)chb);
	m_Rookie2.RedrawWindow();
}

void CMiscEdit::OnRookie3() 
{
CBitmap chb;
	if(Rookie[2]==0)
	{
		Rookie[2]=1;
		chb.LoadBitmap(111);
	}
	else
	{
		Rookie[2]=0;
		chb.LoadBitmap(103);
	}
	m_Rookie3.SetBitmap((HBITMAP)chb);
	m_Rookie3.RedrawWindow();
}

void CMiscEdit::OnRookie4() 
{
CBitmap chb;
	if(Rookie[3]==0)
	{
		Rookie[3]=1;
		chb.LoadBitmap(112);
	}
	else
	{
		Rookie[3]=0;
		chb.LoadBitmap(104);
	}
	m_Rookie4.SetBitmap((HBITMAP)chb);
	m_Rookie4.RedrawWindow();
}

void CMiscEdit::OnRookie5() 
{
CBitmap chb;
	if(Rookie[4]==0)
	{
		Rookie[4]=1;
		chb.LoadBitmap(113);
	}
	else
	{
		Rookie[4]=0;
		chb.LoadBitmap(105);
	}
	m_Rookie5.SetBitmap((HBITMAP)chb);
	m_Rookie5.RedrawWindow();
}

void CMiscEdit::OnRookie6() 
{
CBitmap chb;
	if(Rookie[5]==0)
	{
		Rookie[5]=1;
		chb.LoadBitmap(114);
	}
	else
	{
		Rookie[5]=0;
		chb.LoadBitmap(106);
	}
	m_Rookie6.SetBitmap((HBITMAP)chb);
	m_Rookie6.RedrawWindow();
}

void CMiscEdit::OnRookie7() 
{
CBitmap chb;
	if(Rookie[6]==0)
	{
		Rookie[6]=1;
		chb.LoadBitmap(115);
	}
	else
	{
		Rookie[6]=0;
		chb.LoadBitmap(107);
	}
	m_Rookie7.SetBitmap((HBITMAP)chb);
	m_Rookie7.RedrawWindow();
}

void CMiscEdit::OnRookie8() 
{
CBitmap chb;
	if(Rookie[7]==0)
	{
		Rookie[7]=1;
		chb.LoadBitmap(116);
	}
	else
	{
		Rookie[7]=0;
		chb.LoadBitmap(108);
	}
	m_Rookie8.SetBitmap((HBITMAP)chb);
	m_Rookie8.RedrawWindow();
}

void CMiscEdit::OnSemipro1() 
{
CBitmap chb;
	if(SemiPro[0]==0)
	{
		SemiPro[0]=1;
		chb.LoadBitmap(109);
	}
	else
	{
		SemiPro[0]=0;
		chb.LoadBitmap(101);
	}
	m_SemiPro1.SetBitmap((HBITMAP)chb);
	m_SemiPro1.RedrawWindow();
}

void CMiscEdit::OnSemipro2() 
{
CBitmap chb;
	if(SemiPro[1]==0)
	{
		SemiPro[1]=1;
		chb.LoadBitmap(110);
	}
	else
	{
		SemiPro[1]=0;
		chb.LoadBitmap(102);
	}
	m_SemiPro2.SetBitmap((HBITMAP)chb);
	m_SemiPro2.RedrawWindow();
}

void CMiscEdit::OnSemipro3() 
{
CBitmap chb;
	if(SemiPro[2]==0)
	{
		SemiPro[2]=1;
		chb.LoadBitmap(111);
	}
	else
	{
		SemiPro[2]=0;
		chb.LoadBitmap(103);
	}
	m_SemiPro3.SetBitmap((HBITMAP)chb);
	m_SemiPro3.RedrawWindow();
}

void CMiscEdit::OnSemipro4() 
{
CBitmap chb;
	if(SemiPro[3]==0)
	{
		SemiPro[3]=1;
		chb.LoadBitmap(112);
	}
	else
	{
		SemiPro[3]=0;
		chb.LoadBitmap(104);
	}
	m_SemiPro4.SetBitmap((HBITMAP)chb);
	m_SemiPro4.RedrawWindow();
}

void CMiscEdit::OnSemipro5() 
{
CBitmap chb;
	if(SemiPro[4]==0)
	{
		SemiPro[4]=1;
		chb.LoadBitmap(113);
	}
	else
	{
		SemiPro[4]=0;
		chb.LoadBitmap(105);
	}
	m_SemiPro5.SetBitmap((HBITMAP)chb);
	m_SemiPro5.RedrawWindow();
}

void CMiscEdit::OnSemipro6() 
{
CBitmap chb;
	if(SemiPro[5]==0)
	{
		SemiPro[5]=1;
		chb.LoadBitmap(114);
	}
	else
	{
		SemiPro[5]=0;
		chb.LoadBitmap(106);
	}
	m_SemiPro6.SetBitmap((HBITMAP)chb);
	m_SemiPro6.RedrawWindow();
}

void CMiscEdit::OnSemipro7() 
{
CBitmap chb;
	if(SemiPro[6]==0)
	{
		SemiPro[6]=1;
		chb.LoadBitmap(115);
	}
	else
	{
		SemiPro[6]=0;
		chb.LoadBitmap(107);
	}
	m_SemiPro7.SetBitmap((HBITMAP)chb);
	m_SemiPro7.RedrawWindow();
}

void CMiscEdit::OnSemipro8() 
{
CBitmap chb;
	if(SemiPro[7]==0)
	{
		SemiPro[7]=1;
		chb.LoadBitmap(116);
	}
	else
	{
		SemiPro[7]=0;
		chb.LoadBitmap(108);
	}
	m_SemiPro8.SetBitmap((HBITMAP)chb);
	m_SemiPro8.RedrawWindow();
}

void CMiscEdit::LoadAids()
{
CFileHandling fh;
int i;
int iVal;
	fh.LoadMisc(m_TempFile);
	m_SaveRec=fh.GetSaveRec();
	m_RaceLen=fh.GetQuickRaceLen();
	for(i=0;i<8;i++)
	{
		iVal=fh.GetAids(i);
		Ace[i]=iVal;
	}
	for(i=0;i<8;i++)
	{
		iVal=fh.GetAids(i+8);
		Pro[i]=iVal;
	}
	for(i=0;i<8;i++)
	{
		iVal=fh.GetAids(i+16);
		SemiPro[i]=iVal;
	}
	for(i=0;i<8;i++)
	{
		iVal=fh.GetAids(i+24);
		Amateur[i]=iVal;
	}
	for(i=0;i<8;i++)
	{
		iVal=fh.GetAids(i+32);
		Rookie[i]=iVal;
	}
	OnAce1();
	OnAce2();
	OnAce3();
	OnAce4();
	OnAce5();
	OnAce6();
	OnAce7();
	OnAce8();
	OnPro1();
	OnPro2();
	OnPro3();
	OnPro4();
	OnPro5();
	OnPro6();
	OnPro7();
	OnPro8();
	OnSemipro1();
	OnSemipro2();
	OnSemipro3();
	OnSemipro4();
	OnSemipro5();
	OnSemipro6();
	OnSemipro7();
	OnSemipro8();
	OnAmateur1();
	OnAmateur2();
	OnAmateur3();
	OnAmateur4();
	OnAmateur5();
	OnAmateur6();
	OnAmateur7();
	OnAmateur8();
	OnRookie1();
	OnRookie2();
	OnRookie3();
	OnRookie4();
	OnRookie5();
	OnRookie6();
	OnRookie7();
	OnRookie8();
	UpdateData(FALSE);
}

void CMiscEdit::OnCancel() 
{
	CDialog::OnCancel();	
}

void CMiscEdit::OnOk() 
{
CFileHandling fh;
CString ace="";
CString pro="";
CString amateur="";
CString rookie="";
CString semiPro="";
char buf[260];
	UpdateData(TRUE);
	fh.LoadMisc(m_TempFile);
	for(int i=0;i<8;i++)
	{
		itoa(Ace[i],buf,10);
		ace+=buf;
		ace+="|";
		itoa(Amateur[i],buf,10);
		amateur+=buf;
		amateur+="|";
		itoa(Pro[i],buf,10);
		pro+=buf;
		pro+="|";
		itoa(Rookie[i],buf,10);
		rookie+=buf;
		rookie+="|";
		itoa(SemiPro[i],buf,10);
		semiPro+=buf;
		semiPro+="|";
	}
	ace+=pro;
	ace+=semiPro;
	ace+=amateur;
	ace+=rookie;

	fh.SetAids(ace);
	fh.SetQuickRaceLen(m_RaceLen);
	fh.SetSaveRec((bool)m_SaveRec);
	fh.SaveMisc(m_TempFile);
	CDialog::OnOK();	
}

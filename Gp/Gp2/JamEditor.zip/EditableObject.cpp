// EditableObject.cpp - implementation of the CEditableObject class
//

#include "stdafx.h"
#include "resource.h"

#include "EditableObject.h"

#include "DataEditorDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CEditableObject construction/destruction

CEditableObject::CEditableObject(CEditableObject* pParent/*=NULL*/)
{
	m_hTreeItem = NULL;
	m_pParent = pParent;
}

CEditableObject::~CEditableObject()
{
}


/////////////////////////////////////////////////////////////////////////////
// CEditableObject operations

// Handle double-clicking interaction in the tree.  Return TRUE to
// indicate that the value of this object has been changed, or FALSE
// if not.
BOOL CEditableObject::HandleDblClk()
{
	// Check to see whether we can actually double-click edit
	if (!CanEdit())
		return FALSE;

	// By default, edit the value as a string
	CDataEditorDialog dlg;
	dlg.m_newValue = GetValueToEdit();	// set the initial value
	BOOL bChanged = FALSE;
	if (IDOK == dlg.DoModal())
	{
		// deal with accepting the changes
		bChanged = ChangeDataFromEdit(dlg.m_newValue);
	}

	return bChanged;
}


// GP2Bitmap.h - header file for the CGP2Bitmap class (freely adapted
//				 from the CGP2Bitmap class by Trevor Kellaway).

#ifndef __GP2_BITMAP_H__
#define __GP2_BITMAP_H__

// Constants for the biCompression field
#define BI_RGB      		0L
#define BI_RLE8     		1L
#define BI_RLE4     		2L

// Structure byte-packing?
#pragma pack(1)

class CGP2Bitmap
{
// Construction/destruction
public:
	CGP2Bitmap();
	virtual ~CGP2Bitmap();

// Attributes
protected:
	BITMAPFILEHEADER m_Hdr;
	BITMAPINFO m_bmInfo;
	RGBQUAD m_Palette[256];
	BYTE* m_pbPixels;

// Operations
public:
	// Bitmap creation
	BOOL CreateFromJamPixels(WORD wWidth, WORD wHeight, BYTE* pImage = NULL);
	void SetPalette(const RGBQUAD palette[]);

	void CreateDIB(CBitmap &bitmap);

	// Retrieval of attributes
	WORD GetWidth() const { return (WORD)m_bmInfo.bmiHeader.biWidth; }
	WORD GetHeight() const { return (WORD)m_bmInfo.bmiHeader.biHeight; }
	CSize GetSize() const { return CSize(GetWidth(), GetHeight()); }
	WORD GetPaddedWidth() const;

	BYTE* GetPixels() const { return m_pbPixels; }
	RGBQUAD* GetPalette() { return m_Palette; }

	// Loading/saving functions
	BOOL LoadFile(const CString& strFilename);
	BOOL SaveFile(const CString& strFilename);

	// Format validation
	BOOL IsValid() const;

// Implementation
protected:
	// Internal format validation
	void Initialise();
	BOOL IsBitmap() const;
	BOOL IsRGB256Bitmap() const;
	BOOL IsValidPalette() const;

	// Image manipulation.  As far as the outside world is concerned,
	// the pixels are always the right way up, even though they're
	// saved up-side down in bitmap files.
	BOOL FlipImage();

// Options
public:
	// When loading bitmaps, should we ignore situations in which
	// the colours in the bitmap's palette do not match our global
	// palette?
	static BOOL s_bIgnoreInvalidPalettes;
};

////////////////////////////////////////////////////////////////

#endif	// ~__GP2_BITMAP_H__

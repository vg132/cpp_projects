// FogFilter.h - header file for the CFogFilter class
//

#ifndef __FOG_FILTER_H__
#define __FOG_FILTER_H__

#include "TintedFilter.h"

///////////////////////////////////////////////////////////////////
// Class:	CFogFilter
// Base:	CTintedFilter
// Created:	28 April 99 by Mal Ross
// Overview:
//    This filter produces 4 decoded textures whose colours
//  gradually fade to a misty grey colour, giving the
//  impression of driving in fog (just like this morning in
//  the NE of England :).
//

class CFogFilter : public CTintedFilter
{
// Construction and destruction
public:
	CFogFilter();
	virtual ~CFogFilter();

// Enumerations
public:
	// The valid range of fog ratings, where low is good visibility
	enum eFogRating
	{
		MIN_FOG_RATING = 1,
		MAX_FOG_RATING = 10,
		DEFAULT_FOG_RATING = 6
	};

// Attributes
protected:
	// The visibility rating on a scale from MIN_FOG_RATING
	// to MAX_FOG_RATING, where MIN_FOG_RATING means good visibility
	int m_nFogRating;

// Operations
public:
	// User-configuration of the filter's parameters
	virtual BOOL IsConfigurable() const { return TRUE; }
	virtual void Configure();

// Implementation
protected:
	// Get/set the fog rating (see declaration of m_nFogRating
	// above for its meaning)
	BOOL SetFogRating(const int nRating);
	int GetFogRating() const;
};

/////////////////////////////////////////////////////////////////////

#endif	// ~__FOG_FILTER_H__

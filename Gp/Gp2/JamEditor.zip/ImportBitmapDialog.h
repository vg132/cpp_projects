// ImportBitmapDialog.h : header file
//

#ifndef _IMPORT_BITMAP_DIALOG_H
#define	_IMPORT_BITMAP_DIALOG_H

#include "PreviewFileDialog.h"
class CJamTextureFilter;

/////////////////////////////////////////////////////////////////////////////
// CImportBitmapDialog dialog

class CImportBitmapDialog : public CPreviewFileDialog
{
	DECLARE_DYNAMIC(CImportBitmapDialog)

public:
	CImportBitmapDialog(BOOL bOpenFileDialog, // TRUE for FileOpen, FALSE for FileSaveAs
		LPCTSTR lpszDefExt = NULL,
		LPCTSTR lpszFileName = NULL,
		DWORD dwFlags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		LPCTSTR lpszFilter = NULL,
		CWnd* pParentWnd = NULL);

// Dialog Data
	//{{AFX_DATA(CImportBitmapDialog)
	UINT m_nWidth;
	UINT m_nHeight;
	UINT m_nReqWidth;
	UINT m_nReqHeight;
	int m_nFilterIndex;
	BOOL m_bProtectTransparency;
	//}}AFX_DATA

	// Flag to say whether the Filtering controls should be available
	BOOL m_bEnableFiltering;

	// The ID of the selected import filter
	UINT m_nFilterID;

	// Reporting of the chosen import filter
	CJamTextureFilter* GetSelectedFilter();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CImportBitmapDialog)
	public:
	virtual int DoModal();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Show a preview of the given file in the static
	virtual BOOL SetPreviewFile(const CString& strFilename);

	// Specify the dialog template to use for the preview area
	virtual UINT GetPreviewTemplateID () const;

protected:
	//{{AFX_MSG(CImportBitmapDialog)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelectImportFilter();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif	// ~_IMPORT_BITMAP_DIALOG_H
// SetHandler.h: interface for the CSetHandler class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SETHANDLER_H__5C84FBC2_18A5_4BD9_A594_AEBE8A4C8B84__INCLUDED_)
#define AFX_SETHANDLER_H__5C84FBC2_18A5_4BD9_A594_AEBE8A4C8B84__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CSetHandler  
{
public:
	void NewFile();
	void SetTrack(int, char*);
	void GetTrack(int, char*);
	bool SaveFile(CString file);
	bool LoadFile(CString file);
	CSetHandler();
	virtual ~CSetHandler();
private:
	char SetData[16][260];
};

#endif // !defined(AFX_SETHANDLER_H__5C84FBC2_18A5_4BD9_A594_AEBE8A4C8B84__INCLUDED_)

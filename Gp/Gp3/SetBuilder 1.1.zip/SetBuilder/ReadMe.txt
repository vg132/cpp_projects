30/03/2001                                            Version 1.0
=======================================================================

Title		: Gp3 Set Builder
Filenames	: SetBuilder.exe, readme.txt
Author		: Viktor Gars
Email Address	: viktor.gars@telia.com
Homepage	: http://www.vgsoftware.com/
Description	: Build track set files for GPxPatch
Author Info	: <optional>
Other Works	: Gp2 Track Handler, Gp1 Lap Edit, GPW Save File Editor and some other small programs

=======================================================================

* Construction *

Base		: None
Editor(s) used	: Visual C++
Known Bugs	: None
Build Time	: 2 days

* Installation *

	Unzip and run!

* Other Information *

  If you have any problems running this program visit the support section on my site or mail me.
  http://www.vgsoftware.com/ or viktor.gars@telia.com  
  
* Copyright / Permissions *

	Gp3 Set Builder is freeware. It's not allowed to use it for commercial purposes, either directly or indirectly. 
	You may not redistribute Gp3 Set Builder via any media or for any purpose without the express permission of the author.

* Disclaimer *

	This software is provided as is without warranty of any kind, either expressed or implied. The author will not be held responsible for any losses incurred, either directly or indirectly, by the use of this program. 

=======================================================================
Copyright � Viktor Gars 2001
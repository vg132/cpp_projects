// FlagsDialogBase.cpp: implementation file for the CFlagsDialogBase class
//

#include "stdafx.h"
#include "resource.h"

#include "FlagsDialogBase.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFlagsDialogBase dialog

CFlagsDialogBase::CFlagsDialogBase(CWnd* pParent /*=NULL*/)
	: CDialog(CFlagsDialogBase::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFlagsDialogBase)
	//}}AFX_DATA_INIT

	m_nFirstFlagNameID = 0;
}

void CFlagsDialogBase::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	if (!pDX->m_bSaveAndValidate)
		StoreFlags(FALSE);

	//{{AFX_DATA_MAP(CFlagsDialogBase)
	DDX_Control(pDX, IDC_LIST_FLAGS, m_FlagListBox);
	//}}AFX_DATA_MAP

	if (pDX->m_bSaveAndValidate)
		StoreFlags(TRUE);
}


BEGIN_MESSAGE_MAP(CFlagsDialogBase, CDialog)
	//{{AFX_MSG_MAP(CFlagsDialogBase)
	ON_CBN_SELCHANGE(IDC_DISPLAY_USING_LIST, OnSelectDisplayType)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFlagsDialogBase message handlers

#define DISPLAY_USING_NAMES		0
#define DISPLAY_USING_DECIMAL	1
#define DISPLAY_USING_HEX		2
#define DISPLAY_USING_BIN		3

BOOL CFlagsDialogBase::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// Initialise the checklistbox
	((CComboBox *)GetDlgItem(IDC_DISPLAY_USING_LIST))->SetCurSel(DISPLAY_USING_NAMES);
	OnSelectDisplayType();
	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CFlagsDialogBase::StoreFlags(const BOOL bSaveAndValidate)
{
	if (!::IsWindow(m_FlagListBox.m_hWnd))
		return;

	if (bSaveAndValidate)
	{
		// Taking the values in the list and putting them
		// into the m_wFlags member
		const int FIRST_FLAG = GetFirstFlagPosition();
		int nFlagCount = m_FlagListBox.GetCount();
		for (int nFlagNum = 0; nFlagNum < nFlagCount; nFlagNum++)
			SetFlag(FIRST_FLAG + nFlagNum, (m_FlagListBox.GetCheck(nFlagNum) != 0));
	}
	else
	{
		// Taking the values in the texture and putting them
		// into the list
		const int FIRST_FLAG = GetFirstFlagPosition();
		const int LAST_FLAG = GetLastFlagPosition();
		if (m_FlagListBox.GetCount() > 0)
		{
			for (int nFlagNum = FIRST_FLAG; nFlagNum <= LAST_FLAG; nFlagNum++)
				m_FlagListBox.SetCheck(nFlagNum - FIRST_FLAG, IsFlagSet(nFlagNum) ? 1 : 0);
		}
	}
}


// The user has selected 
void CFlagsDialogBase::OnSelectDisplayType() 
{
	// Get the selection from the combo
	CComboBox* pDisplayAsCombo = (CComboBox *)GetDlgItem(IDC_DISPLAY_USING_LIST);
	ASSERT(NULL != pDisplayAsCombo);
	if (NULL == pDisplayAsCombo)
		return;
	int nDisplayType = pDisplayAsCombo->GetCurSel();

	// Put all of the flags as set in the dialog into the
	// derived class's data member
	StoreFlags(TRUE);

	// Clear the list now that we've made a note of the flag
	// settings in it, and refill it using the new strings
	CString strFlagName("");
	m_FlagListBox.ResetContent();
	const int FIRST_FLAG = GetFirstFlagPosition();
	const int LAST_FLAG = GetLastFlagPosition();
	const int FLAG_NAME_ID1 = GetFirstFlagNameID();
	for (int nFlagNum = FIRST_FLAG; nFlagNum <= LAST_FLAG; nFlagNum++)
	{
		switch (nDisplayType)
		{
		case DISPLAY_USING_NAMES:
			if (0 != FLAG_NAME_ID1)
				strFlagName.LoadString(FLAG_NAME_ID1 + (nFlagNum - FIRST_FLAG));
			else
				strFlagName.Format("Flag %d", (nFlagNum - FIRST_FLAG) + 1);
			break;
		case DISPLAY_USING_DECIMAL:
			strFlagName.Format("%d", FlagNumToMask(nFlagNum));
			break;
		case DISPLAY_USING_HEX:
			strFlagName.Format("%#x", FlagNumToMask(nFlagNum));
			break;
		case DISPLAY_USING_BIN:
			{
				char* name = new char[LAST_FLAG + 1];
				memset(name, (int)'0', LAST_FLAG);
				name[LAST_FLAG] = 0;	// LAST CHAR of string

				// insert a one
				name[LAST_FLAG - nFlagNum] = '1';

				strFlagName = name;

				delete[] name;
				name = NULL;
			}
			break;
		}
		m_FlagListBox.AddString(strFlagName);
	}

	// Reset the flags as they were last set in the dialog
	StoreFlags(FALSE);
}


UINT CFlagsDialogBase::FlagNumToMask(const int& nFlagID) const
{
	// Check to make sure the flag ID is valid
	const int FIRST_FLAG = GetFirstFlagPosition();
	const int LAST_FLAG = GetLastFlagPosition();
	if (nFlagID < FIRST_FLAG || nFlagID > LAST_FLAG)
		return 0;

	// Calculate the mask
	return UINT(1 << (nFlagID - 1));
}


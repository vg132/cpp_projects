11/09/2000                                            Version 0.9
=======================================================================

Title		: Gp3 Track Handler
Filenames	: Gp3Th.exe, readme.txt
Author		: Viktor Gars
Email Address	: viktor.gars@telia.com
Homepage	: http://www.vgsoftware.com/
Description	: Install your new tracks into Gp3
Author Info	: <optional>
Other Works	: Gp2 Track Handler, Gp1 Lap Edit, GPW Save File Editor and some other small programs

=======================================================================

* Construction *

Base		: None
Editor(s) used	: Visual C++
Known Bugs	: None
Build Time	: Long time

* Installation *
  Unzip and run the exe file in your setup directory.

* Other Information *
  If you have any problems running this program visit the support section on my site or mail me.
  http://www.vgsoftware.com/ or viktor.gars@telia.com  
  
* Copyright / Permissions *

  You do not have permission to put this tool on any CD-ROM
  of gp3 utilities that is to be retailed without the authors 
  prior conscent.

  You do however have permission to copy the Gp3 Car Setup Converter.
...


* Disclaimer *
  The author of this package takes no responsibility for
  it's use.
...


* Availability *

...


=======================================================================
Copyright � Viktor Gars 2000
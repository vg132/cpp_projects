// Gp3MenuText.cpp: implementation of the CGp3MenuText class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Gp3Th.h"
#include "Gp3MenuText.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGp3MenuText::CGp3MenuText()
{

}

CGp3MenuText::~CGp3MenuText()
{

}

bool CGp3MenuText::LoadText(CString sFile)
{
HANDLE hFile;
DWORD dwSize;
DWORD dwReadSize;
CString sTmp;
char ch;
int i;
	hFile=CreateFile(sFile,
					GENERIC_READ,
					FILE_SHARE_READ,
					NULL,OPEN_EXISTING,
					FILE_ATTRIBUTE_NORMAL,
					NULL);

	dwSize=GetFileSize(hFile,NULL);

	char * lpBuffer = (char*)GlobalAlloc(GMEM_FIXED,dwSize );
	ReadFile(hFile,(LPVOID)lpBuffer,dwSize,&dwReadSize,NULL);

	CloseHandle(hFile);
	int iSize=dwSize;
	for(i=0;i<iSize;i++)
	{
		ch=lpBuffer[i];
		if(ch!=NULL)
		{
			sTmp+=lpBuffer[i];
		}
		else
		{
			sText.Add(sTmp);
			sTmp="";
		}
	}
	GlobalFree(lpBuffer);
	return(true);
}

bool CGp3MenuText::SaveText(CString sFile)
{
CFile file;
char ch='\0';

	DeleteFile(sFile);
	file.Open(sFile,CFile::modeWrite|CFile::modeCreate,NULL);
	for(int i=0;i<sText.GetUpperBound()+1;i++)
	{
		file.Write(sText.GetAt(i),strlen(sText.GetAt(i)));
		file.Write((char*)&ch,sizeof(char));
	}

	file.Close();
	return(true);
}

CString CGp3MenuText::GetTrackName(int TrackNr)
{
	// Track Nr=1-16
	return(sText.GetAt(1783+TrackNr+LDiff));
}

bool CGp3MenuText::SetTrackName(CString NewString, int TrackNr)
{
	if(NewString!="")
	{
		sText.SetAt(1783+TrackNr+LDiff,NewString);
		return(true);
	}
	return(false);
}

CString CGp3MenuText::GetTrackCountry(int TrackNr)
{
	// Track Nr=1-16
	return(sText.GetAt(1799+TrackNr+LDiff));
}

bool CGp3MenuText::SetTrackCountry(CString NewString, int TrackNr)
{
	if(NewString!="")
	{
		for(int i=0;i<5;i++)
			sText.SetAt(1799+(i*16)+TrackNr+LDiff,NewString);
		return(true);	
	}
	return(false);
}

CString CGp3MenuText::GetTrackAdjective(int TrackNr)
{
	// Track Nr=1-16
	return(sText.GetAt(1879+TrackNr+LDiff));
}

bool CGp3MenuText::SetTrackAdjective(CString NewString, int TrackNr)
{
	if(NewString!="")
	{
		sText.SetAt(1879+TrackNr+LDiff,NewString);
		return(true);
	}
	return(false);
}

int CGp3MenuText::GetTextSize()
{
	return(sText.GetUpperBound());
}

void CGp3MenuText::SetLanguageDiff(int diff)
{
	LDiff=diff;
}

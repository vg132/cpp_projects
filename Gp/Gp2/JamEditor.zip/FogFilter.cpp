// FogFilter.cpp - implementation of the CFogFilter class
//

#include "stdafx.h"
#include "resource.h"

#include "FogFilter.h"
#include "JamTextureFilterIDs.h"
#include "FogFilterDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CFogFilter

// Constructor
CFogFilter::CFogFilter()
	: CTintedFilter(FOG_FILTER, IDS_FILTER_NAME_FOG)
{
	// Set the approach colour as misty-grey
	SetTintColor(RGB(239,239,239));

	// This will set both the tint factor (how rapidly we approach
	// the above colour) and the fogginess rating in one go.
	SetFogRating(DEFAULT_FOG_RATING);
}

// Destructor
CFogFilter::~CFogFilter()
{
}



// Overridden configuration functions
//

// Function:	Configure()
// Overview:	Show a dialog box allowing the user to configure
//				this filter.
void CFogFilter::Configure()
{
	// Set up the options dialog with the current information
	CFogFilterDlg dlg;
	dlg.SetFogRating(GetFogRating());

	// Show the dialog
	if (IDOK == dlg.DoModal())
	{
		// Get the new options from the dialog
		SetFogRating(dlg.GetFogRating());
	}
}
// End of function 'Configure'


// Function:	GetFogRating()
// Overview:	Get the integer value of the fogging rating
int CFogFilter::GetFogRating() const
{
	return m_nFogRating;
}
// End of function 'GetFogRating'


// For some stupid reason, the tint factor in our base class
// has a valid range of 0 to 100 and is an integer. :(
#define MIN_USABLE_TINT_PRESERVATION_FACTOR		35.f
#define MAX_USABLE_TINT_PRESERVATION_FACTOR		75.f

// Function:	SetFogRating()
// Overview:	Set the integer value of the fogging rating
BOOL CFogFilter::SetFogRating(const int nFogRating)
{
	// Just a quick dumb-programmer test first to catch
	// a potential divide-by-zero.
	ASSERT(MAX_FOG_RATING != MIN_FOG_RATING);
	ASSERT(MAX_USABLE_TINT_PRESERVATION_FACTOR != MIN_USABLE_TINT_PRESERVATION_FACTOR);

	// Make sure the new value's in the valid range
	if (nFogRating < MIN_FOG_RATING || nFogRating > MAX_FOG_RATING)
		return FALSE;

	// If we're not actually changing the value, just skip
	// out now (it allows us to keep the colour mappings
	// already cached in CLocalFilter)
	if (nFogRating == m_nFogRating)
		return TRUE;

	// Store the new time index and clear out the old
	// colour mappings
	m_nFogRating = nFogRating;
	InitialiseMappings();

	// Convert the value the user chose between MIN_FOG_RATING
	// and MAX_FOG_RATING to a percentage that represents how
	// much of a pixel's original colour should be preserved
	// during each application of the filter.
	float fInterimFactor = float(nFogRating - MIN_FOG_RATING) /
						   float(MAX_FOG_RATING - MIN_FOG_RATING);
	fInterimFactor = 1.0f - fInterimFactor;
	int nTintFactor = int(MIN_USABLE_TINT_PRESERVATION_FACTOR +
		(fInterimFactor * (MAX_USABLE_TINT_PRESERVATION_FACTOR - MIN_USABLE_TINT_PRESERVATION_FACTOR)));
	return SetTintFactor(nTintFactor);
}
// End of function 'SetFogRating'

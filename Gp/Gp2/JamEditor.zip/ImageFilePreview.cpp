// ImageFilePreview.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "ImageFilePreview.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CImageFilePreview construction

IMPLEMENT_DYNAMIC(CImageFilePreview, CFilePreview)

CImageFilePreview::CImageFilePreview()
{
}

CImageFilePreview::~CImageFilePreview()
{
}


/////////////////////////////////////////////////////////////////////////////
// CImageFilePreview drawing

// Function:	DrawPreview(pDC, rctDraw)
// Overview:	Draw the preview in the given DC
BOOL CImageFilePreview::DrawPreview(CDC* pDC, const CRect& rctDraw) const
{
	// We need a valid DC to be able to draw
	ASSERT(NULL != pDC);
	if (NULL == pDC)
		return FALSE;

	// We must at least have been given a valid filename
	if (m_strFilename.IsEmpty())
		return FALSE;

	// If the image file selected was not actually of the correct
	// format, tell the user this.
	if (!m_bIsValidFile)
	{
		DrawMessage(pDC, rctDraw, GetInvalidFormatText());

		return TRUE;
	}

	// Blank out the background with the usual hatched brush stuff
	pDC->PatBlt(rctDraw.left, rctDraw.top, rctDraw.Width(), rctDraw.Height(), WHITENESS);
	CBrush hatchedBrush;
	hatchedBrush.CreateHatchBrush(HS_DIAGCROSS, RGB(192,192,192));
	pDC->FillRect(rctDraw, &hatchedBrush);

	// Tidy up
	hatchedBrush.DeleteObject();

	// The image is drawn at 1:1 in a memory DC, then scaled
	// using StretchBlt into the DC we've been given.
	CDC memDC;
	memDC.CreateCompatibleDC(pDC);

	// We'll need a bitmap for the DC, too!
	int nWidth = GetImageWidth();
	int nHeight = GetImageHeight();
	CBitmap memBitmap;
	memBitmap.CreateCompatibleBitmap(pDC, nWidth, nHeight);
	CBitmap* pOldBitmap = memDC.SelectObject(&memBitmap);

	// Draw the image at 1:1 in the memory DC
	BOOL bSuccess = DrawImageOneToOne(&memDC);

	// Scale the resulting image, copying it into the DC passed into
	// this function
	if (bSuccess)
	{
		// Work out where we want to put the image and at what zoom.
		// Keep the aspect ratio constant, but make sure that the
		// whole image can be seen
		double dHorzZoom = (double)rctDraw.Width() / (double)nWidth;
		double dVertZoom = (double)rctDraw.Height() / (double)nHeight;
		double dZoomFactor = min(dHorzZoom, dVertZoom);

		// Zoom the sizes and stretchblt into pDC
		int nZoomedWidth  = (int)(nWidth * dZoomFactor);
		int nZoomedHeight = (int)(nHeight * dZoomFactor);
		int nZoomedLeft = (rctDraw.Width() - nZoomedWidth) / 2;
		int nZoomedTop = (rctDraw.Height() - nZoomedHeight) / 2;
		bSuccess = pDC->StretchBlt(nZoomedLeft, nZoomedTop, nZoomedWidth, nZoomedHeight, &memDC, 0, 0, nWidth, nHeight, SRCCOPY);
	}

	// Tidy up resources
	memDC.SelectObject(pOldBitmap);
	memBitmap.DeleteObject();
	memDC.DeleteDC();

	return bSuccess;
}
// End of function 'DrawPreview'


// Function:	GetInvalidFormatText()
// Overview:	Overrideable function to retrieve the text to display
//				when the file format is invalid.
CString CImageFilePreview::GetInvalidFormatText() const
{
	CString strError;
	strError.LoadString(IDS_INVALID_IMAGE_FORMAT);

	return strError;
}
// End of function 'GetInvalidFormatText'




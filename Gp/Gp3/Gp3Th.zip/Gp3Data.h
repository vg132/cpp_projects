// Gp3Data.h: interface for the Gp3Data class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GP3DATA_H__D65D3E81_7F85_11D4_8FC7_0008C7636E27__INCLUDED_)
#define AFX_GP3DATA_H__D65D3E81_7F85_11D4_8FC7_0008C7636E27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Gp3Data  
{
public:
	CString GetRaceTime(int track);
	void SetRaceTime(int track, CString time);
	CString GetQualTime(int track);
	void SetQualTime(int track, CString time);
	CString GetRaceDate(int track);
	void SetRaceDate(int track, CString days);
	CString GetQualDate(int track);
	void SetQualDate(int track, CString days);
	CString GetRaceTeam(int track);
	void SetRaceTeam(int track, CString team);
	CString GetQualTeam(int track);
	void SetQualTeam(int track, CString team);
	CString GetRaceDriver(int track);
	void SetRaceDriver(int track, CString name);
	CString GetQualDriver(int track);
	void SetQualDriver(int track,CString name);
	CString GetPoint(int pos);
	void SetPoint(int pos,CString points);
	CString GetWare(int track);
	void SetWare(int track,CString ware);
	CString GetLength(int track);
	void SetLength(int track,CString length);
	CString GetLaps(int track);
	void SetLaps(int track,CString laps);
	bool SaveData(CString file);
	bool LoadData(CString file);
	Gp3Data();
	virtual ~Gp3Data();
private:
	byte m_Laps[16];
	short m_Length[16][2];
	byte m_Points[26];
	short m_Ware[16];
	long m_Time[32];
	short m_Date[32];
	CString m_Driver[32];
	CString m_Team[32];
};

#endif // !defined(AFX_GP3DATA_H__D65D3E81_7F85_11D4_8FC7_0008C7636E27__INCLUDED_)

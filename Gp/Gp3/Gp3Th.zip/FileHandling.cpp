// FileHandling.cpp: implementation of the CFileHandling class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Gp3Th.h"
#include "FileHandling.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFileHandling::CFileHandling()
{

}

CFileHandling::~CFileHandling()
{

}

bool CFileHandling::Save(CString file, int item)
{
char ch[80];
CString szItem="Track ";
	itoa(item,ch,10);
	szItem+=ch;

	WritePrivateProfileString(szItem,"FileName",td.filename, file);
	WritePrivateProfileString(szItem,"Name",td.trackname,file);
	WritePrivateProfileString(szItem,"Country",td.country,file);
	WritePrivateProfileString(szItem,"Adjective",td.adjective,file);
	WritePrivateProfileString(szItem,"Laps",td.laps,file);
	WritePrivateProfileString(szItem,"Length",td.len,file);
	WritePrivateProfileString(szItem,"TyreWare",td.ware,file);
	WritePrivateProfileString(szItem,"QualName",td.qualdriver,file);
	WritePrivateProfileString(szItem,"QualTeam",td.qualteam ,file);
	WritePrivateProfileString(szItem,"QualDate",td.qualdate,file);
	WritePrivateProfileString(szItem,"QualTime",td.qualtime,file);
	WritePrivateProfileString(szItem,"RaceName",td.racedriver ,file);
	WritePrivateProfileString(szItem,"RaceTeam",td.raceteam ,file);
	WritePrivateProfileString(szItem,"RaceDate",td.racedate ,file);
	WritePrivateProfileString(szItem,"RaceTime",td.racetime,file);
	return(true);
}

bool CFileHandling::Load(CString file, int item)
{
char buf[260];
CString szItem="Track ";
	itoa(item,buf,10);
	szItem+=buf;

	GetPrivateProfileString (szItem,"FileName","",buf,260,file);
	td.filename=buf;
	GetPrivateProfileString (szItem,"Name","",buf,260,file);
	td.trackname=buf;
	GetPrivateProfileString (szItem,"Country","",buf,260,file);
	td.country=buf;
	GetPrivateProfileString (szItem,"Adjective","",buf,260,file);
	td.adjective=buf;
	GetPrivateProfileString (szItem,"Laps","",buf,260,file);
	td.laps=buf;
	GetPrivateProfileString (szItem,"Length","",buf,260,file);
	td.len=buf;
	GetPrivateProfileString (szItem,"TyreWare","",buf,260,file);
	td.ware=buf;
	GetPrivateProfileString (szItem,"QualName","",buf,260,file);
	td.qualdriver=buf;
	GetPrivateProfileString (szItem,"QualTeam","",buf,260,file);
	td.qualteam=buf;
	GetPrivateProfileString (szItem,"QualDate","",buf,260,file);
	td.qualdate=buf;
	GetPrivateProfileString (szItem,"QualTime","",buf,260,file);
	td.qualtime=buf;
	GetPrivateProfileString (szItem,"RaceName","",buf,260,file);
	td.racedriver =buf;
	GetPrivateProfileString (szItem,"RaceTeam","",buf,260,file);
	td.raceteam =buf;
	GetPrivateProfileString (szItem,"RaceDate","",buf,260,file);
	td.racedate =buf;
	GetPrivateProfileString (szItem,"RaceTime","",buf,260,file);
	td.racetime=buf;

	return(true);
}

CString CFileHandling::GetLen()
{
	return(td.len);
}

void CFileHandling::SetLen(CString len)
{
	td.len=len;
}

CString CFileHandling::GetLaps()
{
	return(td.laps);
}

void CFileHandling::SetLaps(CString laps)
{
	td.laps=laps;
}

CString CFileHandling::GetTyreWare()
{
	return(td.ware);
}

void CFileHandling::SetTyreWare(CString ware)
{
	td.ware =ware;
}

CString CFileHandling::GetName()
{
	return(td.trackname);
}

void CFileHandling::SetName(CString name)
{
	td.trackname=name;
}

CString CFileHandling::GetCountry()
{
	return(td.country);
}

void CFileHandling::SetCountry(CString country)
{
	td.country=country;
}

CString CFileHandling::GetAdjective()
{
	return(td.adjective);
}

void CFileHandling::SetAdjective(CString adjective)
{
	td.adjective=adjective;
}

CString CFileHandling::GetFileName()
{
	return(td.filename);
}

void CFileHandling::SetFileName(CString filename)
{
	td.filename=filename;
}

CString CFileHandling::GetQualDriver()
{
	return(td.qualdriver);
}

void CFileHandling::SetQualDriver(CString driver)
{
	td.qualdriver=driver;
}

CString CFileHandling::GetQualTeam()
{
	return(td.qualteam);
}

void CFileHandling::SetQualTeam(CString team)
{
	td.qualteam=team;
}

CString CFileHandling::GetQualDate()
{
	return(td.qualdate);
}

void CFileHandling::SetQualDate(CString date)
{
	td.qualdate=date;
}

CString CFileHandling::GetQualTime()
{
	return(td.qualtime);
}

void CFileHandling::SetQualTime(CString time)
{
	td.qualtime=time;
}

CString CFileHandling::GetRaceDriver()
{
	return(td.racedriver);
}

void CFileHandling::SetRaceDriver(CString driver)
{
	td.racedriver=driver;
}

CString CFileHandling::GetRaceTeam()
{
	return(td.raceteam);
}

void CFileHandling::SetRaceTeam(CString team)
{
	td.raceteam=team;
}

CString CFileHandling::GetRaceDate()
{
	return(td.racedate);
}

void CFileHandling::SetRaceDate(CString date)
{
	td.racedate=date;
}

CString CFileHandling::GetRaceTime()
{
	return(td.racetime);
}

void CFileHandling::SetRaceTime(CString time)
{
	td.racetime=time;
}

void CFileHandling::NewItem()
{
	td.filename ="";
	td.trackname="";
	td.country="";
	td.adjective="";
	td.laps="";
	td.len="";
	td.ware="";
	td.qualdriver="";
	td.qualteam ="";
	td.qualdate="";
	td.qualtime="";
	td.racedate ="";
	td.raceteam ="";
	td.racedate ="";
	td.racetime="";
	td.points="";
}

void CFileHandling::SetPoints(CString points)
{
	td.points=points;
}

CString CFileHandling::GetPoints(int pos)
{
int p=-1;
int p2=0;
	if(td.points=="")
		return("0");
	for(int i=0;i<pos;i++)
		p=td.points.Find("|",p+1);
	p++;
	p2=td.points.Find("|",p);
	return(td.points.Mid(p,p2-p));
}

bool CFileHandling::LoadMisc(CString file)
{
char buf[260];
CString szItem="Misc";
	GetPrivateProfileString (szItem,"Points","10|6|4|3|2|1|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|",buf,260,file);
	td.points=buf;
	GetPrivateProfileString(szItem,"DriverAids","0|1|0|0|0|0|1|1|0|1|0|0|0|1|1|1|0|1|1|1|0|1|1|1|0|1|1|1|1|1|1|1|1|1|1|1|1|1|1|1|",buf,260,file);
	td.aids=buf;
	GetPrivateProfileString(szItem,"SaveRec","0",buf,260,file);
	td.saverec=buf;
	GetPrivateProfileString(szItem,"QuickLen","5",buf,260,file);
	td.racelen=buf;
	return(true);
}

bool CFileHandling::SaveMisc(CString file)
{
CString szItem="Misc";
	WritePrivateProfileString(szItem,"Points",td.points, file);
	WritePrivateProfileString(szItem,"DriverAids",td.aids,file);
	WritePrivateProfileString(szItem,"SaveRec",td.saverec,file);
	WritePrivateProfileString(szItem,"QuickLen",td.racelen,file);
	return(true);
}

void CFileHandling::SetAids(CString aid)
{
	aid.Replace("0","5");
	aid.Replace("1","0");
	aid.Replace("5","1");
	td.aids=aid;
}

int CFileHandling::GetAids(int aid)
{
int p=-1;
int p2=0;
	if(td.aids=="")
		return(0);
	for(int i=0;i<aid;i++)
		p=td.aids.Find("|",p+1);
	p++;
	p2=td.aids.Find("|",p);
	return(atoi(td.aids.Mid(p,p2-p)));
}

void CFileHandling::SetQuickRaceLen(int len)
{
char buf[260];
	itoa(len,buf,10);
	td.racelen=buf;

}

int CFileHandling::GetQuickRaceLen()
{
	return(atoi(td.racelen));
}

void CFileHandling::SetSaveRec(bool saverec)
{
	if(saverec==true)
		td.saverec="1";
	else
		td.saverec="0";
}

bool CFileHandling::GetSaveRec()
{
	return(atoi(td.saverec));
}

// GP2BitmapPreview.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "GP2BitmapPreview.h"

#include "GP2Bitmap.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGP2BitmapPreview construction

IMPLEMENT_DYNAMIC(CGP2BitmapPreview, CImageFilePreview)

// Constructor
CGP2BitmapPreview::CGP2BitmapPreview()
{
	// No file loaded yet
	m_pBitmap = NULL;
}

// Cloning function
CFilePreview* CGP2BitmapPreview::CreateNewPreview() const
{
	return new CGP2BitmapPreview;
}

// Destructor
CGP2BitmapPreview::~CGP2BitmapPreview()
{
	// Get rid of our bitmap (if it had been loaded)
	UnloadFile();
}


/////////////////////////////////////////////////////////////////////////////
// CGP2BitmapPreview properties

// Information retrieval
UINT CGP2BitmapPreview::GetImageWidth() const
{
	// Make sure we've got a bitmap loaded first
	if (NULL == m_pBitmap)
		return 0;

	return m_pBitmap->GetWidth();
}

UINT CGP2BitmapPreview::GetImageHeight() const
{
	// Make sure we've got a bitmap loaded first
	if (NULL == m_pBitmap)
		return 0;

	return m_pBitmap->GetHeight();
}

void CGP2BitmapPreview::GetSupportedFileTypes (CStringList& lstFileTypes) const
{
	// Just make sure the list's empty first
	lstFileTypes.RemoveAll();

	// Then add our extensions
	lstFileTypes.AddTail(".BMP");
}


/////////////////////////////////////////////////////////////////////////////
// CGP2BitmapPreview drawing

// Draw the image at 1:1 zoom in the given DC (and at its origin)
BOOL CGP2BitmapPreview::DrawImageOneToOne(CDC* pDC) const
{
	// Make sure the file is loaded ok
	if (NULL == m_pBitmap)
		return FALSE;

	// We'll need to bitblt the bitmap into the given DC, creating
	// a CBitmap first
	CBitmap bmpTexture;
	m_pBitmap->CreateDIB(bmpTexture);

	// Now use BitBlt between DCs to draw the texture into the DC
	// we've been given
	CDC memDC;
	memDC.CreateCompatibleDC(pDC);
	CBitmap* pOldBitmap = memDC.SelectObject(&bmpTexture);
	pDC->BitBlt(0, 0, GetImageWidth(), GetImageHeight(), &memDC, 0, 0, SRCCOPY);

	// Tidy up
	memDC.SelectObject(pOldBitmap);
	bmpTexture.DeleteObject();
	memDC.DeleteDC();

	return TRUE;
}


/////////////////////////////////////////////////////////////////////////////
// CGP2BitmapPreview file loading/unloading

// Function:	UnloadFile()
// Overview:	Clear out the current file's data.
void CGP2BitmapPreview::UnloadFile()
{
	// Call the base class to clear out any other members
	CImageFilePreview::UnloadFile();

	// Get rid of our bitmap (if it had been loaded)
	if (NULL != m_pBitmap)
	{
		delete m_pBitmap;
		m_pBitmap = NULL;
	}
}
// End of function 'UnloadFile'


// Function:	LoadFile(strFilename)
// Overview:	Load the given file.  Return TRUE upon success, or
//				FALSE otherwise.
BOOL CGP2BitmapPreview::LoadFile(const CString& strFilename)
{
	// Just load into our current bitmap (or create a new
	// one if it doesn't exist yet)
	if (NULL == m_pBitmap)
		m_pBitmap = new CGP2Bitmap;
	if (NULL == m_pBitmap)
		return FALSE;

	// Now load the new one
	return m_pBitmap->LoadFile(strFilename);
}
// End of function 'LoadFile'

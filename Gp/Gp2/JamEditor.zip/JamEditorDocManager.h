// JamEditorDocManager.h - header file for the CJamEditorDocManager
//						   class

#ifndef __JAM_EDITOR_DOC_MGR_H__
#define __JAM_EDITOR_DOC_MGR_H__

///////////////////////////////////////////////////////////////
// Class:	CJamEditorDocManager
// Base:	CDocManager
// Created:	19Jan99 by Mal Ross
// Overview:
//    The CJamEditorDocManager class will allow me to override
//  the behaviour of the standard CDocManager that decides
//  which filters are made available to the user when loading
//  and saving files.  The Jam Editor is a bit unusual in this
//  respect as it uses the same document and view type for two
//  different types of file - encrypted JAMs (i.e. normal ones)
//  and decrypted JAMs (given the .JAD extension).
//

class CJamEditorDocManager : public CDocManager
{
// Construction/destruction
public:
	CJamEditorDocManager ();
	virtual ~CJamEditorDocManager ();

	DECLARE_DYNAMIC(CJamEditorDocManager)

// Overrides
public:
	// Overridden helper for standard commdlg dialogs
	virtual BOOL DoPromptFileName(CString& fileName, UINT nIDSTitle,
			DWORD lFlags, BOOL bOpenFileDialog, CDocTemplate* pTemplate);

	// Overridden to allow multiple file selections
	virtual void OnFileOpen();

// Implementation
private:
	// Out overridden version of DoPromptFileName will fill this
	// member with the selected filenames
	CStringList m_lstOpenFilenames;
};



#endif	// ~__JAM_EDITOR_DOC_MGR_H__


// Jam Texture low-detail colours

// The pair of colours used to show the texture in low detail
// mode i.e. when the texture has been turned off in the Graphics
// Detail Settings.

// this object will merely front a list in the
// tree - the contents of the list will be set by the jam texture


#ifndef JAM_TEXTURE_LOW_DETAIL_COLORS_H
#define JAM_TEXTURE_LOW_DETAIL_COLORS_H

#include "EditableTypedPtrList.h"
#include "TreeIconDefs.h"
#include "Hints.h"

class CJamTextureLowDetailColors : public CEditableTypedPtrList
{
public:
	// constructions
	CJamTextureLowDetailColors(CEditableObject* pParent) : CEditableTypedPtrList(pParent) {};

	// necessary overrides
	virtual UINT	GetIconID() { return JTI_TEXTURE_PALETTE; }			// return the ID for the icon in the tree for this item
	virtual CString GetFullDescription() { return "Untextured colour"; }	// return name and value

	// updates
	virtual void DataHasChanged(CView* pView, LPARAM /*lHint*/, CObject* pHint) { CEditableTypedPtrList::DataHasChanged(pView, HINT_CHANGED_LOW_DETAIL_COLOUR, pHint); }

	// list functions.
	using CEditableTypedPtrList::AddTail;
	POSITION	AddTail(CEditableNumber<BYTE>* pNumber) { return CEditableTypedPtrList::AddTail( (CEditableObject*)pNumber ); }
};


#endif	// ~JAM_TEXTURE_LOW_DETAIL_COLORS_H
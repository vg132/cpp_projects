// JamPixelInfoBar.cpp : implementation file
//

#include "stdafx.h"

#include "JamPixelInfoBar.h"
#include "JamPixelInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJamPixelInfoBar

CJamPixelInfoBar::CJamPixelInfoBar()
{
}

CJamPixelInfoBar::~CJamPixelInfoBar()
{
}


BEGIN_MESSAGE_MAP(CJamPixelInfoBar, CStatusBar)
	//{{AFX_MSG_MAP(CJamPixelInfoBar)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJamPixelInfoBar message handlers

// Show the information of the current pixel under the cursor
BOOL CJamPixelInfoBar::ShowPixelInfo(CJamPixelInfo* pPixelInfo)
{
	// If the caller is simply resetting the status bar,
	// get rid of our pixel information
	if (NULL == pPixelInfo)
	{
		// Discard the current pixel information, if there is any
		if (NULL != m_pPixelInfo)
		{
			delete m_pPixelInfo;
			m_pPixelInfo = NULL;
		}

		return TRUE;
	}

	// Copy the pixel information
	if (NULL == m_pPixelInfo)
		m_pPixelInfo = new CJamPixelInfo(*pPixelInfo);
	else
	{
		// If the information is the same as in the current
		// pixel info we're showing, don't do anything more
		if (*m_pPixelInfo == *pPixelInfo)
			return TRUE;

		// Otherwise, just copy it and carry on with the updates
		*m_pPixelInfo = *pPixelInfo;
	}

	// Check to see whether we were successful
	ASSERT(NULL != m_pPixelInfo);
	if (NULL == m_pPixelInfo)
		return FALSE;

	// TODO: Update the display...
	

	return TRUE;
}

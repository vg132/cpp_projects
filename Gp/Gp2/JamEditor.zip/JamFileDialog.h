// JamFileDialog.h : header file
//

#ifndef _JAM_PREVIEW_FILE_DIALOG_H_
#define	_JAM_PREVIEW_FILE_DIALOG_H_

#include "PreviewFileDialog.h"
class CJam;

/////////////////////////////////////////////////////////////////////////////
// CJamFileDialog dialog

class CJamFileDialog : public CPreviewFileDialog
{
	DECLARE_DYNAMIC(CJamFileDialog)

public:
	CJamFileDialog(BOOL bOpenFileDialog, // TRUE for FileOpen, FALSE for FileSaveAs
		LPCTSTR lpszDefExt = NULL,
		LPCTSTR lpszFileName = NULL,
		DWORD dwFlags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		LPCTSTR lpszFilter = NULL,
		CWnd* pParentWnd = NULL);

// Dialog Data
	//{{AFX_DATA(CJamFileDialog)
	UINT m_nNumTextures;
	CString m_strTextureIDs;
	CString m_strCanvasSize;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJamFileDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

	// Specify the dialog template to use for the preview area
	virtual UINT GetPreviewTemplateID () const;

// Implementation
protected:
	// Show a preview of the given file in the preview static.
	// Overridden to put the extra info in the other statics.
	virtual BOOL SetPreviewFile(const CString& strFilename);
	void UpdateJamInfo(const CJam* pJam);

protected:
	//{{AFX_MSG(CJamFileDialog)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif	// ~_JAM_PREVIEW_FILE_DIALOG_H_
// JamPixelInfoBar.h : header file
//

#ifndef __JAM_PIXEL_INFO_BAR_H__
#define __JAM_PIXEL_INFO_BAR_H__

class CJamPixelInfo;

/////////////////////////////////////////////////////////////////////////////
// CJamPixelInfoBar window

class CJamPixelInfoBar : public CStatusBar
{
// Construction
public:
	CJamPixelInfoBar();

// Attributes
protected:
	CJamPixelInfo* m_pPixelInfo;

// Operations
public:
	// Show the information of the current pixel under the cursor
	BOOL ShowPixelInfo(CJamPixelInfo* pPixelInfo);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJamPixelInfoBar)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CJamPixelInfoBar();

	// Generated message map functions
protected:
	//{{AFX_MSG(CJamPixelInfoBar)
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif	// ~__JAM_PIXEL_INFO_BAR_H__


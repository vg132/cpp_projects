// TintedFilter.h - header file for the CTintedFilter class
//

#ifndef __TINTED_FILTER_H__
#define __TINTED_FILTER_H__

#include "LocalFilter.h"
#include "Color.h"

///////////////////////////////////////////////////////////////////
// Class:	CTintedFilter
// Base:	CLocalFilter (abstract)
// Created:	28 April 99 by Mal Ross
// Overview:
//    This filter produces 4 decoded textures whose colours
//  gradually fade to a particular colour in the GP2 palette.
//  Things such as fog filters should be produced from this,
//  with the colours fading towards a dirty white.
//

class CTintedFilter : public CLocalFilter
{
// Construction and destruction
public:
	CTintedFilter(const UINT& nFilterID, const UINT& nStringID);
	virtual ~CTintedFilter();

// Attributes
protected:
	// How much closer should each subsequent pixel be in colour
	// to the final pixel colour?  The lower this value, the
	// sooner the pixels change colour and the closer to the
	// final colour the 4th palette will be.
	int m_nTintFactor;  // 0 < m_nTintFactor < 100

	// The colour towards which pixel values will tend
	CColor m_TintColor;

// Operations
public:
	// Get/set the tint factor
	int GetTintFactor () const { return m_nTintFactor; }
	BOOL SetTintFactor (const int nTintFactor);

	// Get/set the tint
	COLORREF GetTintColor () const { return m_TintColor; }
	void SetTintColor (const COLORREF color) { m_TintColor = color; }

// Implementation
protected:
	// Shift the given colour towards the tint colour
	virtual void FilterColor(CColor& color);
};

/////////////////////////////////////////////////////////////////////

#endif	// ~__TINTED_FILTER_H__

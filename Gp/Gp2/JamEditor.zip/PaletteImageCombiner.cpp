// PaletteImageCombiner.cpp - implementation of the CPaletteImageCombiner class
//

#include "stdafx.h"

#include "PaletteImageCombiner.h"

#include "PaletteImageSource.h"
#include "LocalPaletteArray.h"
#include "PixelProfileList.h"
#include "PixelProfile.h"
#include "JamConstants.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CPaletteImageCombiner

// Function:	CombineBitmaps(bitmapSource, pbTexturePixels, localPalettes)
// Overview:	Create the palettes and the raw texture pixels from
//				the bitmaps produced by the given image source.  The
//				final parameter says whether we should just make the
//				palette size zero if all pixels are identical in each
//				of the four bitmaps.
//				Return TRUE upon success, or FALSE otherwise.
BOOL CPaletteImageCombiner::CombineBitmaps(CPaletteImageSource& bitmapSource,
										   BYTE*& pbTexturePixels,
										   CLocalPaletteArray& localPalettes,
										   const BOOL bEmptyPalettesIfPoss)
{
	// Make sure we're not going to overwrite existing pixels
	ASSERT(NULL == pbTexturePixels);
	if (NULL != pbTexturePixels)
		return FALSE;

	// Get the bitmaps we're going to merge from our bitmap source
	CPixelBufferArray arrBitmaps;
	arrBitmaps.SetSize(NUM_LOCAL_PALETTES_PER_TEXTURE);
	for (int nBmpNum = 0; nBmpNum < NUM_LOCAL_PALETTES_PER_TEXTURE; nBmpNum++)
		arrBitmaps[nBmpNum] = NULL;
	CSize sizImage(0,0);
	if (!bitmapSource.GetBitmaps(arrBitmaps, sizImage))
		return FALSE;

	// Make a pixel array of integers rather than bytes.  This
	// allow us to initially represent each pixel transition
	// correctly, rather than being limited to 256 tranistions.
	// Later, we will make sure the number of transitions is
	// below 256 by using clustering.  More on that later...
	UINT nImageSize = sizImage.cx * sizImage.cy;
	int* pIdealPixels = new int[nImageSize];
	ASSERT(NULL != pIdealPixels);
	if (NULL == pIdealPixels)
		return FALSE;

	// Loop through the pixels in the filtered bitmaps, storing
	// the unique patterns (profiles) in a list
	CPixelProfileList lstProfiles;
	for (UINT nPixelNum = 0; nPixelNum < nImageSize; nPixelNum++)
	{
		// Create the profile for this next pixel
		CPixelProfile profile(NUM_LOCAL_PALETTES_PER_TEXTURE);
		for (int nPalNum = 0; nPalNum < NUM_LOCAL_PALETTES_PER_TEXTURE; nPalNum++)
			profile.SetPalettePixel(nPalNum, arrBitmaps[nPalNum][nPixelNum]);

		// Get the index in the list for this combination of colours.
		// Note that the profile list will add this profile if it is
		// not already in the list
		pIdealPixels[nPixelNum] = lstProfiles.GetProfileIndex(profile);
	}

	// Now cluster the profiles if there are more than 256 of them.
	// Note: the 256 is dictated by the number of different local
	// palette indexes that can be represented by a single pixel.  As
	// each pixel is a BYTE, there can be only 256 different palette
	// entries at most.
	if (!lstProfiles.ClusterProfiles(256))
	{
		delete[] pIdealPixels;
		return FALSE;
	}

	// Now allocate the memory for the actual raw texture pixels
	pbTexturePixels = new BYTE[nImageSize];
	ASSERT(NULL != pbTexturePixels);
	if (NULL == pbTexturePixels)
	{
		delete[] pIdealPixels;
		return FALSE;
	}

	// Keep the user informed of progress
	CFrameWnd* pFrameWnd = (CFrameWnd *)AfxGetMainWnd();
	if (NULL != pFrameWnd)
		pFrameWnd->SetMessageText("Creating final texture pixels and palettes...");

	// Convert each of the original pixel indexes into ones suitable
	// for use with the clustered profile list and palette
	for (nPixelNum = 0; nPixelNum < nImageSize; nPixelNum++)
		pbTexturePixels[nPixelNum] = lstProfiles.GetPaletteIndex(pIdealPixels[nPixelNum]);

	// Now we're done, extract the local palettes from the
	// list of profiles
	lstProfiles.GetPalettes(localPalettes, bEmptyPalettesIfPoss);

	// Phew - tell the user it's all over
	if (NULL != pFrameWnd)
		pFrameWnd->SetMessageText("Creating final texture pixels and palettes...done!");

	// I know this is silly and inefficient, but... perhaps all we
	// were interested in were the local palettes.
	if (localPalettes.GetPaletteSize() == 0)
		memcpy(pbTexturePixels, arrBitmaps[0], nImageSize);

	// Tidy up local variables
	for (nBmpNum = 0; nBmpNum < NUM_LOCAL_PALETTES_PER_TEXTURE; nBmpNum++)
	{
		delete[] arrBitmaps[nBmpNum];
		arrBitmaps[nBmpNum] = NULL;
	}
	arrBitmaps.RemoveAll();
	delete[] pIdealPixels;
	pIdealPixels = NULL;

	return TRUE;
}
// End of function 'CombineBitmaps'


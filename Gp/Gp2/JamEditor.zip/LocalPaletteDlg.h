// LocalPaletteDlg.h : header file
//

#ifndef __LOCAL_PALETTE_DLG_H__
#define __LOCAL_PALETTE_DLG_H__

class CJamTexture;

/////////////////////////////////////////////////////////////////////////////
// CLocalPaletteDlg dialog

class CLocalPaletteDlg : public CDialog
{
// Construction
public:
	CLocalPaletteDlg(CWnd* pParent = NULL);   // standard constructor
	~CLocalPaletteDlg();

// Dialog Data
	//{{AFX_DATA(CLocalPaletteDlg)
	enum { IDD = IDD_LOCALPALETTE };
	CSpinButtonCtrl	m_spnPalette4;
	CSpinButtonCtrl	m_spnPalette3;
	CSpinButtonCtrl	m_spnPalette2;
	CSpinButtonCtrl	m_spnPalette1;
	CComboBox	m_cboPaletteIndices;
	int		m_nPaletteIndex;
	UINT	m_nPalette2;
	UINT	m_nPalette1;
	UINT	m_nPalette3;
	UINT	m_nPalette4;
	//}}AFX_DATA

	CJamTexture* m_pTexture;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLocalPaletteDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Our own copy of the palettes so we can safely modify them
	BYTE** m_pbPalettes;

	// Keep a record of the last palette index edited so that
	// the user doesn't have to keep on selecting it when using
	// the dialog in trial-and-error mode.
	static int s_nLastIndexEdited;

	// Refresh the edit controls when a different palette
	// index is selected
	void UpdatePaletteValues();

	// Generated message map functions
	//{{AFX_MSG(CLocalPaletteDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelectPaletteIndex();
	virtual void OnOK();
	afx_msg void OnConfirmPaletteValue();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif	// ~__LOCAL_PALETTE_DLG_H__

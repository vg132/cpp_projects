// PixelProfileCluster.h - header file for the CPixelProfileCluster class
//

#ifndef __PIXEL_PROFILE_CLUSTER_H__
#define __PIXEL_PROFILE_CLUSTER_H__

#include "GridTemplate.h"

#include "PixelProfile.h"

///////////////////////////////////////////////////////////////////
// Class:	CPixelProfileCluster
// Base:	[none]
// Created:	19Apr99 by Mal Ross
// Overview:
//    This class represents a single cluster of pixel profiles,
//  from which a single profile will be used as the representative
//  profile to go into the local palettes of a jam texture.
//

class CPixelProfileCluster
{
// Construction and destruction
public:
	CPixelProfileCluster(CPixelProfile* pFirstProfile);
	CPixelProfileCluster(const CPixelProfileCluster& firstCluster, const CPixelProfileCluster& secondCluster);
	~CPixelProfileCluster();

	friend class CPixelProfileClusterer;

// Attributes
protected:
	// The list of pixel profiles comprising this cluster
	CTypedProfileList m_lstProfiles;

	// The degree of closeness of this cluster.  Or rather,
	// the lowest average match factor for a profile in this
	// cluster.
	double** m_Matrix;
	double m_dClusterFactor;
	POSITION m_posMasterProfile;

// Operations
public:
	// Get the degree of closeness in this cluster
	double GetClusterFactor() const { return m_dClusterFactor; }

	// Actually store the information about this cluster in
	// the indexes of each of the profiles
	BOOL AssignClusterInfoToProfiles(const BYTE nClusterIndex);

// Implementation
protected:
	// Initialise the match matrix, but don't calculate any
	// actual match factors
	void InitClusterMatrix();

	// Calculate the match factors between all profiles
	// in this cluster
	void CalcAllClusterFactors();

	// From the current match matrix, calculate which of the
	// profiles is the master profile and record its match factor.
	void UpdateMasterProfile();
};

///////////////////////////////////////////////////////////////////

#endif	// ~__PIXEL_PROFILE_CLUSTER_H__


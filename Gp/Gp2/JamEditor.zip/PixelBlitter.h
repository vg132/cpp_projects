// PixelBlitter.h - header file for the CPixelBlitter class, used for
//					copying pixels between different areas of byte buffers

#ifndef __PIXEL_BLITTER_H__
#define __PIXEL_BLITTER_H__

////////////////////////////////////////////////////////////////
// Class:	CPixelBlitter
// Base:	[none]
// Created:	11Feb99 by Mal Ross
// Overview:
//    This class is to be used as a simple utility class to simplify
//  the copying of an area of pixels in one buffer to a different
//  location in another buffer.
//

class CPixelBlitter
{
// Construction/destruction
public:
	CPixelBlitter();
	virtual ~CPixelBlitter();

// Operations
public:
	// This function is what this class is all about
	// It copies pixels from one buffer to another.
	BOOL CopyPixels(BYTE* pbSrc, const CSize sizSrcBmp, const CRect rctSrc,
					BYTE* pbDest, const CSize sizDestBmp, const CPoint ptDest) const;

	// If CopyPixels is the equiavalent of BitBlt, this
	// is the equiavalent of StretchBlt
	BOOL StretchPixels(BYTE* pbSrc, const CSize& sizSrcBmp, const CRect& rctSrc,
					   BYTE* pbDest, const CSize& sizDestBmp, const CRect& rctDest) const;

// Implementation
protected:
	// Validation of the copy areas to make sure that we
	// don't try to copy outside one of the pixel buffers
	BOOL AreCopyCoordsValid(const CSize& sizSrcBmp, const CRect& rctSrc,
							const CSize& sizDestBmp, const CRect& rctDest) const;
};

////////////////////////////////////////////////////////////////

#endif	// ~__PIXEL_BLITTER_H__

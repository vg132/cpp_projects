// FileHandling.h: interface for the CFileHandling class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILEHANDLING_H__65F70700_7E92_11D4_8FC7_0008C7636E27__INCLUDED_)
#define AFX_FILEHANDLING_H__65F70700_7E92_11D4_8FC7_0008C7636E27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFileHandling  
{
public:
	bool GetSaveRec();
	void SetSaveRec(bool saverec);
	int GetQuickRaceLen();
	void SetQuickRaceLen(int len);
	int GetAids(int aid);
	void SetAids(CString aid);
	bool SaveMisc(CString file);
	bool LoadMisc(CString file);
	CString GetPoints(int pos);
	void SetPoints(CString points);
	void NewItem();
	void SetRaceTime(CString time);
	CString GetRaceTime();
	void SetRaceDate(CString date);
	CString GetRaceDate();
	void SetRaceTeam(CString team);
	CString GetRaceTeam();
	void SetRaceDriver(CString driver);
	CString GetRaceDriver();

	void SetQualTime(CString time);
	CString GetQualTime();
	void SetQualDate(CString date);
	CString GetQualDate();
	void SetQualTeam(CString team);
	CString GetQualTeam();
	void SetQualDriver(CString driver);
	CString GetQualDriver();
	void SetFileName(CString filename);
	CString GetFileName();
	void SetAdjective(CString adjective);
	CString GetAdjective();
	void SetCountry(CString country);
	CString GetCountry();
	void SetName(CString name);
	CString GetName();
	void SetTyreWare(CString ware);
	CString GetTyreWare();
	void SetLaps(CString laps);
	CString GetLaps();
	void SetLen(CString len);
	CString GetLen();
	bool Load(CString file, int item);
	bool Save(CString file, int item);
	CFileHandling();
	virtual ~CFileHandling();
private:
	struct TrackData
	{
		CString laps;
		CString len;
		CString ware;
		CString filename;
		CString trackname;
		CString country;
		CString adjective;
		CString qualdriver;
		CString qualteam;
		CString qualdate;
		CString qualtime;
		CString racedriver;
		CString raceteam;
		CString racedate;
		CString racetime;
		CString points;
		CString aids;
		CString saverec;
		CString racelen;
	} td;	
};

#endif // !defined(AFX_FILEHANDLING_H__65F70700_7E92_11D4_8FC7_0008C7636E27__INCLUDED_)

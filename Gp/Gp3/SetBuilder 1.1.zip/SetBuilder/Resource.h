//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SetBuilder.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_SETBUILDER_FORM             101
#define IDR_MAINFRAME                   128
#define IDR_SETBUITYPE                  129
#define IDC_AUTHOR                      1000
#define IDC_TRACK_LIST                  1000
#define IDC_INFO                        1001
#define IDC_DESC                        1002
#define IDC_EVENT                       1003
#define IDC_TYREWARE                    1004
#define IDC_EDIT_NAME                   1100
#define IDC_EDIT_COUNTRY                1101
#define IDC_EDIT_LAPS                   1102
#define IDC_EDIT_LENGTH                 1103
#define IDC_EDIT_LAPRECORDQUAL          1104
#define IDC_EDIT_LAPRECORDRACE          1105
#define IDC_EDIT_SLOT                   1107
#define IDC_EDIT_TYREWARE               1108
#define IDC_EDIT_EVENT                  1109
#define IDC_EDIT_AUTHOR                 1110
#define IDC_EDIT_DESC                   1111
#define IDC_FRAME                       1112
#define ID_HELP_VGSOFTWAREONLINE        32772
#define IDC_NAME                        65535
#define IDC_COUNTRY                     65535
#define IDC_LAPS                        65535
#define IDC_LENGTH                      65535
#define IDC_LAPRECORDQUAL               65535
#define IDC_LAPRECORDRACE               65535
#define IDC_YEAR                        65535
#define IDC_SLOT                        65535

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

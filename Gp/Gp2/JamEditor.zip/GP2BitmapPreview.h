// GP2BitmapPreview.h - header file for the CGP2BitmapPreview class
//

#ifndef __GP2_BITMAP_PREVIEW_H__
#define __GP2_BITMAP_PREVIEW_H__

#include "ImageFilePreview.h"

class CGP2Bitmap;

/////////////////////////////////////////////////////////////////
// Class:	CGP2BitmapPreview
// Base:	CImageFilePreview (abstract)
// Created:	28 March 1999 by Mal Ross
// Overview:
//    A class used to display a preview of a GP2-compatible
//  bitmap in a given DC.  This is intended for use in the Jam
//  Editor's Import Canvas and Import Texture dialogs.
//

class CGP2BitmapPreview : public CImageFilePreview
{
	DECLARE_DYNAMIC(CGP2BitmapPreview)

// Construction/destruction
public:
	CGP2BitmapPreview();
	virtual ~CGP2BitmapPreview();

	// Cloning function
	virtual CFilePreview* CreateNewPreview() const;

// Attributes
protected:
	// The bitmap we're previewing
	CGP2Bitmap* m_pBitmap;

// Operations
public:
	// Information retrieval
	virtual UINT GetImageWidth() const;
	virtual UINT GetImageHeight() const;
	virtual void GetSupportedFileTypes (CStringList& lstFileTypes) const;

// Implementation
protected:
	// Draw the image at 1:1 zoom in the given DC (and at its origin)
	virtual BOOL DrawImageOneToOne(CDC* pDC) const;

	// Loading the file.  Derived classes must override this as
	// they're the only ones who know the format of the file.
	virtual BOOL LoadFile (const CString& strFilename);
	virtual void UnloadFile ();
};

/////////////////////////////////////////////////////////////////

#endif	// ~__GP2_BITMAP_PREVIEW_H__


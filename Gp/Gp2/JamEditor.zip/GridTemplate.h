// Grid.h - header file for the CGrid class
//

#ifndef __GRID_H__
#define __GRID_H__

///////////////////////////////////////////////////////////////////
// Class:	CGrid
// Base:	CObject
// Created:	01May99 by Mal Ross
// Overview:
//    This class represents...
//

template <class TYPE, class ARG_TYPE>
class CGrid : public CObject
{
// Construction and destruction
public:
	CGrid();
	virtual ~CGrid();

// Attributes
protected:
	// A local type definition to define a row of the grid
	typedef CArray<TYPE, ARG_TYPE> CGridRow;

	// The rows of data in the grid
	CTypedPtrArray<CPtrArray, CGridRow*> m_RowData;

	// Number of rows and columns
	int m_nRows;
	int m_nCols;

// Operations
public:
	// Get/set the number of rows and columns
    int  GetRowCount() const                    { return m_nRows; }
    int  GetColumnCount() const                 { return m_nCols; }
    BOOL SetRowCount(int nRows = 10);
    BOOL SetColumnCount(int nCols = 10);

	// Insert/remove rows or columns
    int  InsertColumn(int nColumn = -1);
    int  InsertRow(int nRow = -1);
    BOOL RemoveColumn(int nColumn);
    BOOL RemoveRow(int nRow);
	BOOL RemoveAll();

	// Accessing elements
	TYPE GetAt(int nRow, int nCol) const;
	void SetAt(int nRow, int nCol, TYPE newElement);
	TYPE& ElementAt(int nRow, int nCol);

// Implementation
protected:
};


template<class TYPE, class ARG_TYPE>
inline CGrid<TYPE, ARG_TYPE>::CGrid()
{
	m_nRows = 0;
	m_nCols = 0;
}

template<class TYPE, class ARG_TYPE>
inline CGrid<TYPE, ARG_TYPE>::~CGrid()
{
	RemoveAll();
}



template<class TYPE, class ARG_TYPE>
BOOL CGrid<TYPE, ARG_TYPE>::SetRowCount(int nRows/*= 10*/)
{
	// Make sure the parameter is valid
    ASSERT(nRows >= 0);
	if (nRows < 0)
		return FALSE;

	// If the number of rows is being set to what is already
	// the number of rows, we've got no work to do.
    if (nRows == GetRowCount())
		return TRUE;

	// Work out how many rows need adding
    int addedRows = nRows - GetRowCount();

    // If we are about to lose rows, then we need to delete
	// each row after the final row we want to keep.
    if (addedRows < 0)
	{
        for (int row = nRows; row < m_nRows; row++)
        {
            // Don't delete the actual objects in the grid, but
            // do delete the row objects
            CGridRow* pRow = m_RowData[row];
            if (NULL != pRow)
			{
				delete pRow;
				pRow = NULL;
			}
        }
    }

    // Change the number of rows.
    m_nRows = nRows;
    m_RowData.SetSize(m_nRows);

    // If we have just added rows, we need to set the number
	// of columns in each of the row objects
    if (addedRows > 0)
	{
        // initialize row data
        int startRow = nRows - addedRows;
        for (int row = startRow; row < GetRowCount(); row++)
		{
            m_RowData[row] = new CGridRow;
            m_RowData[row]->SetSize(m_nCols);
        }
    }

    return TRUE;
}

// Setting columns is a lot simpler than setting rows as we
// don't have to worry about adding or removing row objects,
// or about setting the current number of columns in them.
template<class TYPE, class ARG_TYPE>
BOOL CGrid<TYPE, ARG_TYPE>::SetColumnCount(int nCols)
{
	// Make sure the parameter is valid
    ASSERT(nCols >= 0);
	if (nCols < 0)
		return FALSE;

	// If the number of columns is being set to what is already
	// the number of columns, we've got no work to do.
    if (nCols == GetColumnCount())
		return TRUE;

    int addedCols = nCols - GetColumnCount();

    // Change the number of columns.
    m_nCols = nCols;

    // Change the number of columns in each row.
    for (int i = 0; i < m_nRows; i++)
	{
        if (NULL != m_RowData[i])
			m_RowData[i]->SetSize(nCols);
	}

    return TRUE;
}

// Insert a column at a given position, or add to end of columns (if nColumn = -1)
template<class TYPE, class ARG_TYPE>
int CGrid<TYPE, ARG_TYPE>::InsertColumn(int nColumn /*=-1*/)
{
    // If the insertion is for a specific column, check it's within range.
    if (nColumn >= 0 && nColumn >= GetColumnCount())
        return -1;

    // We need at least one row before we can really insert a
	// new column
//    if (m_nRows < 1)
//        SetRowCount(1);    

    if (nColumn < 0)
    {
        nColumn = m_nCols;
        for (int row = 0; row < m_nRows; row++) 
        {
            CGridRow* pRow = m_RowData[row];
            if (NULL == pRow)
				return -1;
            pRow->SetSize(m_nCols + 1);
        }
    } 
    else
    {
        for (int row = 0; row < m_nRows; row++) 
        {
            CGridRow* pRow = m_RowData[row];
            if (NULL == pRow)
				return -1;
			TYPE newElement;	// uninitialised!!!
            pRow->InsertAt(nColumn, newElement);	// fingers crossed!
        }
    }

    m_nCols++;

    return nColumn;
}

// Insert a row at a given position, or add
// to end of rows (if nRow = -1)
template<class TYPE, class ARG_TYPE>
int CGrid<TYPE, ARG_TYPE>::InsertRow(int nRow /*=-1*/)
{
    // If the insertion is for a specific row, check it's within range.
    if (nRow >= 0 && nRow >= GetRowCount())
        return -1;

    // We need at least one column before we can really insert a
	// new row
//    if (m_nCols < 1) 
//        SetColumnCount(1);    

    // Adding a row to the bottom
    if (nRow < 0) 
    {
        nRow = m_nRows;
        m_RowData.Add(new CGridRow);
    } 
    else 
    {
        m_RowData.InsertAt(nRow, new CGridRow);
    }
    
    m_nRows++;
    m_RowData[nRow]->SetSize(m_nCols);

    return nRow;
}

template<class TYPE, class ARG_TYPE>
BOOL CGrid<TYPE, ARG_TYPE>::RemoveColumn(int nColumn)
{
	// Check to see that the specified column exists
    if (nColumn < 0 || nColumn >= GetColumnCount())
        return FALSE;

	// Go through each of the rows removing the pointer
	// for the given column
    for (int row = 0; row < GetRowCount(); row++) 
    {
        CGridRow* pRow = m_RowData[row];
        if (!pRow)
			return FALSE;

        pRow->RemoveAt(nColumn);
    }

    m_nCols--;

    return TRUE;
}

template<class TYPE, class ARG_TYPE>
BOOL CGrid<TYPE, ARG_TYPE>::RemoveRow(int nRow)
{
	// Check to see that the specified row exists
    if ( nRow < 0 || nRow >= GetRowCount())
        return FALSE;

    CGridRow* pRow = m_RowData[nRow];
    if (!pRow)
		return FALSE;
    delete pRow;
    m_RowData.RemoveAt(nRow);

    m_nRows--;

    return TRUE;
}

// Removes all rows, columns and data from the grid.
template<class TYPE, class ARG_TYPE>
BOOL CGrid<TYPE, ARG_TYPE>::RemoveAll()
{
    // Just delete all of the rows in the grid
    for (int row = 0; row < m_nRows; row++) 
    {
        CGridRow* pRow = m_RowData[row];
        if (!pRow)
			continue;
		pRow->SetSize(0);
        delete pRow;
    }

    // Remove all rows
    m_RowData.RemoveAll();

	m_nRows = 0;
	m_nCols = 0;

    return TRUE;
}


// Accessing elements
template<class TYPE, class ARG_TYPE>
TYPE CGrid<TYPE, ARG_TYPE>::GetAt(int nRow, int nCol) const
{
	if (nRow < 0 || nRow >= GetRowCount())
		return NULL;
	if (nCol < 0 || nCol >= GetColumnCount())
		return NULL;

	return m_RowData[nRow]->GetAt(nCol);
}

template<class TYPE, class ARG_TYPE>
void CGrid<TYPE, ARG_TYPE>::SetAt(int nRow, int nCol, TYPE newElement)
{
	if (nRow < 0 || nRow >= GetRowCount())
		return;
	if (nCol < 0 || nCol >= GetColumnCount())
		return;

	m_RowData[nRow]->SetAt(nCol, newElement);
}

template<class TYPE, class ARG_TYPE>
TYPE& CGrid<TYPE, ARG_TYPE>::ElementAt(int nRow, int nCol)
{
	ASSERT(nRow >= 0 && nRow < GetRowCount());
	ASSERT(nCol >= 0 && nCol < GetColumnCount());

	return m_RowData[nRow]->ElementAt(nCol);
}


#endif	// ~__GRID_H__


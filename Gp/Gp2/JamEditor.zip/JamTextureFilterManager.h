// JamTextureFilterManager.h: header file for the CJamTextureFilterManager class
//

#ifndef _JAM_TEXTURE_FILTER_MGR_H_
#define _JAM_TEXTURE_FILTER_MGR_H_

#include "JamTextureFilter.h"

//////////////////////////////////////////////////////////////////
// Class:	CJamTextureFilterManager
// Base:	[none]
// Created:	16th May 1999 by Mal Ross
// Overview:
//    This class simply acts as a library of import filters.  It
//  is based on the Singleton design pattern.
//

class CJamTextureFilterManager
{
// Construction/destruction
protected:
	CJamTextureFilterManager();
	~CJamTextureFilterManager();

// Attributes
protected:
	// The list of preview types available
	CTypedPtrList<CPtrList, CJamTextureFilter*> m_lstFilters;

	// The only instance of the class that should ever exist.
	static CJamTextureFilterManager* m_pUniqueInstance;

// Operations
public:
	// Singleton-related operations
	static CJamTextureFilterManager* GetManager();
	static void DestroyManager();	// call this from your ExitInstance

	// Add filter types that the application supports:
	BOOL AddFilter(CJamTextureFilter* pFilter);

	// Retrieval of the filters, based on their ID.
	CJamTextureFilter* GetFilter (const UINT nFilterID);

	// Iteration through the filters
	POSITION GetFirstFilterPos() const;
	CJamTextureFilter* GetNextFilter(POSITION& posFilter) const;
};

/////////////////////////////////////////////////////////////////////////////

#endif	// ~_JAM_TEXTURE_FILTER_MGR_H_


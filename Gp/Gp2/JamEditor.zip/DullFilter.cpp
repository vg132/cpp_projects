// DullFilter.cpp - implementation of the CDullFilter class
//

#include "stdafx.h"
#include "resource.h"

#include "DullFilter.h"

#include "Color.h"
#include "JamTextureFilterIDs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CDullFilter

// Constructor
CDullFilter::CDullFilter()
	: CLocalFilter(COLOR_FADE_FILTER, IDS_FILTER_NAME_COLOR_FADE),
	  m_fFadeFactor(0.55f)
{
}

// Destructor
CDullFilter::~CDullFilter()
{
}


// Overridden filtering functions
//

// Function:	FilterColor(color&)
// Overview:	Just reduce the luminance of the given colour by
//				the factor in m_fFadeFactor
void CDullFilter::FilterColor(CColor& color)
{
	// Get, reduce, and set the luminance.
	float fSaturation = color.GetSaturation();
	fSaturation *= m_fFadeFactor;
	color.SetSaturation(fSaturation);
}
// End of function 'FilterColor'

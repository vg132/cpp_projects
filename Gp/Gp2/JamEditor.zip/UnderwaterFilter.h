// UnderwaterFilter.h - header file for the CUnderwaterFilter class
//

#ifndef __UNDERWATER_FILTER_H__
#define __UNDERWATER_FILTER_H__

#include "TintedFilter.h"

///////////////////////////////////////////////////////////////////
// Class:	CUnderwaterFilter
// Base:	CTintedFilter
// Created:	25 May 99 by Mal Ross
// Overview:
//    This filter produces 4 decoded textures whose colours
//  gradually fade to a slightly bluer colour, giving the
//  impression of driving underwater!  Well, ok, maybe not
//  - it was just for a laugh.
//

class CUnderwaterFilter : public CTintedFilter
{
// Construction and destruction
public:
	CUnderwaterFilter();
	virtual ~CUnderwaterFilter();

// Attributes
protected:

// Operations
public:
};

/////////////////////////////////////////////////////////////////////

#endif	// ~__UNDERWATER_FILTER_H__

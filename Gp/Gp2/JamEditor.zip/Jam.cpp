// Jam.cpp - implementation of the CJam class
//

#include "stdafx.h"
#include "resource.h"

#include "Jam.h"

#include "JamTextureAnimation.h"
#include "NullFilter.h"	// for fixing palettes during loading
#include "PixelBlitter.h"
#include "JamEditorDoc.h"
#include "JamIterator.h"

//#include "JamSizeFrontEnd.h"

#include "TexturePalette.h"
#include "GP2Bitmap.h"
#include <math.h>	// needed for 'fabs' function

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CJam

BOOL CJam::s_bFixInvalidPixels = FALSE;

// Construction and destruction
//

// Constructor
CJam::CJam(CJamEditorDoc* pDoc) : m_Textures((CEditableObject*)pDoc)
{
	// No image loaded yet, but we can still have a blank canvas :)
	m_nTotalImageHeight = DEFAULT_JAM_CANVAS_HEIGHT;
	m_pbCanvasPixels = NULL;

	// store pointer to document
	m_pDoc=pDoc;

	// initialise and then set up the texture list front end
	m_pJamSizeObject = NULL;
	if (NULL != m_pDoc)
		m_pJamSizeObject = new CEditableNumber<UINT>(&m_nTotalImageHeight, TRUE, "Canvas height", m_pDoc, 1, MAX_JAM_CANVAS_HEIGHT, JTI_IMAGE_SIZE);
}

// Destructor
CJam::~CJam()
{
	// Delete the list of textures
	while (NULL != m_Textures.GetHeadPosition())
		delete m_Textures.RemoveHead();

	// Delete the canvas, if we have one
	if (NULL != m_pbCanvasPixels)
		delete m_pbCanvasPixels;

	if (m_pJamSizeObject)
		delete m_pJamSizeObject;
}



// Serialization
//

// The JAM file is encrypted in blocks of 32bits (4 bytes).  See the
// comment in the Encryption/decryption section for more information.
#define ENCRYPTION_BLOCK_SIZE	4

// Function:	Serialize(arJam)
// Overview:	Save/load the JAM to or from the given archive,
//				encrypting or decrypting along the way.
void CJam::Serialize(CArchive& arJam)
{
	// To be able to easily encrypt or decrypt the data in the
	// archive, we need to use a CMemFile (it's easy to put data
	// into and take out of).  Therefore, most of our work here
	// will be done with a temporary archive.
	CMemFile memFile(ENCRYPTION_BLOCK_SIZE);

	// Save:
	//   Create archive using a memfile
	//   Serialize data out
	//   Detach byte buffer
	//   Encrypt byte buffer
	//   Write byte buffer to proper archive
	//   Tidy up
	// Load:
	//   Read all data into byte buffer
	//   Decrypt byte buffer
	//   Attach byte buffer to memfile and create archive
	//   Serialize data in
	//   Tidy up

	if (arJam.IsStoring())
	{
		// Create the temporary archive
		CArchive arTemp(&memFile, CArchive::store);

		// Save the jam, not bothering with encryption yet
		SerializeNoEncryption(arTemp);

		// Now we just need to get the data we've saved to the temporary
		// archive, encrypt it, and put it into the proper archive
		arTemp.Close();
		int nFileLength = memFile.GetLength();
		BYTE* pbAllJamData = memFile.Detach();
		EncryptDecrypt(pbAllJamData, nFileLength);
		arJam.Write(pbAllJamData, nFileLength);
		delete[] pbAllJamData;	// this seems suss to me
	}
	else
	{
		// Read the whole of the data from the proper file into
		// a byte buffer
		int nFileLength = arJam.GetFile()->GetLength();
		BYTE* pbAllJamData = new BYTE[nFileLength];
		arJam.Read(pbAllJamData, nFileLength);

		// First we're going to have to decrypt the data.  Only then
		// can we serialize it in properly
		EncryptDecrypt(pbAllJamData, nFileLength);

		// Attach the decrypted data to the memfile and serialize it in
		memFile.Attach(pbAllJamData, nFileLength);
		CArchive arTemp(&memFile, CArchive::load);

		// Now that the decryption's over, we can load the data
		try
		{
			SerializeNoEncryption(arTemp);
		}
		catch (CException* /*pExc*/)
		{
			// Tidy up at this level, then pass the exception up the chain
			arTemp.Close();
			memFile.Detach();
			delete[] pbAllJamData;
			pbAllJamData = NULL;

			throw;
		}

		// Tidy up by releasing the memory of the memfile
		arTemp.Close();
		memFile.Detach();
		delete[] pbAllJamData;
	}
}
// End of function 'Serialize'


// Function:	SerializeNoEncryption(arJam)
// Overview:	Save/load the JAM to or from the given archive,
//				encrypting or decrypting along the way.
void CJam::SerializeNoEncryption(CArchive& arJam)
{
	if (arJam.IsStoring())
	{
		// Save the header first...
		JAM_HEADER header;
		header.m_wNumTextures = (WORD)m_Textures.GetCount();
		header.m_wJamImageHeight = (WORD)m_nTotalImageHeight;
		arJam.Write(&header, sizeof(JAM_HEADER));

		// ...followed by the textures...
		POSITION posTexture = m_Textures.GetHeadPosition();
		CJamTexture* pTexture = NULL;
		while (NULL != posTexture)
			((CJamTexture*)(m_Textures.GetNext(posTexture)))->Serialize(arJam);

		// ...followed by their palettes...
		posTexture = m_Textures.GetHeadPosition();
		while (NULL != posTexture)
			((CJamTexture*)(m_Textures.GetNext(posTexture)))->SerializePalettes(arJam);

		// ...and finally the pixel data.  If we already have a copy
		// of the original canvas pixels, we can just ask the textures
		// to put their latest pixels into that, otherwise we'll need
		// to make a new canvas.
		if (NULL == m_pbCanvasPixels)
		{
			// Create the byte buffer and blank out the pixels with
			// the transparent colour
			m_pbCanvasPixels = new BYTE[JAM_CANVAS_WIDTH * m_nTotalImageHeight];
			if (NULL == m_pbCanvasPixels)
				AfxThrowArchiveException(CArchiveException::generic, NULL);
			memset(m_pbCanvasPixels, GP2_TRANSPARENT_PALETTE_INDEX, 
				JAM_CANVAS_WIDTH * m_nTotalImageHeight);
		}
		GetRawJamPixels(m_pbCanvasPixels);
		arJam.Write(m_pbCanvasPixels, JAM_CANVAS_WIDTH * m_nTotalImageHeight);
	}
	else
	{
		// Start with the jam header
		JAM_HEADER header;
		arJam.Read(&header, sizeof(JAM_HEADER));
		m_nTotalImageHeight = header.m_wJamImageHeight;

		// Make sure there are actually some pixels in this thing!
		ASSERT(m_nTotalImageHeight > 0);
		if (m_nTotalImageHeight <= 0)
			AfxThrowArchiveException(CArchiveException::badIndex,
				arJam.GetFile()->GetFilePath());

		// ...now load the textures...
		for (int nTextureNum = 0; nTextureNum < header.m_wNumTextures; nTextureNum++)
		{
			// Create a new jam entry
			CJamTexture* pTexture = new CJamTexture(&m_Textures);
			if (NULL == pTexture)
				AfxThrowArchiveException(CArchiveException::generic, arJam.GetFile()->GetFilePath());

			// Load it in and add it to the list
			pTexture->Serialize(arJam);
			m_Textures.AddTail(pTexture);
		}

		// ...followed by the textures' palettes...
		POSITION posTexture = m_Textures.GetHeadPosition();
		while (NULL != posTexture)
			((CJamTexture*)(m_Textures.GetNext(posTexture)))->SerializePalettes(arJam);

		// ...and finish by loading the actual pixel data
		ASSERT(NULL == m_pbCanvasPixels);
		m_pbCanvasPixels = new BYTE[JAM_CANVAS_WIDTH * m_nTotalImageHeight];
		if (NULL == m_pbCanvasPixels)
			AfxThrowArchiveException(CArchiveException::generic, NULL);
		arJam.Read(m_pbCanvasPixels, JAM_CANVAS_WIDTH * m_nTotalImageHeight);
		SetRawJamPixels(m_pbCanvasPixels);
	}
}
// End of function 'SerializeNoEncryption'


// Function:	SerializeSelection(ar&)
// Overview:	Save or load the selected texture(s) to or from
//				the given archive.  If loading, do *not* reset
//				the rest of the jam first, as this function is
//				only to be used for cut/copy/paste.
void CJam::SerializeSelection(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// Store the current version number
		UINT nVersion = JAM_CLIPBRD_VERSION;
		ar << nVersion;

		// Store the number of textures we're going
		// to be saving
		CJamTexture* pTexture = GetSelectedTexture();
		int nNumSelectedTextures = (NULL == pTexture) ? 0 : 1;
		ar << nNumSelectedTextures;

		// Save the texture
		if (NULL != pTexture)
		{
			pTexture->Serialize(ar);
			pTexture->SerializePalettes(ar);
			pTexture->SerializePixels(ar);
		}
	}
	else
	{
		// Load and check the version number
		UINT nVersion = 0;
		ar >> nVersion;
		if (nVersion == 0 || nVersion > JAM_CLIPBRD_VERSION)
			AfxThrowArchiveException(CArchiveException::badSchema,
				ar.GetFile()->GetFilePath());

		// Load the number of textures in the archive
		int nTextureCount = 0;
		ar >> nTextureCount;

		// Load the textures themselves
		if (nTextureCount > 0)
		{
			// Deselect all existing textures so that we can
			// leave the ones we're loading as the only ones
			// selected.
			CJamTexture* pSelection = GetSelectedTexture();
			if (NULL != pSelection)
				pSelection->m_bSelected = FALSE;

			// Now just load all of the textures in the archive
			for (int nTextureNum = 0; nTextureNum < nTextureCount; nTextureNum++)
			{
				// Create a new texture
				CJamTexture* pTexture = new CJamTexture(&m_Textures);
				if (NULL == pTexture)
				{
					// Tidy up what we've done so far and then throw
					// an exception
					UpdatePalettePositions();
					AfxThrowArchiveException(CArchiveException::generic, ar.GetFile()->GetFilePath());
				}

				// Load it in and add it to the list
				pTexture->Serialize(ar);
				pTexture->SerializePalettes(ar);
				pTexture->SerializePixels(ar);
				pTexture->m_bSelected = TRUE;
				m_Textures.AddTail(pTexture);
			}

			UpdatePalettePositions();
		}
	}
}
// End of function 'SerializeSelection'



// Encryption/decryption
//

// Taken from the JAM File Primer
// The JAM file uses an exclusive OR function to en/decrypt the file. ie. the 
// en/decryption works both ways. 
// The file is encrypted in blocks of 32 bits. 

// 1) en/decrypt the first four bytes of the file using pattern=0xB082F165 
// 2) calculate pattern=pattern*5 
// 3) en/decrypt next four bytes, etc.


// Function:	EncryptDecrypt(pbJamData, nNumBytes)
// Overview:	Encrypt or decrypt the given data using the JAM file
//				en/decryption code.  Because the encryption is based
//				on XOR, the same routine will both encrypt and decrypt
//				the data
void CJam::EncryptDecrypt(BYTE* pbJamData, int nNumBytes)
{
	unsigned long* pBlocks = (unsigned long *)pbJamData;
	unsigned long lPattern = 0xb082f164UL | 1;

	// Decrypt all of the complete blocks of four bytes
	for (int nNumBlocks = nNumBytes / 4; nNumBlocks > 0; pBlocks++, nNumBlocks--)
	{
		*pBlocks ^= lPattern;
		lPattern *= 5;
	}

	// Decrypt any remaining bytes
	if ((nNumBytes & 3) != 0) 
	{
		// Don't look at me - I've just changed the variable
		// names!  I realise this doesn't make sense! - MR
		BYTE* pbRemainder = (BYTE *)pBlocks;
		*pbRemainder ^= lPattern & 0xff;
		++pbRemainder;
		lPattern >>= 8;
	}
}
// End of function 'EncryptDecrypt'



// Drawing functions
//

// Function:	Draw(pDC, nPaletteNum, dZoomFactor)
// Overview:	The main drawing function - keeping it simple.  The
//				textures themselves can draw the texture outline and
//				texture ID label once the bitmap has been scaled.
BOOL CJam::Draw(CDC* pDC, const int& nPaletteNum, const double dZoomFactor)
{
	// We need a valid DC to be able to draw
	ASSERT(NULL != pDC);
	if (NULL == pDC)
		return FALSE;

	// Draw the textures into the DC
	if (!DrawTextures(pDC, nPaletteNum, dZoomFactor))
		return FALSE;

	// Draw the texture outlines into the DC
	if (!DrawOutlines(pDC, dZoomFactor))
		return FALSE;

	return TRUE;
}
// End of function 'Draw'


// Function:	DrawTextures(pDC, nPaletteNum, dZoomFactor)
// Overview:	Draw the overall JAM bitmap into the given DC at the
//				given zoom factor.  Return TRUE if successful, FALSE
//				otherwise.
BOOL CJam::DrawTextures(CDC* pDC, const int& nPaletteNum, const double dZoomFactor)
{
	// We need a valid DC to be able to draw
	ASSERT(NULL != pDC);
	if (NULL == pDC)
		return FALSE;

	// Each texture is drawn at 1:1 in a memory DC, then scaled
	// using StretchBlt into the DC we've been given.
	CDC memDC;
	memDC.CreateCompatibleDC(pDC);

	// We'll need a bitmap for the DC, too!
	int nWidth = JAM_CANVAS_WIDTH;
	int nHeight = m_nTotalImageHeight;
	CBitmap memBitmap;
	memBitmap.CreateCompatibleBitmap(pDC, nWidth, m_nTotalImageHeight);
	CBitmap* pOldBitmap = memDC.SelectObject(&memBitmap);

	// Blank the background for the textures, but remember - we're
	// drawing at 1:1 and we'll stretch it to the correct size
	// later!!
	BOOL bError = FALSE;
	if (!DrawCanvas(&memDC))
		bError = TRUE;

	// Now that the memory DC is ready, draw each texture into
	// it at 1:1
	POSITION posTexture = m_Textures.GetHeadPosition();
	while (NULL != posTexture && !bError)
	{
		// Draw the next texture into the memory DC at 1:1
		CJamTexture* pTexture = m_Textures.GetNext(posTexture);
		ASSERT(NULL != pTexture);
		if (NULL != pTexture)
			bError = !pTexture->DrawTexture(&memDC, nPaletteNum);
	}

	// If any of the drawing failed, tidy up and fail this function
	if (bError)
	{
		// Tidy up resources
		memDC.SelectObject(pOldBitmap);
		memBitmap.DeleteObject();
		memDC.DeleteDC();

		return FALSE;
	}

	// Scale the resulting image, copying it into the DC passed into
	// this function
	BOOL bSuccess = FALSE;
	if (fabs(dZoomFactor - 1.0f) < 0.001f)
	{
		// Simply bitblt into pDC
		bSuccess = pDC->BitBlt(0, 0, nWidth, nHeight, &memDC, 0, 0, SRCCOPY);
	}
	else
	{
		// Zoom the sizes and stretchblt into pDC
		int nZoomedWidth  = (int)(nWidth * dZoomFactor);
		int nZoomedHeight = (int)(nHeight * dZoomFactor);
		bSuccess = pDC->StretchBlt(0, 0, nZoomedWidth, nZoomedHeight, &memDC, 0, 0, nWidth, nHeight, SRCCOPY);
	}

	// Tidy up resources
	memDC.SelectObject(pOldBitmap);
	memBitmap.DeleteObject();
	memDC.DeleteDC();

	return bSuccess;
}
// End of function 'DrawTextures'


// Function:	DrawCanvas(pDC)
// Overview:	Draw the blank background in which the textures lie.
//				Return TRUE if successful, FALSE otherwise.
BOOL CJam::DrawCanvas(CDC* pDC)
{
	// We need a valid DC to be able to draw
	ASSERT(NULL != pDC);
	if (NULL == pDC)
		return FALSE;

	// Work out where to draw the background
	CSize sizCanvas(JAM_CANVAS_WIDTH, m_nTotalImageHeight);
	CRect rctCanvas(CPoint(0,0), sizCanvas);

	// Create the brush and draw the rectangle
	CBrush brCanvas;
	brCanvas.CreateSolidBrush(g_jamPalette.GetTransparentColor());
	pDC->FillRect(rctCanvas, &brCanvas);

	// Tidy up the resources
	brCanvas.DeleteObject();

	// Also, draw the canvas pixels if we have any.
	if (NULL != m_pbCanvasPixels)
	{
		// Create a bitmap and put the canvas pixels into it.  Note
		// that we'll be drawing the canvas pixels in the same way
		// that we would draw a texture with no local palettes.
		CGP2Bitmap gp2BitmapMaker;
		if (!gp2BitmapMaker.CreateFromJamPixels((WORD)JAM_CANVAS_WIDTH, (WORD)m_nTotalImageHeight, m_pbCanvasPixels))
			return FALSE;

		CBitmap bmpTexture;
		gp2BitmapMaker.CreateDIB(bmpTexture);

		// Now use BitBlt between DCs to draw the texture into the DC
		// we've been given
		CDC memDC;
		memDC.CreateCompatibleDC(pDC);
		CBitmap* pOldBitmap = memDC.SelectObject(&bmpTexture);
		pDC->BitBlt(0, 0, JAM_CANVAS_WIDTH, m_nTotalImageHeight, &memDC, 0, 0, SRCCOPY);

		// Tidy up
		memDC.SelectObject(pOldBitmap);
		bmpTexture.DeleteObject();
		memDC.DeleteDC();
	}

	return TRUE;
}
// End of function 'DrawCanvas'


// Function:	DrawOutlines(pDC, dZoomFactor)
// Overview:	Draw each of the textures' outlines at the given zoom factor
//				in the appropriate place in the DC.  Return TRUE if successful,
//				FALSE otherwise.
BOOL CJam::DrawOutlines(CDC* pDC, const double dZoomFactor)
{
	// We need a valid DC to be able to draw
	ASSERT(NULL != pDC);
	if (NULL == pDC)
		return FALSE;

	// Just ask each of the textures in turn to draw itself
	// in the given DC
	POSITION posTexture = m_Textures.GetHeadPosition();
	while (NULL != posTexture)
	{
		// Draw the next texture into the memory DC at 1:1
		CJamTexture* pTexture = m_Textures.GetNext(posTexture);
		ASSERT(NULL != pTexture);
		if (NULL != pTexture)
		{
			// Give up at the first sign of trouble
			if (!pTexture->DrawOutline(pDC, dZoomFactor))
				return FALSE;
		}
	}

	return TRUE;
}
// End of function 'DrawOutlines'



// Hit-testing and iteration code
//

// Function:	HitTest(pixelInfo&)
// Overview:	Fill the given CJamPixelInfo object with information
//				relating to the pixel under the point in the JAM it
//				represents.
BOOL CJam::HitTest(CJamPixelInfo& pixelInfo) const
{
	// Iterate through the textures in this Jam, stopping when we
	// hit a texture or when we've been through all textures,
	// whichever comes first.  Note that we traverse the list
	// backwards, to make sure that the 'hit' reflects what has
	// been drawn.
	BOOL bHit = FALSE;
	POSITION posTexture = m_Textures.GetTailPosition();
	CJamTexture* pTexture = NULL;
	while (NULL != posTexture && !bHit)
	{
		// Get the next texture in the list and ask it whether
		// it has a pixel at the pixelInfo's position
		pTexture = (CJamTexture *)m_Textures.GetPrev(posTexture);
		if (NULL != pTexture)
			bHit = pTexture->HitTest(pixelInfo);
	}

	// Return TRUE/FALSE to indicate whether there was a texture
	// under the position of the pixelInfo's m_ptPixelInJam member
	return bHit;
}
// End of function 'HitTest'


// Function:	GetTexture(nTextureID)
// Overview:	Return a pointer to the texture in this JAM with the
//				given texture ID (or NULL if it's not in this JAM)
CJamTexture* CJam::GetTexture(const UINT& nTextureID) const
{
	// Iterate through the textures in this Jam, stopping when we
	// find the texture we're after (or when we reach the end of
	// the list!).  Assume that this call is happening after a
	// hit-test, so we'll have to go through the list backwards.
	// This is just in case overlapped textures have the same ID.
	BOOL bFound = FALSE;
	POSITION posTexture = m_Textures.GetTailPosition();
	CJamTexture* pTexture = NULL;
	while (NULL != posTexture && !bFound)
	{
		// Get the next texture in the list and ask it whether
		// it has a pixel at the pixelInfo's position
		pTexture = m_Textures.GetPrev(posTexture);
		if (NULL != pTexture)
			bFound = (pTexture->GetTextureID() == nTextureID);
	}

	// If we found the texture, return it, otherwise return NULL
	if (bFound)
		return pTexture;
	else
		return NULL;
}
// End of function 'GetTexture'


// Function:	GetFirstTexturePos()
// Overview:	Get the position of the first texture in this jam's list
POSITION CJam::GetFirstTexturePos() const
{
	return m_Textures.GetHeadPosition();
}
// End of function 'GetFirstTexturePos'


// Function:	GetNextTexture(posTexture&)
CJamTexture* CJam::GetNextTexture(POSITION& posTexture) const
{
	return m_Textures.GetNext(posTexture);
}
// End of function 'GetNextTexture'


// Function:	GetSelectedTexture()
// Overview:	Return a pointer to the JAM's selected texture (or
//				NULL if there isn't one)
CJamTexture* CJam::GetSelectedTexture() const
{
	// Iterate through the textures in this Jam, stopping when we
	// find the texture we're after (or when we reach the end of
	// the list!)
	BOOL bFound = FALSE;
	POSITION posTexture = m_Textures.GetHeadPosition();
	CJamTexture* pTexture = NULL;
	while (NULL != posTexture && !bFound)
	{
		// Get the next texture in the list and ask it whether
		// it has a pixel at the pixelInfo's position
		pTexture = m_Textures.GetNext(posTexture);
		if (NULL != pTexture)
			bFound = pTexture->m_bSelected;
	}

	// If we found the texture, return it, otherwise return NULL
	if (bFound)
		return pTexture;
	else
		return NULL;
}
// End of function 'GetSelectedTexture'


// Function:	AreTexturesOverlapped()
// Overview:	Check to see whether any of the textures in the JAM
//				are overlapping each other.  Return TRUE if they are,
//				or FALSE if not.
BOOL CJam::AreTexturesOverlapped() const
{
	// We're going to have to test each texture against every other
	// texture to see if any two of them are overlapping.  However,
	// we'll save ourselves the bother of doing each pair twice by
	// only checking the textures after the one we're currently
	// looking at.
	BOOL bOverlapped = FALSE;
	POSITION posCurrTexture = m_Textures.GetHeadPosition();
	while (NULL != posCurrTexture && !bOverlapped)
	{
		// Get the next texture in the list
		CJamTexture* pCurrTexture = m_Textures.GetNext(posCurrTexture);
		ASSERT(NULL != pCurrTexture);
		if (NULL == pCurrTexture)
			continue;

		// Get the texture's outline and check against all textures
		// after it in the list
		CRect rctCurrTexture = pCurrTexture->GetRect();
		POSITION posTestTexture = posCurrTexture;
		while (NULL != posTestTexture && !bOverlapped)
		{
			// Get the next texture to test from the list and
			// see whether it overlaps the current texture
			CJamTexture* pTestTexture = m_Textures.GetNext(posTestTexture);
			ASSERT(NULL != pTestTexture);
			if (NULL == pTestTexture)
				continue;

			CRect rctIntersect(0,0,0,0), rctTestTexture(pTestTexture->GetRect());
			if (rctIntersect.IntersectRect(rctTestTexture, rctCurrTexture))
				bOverlapped = TRUE;
		}
	}

	// Return the result of our search
	return bOverlapped;
}
// End of function 'AreTexturesOverlapped'



// Getting/setting the pixels in the textures
//

// Function:	GetRawJamPixels(pbRawJamPixels)
// Overview:	Get the raw pixels from the textures, putting them in the
//				correct place in the array of pixels given, which
//				represents the whole JAM's pixels (JAM_CANVAS_WIDTH by
//				m_nTotalImageHeight).
BOOL CJam::GetRawJamPixels(BYTE* pbRawJamPixels)
{
	// Cycle through all of the textures, asking them to put
	// their pixels into the buffer we've been passed.
	POSITION posTexture = m_Textures.GetHeadPosition();
	BOOL bError = FALSE;
	CJamTexture* pTexture = NULL;
	CSize sizCanvas(JAM_CANVAS_WIDTH, m_nTotalImageHeight);
	while (NULL != posTexture && !bError)
	{
		// Get the next texture and ask for the pixels
		pTexture = (CJamTexture *)m_Textures.GetNext(posTexture);
		if (NULL != pTexture)
			bError = !pTexture->InsertRawPixelsIntoCanvas(pbRawJamPixels, sizCanvas);
		else
			bError = TRUE;
	}

	return !bError;
}
// End of function 'GetRawJamPixels'


// Function:	SetRawJamPixels(pbRawJamPixels)
// Overview:	Give the raw pixels of the JAM file (contained in the
//				pbRawJamPixels parameter) to the textures, allowing
//				them to extract their area's pixels.
BOOL CJam::SetRawJamPixels(BYTE* pbRawJamPixels)
{
	// Cycle through all of the textures, giving them the
	// pixels so they can extract their own.
	POSITION posTexture = m_Textures.GetHeadPosition();
	BOOL bError = FALSE;
	CJamTexture* pTexture = NULL;
	CSize sizCanvas(JAM_CANVAS_WIDTH, m_nTotalImageHeight);
	while (NULL != posTexture && !bError)
	{
		// Get the next texture and give it the pixels
		pTexture = (CJamTexture *)m_Textures.GetNext(posTexture);
		if (NULL != pTexture)
			bError = !pTexture->ExtractRawPixelsFromCanvas(pbRawJamPixels, sizCanvas);
		else
			bError = TRUE;
	}

	return !bError;
}
// End of function 'SetRawJamPixels'


// Function:	FixAnyInvalidTexturePixels()
// Overview:	Fix any textures that contain pixels referencing
//				palette indexes outside that texture's range by
//				applying a null filter (which removes all local
//				palettes).  Return the number of textures whose
//				pixels have been fixed, or -1 if the function
//				fails.
int CJam::FixAnyInvalidTexturePixels()
{
	// If any of the palettes/pixels are not valid, we'll
	// need to make them valid applying a null filter
	CNullFilter filter;
	int nNumFiltered = 0;

	// Cycle through all of the textures, giving them the
	// pixels so they can extract their own.
	POSITION posTexture = m_Textures.GetHeadPosition();
	BOOL bError = FALSE;
	CJamTexture* pTexture = NULL;
	while (NULL != posTexture && !bError)
	{
		// Get the next texture and give it the pixels
		pTexture = (CJamTexture *)m_Textures.GetNext(posTexture);
		if (NULL == pTexture)
			continue;

		// Make sure the raw pixels are fine for the texture's
		// palettes
		if (!pTexture->AreRawPixelsValid())
		{
			pTexture->ApplyFilter(&filter);
			nNumFiltered++;
		}
	}

	if (nNumFiltered > 0)
	{
		// Correct the palette offsets in the textures
		UpdatePalettePositions();
	}

	if (bError)
		return -1;
	else
		return nNumFiltered;
}
// End of function 'FixAnyInvalidTexturePixels'



// Bitmap import / export
//

// Function:	ExportCanvas(strBitmapFile)
// Overview:	Export the whole of the canvas to the given bitmap
//				file.  Return TRUE upon success, FALSE otherwise.
BOOL CJam::ExportCanvas(const CString& strBitmapFile)
{
	// Create the canvas bitmap into which we'll ask each texture
	// to put its pixels
	BYTE* pbBitmapPixels = new BYTE[JAM_CANVAS_WIDTH * m_nTotalImageHeight];
	if (NULL == pbBitmapPixels)
	{
		AfxMessageBox(IDS_ERR_OUTOFMEMORY_FOR_SAVING_BITMAP);
		return FALSE;
	}
	memset(pbBitmapPixels, GP2_TRANSPARENT_PALETTE_INDEX, JAM_CANVAS_WIDTH * m_nTotalImageHeight);

	// Loop through the textures, asking each to export its
	// pixels to the canvas bitmap
	POSITION posTexture = m_Textures.GetHeadPosition();
	while (NULL != posTexture)
	{
		// Get the next texture and set the position
		// of its palettes
		CJamTexture* pTexture = m_Textures.GetNext(posTexture);
		ASSERT(NULL != pTexture);
		if (NULL != pTexture)
			pTexture->ExportPixelsToCanvasBitmap(pbBitmapPixels);
	}

	// Create a bitmap and put the canvas into it
	CGP2Bitmap jamBitmap;
	if (!jamBitmap.CreateFromJamPixels(JAM_CANVAS_WIDTH, (WORD)m_nTotalImageHeight, pbBitmapPixels))
	{
		ASSERT(FALSE);	// what went wrong?
		delete[] pbBitmapPixels;
		pbBitmapPixels = NULL;

		return FALSE;
	}

	// Finally, save the bitmap and tidy up
	BOOL bSuccess = jamBitmap.SaveFile(strBitmapFile);
	delete[] pbBitmapPixels;
	pbBitmapPixels = NULL;

	return bSuccess;
}
// End of function 'ExportCanvas'


// Function:	ImportCanvas(strBitmapFile, pFilter)
// Overview:	Import the whole of the canvas from the given bitmap
//				file.  Return TRUE upon success, FALSE otherwise.
BOOL CJam::ImportCanvas(const CString& strBitmapFile, CJamTextureFilter* pFilter)
{
	// Load the bitmap
	CGP2Bitmap jamBitmap;
	if (!jamBitmap.LoadFile(strBitmapFile))
		return FALSE;
	if (jamBitmap.GetSize() != CSize(JAM_CANVAS_WIDTH, m_nTotalImageHeight))
	{
		AfxMessageBox(IDS_ERR_IMPORT_CANVAS_WRONG_SIZE);
		return FALSE;
	}
	BYTE* pbBitmapPixels = jamBitmap.GetPixels();

	// Copy the pixels into our canvas, creating it on the fly
	// if we need to
	if (NULL == m_pbCanvasPixels)
		m_pbCanvasPixels = new BYTE[JAM_CANVAS_WIDTH * m_nTotalImageHeight];
	if (NULL == m_pbCanvasPixels)
		return FALSE;
	memcpy(m_pbCanvasPixels, pbBitmapPixels, JAM_CANVAS_WIDTH * m_nTotalImageHeight);

	// Loop through the textures, asking each to extract its
	// pixels, filter them and create its palettes/pixels
	POSITION posTexture = m_Textures.GetHeadPosition();
	BOOL bSuccess = TRUE;
	while (NULL != posTexture && bSuccess)
	{
		// Get the next texture and set the position
		// of its palettes
		CJamTexture* pTexture = m_Textures.GetNext(posTexture);
		ASSERT(NULL != pTexture);
		if (NULL != pTexture)
			bSuccess = pTexture->ImportPixelsFromCanvasBitmap(pbBitmapPixels, pFilter);
	}

	// Update the palette pointers in the textures
	UpdatePalettePositions();

	return bSuccess;
}
// End of function 'ImportCanvas'


// Function:	ExportTexture(strBitmapFile, nTextureID)
// Overview:	Export the texture with the given ID to the given
//				bitmap.  Return TRUE upon success, FALSE otherwise.
BOOL CJam::ExportTexture(const CString& strBitmapFile, const UINT nTextureID)
{
	// Get a pointer to the texture in question
	CJamTexture* pTexture = GetTexture(nTextureID);
	ASSERT(NULL != pTexture);
	if (NULL == pTexture)
		return FALSE;	// no texture of the given ID!

	// Create the bitmap pixels into which we'll ask the given
	// texture to put its pixels
	CSize sizTexture = pTexture->GetRect().Size();
	BYTE* pbBitmapPixels = new BYTE[sizTexture.cx * sizTexture.cy];
	if (NULL == pbBitmapPixels)
	{
		AfxMessageBox(IDS_ERR_OUTOFMEMORY_FOR_SAVING_BITMAP);
		return FALSE;
	}
	memset(pbBitmapPixels, GP2_TRANSPARENT_PALETTE_INDEX, sizTexture.cx * sizTexture.cy);
	pTexture->ExportPixelsToTextureBitmap(pbBitmapPixels);

	// Create a bitmap and put the texture into it
	CGP2Bitmap jamBitmap;
	if (!jamBitmap.CreateFromJamPixels((WORD)sizTexture.cx, (WORD)sizTexture.cy, pbBitmapPixels))
	{
		ASSERT(FALSE);	// what went wrong?
		delete[] pbBitmapPixels;
		pbBitmapPixels = NULL;

		return FALSE;
	}

	// Finally, save the bitmap and tidy up
	BOOL bSuccess = jamBitmap.SaveFile(strBitmapFile);
	delete[] pbBitmapPixels;
	pbBitmapPixels = NULL;

	return bSuccess;
}
// End of function 'ExportTexture'


// Function:	ImportTexture(strBitmapFile, nTextureID, pFilter)
// Overview:	Import the given bitmap into the texture with the
//				given ID.  Return TRUE upon success, FALSE otherwise.
BOOL CJam::ImportTexture(const CString& strBitmapFile, const UINT nTextureID, CJamTextureFilter* pFilter)
{
	// Get a pointer to the texture in question
	CJamTexture* pTexture = GetTexture(nTextureID);
	ASSERT(NULL != pTexture);
	if (NULL == pTexture)
		return FALSE;	// no texture of the given ID!

	// Load the bitmap
	CGP2Bitmap textureBitmap;
	if (!textureBitmap.LoadFile(strBitmapFile))
		return FALSE;
	if (textureBitmap.GetSize() != pTexture->GetRect().Size())
	{
		AfxMessageBox(IDS_ERR_IMPORT_TEXTURE_WRONG_SIZE);
		return FALSE;
	}

	// Now get the pixels from the bitmap, BUT DON'T get any padding
	// pixels required by the bitmap format!
	BYTE* pbBitmapPixels = new BYTE[textureBitmap.GetWidth() * textureBitmap.GetHeight()];
	if (NULL == pbBitmapPixels)
		return FALSE;
	CPixelBlitter blitter;
	CSize sizPaddedBitmap(textureBitmap.GetPaddedWidth(), textureBitmap.GetHeight());
	CSize sizTextureBitmap(textureBitmap.GetSize());
	blitter.CopyPixels(textureBitmap.GetPixels(), sizPaddedBitmap, CRect(CPoint(0,0),sizTextureBitmap),
					   pbBitmapPixels, sizTextureBitmap, CPoint(0,0));
	BOOL bSuccess = pTexture->ImportPixelsFromTextureBitmap(pbBitmapPixels, pFilter);

	// Tidy up
	delete[] pbBitmapPixels;

	// Update the palette pointers in the textures
	UpdatePalettePositions();

	return bSuccess;
}
// End of function 'ImportTexture'


// Function:	ImportAnimation(lstBitmapFiles, nTextureID)
// Overview:	Import the given bitmaps into the texture with the
//				given ID, treating the bitmaps as the frames of an
//				animation.  Return TRUE upon success, FALSE otherwise.
BOOL CJam::ImportAnimation(const CStringList& lstBitmapFiles, const UINT nTextureID)
{
	// Get a pointer to the texture in question
	CJamTexture* pTexture = GetTexture(nTextureID);
	ASSERT(NULL != pTexture);
	if (NULL == pTexture)
		return FALSE;	// no texture of the given ID!

	// Load the bitmaps (if there's an error in loading them, the 
	// user will already have seen an error message, so all we need
	// to do is make sure that the frames are of the right size for
	// the texture).
	CJamTextureAnimation animation;
	if (!animation.SetFiles(lstBitmapFiles))
		return FALSE;
	if (animation.GetFrameSize() != pTexture->GetRect().Size())
	{
		AfxMessageBox(IDS_ERR_IMPORT_ANIMATION_WRONG_SIZE);
		return FALSE;
	}

	// Right, everything's going well so far, so we'll have a
	// go at doing the import proper...
	BOOL bSuccess = pTexture->ImportAnimation(animation);

	// Update the palette pointers in the textures
	UpdatePalettePositions();

	return bSuccess;
}
// End of function 'ImportAnimation'


// Function:	AddNewTexture(strBitmapFile, pFilter)
// Overview:	Import the given bitmap into the Jam as a new texture.
//				Return TRUE upon success, FALSE otherwise.
BOOL CJam::AddNewTexture(const CString& strBitmapFile, CJamTextureFilter* pFilter)
{
	// Load the bitmap
	CGP2Bitmap textureBitmap;
	if (!textureBitmap.LoadFile(strBitmapFile))
		return FALSE;
	if (textureBitmap.GetWidth() > JAM_CANVAS_WIDTH ||
		textureBitmap.GetHeight() > MAX_JAM_CANVAS_HEIGHT)
	{
		AfxMessageBox(IDS_ERR_ADD_TEXTURE_TOO_LARGE);
		return FALSE;
	}

	// Create a new jam entry
	CSize sizTextureBitmap(textureBitmap.GetSize());
	CJamTexture* pNewTexture = new CJamTexture(sizTextureBitmap, &m_Textures);
	if (NULL == pNewTexture)
		return FALSE;

	// Now get the pixels from the bitmap, BUT DON'T get any padding
	// pixels required by the bitmap format!
	BYTE* pbBitmapPixels = new BYTE[textureBitmap.GetWidth() * textureBitmap.GetHeight()];
	if (NULL == pbBitmapPixels)
		return FALSE;
	CPixelBlitter blitter;
	CSize sizPaddedBitmap(textureBitmap.GetPaddedWidth(), textureBitmap.GetHeight());
	blitter.CopyPixels(textureBitmap.GetPixels(), sizPaddedBitmap, CRect(CPoint(0,0),sizTextureBitmap),
					   pbBitmapPixels, sizTextureBitmap, CPoint(0,0));
	BOOL bSuccess = pNewTexture->ImportPixelsFromTextureBitmap(pbBitmapPixels, pFilter);

	// Tidy up
	delete[] pbBitmapPixels;

	if (bSuccess)
	{
		// Select the new texture, deselecting the current one first
		CJamTexture* pOldSel = GetSelectedTexture();
		if (NULL != pOldSel)
			pOldSel->m_bSelected = FALSE;
		pNewTexture->m_bSelected = TRUE;

		// Add the new texture to the Jam
		m_Textures.AddTail(pNewTexture);

		// Update the palette pointers in the textures
		UpdatePalettePositions();
	}

	return bSuccess;
}
// End of function 'AddNewTexture'


// Function:	DeleteTexture(pTexture&)
// Overview:	Delete the given texture from the jam
BOOL CJam::DeleteTexture(CJamTexture*& pTexture)
{
	// Make sure we've been given a texture to delete
	// and that it is ours!
	if (NULL == pTexture)
		return FALSE;
	POSITION posTexture = m_Textures.Find(pTexture);
	if (NULL == posTexture)
		return FALSE;

	// Remove the texture and delete it
	m_Textures.RemoveAt(posTexture);
	delete pTexture;
	pTexture = NULL;

	// Update the palette pointers in the textures
	UpdatePalettePositions();

	return TRUE;
}
// End of function 'DeleteTexture'


// Function:	UpdatePalettePositions()
// Overview:	Update of palette positions required after bitmap
//				import and re-filtering
void CJam::UpdatePalettePositions()
{
	UINT nPalettePosition = 0;
	POSITION posTexture = m_Textures.GetHeadPosition();
	while (NULL != posTexture)
	{
		// Get the next texture and set the position
		// of its palettes
		CJamTexture* pTexture = m_Textures.GetNext(posTexture);
		ASSERT(NULL != pTexture);
		if (NULL != pTexture)
		{
			pTexture->SetPalettePos(nPalettePosition);
			nPalettePosition += (pTexture->GetPaletteSize() * NUM_LOCAL_PALETTES_PER_TEXTURE);
		}
	}
}
// End of function 'UpdatePalettePositions'


// Function:	ApplyFilter(pFilter, bApplyToAll)
// Overview:	Apply the given filter the current filter (or all
//				filters).  Return TRUE upon success, or FALSE otherwise.
BOOL CJam::ApplyFilter(CJamTextureFilter* pFilter, const BOOL bAllTextures /*= TRUE*/)
{
	// Just iterate through the list of textures in this jam,
	// filtering each one, if bAllTextures is TRUE, or only
	// selected textures, if not.
	CJamIterator iterator(this);
	BOOL bSuccess = TRUE;
	for (iterator.FindFirst(); !iterator.IsDone() && bSuccess; iterator.FindNext())
	{
		// Get the current texture
		CJamTexture* pTexture = iterator.GetCurrent();
		ASSERT(NULL != pTexture);
		if (NULL == pTexture)
			continue;

		// If it's one we need to filter, do it
		if (bAllTextures || pTexture->m_bSelected)
			bSuccess = pTexture->ApplyFilter(pFilter);
	}

	// Update the palette pointers in the textures
	UpdatePalettePositions();

	return bSuccess;
}
// End of function 'ApplyFilter'




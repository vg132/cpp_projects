// JamEditorDoc.cpp : implementation of the CJamEditorDoc class
//

#include "stdafx.h"
#include "JamEditor.h"

#include "MainFrame.h"

#include "JamEditorDoc.h"

#include "Jam.h"
#include "Hints.h"
#include "TreeIconDefs.h"

#include "MRUPathList.h"
#include "JamEditorMRUPaths.h"
#include "FilenameParser.h"
#include "JamIterator.h"

#include "JamTextureFilterManager.h"
#include "JamTextureFilter.h"
#include "ImportBitmapDialog.h"
#include "ImportAnimationDlg.h"
#include "DrivingConditionsDlg.h"
#include "LocalPaletteDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJamEditorDoc

IMPLEMENT_DYNCREATE(CJamEditorDoc, CDocument)

BEGIN_MESSAGE_MAP(CJamEditorDoc, CDocument)
	//{{AFX_MSG_MAP(CJamEditorDoc)
	ON_COMMAND(ID_EDIT_IMPORT_CANVAS, OnImportCanvas)
	ON_COMMAND(ID_EDIT_EXPORT_CANVAS, OnExportCanvas)
	ON_COMMAND(ID_EDIT_EXPORT_TEXTURE, OnExportTexture)
	ON_UPDATE_COMMAND_UI(ID_EDIT_EXPORT_TEXTURE, OnUpdateExportTexture)
	ON_COMMAND(ID_EDIT_IMPORT_TEXTURE, OnImportTexture)
	ON_UPDATE_COMMAND_UI(ID_EDIT_IMPORT_TEXTURE, OnUpdateImportTexture)
	ON_COMMAND(ID_EDIT_DRIVING_CONDITIONS, OnEditDrivingConditions)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DRIVING_CONDITIONS, OnUpdateDrivingConditions)
	ON_COMMAND(ID_EDIT_ADD_NEW_TEXTURE, OnAddNewTexture)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	ON_COMMAND(ID_VIEW_PALETTE_NEXT, OnNextPalette)
	ON_COMMAND(ID_VIEW_PALETTE_PREVIOUS, OnPreviousPalette)
	ON_COMMAND(ID_EDIT_DELETE_TEXTURE, OnDeleteTexture)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE_TEXTURE, OnUpdateDeleteTexture)
	ON_COMMAND(ID_EDIT_LOCAL_PALETTES, OnEditLocalPalettes)
	ON_UPDATE_COMMAND_UI(ID_EDIT_LOCAL_PALETTES, OnUpdateEditLocalPalettes)
	ON_COMMAND(ID_EDIT_IMPORT_ANIMATION, OnImportAnimation)
	ON_UPDATE_COMMAND_UI(ID_EDIT_IMPORT_ANIMATION, OnUpdateImportAnimation)
	//}}AFX_MSG_MAP
	ON_COMMAND_RANGE(ID_VIEW_PALETTE_ZERO, ID_VIEW_PALETTE_FOUR, OnSelectPalette)
	ON_UPDATE_COMMAND_UI_RANGE(ID_VIEW_PALETTE_ZERO, ID_VIEW_PALETTE_FOUR, OnUpdateSelectPalette)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJamEditorDoc construction/destruction

CJamEditorDoc::CJamEditorDoc()
{
	// Initialize the Jam member
	m_pJam = NULL;

	// Use the standard palette by default
	m_nPaletteNum = 1;
}

CJamEditorDoc::~CJamEditorDoc()
{
	// Just making sure...
	if (NULL != m_pJam)
		delete m_pJam;
}

BOOL CJamEditorDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// This function shouldn't be needed as this is an MDI app,
	// but I figure I'd better include this just in case.
	if (NULL != m_pJam)
		delete m_pJam;
	m_pJam = new CJam(this);

	// Get the active document and add it to the tree
	CMainFrame* pMainFrame = (CMainFrame*)AfxGetMainWnd();
	ASSERT(NULL != pMainFrame);
	if (NULL != pMainFrame)
		pMainFrame->UpdateTreeAfterOpenDocument(this);

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CJamEditorDoc serialization

void CJamEditorDoc::Serialize(CArchive& ar)
{
	// Check to see whether we should encrypt/decrypt
	CString strFileName = ar.GetFile()->GetFilePath();
	CFilenameParser fnJamJad(strFileName);
	BOOL bEncryptDecrypt = FALSE;
	if (fnJamJad.IsOfType(".jam"))
		bEncryptDecrypt = TRUE;
	else if (fnJamJad.IsOfType(".jad"))
		bEncryptDecrypt = FALSE;
	else if (fnJamJad.IsOfType(".jip"))		// scaled JAM
		bEncryptDecrypt = TRUE;
	else
		AfxThrowArchiveException(CArchiveException::badIndex, strFileName);

	if (ar.IsStoring())
	{
		// Just serialize the jam file
		ASSERT(NULL != m_pJam);
		if (bEncryptDecrypt)
			m_pJam->Serialize(ar);
		else
			m_pJam->SerializeNoEncryption(ar);
	}
	else
	{
		// Just serialize the jam file
		ASSERT(NULL == m_pJam);
		m_pJam = new CJam(this);
		if (bEncryptDecrypt)
			m_pJam->Serialize(ar);
		else
			m_pJam->SerializeNoEncryption(ar);
	}
}
// End of function 'Serialize'


// Function:	SerializeSelection(ar&)
// Overview:	Function to serialize nothing but the currently selected
//				texture(s).  This is used by the view's clipboarding
//				functions.
void CJamEditorDoc::SerializeSelection(CArchive& ar)
{
	// Make sure there's a jam first!
	CJam* pJam = GetJam();
	if (NULL == pJam)
		AfxThrowArchiveException(CArchiveException::generic, ar.GetFile()->GetFilePath());

	if (ar.IsStoring())
	{
		// Store the version number
		UINT nVersion = JAMEDITOR_DOC_CLIPBRD_VERSION;
		ar << nVersion;

		// Store the current texture(s)
		pJam->SerializeSelection(ar);
	}
	else
	{
		// Load the version number
		UINT nVersion = 0;
		ar >> nVersion;

		// Check the verison number
		if (0 == nVersion || nVersion > JAMEDITOR_DOC_CLIPBRD_VERSION)
			AfxThrowArchiveException(CArchiveException::badSchema,
				ar.GetFile()->GetFilePath());

		// Load the texture(s) from the archive
		pJam->SerializeSelection(ar);

		// Update the views
		UpdateAllViews(NULL, HINT_ADDED_TEXTURE);
		SetModifiedFlag(TRUE);

		// Add the new texture to the tree
		CMainFrame* pMainFrame = (CMainFrame *)AfxGetMainWnd();
		if (NULL != pMainFrame)
			pMainFrame->UpdateTreeAfterAddNewTexture(pJam->GetSelectedTexture());
	}
}
// End of function 'SerializeSelection'


/////////////////////////////////////////////////////////////////////////////
// CJamEditorDoc diagnostics

#ifdef _DEBUG
void CJamEditorDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CJamEditorDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CJamEditorDoc commands

void CJamEditorDoc::DeleteContents() 
{
	// Get rid of the current jam
	if (NULL != m_pJam)
	{
		delete m_pJam;
		m_pJam = NULL;
	}

	// Call base class version
	CDocument::DeleteContents();
}



/////////////////////////////////////////////////////////////////////////////
// Palette functions

void CJamEditorDoc::OnSelectPalette(UINT nID)
{
	// Set the current palette
	m_nPaletteNum = CommandIDToPaletteNum(nID);

	// Make sure the views redraw themselves accordingly
	UpdateAllViews(NULL, HINT_SELECTED_PALETTE);
}

void CJamEditorDoc::OnUpdateSelectPalette(CCmdUI* pCmdUI)
{
	// Show which palette is currently selected with a radio option
	const int nUIPaletteNum = CommandIDToPaletteNum(pCmdUI->m_nID);
	pCmdUI->SetRadio(nUIPaletteNum == m_nPaletteNum);
}

// Convert the command ID of one of the ID_VIEW_PALETTE* commands
// to an equivalent palette number
int CJamEditorDoc::CommandIDToPaletteNum(const int nCommandID)
{
	return (nCommandID - ID_VIEW_PALETTE_ZERO);
}

void CJamEditorDoc::OnNextPalette() 
{
	// Select the next palette in the sequence (but don't
	// include the untextured palettes in the sequence)
	if (m_nPaletteNum < 1)
		m_nPaletteNum = 1;
	else
		m_nPaletteNum = (m_nPaletteNum % 4 + 1);

	// Make sure the views redraw themselves accordingly
	UpdateAllViews(NULL, HINT_SELECTED_PALETTE);
}

void CJamEditorDoc::OnPreviousPalette() 
{
	// Select the previous palette in the sequence (but don't
	// include the untextured palettes in the sequence)
	m_nPaletteNum--;
	if (m_nPaletteNum < 1)
		m_nPaletteNum = 4;

	// Make sure the views redraw themselves accordingly
	UpdateAllViews(NULL, HINT_SELECTED_PALETTE);
}



/////////////////////////////////////////////////////////////////////////////
// Bitmap import/export commands

// Function:	OnImportCanvas()
// Overview:	Command to allow the user to import a bitmap to replace
//				the whole of the current Jam's canvas
void CJamEditorDoc::OnImportCanvas() 
{
	// Make sure the Jam's valid
	if (NULL == m_pJam)
		return;

	// Prepare some strings for use in the dialog
	CString strFileName("*.bmp"), strFilter(""), strDlgTitle(""), strDefaultDir("");
	strFilter.LoadString(IDS_IMPORT_EXPORT_BMP_FILTER);
	strDlgTitle.LoadString(IDS_IMPORT_CANVAS_DLGTITLE);
	CMRUPathList* pMRUPaths = CMRUPathList::GetPathList();
	if (NULL != pMRUPaths)
		strDefaultDir = pMRUPaths->GetMRUPath(szImportCanvasPath);

	// Create the dialog and set it up
	CImportBitmapDialog dlg(TRUE, ".BMP", "*.bmp", OFN_FILEMUSTEXIST | OFN_HIDEREADONLY, strFilter);
	dlg.m_ofn.lpstrTitle = strDlgTitle;
	dlg.m_ofn.lpstrInitialDir = strDefaultDir;
	dlg.m_nReqWidth = m_pJam->GetSize().cx;
	dlg.m_nReqHeight = m_pJam->GetSize().cy;

	// Display the dialog
	if (IDOK == dlg.DoModal())
	{
		// This may take some time... ;-)
		CWaitCursor curWait;

		// Import the bitmap using the filter selected in the dialog.
		BOOL bSuccess = m_pJam->ImportCanvas(dlg.GetPathName(), dlg.GetSelectedFilter());

		// Update the document and views
		if (bSuccess)
		{
			// Save the path as the most recently used for this type
			// of operation.
			CFilenameParser parsedFileName(dlg.GetPathName());
			if (NULL != pMRUPaths)
				pMRUPaths->SetMRUPath(szImportCanvasPath, parsedFileName.DriveAndPath(TRUE));

			// Dirty the document and update the rest of the program
			SetModifiedFlag(TRUE);
			UpdateAllViews(NULL, HINT_IMPORTED_CANVAS_BITMAP);

			// Let the user know it's finished
			::MessageBeep(MB_ICONASTERISK);
		}
		else
		{
			// Let the user know something went wrong (or they
			// successfully canceled the operation)
			::MessageBeep(MB_ICONHAND);
		}
	}
}
// End of function 'OnImportCanvas'


// Function:	OnExportCanvas()
// Overview:	Command to allow the user to export the whole of the
//				current Jam's canvas to a bitmap file.
void CJamEditorDoc::OnExportCanvas() 
{
	// Make sure the Jam's valid
	if (NULL == m_pJam)
		return;

	// Prepare some strings for use in the dialog
	CString strFileName("*.bmp"), strFilter(""), strDlgTitle(""), strDefaultDir("");
	strFilter.LoadString(IDS_IMPORT_EXPORT_BMP_FILTER);
	strDlgTitle.LoadString(IDS_EXPORT_CANVAS_DLGTITLE);
	CFilenameParser defaultFile(m_strTitle);
	CString strPaletteSuffix("");
	strPaletteSuffix.Format(IDS_PALETTE_EXPORT_SUFFIX, GetPaletteNum());
	defaultFile.FileName() += strPaletteSuffix;
	defaultFile.Extension() = ".bmp";
	CMRUPathList* pMRUPaths = CMRUPathList::GetPathList();
	if (NULL != pMRUPaths)
		strDefaultDir = pMRUPaths->GetMRUPath(szExportCanvasPath);

	// Create the dialog and set it up
	CImportBitmapDialog dlg(FALSE, ".BMP", defaultFile.GetFileNameEx(), OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY, strFilter);
	dlg.m_ofn.lpstrTitle = strDlgTitle;
	dlg.m_ofn.lpstrInitialDir = strDefaultDir;

	// Display the dialog
	if (IDOK == dlg.DoModal())
	{
		// This may take some time (but it's unlikely to be too long)
		CWaitCursor curWait;

		// Ask the Jam to export its canvas to the given filename
		BOOL bSuccess = m_pJam->ExportCanvas(dlg.GetPathName());
		if (bSuccess)
		{
			// Save the path as the most recently used for this type
			// of operation.
			CFilenameParser parsedFileName(dlg.GetPathName());
			if (NULL != pMRUPaths)
				pMRUPaths->SetMRUPath(szExportCanvasPath, parsedFileName.DriveAndPath(TRUE));
		}
	}
}
// End of function 'OnExportCanvas'


// Function:	OnImportTexture()
// Overview:	Command to allow the user to import a bitmap to replace
//				the currently selected texture
void CJamEditorDoc::OnImportTexture() 
{
	// Just check to make sure there is a selected texture
	if (NULL == m_pJam)
		return;
	CJamTexture* pTexture = m_pJam->GetSelectedTexture();
	if (NULL == pTexture)
		return;

	// Prepare some strings for use in the dialog
	CString strFileName("*.bmp"), strFilter(""), strDlgTitle(""), strDefaultDir("");
	strFilter.LoadString(IDS_IMPORT_EXPORT_BMP_FILTER);
	strDlgTitle.LoadString(IDS_IMPORT_TEXTURE_DLGTITLE);
	CMRUPathList* pMRUPaths = CMRUPathList::GetPathList();
	if (NULL != pMRUPaths)
		strDefaultDir = pMRUPaths->GetMRUPath(szImportTexturePath);

	// Create the dialog and set it up
	CImportBitmapDialog dlg(TRUE, ".BMP", strFileName, OFN_FILEMUSTEXIST | OFN_HIDEREADONLY, strFilter);
	dlg.m_ofn.lpstrTitle = strDlgTitle;
	dlg.m_ofn.lpstrInitialDir = strDefaultDir;
	dlg.m_nReqWidth = pTexture->GetRect().Width();
	dlg.m_nReqHeight = pTexture->GetRect().Height();

	// Display the dialog
	if (IDOK == dlg.DoModal())
	{
		// This may take some time, but hopefully not
		CWaitCursor curWait;

		// Import the bitmap using the filter selected in the dialog.
		BOOL bSuccess = m_pJam->ImportTexture(dlg.GetPathName(), pTexture->GetTextureID(), dlg.GetSelectedFilter());

		// Update the document and views, etc.
		if (bSuccess)
		{
			// Save the path as the most recently used for this type
			// of operation.
			CFilenameParser parsedFileName(dlg.GetPathName());
			if (NULL != pMRUPaths)
				pMRUPaths->SetMRUPath(szImportTexturePath, parsedFileName.DriveAndPath(TRUE));

			// Dirty the document and update the rest of the program
			SetModifiedFlag(TRUE);
			UpdateAllViews(NULL, HINT_IMPORTED_TEXTURE_BITMAP);

			// Let the user know it's finished
			::MessageBeep(MB_ICONASTERISK);
		}
		else
		{
			// Let the user know something went wrong (or they
			// successfully canceled the operation)
			::MessageBeep(MB_ICONHAND);
		}
	}
}
// End of function 'OnImportTexture'


// Function:	OnUpdateImportTexture(pCmdUI)
// Overview:	UI-update function for the Import Texture command
void CJamEditorDoc::OnUpdateImportTexture(CCmdUI* pCmdUI) 
{
	// Enable the command if there is a texture selected
	pCmdUI->Enable((NULL != m_pJam) && (NULL != m_pJam->GetSelectedTexture()));
}
// End of function 'OnUpdateImportTexture'


// Function:	OnExportTexture()
// Overview:	Command to allow the user to export the currently
//				selected texture to a bitmap file.
void CJamEditorDoc::OnExportTexture() 
{
	// Just check to make sure there is a selected texture
	if (NULL == m_pJam)
		return;
	CJamTexture* pTexture = m_pJam->GetSelectedTexture();
	if (NULL == pTexture)
		return;

	// Prepare some strings for use in the dialog
	CString strFileName("*.bmp"), strFilter(""), strDlgTitle(""), strDefaultDir("");
	strFilter.LoadString(IDS_IMPORT_EXPORT_BMP_FILTER);
	strDlgTitle.LoadString(IDS_EXPORT_TEXTURE_DLGTITLE);
	CMRUPathList* pMRUPaths = CMRUPathList::GetPathList();
	if (NULL != pMRUPaths)
		strDefaultDir = pMRUPaths->GetMRUPath(szExportTexturePath);

	// Create the dialog and set it up
	CImportBitmapDialog dlg(FALSE, ".BMP", strFileName, OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY, strFilter);
	dlg.m_ofn.lpstrTitle = strDlgTitle;
	dlg.m_ofn.lpstrInitialDir = strDefaultDir;

	// Display the dialog
	if (IDOK == dlg.DoModal())
	{
		// This may take some time (but it's unlikely to be too long)
		CWaitCursor curWait;

		// Ask the Jam to export its selected texture to the given filename
		BOOL bSuccess = m_pJam->ExportTexture(dlg.GetPathName(), pTexture->GetTextureID());
		if (bSuccess)
		{
			// Save the path as the most recently used for this type
			// of operation.
			CFilenameParser parsedFileName(dlg.GetPathName());
			if (NULL != pMRUPaths)
				pMRUPaths->SetMRUPath(szExportTexturePath, parsedFileName.DriveAndPath(TRUE));
		}
	}
}
// End of function 'OnExportTexture'


// Function:	OnUpdateExportTexture(pCmdUI)
// Overview:	UI-update function for the Export Texture command
void CJamEditorDoc::OnUpdateExportTexture(CCmdUI* pCmdUI) 
{
	// Enable the command if there is a texture selected
	pCmdUI->Enable((NULL != m_pJam) && (NULL != m_pJam->GetSelectedTexture()));
}
// End of function 'OnUpdateExportTexture'


// Function:	OnImportAnimation()
// Overview:	Command to allow the user to import a series of bitmaps
//				as an animation, replacing the image in the currently
//				selected texture.
void CJamEditorDoc::OnImportAnimation() 
{
	// Just check to make sure there is a selected texture
	if (NULL == m_pJam)
		return;
	CJamTexture* pTexture = m_pJam->GetSelectedTexture();
	if (NULL == pTexture)
		return;

	// Set up the Import Animation dialog and display it
	CImportAnimationDlg dlg;
	dlg.m_nReqWidth = pTexture->GetRect().Width();
	dlg.m_nReqHeight = pTexture->GetRect().Height();

	if (IDOK == dlg.DoModal())
	{
		// Everything appears to have gone well, so get the filenames
		// from the dialog and ask the texture to do its stuff.
		CStringList lstFilenames;
		dlg.GetFilenames(lstFilenames);

		// This may take some time, but hopefully not
		CWaitCursor curWait;

		// Import the bitmap using the filter selected in the dialog.
		BOOL bSuccess = m_pJam->ImportAnimation(lstFilenames, pTexture->GetTextureID());

		// Update the document and views, etc.
		if (bSuccess)
		{
			// Dirty the document and update the rest of the program
			SetModifiedFlag(TRUE);
			UpdateAllViews(NULL, HINT_IMPORTED_TEXTURE_BITMAP);

			// Let the user know it's finished
			::MessageBeep(MB_ICONASTERISK);
		}
		else
		{
			// Let the user know something went wrong (or they
			// successfully canceled the operation)
			::MessageBeep(MB_ICONHAND);
		}
	}
}
// End of function 'OnImportAnimation'


// Function:	OnUpdateImportAnimation(pCmdUI)
// Overview:	UI-update function for the Import Animation command
void CJamEditorDoc::OnUpdateImportAnimation(CCmdUI* pCmdUI) 
{
	// Enable the command if there is a texture selected
	pCmdUI->Enable((NULL != m_pJam) && (NULL != m_pJam->GetSelectedTexture()));
}
// End of function 'OnUpdateImportAnimation'



/////////////////////////////////////////////////////////////////////////////
// Adding and removing textures

// Function:	OnAddNewTexture()
// Overview:	Command to allow the user to import a bitmap as a new
//				texture in the JAM.
void CJamEditorDoc::OnAddNewTexture() 
{
	// Make sure the document's not in a dodgy state
	ASSERT(NULL != m_pJam);
	if (NULL == m_pJam)
		return;

	// Prepare some strings for use in the dialog
	CString strFileName("*.bmp"), strFilter(""), strDlgTitle(""), strDefaultDir("");
	strFilter.LoadString(IDS_IMPORT_EXPORT_BMP_FILTER);
	strDlgTitle.LoadString(IDS_NEW_TEXTURE_DLGTITLE);
	// Use the same path as for Import Texture
	CMRUPathList* pMRUPaths = CMRUPathList::GetPathList();
	if (NULL != pMRUPaths)
		strDefaultDir = pMRUPaths->GetMRUPath(szImportTexturePath);

	// Create the dialog and set it up
	CImportBitmapDialog dlg(TRUE, ".BMP", strFileName, OFN_FILEMUSTEXIST | OFN_HIDEREADONLY, strFilter);
	dlg.m_ofn.lpstrTitle = strDlgTitle;
	dlg.m_ofn.lpstrInitialDir = strDefaultDir;
	dlg.m_nReqWidth = 0;	// any old width and height will do
	dlg.m_nReqHeight = 0;

	// Display the dialog
	if (IDOK == dlg.DoModal())
	{
		// This may take some time, but hopefully not
		CWaitCursor curWait;

		// Import the bitmap using the filter selected in the dialog.
		BOOL bSuccess = m_pJam->AddNewTexture(dlg.GetPathName(), dlg.GetSelectedFilter());

		// Update the document and views, etc.
		if (bSuccess)
		{
			// Save the path as the most recently used for this type
			// of operation.
			CFilenameParser parsedFileName(dlg.GetPathName());
			if (NULL != pMRUPaths)
				pMRUPaths->SetMRUPath(szImportTexturePath, parsedFileName.DriveAndPath(TRUE));

			// Dirty the document and update the rest of the program
			SetModifiedFlag(TRUE);
			UpdateAllViews(NULL, HINT_ADDED_TEXTURE);

			// Add the new texture to the tree (I wish!)
			CMainFrame* pMainFrame = (CMainFrame *)AfxGetMainWnd();
			if (NULL != pMainFrame)
				pMainFrame->UpdateTreeAfterAddNewTexture(m_pJam->GetSelectedTexture());

			// Let the user know it's finished
			::MessageBeep(MB_ICONASTERISK);

			// Now open the Texture Properties dialog for the user - hopefully
			// they'll take the hint and edit the texture ID.
			if (IDYES == AfxMessageBox(IDS_CREATED_TEXTURE_NOW_PROMPT_FOR_ID, MB_ICONQUESTION | MB_YESNO))
			{
				// Just send the message that would occur if the user
				// selected the Texture Properties command
				if (NULL != pMainFrame)
					pMainFrame->SendMessage(WM_COMMAND, ID_EDIT_TEXTURE_PROPERTIES);
			}
		}
		else
		{
			// Let the user know something went wrong (or they
			// successfully canceled the operation)
			::MessageBeep(MB_ICONHAND);
		}
	}
}
// End of function 'OnAddNewTexture'


// Function:	OnDeleteTexture()
// Overview:	Delete the currently selected texture from the JAM.
void CJamEditorDoc::OnDeleteTexture() 
{
	// Make sure there's a currently selected texture in the jam
	CJam* pJam = GetJam();
	if (NULL == pJam)
		return;
	CJamTexture* pTexture = pJam->GetSelectedTexture();
	if (NULL == pTexture)
		return;

	// Ask the user to confirm the action
	if (IDYES != AfxMessageBox(IDS_QUESTION_DELETE_TEXTURE, MB_ICONQUESTION | MB_YESNO))
		return;

	// Ok, then, let's go for it!
	DeleteCurrentTexture();
}
// End of function 'OnDeleteTexture'


// Function:	OnUpdateDeleteTexture(pCmdUI)
// Overview:	Enable/disable the Delete Texture command as appropriate
void CJamEditorDoc::OnUpdateDeleteTexture(CCmdUI* pCmdUI) 
{
	// Disable the command if there is no selected texture
	pCmdUI->Enable(NULL != GetJam() && NULL != GetJam()->GetSelectedTexture());
}
// End of function 'OnUpdateDeleteTexture'


// Function:	DeleteCurrentTexture()
// Overview:	A function to silently do the donkey work of getting rid of
//				the currently selected texture.  This functionality has been
//				exposed for use by clipboarding in the view.
BOOL CJamEditorDoc::DeleteCurrentTexture()
{
	// Make sure there's a currently selected texture in the jam
	CJam* pJam = GetJam();
	if (NULL == pJam)
		return FALSE;
	CJamTexture* pTexture = pJam->GetSelectedTexture();
	if (NULL == pTexture)
		return FALSE;

	// Ask the jam to delete its selected texture.  But before we
	// do so, get rid of references to it in the Jam Tree.
	CMainFrame* pMainFrame = (CMainFrame *)AfxGetMainWnd();
	if (NULL != pMainFrame)
		pMainFrame->UpdateTreeForDeleteTexture(pTexture);

	// Delete the texture (deallocating its memory).  NOTE: we can
	// no longer refer to the 'selected' texture, as removing the
	// texture from the tree may have moved the selection onto a
	// different tree item, thereby selecting a different texture!!!
	pJam->DeleteTexture(pTexture);

	// Now refresh the tree to show how many textures are left
	if (NULL != pMainFrame)
		pMainFrame->UpdateTreeDataDisplay(pJam->GetTextureListFrontEnd());

	// Dirty the document and update the rest of the program
	SetModifiedFlag(TRUE);
	UpdateAllViews(NULL, HINT_DELETED_TEXTURE);

	return TRUE;
}
// End of function 'DeleteCurrentTexture'



/////////////////////////////////////////////////////////////////////////////
// Filtering commands

// Function:	OnEditDrivingConditions()
// Overview:	Display the Driving Conditions dialog box
void CJamEditorDoc::OnEditDrivingConditions() 
{
	// Make sure there's a jam first!
	ASSERT(NULL != m_pJam);
	if (NULL == m_pJam)
		return;

	// Create and display the Driving Conditions dialog box.
	CDrivingConditionsDlg dlg;
	dlg.m_bApplyToAll = (NULL == m_pJam->GetSelectedTexture());
	if (IDOK == dlg.DoModal())
	{
		// This may take some time, but hopefully not
		CWaitCursor curWait;

		// Apply the filter selected in the dialog, either to all
		// textures or just the current one (this too is specified
		// in the dialog).
		BOOL bSuccess = FALSE;
		bSuccess = m_pJam->ApplyFilter(dlg.GetSelectedFilter(), dlg.m_bApplyToAll);

		// Update the document and views, etc.
		if (bSuccess)
		{
			// Dirty the document and update the rest of the program
			SetModifiedFlag(TRUE);
			UpdateAllViews(NULL, HINT_IMPORTED_TEXTURE_BITMAP);

			// Let the user know it's finished
			::MessageBeep(MB_ICONASTERISK);
		}
		else
		{
			// Let the user know something went wrong (or they
			// successfully canceled the operation)
			::MessageBeep(MB_ICONHAND);
		}
	}
}
// End of function 'OnEditDrivingConditions'


// Function:	OnUpdateDrivingConditions(pCmdUI)
// Overview:	Enable/disable the Set Driving Conditions command.
void CJamEditorDoc::OnUpdateDrivingConditions(CCmdUI* pCmdUI) 
{
	// Enable the command if there is actually a jam loaded
	pCmdUI->Enable(NULL != m_pJam);
}
// End of function 'OnUpdateDrivingConditions'



/////////////////////////////////////////////////////////////////////////////
// Stuff added by Ashley for the tree updates

// function to get the icon ID for a document
UINT CJamEditorDoc::GetIconID()
{
	// return the ID for the icon in the tree for this item
	
	// find the jam that the doc uses
	CJam* pJam=GetJam();
	if (!pJam)
		return JTI_JAM_FILE_UNK;	// unknown type - NO JAM!

	return JTI_JAM_FILE;
}

CString CJamEditorDoc::GetFullDescription()
{
	// return the filename of the jam file
	return GetTitle();
}

CString	CJamEditorDoc::GetValueToEdit()
{
	// will return empty - we cannot edit this one
	return "";
}

POSITION CJamEditorDoc::GetFirstSubItemPosition()
{
	// in this class, we'll make POSITION equal to the pointer
	// to the item in question
	// since there are only two items, this will be simple

	if (!GetJam())
		return NULL;	// no sub-items 
	
	return (POSITION)(GetJam()->GetTextureListFrontEnd());
}

CEditableObject* CJamEditorDoc::GetNextSubItem(POSITION& pos)
{
	CEditableObject* pResult=(CEditableObject*)pos;

	// we have our return, let's work out the next position
	// it is either the second front end or NULL

	if (GetJam())
	{
		if ((POSITION)(GetJam()->GetTextureListFrontEnd()) == pos)
		{
			// we were on the first one, so set the pos to point
			// to the second
			pos=(POSITION)(GetJam()->m_pJamSizeObject);
			return pResult;
		}
	}

	// there are no more sub items, set pos to NULL
	pos=NULL;
	return pResult;
}

// data has changed - tell the world
void CJamEditorDoc::DataHasChanged(CView* pView, LPARAM lHint, CObject* pHint)
{
	UpdateAllViews(pView, lHint, pHint);
}


// Function:	OnChangedGlobalPalette()
// Overview:	Get all of the views to update themselves in response to
//				a change in the global palette.
void CJamEditorDoc::OnChangedGlobalPalette()
{
	// Make sure we're actually using the palette before updating
	// ourselves to account for a new one.
	ASSERT(NULL != GetJam());
	if (NULL == GetJam())
		return;

	// Clear the current pixels from the textures, etc.
	CJamIterator iterator(GetJam());
	CJamTexture* pTexture = NULL;
	for (iterator.FindFirst(); !iterator.IsDone(); iterator.FindNext())
	{
		// Get the next texture...
		pTexture = iterator.GetCurrent();
		ASSERT(NULL != pTexture);
		if (NULL == pTexture)
			continue;

		// ...and tell it to flush any cached images it may own
		pTexture->InvalidatePalette();
	}

	// Now we just need to update all of the views
	UpdateAllViews(NULL, HINT_CHANGED_GLOBAL_PALETTE);
}
// End of function 'OnChangedGlobalPalette'


// the document will act on some updates itself
void CJamEditorDoc::UpdateAllViews(CView* pSender, LPARAM lHint, CObject* pHint)
{
	// decide what to do on various hints
	
	BOOL bUpdateTree=FALSE;

	switch (lHint)
	{
	case HINT_IMPORTED_CANVAS_BITMAP:
	case HINT_TEXTURE_PROPERTIES_CHANGED:
		SetModifiedFlag(TRUE);
		bUpdateTree=TRUE;
		break;
	}

	// Do we need to reflect texture selection in the tree?
	CMainFrame* pMainFrame=(CMainFrame*)AfxGetMainWnd();
	ASSERT(pMainFrame);
	if (HINT_SELECTED_TEXTURE == lHint)
	{
		// Has the selection actually happened yet?  If the
		// hint comes from the tree via the texture itself,
		// the selection has not been performed as the texture
		// doesn't know how to deselect a sybling.  Instead,
		// it will have passed itself as pHint to let us know
		// that it wants to be selected
		CJam* pJam = GetJam();
		if (NULL != pHint)
		{
			// First, remove the current selection
			if (NULL != pJam)
			{
				CJamTexture* pCurrSelTexture = pJam->GetSelectedTexture();
				if (NULL != pCurrSelTexture)
					pCurrSelTexture->m_bSelected = FALSE;
			}

			// Now select the one that's asking for it ;)
			CJamTexture* pTexture = (CJamTexture *)pHint;
			pTexture->m_bSelected = TRUE;

			// Make sure that this document is actually visible
			// to see the newly selected texture in the doc's
			// view(s)
			if (pMainFrame->GetActiveDocument() != this)
			{
				// God it's convoluted doing this...
				POSITION posView = GetFirstViewPosition();
				CView* pView = GetNextView(posView);
				CFrameWnd* pFirstFrame = NULL;
				if (NULL != pView)
				{
					pFirstFrame = pView->GetParentFrame();
					pMainFrame->MDIActivate(pFirstFrame);
				}
			}
		}
		else
		{
			// If the selection *didn't* come from the tree, we'd
			// better update the tree to show the new selection.
			if (pJam && pJam->GetSelectedTexture())
				pMainFrame->UpdateTreeAfterSelectTexture(pJam->GetSelectedTexture());
		}
	}

	if (bUpdateTree)
	{
		// tell the mainframe of the change and it will refresh all document
		// this could be done more efficiently, but it
		// will at least update the tree for the time being
		
		if (pMainFrame)
		{
			// get the mainframe to pass our front end to the tree
			pMainFrame->UpdateTreeDataDisplay(this);
		}
	}

	CDocument::UpdateAllViews(pSender, lHint, pHint);
}


/////////////////////////////////////////////////////////////////////////////
// Overridden document opening, saving, and closing

// Function:	OnOpenDocument()
// Overview:	Overridden from CDocument to store the most recently
//				used path and to add the jam to the tree.
BOOL CJamEditorDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;

	// store the filename
	SetPathName(lpszPathName);

	// Store the path as the most-recently-used for
	// opening Jam/Jad files
	CFilenameParser parsedFileName(lpszPathName);
	CMRUPathList* pMRUPaths = CMRUPathList::GetPathList();
	if (NULL != pMRUPaths)
		pMRUPaths->SetMRUPath(szOpenJamPath, parsedFileName.DriveAndPath(TRUE));


	// Fix any invalid pixels, if the option to do so is set
	if (CJam::s_bFixInvalidPixels && NULL != GetJam())
	{
		CJam* pJam = GetJam();
		int nNumFixed = pJam->FixAnyInvalidTexturePixels();
		
		// Give some indication to the user that we've changed his textures,
		// if we did so, that is
		if (nNumFixed > 0)
		{
			CFrameWnd* pMainFrame = (CFrameWnd *)AfxGetMainWnd();
			if (NULL != pMainFrame)
			{
				CString strReport;
				strReport.Format(IDS_AUTOFIXED_TEXTURE_PIXELS, nNumFixed);
				pMainFrame->SetMessageText(strReport);
			}

			// Set the modified flag in the document, so that it is
			// marked as having its contents changed
			SetModifiedFlag(TRUE);
			::MessageBeep(MB_ICONINFORMATION);
		}
	}

	// we've opened successfully, get the tree to indicate this
	CMainFrame* pMainFrame=(CMainFrame*)AfxGetMainWnd();
	ASSERT(pMainFrame);
	
	if (pMainFrame)
	{
		// get the mainframe to pass our front end to the tree
		pMainFrame->UpdateTreeAfterOpenDocument(this);
	}
	
	return TRUE;
}
// End of function 'OnOpenDocument'


// Function:	OnSaveDocument(lpszPathName)
// Overview:	Overridden from CDocument to perform a limited sanity
//				check before saving the file.
BOOL CJamEditorDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	// First, make sure there's a jam to save
	ASSERT(NULL != m_pJam);
	if (NULL == m_pJam)
		return FALSE;

	// Check to see whether any of the textures in the Jam file
	// are overlapping
	if (m_pJam->AreTexturesOverlapped())
	{
		// Some textures *are* overlapped, so ask the user whether
		// they really want to save a dodgy jam.
		CString strPrompt;
		strPrompt.Format(IDS_SAVE_OVERLAPPED_TEXTURES, GetPathName());
		if (IDYES != AfxMessageBox(strPrompt, MB_YESNO | MB_DEFBUTTON2))
			return FALSE;
	}

	// Attempt to save the file
	BOOL bSuccess = CDocument::OnSaveDocument(lpszPathName);

	// If successfully saved, store the path as the most-recently-
	// used for saving Jam/Jad files
	if (bSuccess)
	{
		CFilenameParser parsedFileName(lpszPathName);
		CMRUPathList* pMRUPaths = CMRUPathList::GetPathList();
		if (NULL != pMRUPaths)
			pMRUPaths->SetMRUPath(szSaveJamPath, parsedFileName.DriveAndPath(TRUE));
	}

	return bSuccess;
}
// End of function 'OnSaveDocument'


// Function:	OnFileSaveAs()
// Overview:	Overridden to update the filename in the Jam Tree.  This
//				could not be done in the OnSaveDocument or Serialize
//				functions as m_strTitle is not up-to-date with the new
//				filename when they are called.
void CJamEditorDoc::OnFileSaveAs() 
{
	// Just do all of the usual stuff, then update the filename
	// shown in the tree
	CDocument::OnFileSaveAs();

	CMainFrame* pMainFrame=(CMainFrame*)AfxGetMainWnd();
	ASSERT(NULL != pMainFrame);
	if (NULL != pMainFrame)
		pMainFrame->UpdateTreeDataDisplay(this);
}
// End of function 'OnFileSaveAs'


// Function:	OnCloseDocument()
// Overview:	Overridden from CDocument to tidy up the jam tree
//				before closing the document.  We don't want to leave
//				dangling pointers in the tree.
void CJamEditorDoc::OnCloseDocument() 
{
	// we're about to close - so tell the mainframe
	// so it can remove us from the tree
	CMainFrame* pMainFrame=(CMainFrame*)AfxGetMainWnd();
	ASSERT(pMainFrame);
	
	if (pMainFrame)
	{
		// get the mainframe to pass our front end to the tree
		pMainFrame->UpdateTreeForCloseDocument(this);
	}
	
	CDocument::OnCloseDocument();
}
// End of function 'OnCloseDocument'


/////////////////////////////////////////////////////////////////////////////
// Palette-editing functions

// Function:	OnEditLocalPalettes()
// Overview:	Display a dialog for editing the local palette values
//				of the selected texture.
void CJamEditorDoc::OnEditLocalPalettes() 
{
	// Get the texture whose local palettes we are to edit
	CJam* pJam = GetJam();
	if (NULL == pJam)
		return;
	CJamTexture* pTexture = pJam->GetSelectedTexture();
	if (NULL == pTexture)
		return;

	// Set up a palette-editing dialog and show it.
	CLocalPaletteDlg dlg;
	dlg.m_pTexture = pTexture;
	if (IDOK == dlg.DoModal())
	{
		// Palette has probably been edited, so force a refresh
		// and make the document 'dirty'
		SetModifiedFlag(TRUE);
		pTexture->InvalidatePalette();
		UpdateAllViews(NULL, HINT_EDITED_LOCAL_PALETTE);
	}
}
// End of function 'OnEditLocalPalettes'


// Function:	OnUpdateEditLocalPalettes(pCmdUI)
// Overview:	UI update handler for the ID_EDIT_LOCAL_PALETTE
//				command.
void CJamEditorDoc::OnUpdateEditLocalPalettes(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(CanEditLocalPalettes());
}
// End of function 'OnUpdateEditLocalPalettes'


// Function:	CanEditLocalPalettes()
// Overview:	Function used to determine whether the document is in
//				a state in which the local palettes of its selected
//				texture can be edited.
BOOL CJamEditorDoc::CanEditLocalPalettes() const
{
	// We can edit the local palettes iff there is a selected
	// texture and it has local palettes.
	return (NULL != GetJam() &&
			NULL != GetJam()->GetSelectedTexture() &&
			0 != GetJam()->GetSelectedTexture()->GetPaletteSize());
}
// End of function 'CanEditLocalPalettes'



#ifndef __PREVIEWFILEDIALOG__
#define __PREVIEWFILEDIALOG__
// PreviewFileDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPreviewFileDialog dialog

#include "Gp3FileInfo.h"

class CPreviewFileDialog : public CFileDialog
{
	DECLARE_DYNAMIC(CPreviewFileDialog)

public:
	void ClearText();
	void Test(CString file);
	CPreviewFileDialog(BOOL bOpenFileDialog, // TRUE for FileOpen, FALSE for FileSaveAs
		LPCTSTR initDir=NULL,
		LPCTSTR lpszDefExt = NULL,
		LPCTSTR lpszFileName = NULL,
		DWORD dwFlags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		LPCTSTR lpszFilter = NULL,
		CWnd* pParentWnd = NULL);

protected:
	//{{AFX_MSG(CPreviewFileDialog)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	virtual void OnFileNameChange();
	virtual void OnFolderChange();
	CGp3FileInfo m_FileInfo;
};

#endif

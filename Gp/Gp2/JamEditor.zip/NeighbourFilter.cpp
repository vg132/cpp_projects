// NeighbourFilter.cpp - implementation of the CNeighbourFilter class
//

#include "stdafx.h"
#include "resource.h"

#include "NeighbourFilter.h"
#include "TexturePalette.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CNeighbourFilter

int CNeighbourFilter::s_nSpreadFactor = DEFAULT_SPREAD_FACTOR;
double CNeighbourFilter::s_dSpreadThreshold = 0.44f;

// Constructor
CNeighbourFilter::CNeighbourFilter(const UINT& nFilterID, const UINT& nStringID)
	: CJamTextureFilter(nFilterID, nStringID),
	  m_sizFilter(3,3)	// default to filter the pixels immediately surrounding the current pixel
{
	// Calculate the total number of pixels in the neighbourhood
	// and create it.
	int nFilterSize = m_sizFilter.cx * m_sizFilter.cy;
	m_pbNeighbourhood = new BYTE[nFilterSize];
}

// Destructor
CNeighbourFilter::~CNeighbourFilter()
{
	// Delete the neighbourhood pixel array
	if (NULL != m_pbNeighbourhood)
	{
		delete[] m_pbNeighbourhood;
		m_pbNeighbourhood = NULL;
	}
}


// Overridden filtering functions
//

// Function:	CreateNextFilteredBitmap(pbSrcPixels, pbNewPixels, nImageSize)
// Overview:	Overridden function to create each filtered image from the 
//				image created using the previous local palette.  Each pixel
//				is a function of its neighbours.
BOOL CNeighbourFilter::CreateNextFilteredBitmap(const BYTE* pbSrcPixels, BYTE*& pbNewPixels, const CSize& sizImage)
{
	// Don't blame me for the bad variable names in this
	// function - it's not my code! - Mal.

	// Calculate row and column limits of the image
	long nMaxX = sizImage.cx - 1;
	long nMaxY = sizImage.cy - 1;

	// the limits of local area around current pixel
	long startX = 0, endX = 0, startY = 0, endY = 0;

	// the current row of pixels being filtered
	long curX = 0, curY = 0;

	// for iterating through filter matrix indexes
	long filterX = 0, filterY = 0;

	// Number of neighbouring pixels (possibly including the
	// current pixel) that are not transparent
	long nNumTexturedPixels = 0;

	// Number of pixels surrounding, and not including, the
	// current pixel
	long nNumSurroundingPixels = 0;

	// Number of pixels in the image that need to be skipped
	// to move to the next row of the nighbourhood for the
	// current pixel (I think).
	long skip = 0;

	// Offsets within the filter matrix of the edges of the
	// matrix with respect to the centred pixel.
	int filterOffsetLeft = (m_sizFilter.cx - 1) / 2;
	int filterOffsetRight = m_sizFilter.cx - filterOffsetLeft - 1;
	int filterOffsetTop = (m_sizFilter.cy - 1) / 2;
	int filterOffsetBottom = m_sizFilter.cy - filterOffsetTop - 1;

	// Pointers to pixels used during the loops below
	BYTE* pbFirstNeighbourRow = NULL;
	BYTE* pbCurrentNeighbour = NULL;

	// Start by copying all pixels values to the output.  This
	// is simply so that we can quickly check to see whether we're
	// at a transparent pixel - we look at pbOutputPixel.
	memcpy(pbNewPixels, pbSrcPixels, sizImage.cx * sizImage.cy);
	BYTE* pbOutputPixel = pbNewPixels;

	// Make sure the neighbourhood exists
	ASSERT(NULL != m_pbNeighbourhood);
	if (NULL == m_pbNeighbourhood)
		return FALSE;

	for (curY = 0; curY <= nMaxY; curY++)
	{
		startY = max(curY - filterOffsetTop, 0);
		endY = min(curY + filterOffsetBottom, nMaxY);

		// The stupid reference and dereference here are to get around
		// the compiler's insistence on thinking I was changing the
		// value of pbSrcPixels (remember, it's a const BYTE*)
		pbFirstNeighbourRow = (BYTE *)(&(*pbSrcPixels) + (long)startY * sizImage.cx);

		// startX..endX, startY..endY are x,y limits of local area
		// around current pixel, curX,curY. These limits are fixed
		// so's not to exceed overall image boundary.
       	for (curX = 0;curX <= nMaxX;curX++, pbOutputPixel++)
    	{
			// Skip any transparent pixels if the user has selected
			// the Protect Transparency option.
			if (s_bProtectTransparency &&
				GP2_TRANSPARENT_PALETTE_INDEX == *pbOutputPixel)
				continue;

			// Work out where the neighbour begins and ends (this
			// may depend upon how close to the edge of the image
			// the current pixel is)
		   	startX = max(curX - filterOffsetLeft, 0);
			endX = min(curX + filterOffsetRight, nMaxX);
			nNumSurroundingPixels = ((endX - startX + 1) * (endY - startY + 1)) - 1;
			skip = nMaxX + startX - endX;
			pbCurrentNeighbour = pbFirstNeighbourRow + startX;

			// Put the values of the current pixel's neighbours
			// into the neighbourhood array
			for (nNumTexturedPixels = 0, filterY = startY; filterY <= endY;filterY++,pbCurrentNeighbour += skip)
			{
				for (filterX = startX;filterX <= endX;filterX++, pbCurrentNeighbour++)
					if (GP2_TRANSPARENT_PALETTE_INDEX != *pbCurrentNeighbour)
						m_pbNeighbourhood[nNumTexturedPixels++] = *pbCurrentNeighbour;
			}

			// Work out the new value for the current pixel, or leave as it
			// is if it was transparent and there aren't enough textured
			// neighbours for a spread to happen.  (See the header file for
			// a more detailed explanation of the spread factor.)
			if (nNumTexturedPixels > 0 &&
				((GP2_TRANSPARENT_PALETTE_INDEX != *pbOutputPixel) || ((double(nNumTexturedPixels) / double(nNumSurroundingPixels) >= s_dSpreadThreshold))))
				*pbOutputPixel = FilterNeighbourhood(m_pbNeighbourhood, nNumTexturedPixels);
		}
	}

	return TRUE;
}
// End of function 'CreateNextFilteredBitmap'

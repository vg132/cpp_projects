// TintedFilter.cpp - implementation of the CTintedFilter class
//

#include "stdafx.h"
#include "resource.h"

#include "TintedFilter.h"

#include "TexturePalette.h"
#include "Color.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CTintedFilter

// Constructor
CTintedFilter::CTintedFilter(const UINT& nFilterID, const UINT& nStringID)
	: CLocalFilter(nFilterID, nStringID),
	  m_TintColor(RGB(255,63,0)),	// sickly orangey-pink used in McLarens
	  m_nTintFactor(46)
{
	// NOTE: the default reduction factor of 0.5 is taken from
	//       the fact that this value will result in a final
	//       intensity in palette 4 that is 9/10ths of the way
	//       to the tint colour.
	//        i.e. (1.0 * 0.46 * 0.46 * 0.46 ~= 0.1).
}

// Destructor
CTintedFilter::~CTintedFilter()
{
}


// CTintedFilter attributes
//

// Function:	SetTintFactor(nTintFactor)
// Overview:	Set the degree to which the colour of a given pixel
//				will move towards the tint colour.
BOOL CTintedFilter::SetTintFactor (const int nTintFactor)
{
	// Value must be between 0 and 1
	if (nTintFactor <= 0 || nTintFactor >= 100)
		return FALSE;

	// Accept the valid value
	m_nTintFactor = nTintFactor;

	return TRUE;
}
// End of function 'SetTintFactor'



// Overridden filtering functions
//

// Function:	FilterColor(color&)
// Overview:	Just move the given colour toward the tint colour by multiplying
//				its red, green, and blue by the factor in m_nTintFactor
void CTintedFilter::FilterColor(CColor& color)
{
	// Get, reduce, and set the red.
	int nCurrRed = color.GetRed();
	int nTargetRed = m_TintColor.GetRed();
	color.SetRed(nTargetRed + (((nCurrRed - nTargetRed) * m_nTintFactor) / 100));

	// Get, reduce, and set the green.
	int nCurrGreen = color.GetGreen();
	int nTargetGreen = m_TintColor.GetGreen();
	color.SetGreen(nTargetGreen + (((nCurrGreen - nTargetGreen) * m_nTintFactor) / 100));

	// Get, reduce, and set the blue.
	int nCurrBlue = color.GetBlue();
	int nTargetBlue = m_TintColor.GetBlue();
	color.SetBlue(nTargetBlue + (((nCurrBlue - nTargetBlue) * m_nTintFactor) / 100));
}
// End of function 'FilterColor'

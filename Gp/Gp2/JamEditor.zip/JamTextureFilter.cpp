// JamTextureFilter.cpp - implementation of the CJamTextureFilter class
//

#include "stdafx.h"

#include "JamTextureFilter.h"

#include "PixelProfileList.h"
#include "PixelProfile.h"
#include "JamConstants.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CJamTextureFilter

BOOL CJamTextureFilter::s_bProtectTransparency = TRUE;

// Constructor
CJamTextureFilter::CJamTextureFilter(const UINT& nFilterID, const UINT& nStringID)
{
	// Just set the filter ID and name
	m_nFilterID = nFilterID;
	m_strFilterName.LoadString(nStringID);

	// Initialise the temporary pre-filtered storage
	m_pbOriginalPixels = NULL;	// the buffer to store pixels waiting to be filtered
	m_sizImage = CSize(-1,-1);	// the dimensions of the above buffer
}

// Destructor
CJamTextureFilter::~CJamTextureFilter()
{
	ClearOutTemporaryStorage();
}

// Function:	ClearOutTemporaryStorage()
// Overview:	Delete the buffer in which we store pixels between calls
//				to PrepareFilter() and GetBitmaps().
void CJamTextureFilter::ClearOutTemporaryStorage()
{
	if (NULL != m_pbOriginalPixels)
	{
		delete[] m_pbOriginalPixels;
		m_pbOriginalPixels = NULL;
		m_sizImage = CSize(-1,-1);
	}
}
// End of function 'ClearOutTemporaryStorage'



// Overrides from CPaletteImageSource
//

// Function:	GetBitmaps(pixelBuffers, sizImage)
// Overview:	Overridden function to retrieve the pixel buffers to
//				the 4 bitmaps this object provides.  This is the point
//				at which we actually do the filtering
BOOL CJamTextureFilter::GetBitmaps(CPixelBufferArray& pixelBuffers, CSize& sizImage)
{
	// Just ask the CreateFilteredBitmaps function to do the
	// dirty work for us.
	BOOL bSuccess = CreateFilteredBitmaps(pixelBuffers, sizImage);

	// Now that we've had a request for the filtered versions of
	// m_pbOriginalPixels, we can clear them out.
	ClearOutTemporaryStorage();

	return bSuccess;
}
// End of function 'GetBitmaps'



// Filtering functions
//

// Function:	PrepareFilter(pbOriginalPixels, sizImage)
// Overview:	This function prepares the filter for a forthcoming call to
//				GetBitmaps, which will be made by an instance of the
//				CPaletteImageCombiner class.  As soon as that call is made
//				the filter object can ditch its record of the bitmap being
//				filtered.
BOOL CJamTextureFilter::PrepareFilter(const BYTE* pbOriginalPixels, const CSize& sizImage)
{
	// Make sure we've been given a valid pixel buffer.
	ASSERT(NULL != pbOriginalPixels);
	if (NULL == pbOriginalPixels)
		return FALSE;

	// Copy the pixels and store the size of the buffer
	ClearOutTemporaryStorage();
	m_pbOriginalPixels = new BYTE[sizImage.cx * sizImage.cy];
	if (NULL == m_pbOriginalPixels)
		return FALSE;
	memcpy(m_pbOriginalPixels, pbOriginalPixels, sizImage.cx * sizImage.cy);
	m_sizImage = sizImage;

	return TRUE;
}
// End of function 'PrepareFilter'


// Function:	CreateFilteredBitmaps(pixelBuffers&, sizImage&)
// Overview:	This is the function that coordinates the actual filtering
//				performed upon the pixels we were given in the PrepareFilter
//				function.  Return TRUE upon success, FALSE otherwise.
BOOL CJamTextureFilter::CreateFilteredBitmaps(CPixelBufferArray& pixelBuffers, CSize& sizImage)
{
	// Make sure the user has already called PrepareFilter
	if (NULL == m_pbOriginalPixels)
	{
		ASSERT(FALSE);	// not yet called PrepareFilter?
		return FALSE;
	}

	// Check to see that there are the correct number of
	// buffers in the array we've been passed
	ASSERT(NUM_LOCAL_PALETTES_PER_TEXTURE == pixelBuffers.GetSize());
	if (NUM_LOCAL_PALETTES_PER_TEXTURE != pixelBuffers.GetSize())
		return FALSE;

	// Create the pixel buffers for holding the filtered bitmaps
	BOOL bAllocatedOK = TRUE;
	for (int nBmpNum = 0; nBmpNum < NUM_LOCAL_PALETTES_PER_TEXTURE && bAllocatedOK; nBmpNum++)
	{
		pixelBuffers[nBmpNum] = new BYTE[m_sizImage.cx * m_sizImage.cy];
		if (NULL == pixelBuffers[nBmpNum])
		{
			DeleteFilteredBitmaps(pixelBuffers);
			bAllocatedOK = FALSE;
		}
	}
	if (!bAllocatedOK)
		return FALSE;

	// Create the filtered bitmaps, from which we'll determine the
	// local palettes required, and subsequently the raw pixels.
	// We create the first bitmap separately as it is often just a
	// copy of the original bitmap we're importng
	if (!CreateFirstFilteredBitmap(m_pbOriginalPixels, pixelBuffers[0], m_sizImage))
	{
		DeleteFilteredBitmaps(pixelBuffers);
		return FALSE;
	}
	// Now create each of the remaining filtered bitmaps based
	// upon the previous one
	CFrameWnd* pFrameWnd = (CFrameWnd *)AfxGetMainWnd();
	for (int nFilterNum = 1; nFilterNum < NUM_LOCAL_PALETTES_PER_TEXTURE; nFilterNum++)
	{
		// Keep the user informed
		if (NULL != pFrameWnd)
		{
			CString strPrompt("");
			strPrompt.Format("Applying filter to produce texture for palette #%d...", nFilterNum+1);
			pFrameWnd->SetMessageText(strPrompt);
		}

		if (!CreateNextFilteredBitmap(pixelBuffers[nFilterNum - 1], pixelBuffers[nFilterNum], m_sizImage))
		{
			DeleteFilteredBitmaps(pixelBuffers);
			return FALSE;
		}
	}

	sizImage = m_sizImage;

	return TRUE;
}
// End of function 'CreateFilteredBitmaps'


// Function:	DeleteFilteredBitmaps(pixelBuffers&)
// Overview:	Handle with care!  This function is to be used to
//				make tidying up the filtered bitmaps easier when
//				something goes wrong.
void CJamTextureFilter::DeleteFilteredBitmaps(CPixelBufferArray& pixelBuffers)
{
	// Go through the bitmaps already allocated and deallocate
	// their memory
	for (int nDelNum = 0; nDelNum < NUM_LOCAL_PALETTES_PER_TEXTURE; nDelNum++)
	{
		if (NULL != pixelBuffers[nDelNum])
		{
			delete[] pixelBuffers[nDelNum];
			pixelBuffers[nDelNum] = NULL;
		}
	}
}
// End of function 'DeleteFilteredBitmaps'


// Function:	CreateFirstFilteredBitmap(pbBitmapPixels, pbNewPixels, sizImage)
// Overview:	Create the decoded version of the texture as seen when using
//				palette #1.  Generally, this is simply a copy of the actual
//				bitmap pixels we're importing/filtering.
BOOL CJamTextureFilter::CreateFirstFilteredBitmap(const BYTE* pbBitmapPixels, BYTE*& pbNewPixels, const CSize& sizImage)
{
	try
	{
		// Just do a straight memcpy from the bitmap into the
		// first decoded texture
		memcpy(pbNewPixels, pbBitmapPixels, sizImage.cx * sizImage.cy);
	}
	catch (CException* pExc)
	{
		// Just delete the exception and let the calling function
		// know that we failed
		ASSERT(FALSE);
		pExc->Delete();
		return FALSE;
	}

	// Success! :)
	return TRUE;
}
// End of function 'CreateFirstFilteredBitmap'



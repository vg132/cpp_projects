// SetBuilderView.cpp : implementation of the CSetBuilderView class
//

#include "stdafx.h"
#include "SetBuilder.h"
#include "Shlwapi.h"

#include "SetBuilderDoc.h"
#include "SetBuilderView.h"

#include "CPreviewFileDialog.h"
#include "Gp3FileInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSetBuilderView

IMPLEMENT_DYNCREATE(CSetBuilderView, CFormView)

BEGIN_MESSAGE_MAP(CSetBuilderView, CFormView)
	//{{AFX_MSG_MAP(CSetBuilderView)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_NOTIFY(NM_DBLCLK, IDC_TRACK_LIST, OnDblclkTrackList)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_NOTIFY(LVN_KEYDOWN, IDC_TRACK_LIST, OnKeydownTrackList)
	ON_COMMAND(ID_HELP_VGSOFTWAREONLINE, OnHelpVgsoftwareonline)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CFormView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetBuilderView construction/destruction

CSetBuilderView::CSetBuilderView()
	: CFormView(CSetBuilderView::IDD)
{
	//{{AFX_DATA_INIT(CSetBuilderView)
	//}}AFX_DATA_INIT
	// TODO: add construction code here

}

CSetBuilderView::~CSetBuilderView()
{
}

void CSetBuilderView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSetBuilderView)
	DDX_Control(pDX, IDC_TRACK_LIST, m_TrackList);
	//}}AFX_DATA_MAP
}

BOOL CSetBuilderView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CSetBuilderView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

	DWORD exStyle=LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES;
	m_TrackList.SetExtendedStyle(exStyle);
	TrackSetHandler.NewFile();
	m_TrackList.InsertColumn(0,"Nr",LVCFMT_LEFT,25,-1);
	m_TrackList.InsertColumn(1,"Track Name",LVCFMT_LEFT,100,-1);
	m_TrackList.InsertColumn(2,"Country",LVCFMT_LEFT,100,-1);
	m_TrackList.InsertColumn(3,"Laps",LVCFMT_LEFT,50,-1);
	m_TrackList.InsertColumn(4,"Length (m)",LVCFMT_LEFT,80,-1);
	m_TrackList.InsertColumn(5,"Tyre Ware",LVCFMT_LEFT,80,-1);
	PaintListBox();
	szFileTitle = "Untitled";
	SetTitle(true);
}

/////////////////////////////////////////////////////////////////////////////
// CSetBuilderView printing

BOOL CSetBuilderView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CSetBuilderView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CSetBuilderView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CSetBuilderView::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	// TODO: add customized printing code here
}

/////////////////////////////////////////////////////////////////////////////
// CSetBuilderView diagnostics

#ifdef _DEBUG
void CSetBuilderView::AssertValid() const
{
	CFormView::AssertValid();
}

void CSetBuilderView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CSetBuilderDoc* CSetBuilderView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSetBuilderDoc)));
	return (CSetBuilderDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CSetBuilderView message handlers

void CSetBuilderView::OnFileOpen() 
{
CFileDialog dialog(TRUE,"set",NULL,NULL,"Track Set Files (*.set)|*.set|All Files (*.*)|*.*||",NULL);
	if(dialog.DoModal()==IDOK)
	{
		szFile=dialog.m_ofn.lpstrFile;
		TrackSetHandler.LoadFile(szFile);
		szFileTitle = dialog.m_ofn.lpstrFileTitle;
		SetTitle(true);
		PaintListBox();
	}
}

void CSetBuilderView::PaintListBox()
{
CGp3FileInfo fi;
char c[1];
WIN32_FIND_DATA wfd;
bool FileNotFound=false;
char *cTemp;
char *cFile;
char *cMessage;

	m_TrackList.DeleteAllItems();
	for(int i=0;i<16;i++)
	{
		itoa(i+1,c,10);
		m_TrackList.InsertItem(i,c,NULL);
		cFile = new char[260];
		cTemp = new char[260];
		TrackSetHandler.GetTrack(i,cTemp);
		GetGp3Dir(cFile);
		strcat(cFile,"\\");
		strcat(cFile,cTemp);
		if((FindFirstFile(cTemp,&wfd)!=(HANDLE)-1)||(FindFirstFile(cFile,&wfd)!=(HANDLE)-1))
		{
			if(FindFirstFile(cTemp,&wfd)!=(HANDLE)-1)
				TrackSetHandler.GetTrack(i,cFile);
			fi.LoadInfo(cFile);
			m_TrackList.SetItem(i,1,LVIF_TEXT ,fi.GetName(),NULL,NULL,NULL,NULL);
			m_TrackList.SetItem(i,2,LVIF_TEXT ,fi.GetCountry(),NULL,NULL,NULL,NULL);
			m_TrackList.SetItem(i,3,LVIF_TEXT ,fi.GetLaps(),NULL,NULL,NULL,NULL);
			m_TrackList.SetItem(i,4,LVIF_TEXT ,fi.GetLength(),NULL,NULL,NULL,NULL);
			m_TrackList.SetItem(i,5,LVIF_TEXT, fi.GetWare(),NULL,NULL,NULL,NULL);
		}
		else
		{
			if(cTemp[0]!='\0')
			{
				cMessage = new char[300];
				cMessage = "File \"\0";
				strcat(cMessage,cTemp);
				strcat(cMessage,"\" could not be found.\0");
				MessageBox(cMessage,"Gp3 SetBuilder - File Not Found",MB_ICONWARNING);
				delete[] cMessage;
			}
			m_TrackList.SetItem(i,1,LVIF_TEXT ,"-No Track-",NULL,NULL,NULL,NULL);
			m_TrackList.SetItem(i,2,LVIF_TEXT ,"-No Country-",NULL,NULL,NULL,NULL);
			m_TrackList.SetItem(i,3,LVIF_TEXT ,"",NULL,NULL,NULL,NULL);
			m_TrackList.SetItem(i,4,LVIF_TEXT ,"",NULL,NULL,NULL,NULL);
			m_TrackList.SetItem(i,5,LVIF_TEXT,"",NULL,NULL,NULL,NULL);
		}
		delete[] cFile;
		delete[] cTemp;
	}
}

void CSetBuilderView::OnDblclkTrackList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	int m_CurItem=((NM_LISTVIEW *)pNMHDR)->iItem;

	CPreviewFileDialog FileDialog(TRUE);
	if(FileDialog.DoModal()==IDOK)
	{
		TrackSetHandler.SetTrack(m_CurItem,FileDialog.m_ofn.lpstrFile);	
		SetTitle(false);
		PaintListBox();
	}
	*pResult = 0;
}

void CSetBuilderView::OnFileSave() 
{
	if(szFile!="")
	{
		TrackSetHandler.SaveFile(szFile);
		SetTitle(true);
	}
	else
		OnFileSaveAs();
}

void CSetBuilderView::OnFileSaveAs() 
{
CFileDialog dialog(FALSE,"set",NULL,NULL,"Track Set Files (*.set)|*.set|All Files (*.*)|*.*||",NULL);
	if(dialog.DoModal()==IDOK)
	{
		szFile=dialog.m_ofn.lpstrFile;
		TrackSetHandler.SaveFile(szFile); 
		szFileTitle = dialog.m_ofn.lpstrFileTitle;
		SetTitle(true);
	}
}

void CSetBuilderView::OnFileNew() 
{
	TrackSetHandler.NewFile();
	szFileTitle = "Untitled";
	szFile = "";
	SetTitle(true);
	PaintListBox();
}

void CSetBuilderView::SetTitle(bool saved)
{
	CString szTitle = "Gp3 Set Builder - [";
	szTitle+= szFileTitle;
	if(saved==false)
		szTitle+="*]";
	else
		szTitle+="]";
	AfxGetMainWnd()->SetWindowText(szTitle);
}

void CSetBuilderView::OnKeydownTrackList(NMHDR* pNMHDR, LRESULT* pResult) 
{
int nItem;
POSITION pos=m_TrackList.GetFirstSelectedItemPosition();
	if(pos==NULL)
		return;
	nItem=m_TrackList.GetNextSelectedItem(pos);
	LV_KEYDOWN* pLVKeyDow = (LV_KEYDOWN*)pNMHDR;

	int i=((LV_KEYDOWN*)pLVKeyDow)->wVKey;
	if(i==VK_DELETE)
	{
		TrackSetHandler.SetTrack(nItem,"");
		SetTitle(false);
		PaintListBox();
	}
	*pResult = 0;
}

void CSetBuilderView::OnHelpVgsoftwareonline() 
{
	ShellExecute(m_hWnd,"open","http://www.vgsoftware.com/",NULL,NULL,1);	
}

void CSetBuilderView::GetGp3Dir(char *cGp3Dir)
{
char lpBuffer[260];
unsigned long lwSize(260);
HKEY phKey(NULL);
unsigned long lwType;

	if (RegOpenKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microprose\\Grand Prix 3\\3.00.000\\Install Dir",&phKey)==ERROR_SUCCESS)
		RegQueryValueEx(phKey,"Directory",NULL,&lwType,(LPBYTE)lpBuffer,&lwSize);
	strcpy(cGp3Dir,lpBuffer);
}

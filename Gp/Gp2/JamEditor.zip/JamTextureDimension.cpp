// JamTextureDimension.cpp - implementation of the CJamTextureDimension class
//

#include "stdafx.h"

#include "JamTextureDimension.h"

#include "JamTexture.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CJamTextureDimension construction/destruction

CJamTextureDimension::CJamTextureDimension(int nDimensionType, CJamTexture* pParent)
	: CEditableObject(pParent)
{
	ASSERT(nDimensionType == DIM_WIDTH || nDimensionType == DIM_HEIGHT);
	m_nDimensionType = nDimensionType;
}

CJamTextureDimension::~CJamTextureDimension()
{
}


/////////////////////////////////////////////////////////////////////////////
// CJamTextureDimension operations

CString CJamTextureDimension::GetFullDescription()
{
	CString strDesc("Error");
	CJamTexture* pTexture = (CJamTexture *)m_pParent;
	switch (m_nDimensionType)
	{
	case DIM_WIDTH:
		strDesc.Format("Width: %d", pTexture->GetWidth());
		break;
	case DIM_HEIGHT:
		strDesc.Format("Height: %d", pTexture->GetHeight());
		break;
	}

	return strDesc;
}

CString CJamTextureDimension::GetValueToEdit()
{
	WORD wSize = 0;
	CJamTexture* pTexture = (CJamTexture *)m_pParent;
	switch (m_nDimensionType)
	{
	case DIM_WIDTH:
		wSize = pTexture->GetWidth();
		break;
	case DIM_HEIGHT:
		wSize = pTexture->GetHeight();
		break;
	}

	CString strValue;
	strValue.Format("%d", wSize);
	return strValue;
}

BOOL CJamTextureDimension::ChangeDataFromEdit(CString string)
{
	// Get the new value and set the new height/width
	WORD wSize = (WORD)atoi(string);
	CJamTexture* pTexture = (CJamTexture *)m_pParent;
	BOOL bSuccess = FALSE;
	switch (m_nDimensionType)
	{
	case DIM_WIDTH:
		bSuccess = pTexture->SetWidth(wSize);
		break;
	case DIM_HEIGHT:
		bSuccess = pTexture->SetHeight(wSize);
		break;
	}

	// Update the rest of the program
	if (bSuccess)
	{
		DataHasChanged(NULL, HINT_TEXTURE_PROPERTIES_CHANGED, NULL);
	}

	return bSuccess;
}


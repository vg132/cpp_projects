// ImportBitmapDialog.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "ImportBitmapDialog.h"

#include "ImageFilePreview.h"
#include "JamTextureFilterManager.h"
#include "JamTextureFilter.h"
#include "JamTextureFilterIDs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CImportBitmapDialog

IMPLEMENT_DYNAMIC(CImportBitmapDialog, CPreviewFileDialog)

CImportBitmapDialog::CImportBitmapDialog(BOOL bOpenFileDialog, LPCTSTR lpszDefExt, LPCTSTR lpszFileName,
		DWORD dwFlags, LPCTSTR lpszFilter, CWnd* pParentWnd) :
		CPreviewFileDialog(bOpenFileDialog, lpszDefExt, lpszFileName, dwFlags, lpszFilter, pParentWnd)
{
	//{{AFX_DATA_INIT(CImportBitmapDialog)
	m_nWidth = 0;
	m_nHeight = 0;
	m_nFilterIndex = -1;
	m_bProtectTransparency = TRUE;
	//}}AFX_DATA_INIT

	m_nReqWidth = 0;
	m_nReqHeight = 0;

	m_bEnableFiltering = TRUE;
	m_nFilterID = NULL_FILTER;
}


BEGIN_MESSAGE_MAP(CImportBitmapDialog, CPreviewFileDialog)
	//{{AFX_MSG_MAP(CImportBitmapDialog)
	ON_CBN_SELCHANGE(IDC_FILTER_LIST, OnSelectImportFilter)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


// Standard dialog messages and handling

// Function:	DoDataExchange(pDX)
// Overview:	Overridden for the extra preview controls
void CImportBitmapDialog::DoDataExchange(CDataExchange* pDX)
{
	CPreviewFileDialog::DoDataExchange(pDX);

	if (!IsPreviewInUse())
		return;

	//{{AFX_DATA_MAP(CImportBitmapDialog)
	DDX_Text(pDX, IDC_IMAGE_WIDTH, m_nWidth);
	DDX_Text(pDX, IDC_IMAGE_HEIGHT, m_nHeight);
	DDX_CBIndex(pDX, IDC_FILTER_LIST, m_nFilterIndex);
	DDX_Check(pDX, IDC_PROTECT_TRANSPARENCY, m_bProtectTransparency);
	//}}AFX_DATA_MAP

	// Things we want greater control over...

	// If the required height and width have not been set
	// i.e. they're zero, don't bother with the data
	// exchange.  Just let the OnInitDialog put "n/a" into
	// them instead
	if (m_nReqWidth != 0 && m_nReqHeight != 0)
	{
		DDX_Text(pDX, IDC_REQUIRED_WIDTH, m_nReqWidth);
		DDX_Text(pDX, IDC_REQUIRED_HEIGHT, m_nReqHeight);
	}
}
// End of function 'DoDataExchange'


// Function:	DoModal()
// Overview:	Overridden to store the selected import filter in the
//				app's INI file.
int CImportBitmapDialog::DoModal() 
{
	// Let the base class do all of the usual stuff...
	int nResult = CPreviewFileDialog::DoModal();

	// ...then store the selected filter as the default (if
	// the dialog was in use as an Import rather than Export
	// dialog)
	if ((IDOK == nResult) && IsPreviewInUse())
	{
		AfxGetApp()->WriteProfileInt("Driving Conditions", "Import Filter", m_nFilterID);
		CJamTextureFilter::s_bProtectTransparency = m_bProtectTransparency;
	}

	return nResult;
}
// End of function 'DoModal'


// Function:	OnInitDialog()
// Overview:	Overridden to put appropriate values into the
//				required height and width statics
BOOL CImportBitmapDialog::OnInitDialog() 
{
	CPreviewFileDialog::OnInitDialog();
	
	// Make sure the required width and height fields say
	// something sensible if we're not importing a bitmap.
	if ((m_nReqWidth == 0 || m_nReqHeight == 0) && IsPreviewInUse())
	{
		GetDlgItem(IDC_REQUIRED_WIDTH)->SetWindowText("n/a");
		GetDlgItem(IDC_REQUIRED_HEIGHT)->SetWindowText("n/a");
	}

	// Initialise the filter combo with the names and IDs
	// of all available filters
	if (!m_bEnableFiltering)
	{
		// Disable the drop-down filter list
		CWnd* pFilterCombo = GetDlgItem(IDC_FILTER_LIST);
		if (NULL != pFilterCombo)
			pFilterCombo->EnableWindow(FALSE);

		// Disable the Protect Transparency option
		CWnd* pProtectCheckbox = GetDlgItem(IDC_PROTECT_TRANSPARENCY);
		if (NULL != pProtectCheckbox)
			pProtectCheckbox->EnableWindow(FALSE);
	}
	else if (IsPreviewInUse())
	{
		// Set the value in the Protect Transparency checkbox to
		// reflect the status of the option.
		m_bProtectTransparency = CJamTextureFilter::s_bProtectTransparency;

		// Get the default filter ID from the INI file, ready to
		// select its entry when added to the list
		int nDefaultFilterID = AfxGetApp()->GetProfileInt("Driving Conditions", "Import Filter", -1);

		// Now add all filter
		CComboBox* pFilterCombo = (CComboBox *)GetDlgItem(IDC_FILTER_LIST);
		pFilterCombo->ResetContent();
		CJamTextureFilterManager* pFilterMgr = CJamTextureFilterManager::GetManager();
		if (NULL != pFilterMgr)
		{
			// Cycle through the filters in the filter manager,
			// getting their names and IDs
			POSITION posFilter = pFilterMgr->GetFirstFilterPos();
			while (NULL != posFilter)
			{
				// Get the next filter in the manager
				CJamTextureFilter* pFilter = pFilterMgr->GetNextFilter(posFilter);
				ASSERT(NULL != pFilter);
				if (NULL == pFilter)
					continue;

				// Add this filter to the list and set its ID as the
				// item's data
				CString strFilterName = pFilter->GetFilterName();
				int nFilterID = pFilter->GetFilterID();
				int nNewIndex = pFilterCombo->AddString(strFilterName);
				if (-1 != nNewIndex)
				{
					pFilterCombo->SetItemData(nNewIndex, (DWORD)nFilterID);

					// If this is the default filter, select it now
					if (nFilterID == nDefaultFilterID)
					{
						m_nFilterIndex = nNewIndex;
						m_nFilterID = nDefaultFilterID;
					}
				}
			}
		}

		// If we didn't find the default filter in the filter manager,
		// just select the first in the list
		if (-1 == m_nFilterIndex)
		{
			m_nFilterIndex = 0;
			m_nFilterID = pFilterCombo->GetItemData(m_nFilterIndex);
		}

		UpdateData(FALSE);
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
// End of function 'OnInitDialog'


// Function:	OnSelectImportFilter()
// Overview:	Handle a change in the selection of the import filter
//				to keep track of the filter's internal ID.
void CImportBitmapDialog::OnSelectImportFilter()
{
	// Make sure this class's data is up-to-date
	UpdateData(TRUE);

	if (m_nFilterIndex == -1)
	{
		// It should be impossible to deselect all in a combo
		ASSERT(FALSE);
		m_nFilterID = NULL_FILTER;
	}
	else
	{
		// Extract the ID of the chosen filter from the item
		// data for the selected item,
		CComboBox* pFilterCombo = (CComboBox *)GetDlgItem(IDC_FILTER_LIST);
		m_nFilterID = (int)pFilterCombo->GetItemData(m_nFilterIndex);
	}
}
// End of function 'OnSelectImportFilter'


// Function:	GetSelectedFilter()
// Overview:	Reporting of the chosen import filter using its filter ID.
CJamTextureFilter* CImportBitmapDialog::GetSelectedFilter()
{
	CJamTextureFilterManager* pFilterMgr = CJamTextureFilterManager::GetManager();
	if (NULL == pFilterMgr)
		return NULL;

	return pFilterMgr->GetFilter(m_nFilterID);
}
// End of function 'GetSelectedFilter'



/////////////////////////////////////////////////////////////////////////////
// CImportBitmapDialog overrides

// Function:	SetPreviewFile(strFilename)
// Overview:	Show a preview of the given file in the static.
BOOL CImportBitmapDialog::SetPreviewFile(const CString& strFilename)
{
	// Call the nase class first to get the new preview
	if (!CPreviewFileDialog::SetPreviewFile(strFilename))
		return FALSE;

	// Tell the static control which file we want it to show
	CFilePreview* pPreview = m_stcPreview.GetPreviewer();
	if (NULL == pPreview)
		return TRUE;	// well, we managed something anyway

	// If the current preview type is an image previewer, get its
	// height and wisth information
	if (pPreview->IsKindOf(RUNTIME_CLASS(CImageFilePreview)))
	{
		CImageFilePreview* pImagePreview = (CImageFilePreview *)pPreview;
		m_nHeight = pImagePreview->GetImageHeight();
		m_nWidth = pImagePreview->GetImageWidth();
	}
	else
	{
		m_nHeight = 0;
		m_nWidth = 0;
	}
	UpdateData(FALSE);

	return TRUE;
}
// End of function 'SetPreviewFile'


// Function:	GetPreviewTemplateID()
// Overview:	Overridden to specify the dialog template to
//				use for the preview area.
UINT CImportBitmapDialog::GetPreviewTemplateID () const
{
	// Just return the default template, which contains a preview
	// pane and nothing else.
	return IDD_IMPORT_BITMAP_PREVIEW;
}
// End of function 'GetPreviewTemplateID'

// PreviewFileDialog.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "PreviewFileDialog.h"

#include <dlgs.h>
#include "FilenameParser.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPreviewFileDialog

IMPLEMENT_DYNAMIC(CPreviewFileDialog, CFileDialog)

CPreviewFileDialog::CPreviewFileDialog(BOOL bOpenFileDialog, LPCTSTR lpszDefExt, LPCTSTR lpszFileName,
		DWORD dwFlags, LPCTSTR lpszFilter, CWnd* pParentWnd) :
		CFileDialog(bOpenFileDialog, lpszDefExt, lpszFileName, dwFlags, lpszFilter, pParentWnd)
{
}

CPreviewFileDialog::~CPreviewFileDialog()
{
	// Empty the list of previewable file types
	m_lstPreviewableFileTypes.RemoveAll();
}


BEGIN_MESSAGE_MAP(CPreviewFileDialog, CFileDialog)
	//{{AFX_MSG_MAP(CPreviewFileDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CPreviewFileDialog creation/initialisation

// Function:	DoModal()
// Overview:	Overridden to get the template ID to use for the
//				preview area.  Note that the GetPreviewTemplateID
//				can not simply be called from the constructor as
//				dynamic binding won't work in constructors and
//				destructors (for reasons I'm not about to go into
//				- see the online C++ FAQ).
int CPreviewFileDialog::DoModal() 
{
	// If this is an Open dialog, get the template ID of the
	// dialog template to use for the preview.  If a value of
	// zero is returned, take this as meaning "don't use a
	// template".
	if (m_bOpenFileDialog)	// protected implementation in CFileDialog
	{
		UINT nTemplateID = GetPreviewTemplateID();
		if (nTemplateID != 0)
		{
			// Remember that we need certain flags for the
			// template stuff to work.
			m_ofn.Flags |= (OFN_ENABLETEMPLATE | OFN_EXPLORER);
			m_ofn.lpTemplateName = MAKEINTRESOURCE(nTemplateID);

			// Work out the allowed preview types
			CString strFilter = m_ofn.lpstrFilter;
			ParsePreviewableFileTypes();
		}
	}

	// Now just get on with it
	return CFileDialog::DoModal();
}
// End of function 'DoModal'


// Function:	GetPreviewTemplateID()
// Overview:	Override this to specify the dialog template to
//				use for the preview area.
UINT CPreviewFileDialog::GetPreviewTemplateID () const
{
	// Just return the default template, which contains a preview
	// pane and nothing else.
	return IDD_FILEDIALOG_PREVIEW;
}
// End of function 'GetPreviewTemplateID'


// Function:	OnInitDialog()
// Overview:	Set up the dialog controls and initialise any
//				values in them.
BOOL CPreviewFileDialog::OnInitDialog() 
{
	// Perform usual initialisation
	CFileDialog::OnInitDialog();
	
	// Attach the static in the dialog to the preview member
	if (IsPreviewInUse())
		m_stcPreview.SubclassDlgItem(IDC_PREVIEW, this);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
// End of function 'OnInitDialog'


// Function:	IsPreviewInUse()
// Overview:	Internal checking to see whether the dialog's
//				preview area is being used.  This is really
//				just for use after DoModal() has been called.
BOOL CPreviewFileDialog::IsPreviewInUse () const
{
	// Just perform a simple check to see whether the preview
	// template is being used
	return ((m_ofn.Flags & OFN_ENABLETEMPLATE) == OFN_ENABLETEMPLATE);
}
// End of function 'IsPreviewInUse'



/////////////////////////////////////////////////////////////////////////////
// CPreviewFileDialog previewing overrides

// Function:	OnFileNameChange()
// Overview:	Handler for when the user selects a new file in the
//				list control.  This should trigger a preview of the
//				newly-selected file to be displayed.
void CPreviewFileDialog::OnFileNameChange()
{
	// Call any base class handling first
	CFileDialog::OnFileNameChange();

	// Don't need to do anything if we're not showing the
	// preview controls
	if (!IsPreviewInUse())
		return;

	// Just set the path of the currently selected file as the
	// one to preview.  However, we should make sure the file
	// exists first (in case the user has just typed in rubbish)
	CString strFilename(GetPathName());
	CFilenameParser fnFilename(strFilename);
	if (fnFilename.Exists())
		SetPreviewFile(strFilename);
	else
		SetPreviewFile("");
}
// End of function 'OnFileNameChange'


// Function:	OnFolderChange()
// Overview:	Handler for when the user changes directory in the
//				dialog.  This should cause the current preview (if
//				there is one) to be cleared.
void CPreviewFileDialog::OnFolderChange()
{
	// Call any base class handling first
	CFileDialog::OnFolderChange();

	// Don't need to do anything if we're not showing the
	// preview controls
	if (!IsPreviewInUse())
		return;

	// Reset the preview so that it's not showing anything
	SetPreviewFile("");
}
// End of function 'OnFolderChange'


// Function:	SetPreviewFile(strFilename)
// Overview:	Show a preview of the given file in the preview static.
//				Return TRUE or FALSE to indicate whether we did or
//				didn't show a preview.
BOOL CPreviewFileDialog::SetPreviewFile(const CString& strFilename)
{
	// Just check to see whether the preview window
	// is actually there!
	ASSERT(IsPreviewInUse());
	if (!IsPreviewInUse())
		return FALSE;

	// Check to see whether the dialog wants to show this type of
	// file in its preview.
	// Reason: suppose we have 2 types/ of dialog that support
	// previews - Open Document and Import Image.  It wouldn't make
	// sense to show document previews in the Import Image dialog,
	// but that's what would happen if the dialog itself weren't
	// able to specify which types of preview it wants.  The preview
	// static just tries to find a preview for whatever file type
	// you give it.
	BOOL bShowPreview = IsPreviewableFile(strFilename);

	// Tell the static control which file we want it to show
	if (bShowPreview)
		m_stcPreview.SetFilename(strFilename);
	else
		m_stcPreview.SetFilename("");

	// Now just make sure the static repaints :)
	CWnd* pPreviewWnd = GetDlgItem(IDC_PREVIEW);
	ASSERT(NULL != pPreviewWnd);
	if (NULL != pPreviewWnd)
		pPreviewWnd->Invalidate();

	return TRUE;
}
// End of function 'SetPreviewFile'


// Function:	OnTypeChange()
// Overview:	Called when the user changes the selection in the Files
//				Of Type drop-down.  Handled here to change the extension
//				of the filename currently selected.
void CPreviewFileDialog::OnTypeChange()
{
	// This is more hassle than it's worth, but here goes...

	// Remember, we only want to do this if this is a Save As dialog.
	if (!m_bOpenFileDialog)
	{
		// Work out the newly-selected filter's extension and whether
		// or not it represents a *single* extension.  If the filter
		// represents multiple extensions, just don't bother changing
		// the file's current extension at all.
		CString strNewExtension("");
		if (GetSingleFilterExtension(m_ofn.nFilterIndex, strNewExtension))
		{
			// Ok, we're in business.  Now to set the current filename's
			// new extension.  We'll first retrieve the current filename
			// by getting it directly from the edit box, as otherwise we
			// would risk replacing a relative path with a full path, or
			// vice versa.
			CWnd* pEdit = GetParent()->GetDlgItem(edt1); 	// edt1 is defined in <dlgs.h>
			ASSERT(NULL != pEdit); 							// this should never fail
			CString strCurrFilename("");
			pEdit->GetWindowText(strCurrFilename);
			CString strNewFilename("");
			if (strCurrFilename.IsEmpty())
			{
				// Just make the filename *.EXT
				strNewFilename = "*" + strNewExtension;
			}
			else
			{
				// Put the .EXT extension onto the existing filename
				CFilenameParser fnNewFilename(strCurrFilename);
				fnNewFilename.Extension() = strNewExtension;
				strNewFilename = fnNewFilename.GetFullSpec();
			}
			pEdit->SetWindowText(strNewFilename);
		}
	}
}
// End of function 'OnTypeChange'


// Function:	GetSingleFilterExtension(nFilterIndex, strExtension&)
// Overview:	Get the file extension associated with the filter at
//				the given index in the Files Of Type list.  However,
//				if that filter represents more than one file extension,
//				just return FALSE.
BOOL CPreviewFileDialog::GetSingleFilterExtension(const int nFilterIndex, CString& strExtension)
{
	// First we need to separate out the individual filters (not
	// the individual extensions).
	CStringList lstFilterExtensions;
	if (!GetFilterExtensions(GetFiltersForParsing(), lstFilterExtensions))
	{
		ASSERT(FALSE);
		return FALSE;
	}

	// Get the position in the list of the filter at the given
	// position (remember that nFilterIndex is 1-based (for some
	// reason beyond my recollection).
	POSITION posFilter = lstFilterExtensions.FindIndex(nFilterIndex - 1);
	if (NULL == posFilter)
	{
		ASSERT(FALSE);
		return FALSE;
	}

	// Get the actual filter string and check to see whether it
	// contains more than one extension.
	CString strFilter = lstFilterExtensions.GetAt(posFilter);
	if (-1 != strFilter.Find(';'))
		return FALSE;	// more than one extension!

	// Avoid returning ".*" for the All Files filter
	if (strFilter == "*.*")
		return FALSE;

	// Now just strip the asterisk from the front of the extension
	// and return it in the strExtension parameter
	int nDotPos = strFilter.ReverseFind('.');
	ASSERT(-1 != nDotPos);
	strExtension = strFilter.Mid(nDotPos);	// keep the dot
	strExtension.MakeLower();				// make it slightly prettier

	return TRUE;
}
// End of function 'GetSingleFilterExtension'



/////////////////////////////////////////////////////////////////////////////
// CPreviewFileDialog previewable file types

// Function:	GetFiltersForParsing()
// Overview:	Convert the NULL-delimited filter string in m_ofn
//				into the form in which it's entered in the string
//				resources.  This makes it a hell of a lot easier
//				for parsing as routines like CString::Find don't
//				get confused about end-of-string conditions.
CString CPreviewFileDialog::GetFiltersForParsing() const
{
	// Make a copy of the filter string and replace all of its
	// null characters with the '|' character so that we can use
	// if properly with CString's fucntions.  This code is taken
	// from CFileDialog::Dump() as I didn't know how else to handle
	// strings with null chars in them.
	LPCTSTR lpstrItem = m_ofn.lpstrFilter;
	LPTSTR lpszBreak = _T("|");
	CString strFilter("");
	while (lpstrItem != NULL && *lpstrItem != '\0')
	{
		strFilter += CString(lpstrItem);
		strFilter += lpszBreak;
		lpstrItem += lstrlen(lpstrItem) + 1;
	}
	if (lpstrItem != NULL)
		strFilter += lpszBreak;

	return strFilter;
}
// End of function 'GetFiltersForParsing'


// Function:	GetFilterExtensions(strAllFilters, lstFilterExtensions&)
// Overview:	Given the string of all filters used in the dialog (in
//				a parsable, pipe-delimited form), fill the CStringList
//				with the "*.EXT" or "*.EX1;*.EX2" bits of the filters.
//				This does *not* separate multi-extension filters into
//				their own entries in the list.
BOOL CPreviewFileDialog::GetFilterExtensions(CString strAllFilters, CStringList& lstFilterExtensions) const
{
	BOOL bSuccess = TRUE;
	while (!strAllFilters.IsEmpty())
	{
		// Skip the bit of the next filter type that appears
		// in the drop-down list.  If there isn't another one,
		// the only remaining char will be a '|'
		int nSeparatorPos = strAllFilters.Find('|');
		if (nSeparatorPos < 1)	// includes -1, which means it wasn't found
		{
			// Finished!
			strAllFilters.Empty();
			continue;
		}

		// Chop the unwanted part off and get the actual filter
		// part of out of the string
		strAllFilters = strAllFilters.Mid(nSeparatorPos + 1);
		nSeparatorPos = strAllFilters.Find('|');
		if (nSeparatorPos < 1)	// includes -1, which means it wasn't found
		{
			// Hmmm... appears to be a cock-up in the format
			ASSERT(FALSE);
			bSuccess = FALSE;
			strAllFilters.Empty();
			continue;
		}

		// Get the types out of this clause and cut the filter
		// string down again, ready for the next bit.
		CString strTypes = strAllFilters.Left(nSeparatorPos);
		strAllFilters = strAllFilters.Mid(nSeparatorPos + 1);

		// Add the extensions for this filter to our stringlist
		lstFilterExtensions.AddTail(strTypes);
	}

	return bSuccess;
}
// End of function 'GetFilterExtensions'


// Function:	ParsePreviewableFileTypes()
// Overview:	Determine which file types can be previewed by this
//				dialog, based on the filter set in the constructor.
void CPreviewFileDialog::ParsePreviewableFileTypes()
{
	// First, empty the list of previewable file types
	m_lstPreviewableFileTypes.RemoveAll();

	// Go through our filter string, parsing out the *.??? bits.
	// First we need to separate out the individual filters (not
	// the individual extensions).
	CStringList lstFilterExtensions;
	if (!GetFilterExtensions(GetFiltersForParsing(), lstFilterExtensions))
	{
		ASSERT(FALSE);
		return;
	}

	// Now go through each of the filters, adding its extension(s)
	// to our record of previewable file types.
	POSITION posFilter = lstFilterExtensions.GetHeadPosition();
	while (NULL != posFilter)
	{
		// Get the next batch of file extensions...
		CString strTypes = lstFilterExtensions.GetNext(posFilter);

		// ...and parse the "*.abc;*.123;*.xyz" bit
		BOOL bParsedTypes = FALSE;
		while (!bParsedTypes)
		{
			// Get the position of the end of the next *.??? type
			int nSemiColonPos = strTypes.Find(';');
			if (-1 == nSemiColonPos)
			{
				nSemiColonPos = strTypes.GetLength();
				bParsedTypes = TRUE;	// this will be the last
			}

			// Get this next *.??? clause
			CString strThisType = strTypes.Left(nSemiColonPos);
			strTypes = strTypes.Mid(nSemiColonPos + 1);
			if (strThisType == "*.*")
				continue;	// don't add the All Files type to our list!

			int nDotPos = strThisType.ReverseFind('.');
			ASSERT(-1 != nDotPos);
			strThisType = strThisType.Mid(nDotPos);	// keep the dot

			// Add this extension to the list of valid ones
			m_lstPreviewableFileTypes.AddTail(strThisType);
		}
	}
}
// End of function 'ParsePreviewableFileTypes'


// Function:	IsPreviewableFile(strFileName)
// Overview:	Check whether the given file can be previewed.  Logic
//				is based upon the file's extension here, but can be
//				overridden in derived classes.
BOOL CPreviewFileDialog::IsPreviewableFile(const CString& strFileName) const
{
	// If there's nothing in our list of previewable file types,
	// just assume that the filter drop-down has only *.* and try
	// to preview absolutely anything that gets selected. :)
	if (m_lstPreviewableFileTypes.GetCount() == 0)
		return TRUE;

	// Just check to see whether the file's extension is in our
	// list of supported file types
	CFilenameParser parsedFileName(strFileName);
	POSITION posType = m_lstPreviewableFileTypes.GetHeadPosition();
	BOOL bFound = FALSE;
	while (NULL != posType && !bFound)
	{
		CString strType = m_lstPreviewableFileTypes.GetNext(posType);
		bFound = parsedFileName.IsOfType(strType);
	}

	return bFound;
}
// End of function 'IsPreviewableFile'


#if !defined(AFX_LANGUAGE_H__9423BDC0_8582_11D4_8FC7_0008C7636E27__INCLUDED_)
#define AFX_LANGUAGE_H__9423BDC0_8582_11D4_8FC7_0008C7636E27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Language.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CLanguage dialog

class CLanguage : public CDialog
{
// Construction
public:
	void GetAllFiles();
	CLanguage(CWnd* pParent = NULL);   // standard constructor
	CString m_Gp3Path;
// Dialog Data
	//{{AFX_DATA(CLanguage)
	enum { IDD = IDD_LANGUAGE };
	CListBox	m_Language;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLanguage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CLanguage)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LANGUAGE_H__9423BDC0_8582_11D4_8FC7_0008C7636E27__INCLUDED_)

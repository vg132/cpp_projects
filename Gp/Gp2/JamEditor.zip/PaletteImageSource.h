// PaletteImageSource.h - header file for the CPaletteImageSource class
// NOTE: there is no corresponding .CPP file for this class.
//

#ifndef __PALETTE_IMAGE_SOURCE_H__
#define __PALETTE_IMAGE_SOURCE_H__

#include "LocalPaletteArray.h"

typedef CTypedPtrArray<CPtrArray, BYTE*> CPixelBufferArray;

///////////////////////////////////////////////////////////////////
// Class:	CPaletteImageSource
// Base:	[none]
// Created:	14Jan00 by Mal Ross
// Overview:
//    This class is an interface class that is used for all classes
//  that can produce bitmaps needing to be merged to form a texture's
//  raw pixel buffer.  It simply provides access to those bitmaps
//  through its GetBitmaps function.  This must be overridden by the
//  derived class (it is a pure virtual).
//

class CPaletteImageSource
{
// Construction and destruction
public:
	CPaletteImageSource() {}
	virtual ~CPaletteImageSource() {}

// Operations
public:
	// The function to retrieve the pixel buffers to the four
	// bitmaps this object provides.
	virtual BOOL GetBitmaps(CPixelBufferArray& pixelBuffers, CSize& sizImage) = 0;
};

/////////////////////////////////////////////////////////////////////

#endif	// ~__PALETTE_IMAGE_SOURCE_H__

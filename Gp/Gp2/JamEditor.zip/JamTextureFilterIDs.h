// JamTextureFilterIDs.h - contains #defines for the different
//						   types of bitmap import filter

// No blurring of any kind - makes empty local palettes
#define NULL_FILTER			0

// Median filter
#define MEDIAN_FILTER		1

// Night-driving filter
#define NIGHT_FILTER		2

// Driving in fog filter
#define FOG_FILTER			3

// Colour-fade filter (as seen in GP2JAM by Trevor Kellaway)
#define COLOR_FADE_FILTER	4

// Simple blurring, corrected by GetNearestColor function
#define BLUR_FILTER			5

// A stupid underwater filter
#define UNDERWATER_FILTER	6

// An equally-stupid red mist / beserk filter
#define RED_MIST_FILTER		7


// GP2Bitmap.cpp - implementation file for the CGP2Bitmap class
//

#include "stdafx.h"
#include "resource.h"

#include "GP2Bitmap.h"
#include "TexturePalette.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGP2Bitmap

// When loading bitmaps, should we ignore situations in which the
// colours in the bitmap's palette do not match our global palette?
BOOL CGP2Bitmap::s_bIgnoreInvalidPalettes = TRUE;

// Constructor
CGP2Bitmap::CGP2Bitmap()
{
	// Initialise all members (for an empty bitmap)
	Initialise();
}

void CGP2Bitmap::Initialise()
{
	// Initialise all members (for an empty bitmap)
	memset(&m_Hdr, 0, sizeof(m_Hdr));
	memset(&m_bmInfo.bmiHeader, 0, sizeof(m_bmInfo.bmiHeader));
	m_pbPixels		= NULL;

	SetPalette(&g_jamPalette[0]);
}


// Destructor
CGP2Bitmap::~CGP2Bitmap()
{
	if (NULL != m_pbPixels)
	{
		delete[] m_pbPixels;
		m_pbPixels = NULL;
	}
}


// File loading and saving
//

// Function:	LoadFile(strFilename)
// Overview:	Load the given bitmap file.
BOOL CGP2Bitmap::LoadFile(const CString& strFilename)
{
	// Initialise all bitmap members to empty
	if (m_pbPixels)
	{
		delete[] m_pbPixels;
		m_pbPixels = NULL;
	}
	Initialise();

	// Attempt to open the file
	CFile fileBitmap;
	CFileException fe;
	if (!fileBitmap.Open(strFilename, CFile::modeRead | CFile::shareDenyWrite, &fe))
	{
		// Failed, so tell the user what the problem was then give up
		fe.ReportError();
		return FALSE;
	}

	try
	{
		// Read the bitmap file header
		fileBitmap.Read(&m_Hdr, sizeof(m_Hdr));
		if (!IsBitmap())
		{
			AfxMessageBox(IDS_ERR_NOT_BITMAP_FILE);
			AfxThrowUserException();
		}

		// Read the bitmap info, then calculate some of the
		// bitmap fields that need to be filled in
		fileBitmap.Read(&m_bmInfo.bmiHeader, sizeof(m_bmInfo.bmiHeader));
		if (m_bmInfo.bmiHeader.biSizeImage == 0)
		{
			// Calculate the size of bitmap image, remembering to
			// take account of the 4-byte boundary
			UINT nSize = (m_bmInfo.bmiHeader.biWidth * m_bmInfo.bmiHeader.biBitCount) / 8;
			if ((nSize % 4) != 0)
				nSize += 4 - (nSize % 4);
			nSize *= m_bmInfo.bmiHeader.biHeight;
			m_bmInfo.bmiHeader.biSizeImage = nSize;
		}

		// Check to see that the bitmap is of a valid format i.e.
		// colour depth is 256, etc.
		if (!IsRGB256Bitmap())
		{
			AfxMessageBox(IDS_ERR_INVALID_BITMAP_FILE);
			AfxThrowUserException();
		}

		// Load the palette and check it's the right one
		fileBitmap.Read(m_Palette, sizeof(m_Palette));
		if (!IsValidPalette() && !s_bIgnoreInvalidPalettes)
		{
			if (IDOK != AfxMessageBox(IDS_ERR_INVALID_BITMAP_PALETTE, MB_ICONEXCLAMATION | MB_OKCANCEL))
				AfxThrowUserException();
		}
		// Correct the palette, just in case
		SetPalette(&g_jamPalette[0]);

		// Create the buffer for the pixels then read them in
		m_pbPixels = new BYTE[m_bmInfo.bmiHeader.biSizeImage];
		if (NULL == m_pbPixels)
		{
			AfxMessageBox(IDS_ERR_OUTOFMEMORY_FOR_LOADING_BITMAP);
			AfxThrowUserException();
		}
		memset(m_pbPixels, 0, m_bmInfo.bmiHeader.biSizeImage);
		fileBitmap.Read(m_pbPixels, m_bmInfo.bmiHeader.biSizeImage);

		// Store the pixels the right way up, rather than up-side down
		FlipImage();
	}
	catch (CUserException* pUserExc)
	{
		// User has already been notified
		pUserExc->Delete();
		fileBitmap.Close();

		return FALSE;
	}
	catch (CException* pExc)
	{
		// Report error to user
		pExc->ReportError();
		pExc->Delete();
		fileBitmap.Close();

		return FALSE;
	}

	// Success!
	fileBitmap.Close();
	return TRUE;
}
// End of function 'LoadFile'


// Function:	SaveFile(strFilename)
// Overview:	Save this object as a bitmap file of the given
//				filename.
BOOL CGP2Bitmap::SaveFile(const CString& strFilename)
{
	// Attempt to open the file
	CFile fileBitmap;
	CFileException fe;
	if (!fileBitmap.Open(strFilename, CFile::modeCreate | CFile::modeWrite | CFile::shareExclusive, &fe))
	{
		// Failed, so tell the user what the problem was then give up
		fe.ReportError();
		return FALSE;
	}

	try
	{
		// Write all of the header information and the palette
		fileBitmap.Write(&m_Hdr, sizeof(m_Hdr));
		fileBitmap.Write(&m_bmInfo.bmiHeader, sizeof(m_bmInfo.bmiHeader));
		fileBitmap.Write(&g_jamPalette[0], GP2_PALETTE_SIZE * sizeof(RGBQUAD));

		// Write the pixels in the up-side down format
		FlipImage();
		fileBitmap.Write(m_pbPixels, m_bmInfo.bmiHeader.biSizeImage);
		FlipImage();
	}
	catch (CException* pExc)
	{
		// Report error to user
		pExc->ReportError();
		pExc->Delete();
		fileBitmap.Close();

		return FALSE;
	}

	// Success!
	fileBitmap.Close();
	return TRUE;
}
// End of function 'SaveFile'


BOOL CGP2Bitmap::CreateFromJamPixels(WORD wWidth, WORD wHeight, BYTE* pImage)
{
	UINT nPackedByteWidth = wWidth;

	if ((nPackedByteWidth & 0x03) != 0) {
		nPackedByteWidth += 4;
		nPackedByteWidth &= ~0x03;
	}


	m_bmInfo.bmiHeader.biSizeImage = nPackedByteWidth * wHeight;

	m_Hdr.bfType		= 0x4d42;
	m_Hdr.bfSize		= sizeof(m_Hdr) + sizeof(m_bmInfo.bmiHeader) + sizeof(m_Palette) + m_bmInfo.bmiHeader.biSizeImage;
	m_Hdr.bfReserved1	= 0;
	m_Hdr.bfReserved2	= 0;
	m_Hdr.bfOffBits	= sizeof(m_Hdr) + sizeof(m_bmInfo.bmiHeader) + sizeof(m_Palette);

	m_bmInfo.bmiHeader.biSize            = sizeof(m_bmInfo.bmiHeader);
	m_bmInfo.bmiHeader.biWidth           = (long) wWidth;
	m_bmInfo.bmiHeader.biHeight          = (long) wHeight;
	m_bmInfo.bmiHeader.biPlanes          = 1;
	m_bmInfo.bmiHeader.biBitCount        = 8;
	m_bmInfo.bmiHeader.biCompression     = BI_RGB;
	m_bmInfo.bmiHeader.biXPelsPerMeter   = 0;
	m_bmInfo.bmiHeader.biYPelsPerMeter   = 0;
	m_bmInfo.bmiHeader.biClrUsed         = 256;
	m_bmInfo.bmiHeader.biClrImportant    = 256;

	m_pbPixels = new unsigned char[(unsigned int) m_bmInfo.bmiHeader.biSizeImage];
	if (m_pbPixels == NULL) {
		printf("Out of memory trying to allocate a buffer for CGP2Bitmap file.\n");
		return FALSE;
	}
	memset(m_pbPixels, 0, (unsigned int) m_bmInfo.bmiHeader.biSizeImage);

	if (pImage) {
		unsigned int	y;

		for (y = 0; y < wHeight; y++) {
			memcpy(&m_pbPixels[y * nPackedByteWidth], &pImage[y * wWidth], wWidth);
		}
	}

	return TRUE;
}

void CGP2Bitmap::CreateDIB(CBitmap &bitmap)
{
	CClientDC dc(NULL);

	FlipImage();
	HBITMAP hBmp = CreateDIBitmap(dc.m_hDC,		// handle to device context 
		&m_bmInfo.bmiHeader,					// pointer to bitmap size and format data 
		CBM_INIT,								// initialization flag 
		m_pbPixels,								// pointer to initialization data 
		&m_bmInfo,								// pointer to bitmap color-format data 
		DIB_RGB_COLORS);						// color-data usage 
	bitmap.Attach(hBmp);
	FlipImage();
}




/////////////////////////////////////////////////////////////
// Image manipulation

// Function:	GetPaddedWidth()
// Overview:	Get the width in bytes of the actual pixel buffer
//				required to hold the bitmap's pixels.
WORD CGP2Bitmap::GetPaddedWidth() const
{
	// Bitmaps need to be padded to a 4-byte boundary, so
	// calculate the padded width of each row we'll have to
	// flip.
	int wPaddedByteWidth = GetWidth();
	if ((wPaddedByteWidth & 3) != 0)
		wPaddedByteWidth = (wPaddedByteWidth + 4) & ~3;

	return (WORD)wPaddedByteWidth;
}
// End of function 'GetPaddedWidth'


// Function:	FlipImage()
// Overview:	Flip the pixels of the bitmap vertically.  This function
//				is required for converting between JAM pixel layout and
//				bitmap pixel layout.
BOOL CGP2Bitmap::FlipImage()
{
	// Bitmaps need to be padded to a 4-byte boundary, so
	// calculate the padded width of each row we'll have to
	// flip.
	int wPaddedByteWidth = m_bmInfo.bmiHeader.biWidth;
	if ((wPaddedByteWidth & 3) != 0)
		wPaddedByteWidth = (wPaddedByteWidth + 4) & ~3;

	// Allocate a buffer for putting the pixels into before
	// storing it as a row in the new bitmap
	BYTE* pbLineBuffer = new BYTE[wPaddedByteWidth];
	ASSERT(NULL != pbLineBuffer);
	if (NULL == pbLineBuffer)
		return FALSE;

	// Flip the image by swapping the top and bottom rows, and
	// then moving towards the centre one row at each edge then
	// swapping again.
	int wOrigRowNum = 0, wNewRowNum = 0;
	for (wOrigRowNum = 0, wNewRowNum = GetHeight() - 1; wOrigRowNum < (GetHeight() / 2); wOrigRowNum++, wNewRowNum--)
	{
		memcpy(pbLineBuffer, &m_pbPixels[wOrigRowNum * wPaddedByteWidth], wPaddedByteWidth);
		memcpy(&m_pbPixels[wOrigRowNum * wPaddedByteWidth], &m_pbPixels[wNewRowNum * wPaddedByteWidth],	wPaddedByteWidth);
		memcpy(&m_pbPixels[wNewRowNum * wPaddedByteWidth], pbLineBuffer, wPaddedByteWidth);
	}

	// Delete the temporary line buffer
	delete[] pbLineBuffer;
	pbLineBuffer = NULL;

	return TRUE;
}
// End of function 'FlipImage'



/////////////////////////////////////////////////////////////
// Format validation

// Public validation function
BOOL CGP2Bitmap::IsValid() const
{
	return (IsBitmap() &&
			IsRGB256Bitmap() &&
			IsValidPalette());
}

// Internal format validation
BOOL CGP2Bitmap::IsBitmap() const
{
	return (m_Hdr.bfType == 0x4d42);
}

BOOL CGP2Bitmap::IsRGB256Bitmap() const
{
	return ((m_bmInfo.bmiHeader.biPlanes == 1) &&
			(m_bmInfo.bmiHeader.biBitCount == 8) &&
			(m_bmInfo.bmiHeader.biCompression == BI_RGB));
}

BOOL CGP2Bitmap::IsValidPalette() const
{
	BOOL bValid = TRUE;
	for (int nPalIndex = 0; nPalIndex < 256 && bValid; nPalIndex++)
		bValid = (m_Palette[nPalIndex].rgbRed == g_jamPalette[nPalIndex].rgbRed &&
				  m_Palette[nPalIndex].rgbGreen == g_jamPalette[nPalIndex].rgbGreen &&
				  m_Palette[nPalIndex].rgbBlue == g_jamPalette[nPalIndex].rgbBlue);

	return bValid;
}

// Function:	SetPalette(palette[])
// Overview:	Copy the given palette into our own palette info.
void CGP2Bitmap::SetPalette(const RGBQUAD palette[])
{
	// Copy the palette info into the first element of the
	// bmiColors array, followed by the m_Palette member.
	// NOTE: this is a TERRIBLE, TERRIBLE bodge to get around
	// the fact that I don't know how to properly put the
	// palette into m_bmInfo.bmiColors.  It only works because
	// the next thing in memory after m_bmInfo is m_Palette.
	memcpy(m_bmInfo.bmiColors, &palette[0], sizeof(RGBQUAD));
	memcpy(m_Palette, &palette[1], sizeof(m_Palette) - sizeof(RGBQUAD));
}
// End of function 'SetPalette'

// JamTree.h : header file for the CJamTree class
//

#ifndef _JAM_TREE_H_
#define _JAM_TREE_H_

#include "EnhancedTreeCtrl.h"

/////////////////////////////////////////////////////////////////////////////
// CJamTree window

class CJam;
class CEditableObject;

class CJamTree : public CEnhancedTreeCtrl
{
// Construction
public:
	CJamTree();

// Attributes
public:
	
	// here is where we add data to the tree - tell it the front end
	// and it uses that to work out the rest
	void AddData(CEditableObject* pObject, HTREEITEM hParent=TVI_ROOT);

	// like the above but to the main node of the tree
	void AddDataToAllJams(CEditableObject* pObject);
	
	// when a jam closes
	void RemoveJamDoc(CEditableObject* pObject);

	// refresh data display
	// this function simply uses the existing
	// data hierarchy and ensures that is it showing the correct
	// text for each node
	// the given object is refresh as is its children
	void RefreshDataDisplay(CEditableObject* pObject);

// Operations
public:

protected:
	// the UI is partially defined by the overrides below
	virtual BOOL CanEditLabelOf(HTREEITEM hItem, CString& replacementText);	// do you want to allow editing of hItem, if so you may specify a different bit of text than the existing one to be edited
	virtual void HandleLabelChanged(HTREEITEM hItem, CString newLabel);		// we've changed the label for the given tree item - you must validate and replace label in item if you like it
	virtual void HandleLabelChangeCancelled(HTREEITEM hItem);				// the in-place edit on hItem was cancelled - deal with it

	// interaction virtual functions - makes the ctreectrl notifications simpler to use
	virtual void HandleSelchanged(HTREEITEM hItem);
	virtual void HandleDblclk(HTREEITEM hItem);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJamTree)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CJamTree();

	// The image list containing the various icons, as defined
	// in TreeIconDefs.h
	CImageList m_ImageList;

	// Generated message map functions
protected:
	//{{AFX_MSG(CJamTree)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif	// ~_JAM_TREE_H_

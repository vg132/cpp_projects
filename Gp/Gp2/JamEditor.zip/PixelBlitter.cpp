// PixelBlitter.cpp - implementation of the CPixelBlitter class
//

#include "stdafx.h"

#include "PixelBlitter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CPixelBlitter

// Constructor
CPixelBlitter::CPixelBlitter()
{
}

// Destructor
CPixelBlitter::~CPixelBlitter()
{
}



// Pixel-copying functions
//

// This function is what this class is all about
// Copy pixels from one buffer to another, without stretching
BOOL CPixelBlitter::CopyPixels(BYTE* pbSrc, const CSize sizSrcBmp, const CRect rctSrc,
							   BYTE* pbDest, const CSize sizDestBmp, const CPoint ptDest) const
{
	// Make sure the byte buffers actually exist!
	ASSERT(NULL != pbSrc && NULL != pbDest);
	if (NULL == pbSrc || NULL == pbDest)
		return FALSE;

	// Make sure the coordinates we've been given are valid for the
	// sizes of the pixel buffers
	if (!AreCopyCoordsValid(sizSrcBmp, rctSrc, sizDestBmp, CRect(ptDest, rctSrc.Size())))
		return FALSE;

	// Now just perform a simple loop, copying a single row of
	// pixels at a time into the destination buffer.
	// and size before we copy it into m_pbRawTexturePixels
	BYTE* pbCurrSrcPixels = pbSrc + rctSrc.left + (rctSrc.top * sizSrcBmp.cx);
	BYTE* pbCurrDestPixels = pbDest + ptDest.x + (ptDest.y * sizDestBmp.cx);
	for (int nRow = 0; nRow < rctSrc.Height(); nRow++)
	{
		memcpy(pbCurrDestPixels, pbCurrSrcPixels, rctSrc.Width());
		pbCurrSrcPixels += sizSrcBmp.cx;
		pbCurrDestPixels += sizDestBmp.cx;
	}

	return TRUE;
}


// If CopyPixels is the equiavalent of BitBlt, this
// is the equiavalent of StretchBlt
BOOL CPixelBlitter::StretchPixels(BYTE* pbSrc, const CSize& sizSrcBmp, const CRect& rctSrc,
								  BYTE* pbDest, const CSize& sizDestBmp, const CRect& rctDest) const
{
	// If the operation wouldn't actually involve any stretching,
	// just use the straight copy function
	if (rctSrc.Size() == rctDest.Size())
		return CopyPixels(pbSrc, sizSrcBmp, rctSrc, pbDest, sizDestBmp, rctDest.TopLeft());

	// Make sure the coordinates we've been given are valid for the
	// sizes of the pixel buffers
	if (!AreCopyCoordsValid(sizSrcBmp, rctSrc, sizDestBmp, rctDest))
		return FALSE;

	// Stretching is not supported (yet?)
	return FALSE;
}


// Validation of the copy areas to make sure that we
// don't try to copy outside one of the pixel buffers
BOOL CPixelBlitter::AreCopyCoordsValid(const CSize& sizSrcBmp, const CRect& rctSrc,
									   const CSize& sizDestBmp, const CRect& rctDest) const
{
	// Check the source area
	if (rctSrc.top < 0 || rctSrc.left < 0 ||
		rctSrc.left + rctSrc.Width() > sizSrcBmp.cx ||
		rctSrc.top + rctSrc.Height() > sizSrcBmp.cy)
		return FALSE;

	// Check the destination area
	if (rctDest.top < 0 || rctDest.left < 0 ||
		rctDest.left + rctDest.Width() > sizDestBmp.cx ||
		rctDest.top + rctDest.Height() > sizDestBmp.cy)
		return FALSE;

	return TRUE;
}

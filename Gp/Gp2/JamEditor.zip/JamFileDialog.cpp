// JamFileDialog.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "JamFileDialog.h"

#include "JamFilePreview.h"
#include "JamTexture.h"
#include "Jam.h"
#include "JamIterator.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJamFileDialog

IMPLEMENT_DYNAMIC(CJamFileDialog, CPreviewFileDialog)

CJamFileDialog::CJamFileDialog(BOOL bOpenFileDialog, LPCTSTR lpszDefExt, LPCTSTR lpszFileName,
		DWORD dwFlags, LPCTSTR lpszFilter, CWnd* pParentWnd) :
		CPreviewFileDialog(bOpenFileDialog, lpszDefExt, lpszFileName, dwFlags, lpszFilter, pParentWnd)
{
	//{{AFX_DATA_INIT(CJamFileDialog)
	m_nNumTextures = 0;
	m_strTextureIDs = _T("");
	m_strCanvasSize = _T("");
	//}}AFX_DATA_INIT
}


BEGIN_MESSAGE_MAP(CJamFileDialog, CPreviewFileDialog)
	//{{AFX_MSG_MAP(CJamFileDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


// Standard dialog messages and handling

// Function:	DoDataExchange(pDX)
// Overview:	Overridden for the extra preview controls
void CJamFileDialog::DoDataExchange(CDataExchange* pDX)
{
	CPreviewFileDialog::DoDataExchange(pDX);

	// Don't try to set values in the preview controls
	// if they don't exist!
	if (!IsPreviewInUse())
		return;

	//{{AFX_DATA_MAP(CJamFileDialog)
	DDX_Text(pDX, IDC_NUM_TEXTURES, m_nNumTextures);
	DDX_Text(pDX, IDC_TEXTURE_IDS, m_strTextureIDs);
	DDX_Text(pDX, IDC_CANVAS_SIZE, m_strCanvasSize);
	//}}AFX_DATA_MAP
}
// End of function 'DoDataExchange'


// Function:	OnInitDialog()
// Overview:	Overridden to put appropriate values into the
//				required height and width statics
BOOL CJamFileDialog::OnInitDialog() 
{
	CPreviewFileDialog::OnInitDialog();
	
	// Make sure the information about the current jam is up to date
	// or at least says something sensible
	if (IsPreviewInUse())
		UpdateJamInfo(NULL);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
// End of function 'OnInitDialog'


// Function:	GetPreviewTemplateID()
// Overview:	Specify the dialog template to use for the preview area
UINT CJamFileDialog::GetPreviewTemplateID () const
{
	return IDD_JAM_PREVIEW;
}
// End of function 'GetPreviewTemplateID'



/////////////////////////////////////////////////////////////////////////////
// CJamFileDialog preview updates

// Function:	SetPreviewFile(strFilename)
// Overview:	Show a preview of the given file in the static.
BOOL CJamFileDialog::SetPreviewFile(const CString& strFilename)
{
	// Call the nase class first to get the new preview
	if (!CPreviewFileDialog::SetPreviewFile(strFilename))
		return FALSE;

	// Get the previewer from the static control, so that we can get
	// extra info about the preview.
	CFilePreview* pPreview = m_stcPreview.GetPreviewer();
	ASSERT(NULL != pPreview);
	if (NULL == pPreview)
		return TRUE;	// well, we still managed to preview it, really.

	// If the current preview type is an image previewer, get its
	// height and wisth information
	if (pPreview->IsKindOf(RUNTIME_CLASS(CImageFilePreview)))
	{
		CJamFilePreview* pJamPreview = (CJamFilePreview *)pPreview;
		UpdateJamInfo(pJamPreview->GetJam());
	}
	else
	{
		UpdateJamInfo(NULL);
	}

	return TRUE;
}
// End of function 'SetPreviewFile'


// Function:	UpdateJamInfo(pJam)
// Overview:	Update the jam information that's shown alongside the preview
//				to represent the given jam.
void CJamFileDialog::UpdateJamInfo(const CJam* pJam)
{
	// Check to see whether the info is being wiped
	if (NULL == pJam)
	{
		// Set empty values - there's no jam being previewed
		m_nNumTextures = 0;
		m_strCanvasSize = "n/a";
		m_strTextureIDs = "n/a";
	}
	else
	{
		// Set proper values - there *is* a jam being previewed
		m_nNumTextures = pJam->GetNumTextures();
		m_strCanvasSize.Format("%dx%d", pJam->GetSize().cx, pJam->GetSize().cy);

		// Build the string to indicate which textures are represented in
		// the jam
		CJamIterator iterator(pJam);
		CString strNextID("");
		int nNumIDsAdded = 0;
		m_strTextureIDs = "";
		for (iterator.FindFirst(); !iterator.IsDone(); iterator.FindNext())
		{
			// Get the next texture to be able to add its ID to
			// our string
			CJamTexture* pTexture = iterator.GetCurrent();
			if (NULL == pTexture)
				continue;

			// Add the ID of the current texture to the string
			if (nNumIDsAdded > 0)
				strNextID.Format(", %d", pTexture->GetTextureID());
			else
				strNextID.Format("%d", pTexture->GetTextureID());
			m_strTextureIDs += strNextID;

			nNumIDsAdded++;
		}
		ASSERT(nNumIDsAdded == (int)m_nNumTextures);
	}

	// Make sure the data gets put into the dialog controls
	UpdateData(FALSE);
}
// End of function 'UpdateJamInfo'



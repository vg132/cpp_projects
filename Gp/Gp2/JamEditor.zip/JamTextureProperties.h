#ifndef JAM_TEXTURE_PROPERTIES_H
#define JAM_TEXTURE_PROPERTIES_H

#include "EditableTypedPtrList.h"
#include "EditableNumber.h"

class CJamTexture;

class CJamTextureProperties : public CEditableTypedPtrList
{
public:
	// constructor/destructor
	CJamTextureProperties(CJamTexture* pTexture, CEditableObject* pParent);
	virtual ~CJamTextureProperties();
		
	virtual UINT	GetIconID();
	virtual CString GetFullDescription();
	virtual CString	GetValueToEdit();
	virtual BOOL	CanEdit();

public:
	// list functions
	using CEditableTypedPtrList::AddTail;
	POSITION	AddTail(CEditableNumber<BYTE>* pNumber) { return CEditableTypedPtrList::AddTail( (CEditableObject*)pNumber ); }
	POSITION	AddTail(CEditableNumber<WORD>* pNumber) { return CEditableTypedPtrList::AddTail( (CEditableObject*)pNumber ); }

protected:
	CJamTexture* m_pTexture;	// the texture we're fronting for
};


#endif

// JascPalettePreview.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "JascPalettePreview.h"

#include "GP2Bitmap.h"
#include "TexturePalette.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJascPalettePreview construction

IMPLEMENT_DYNAMIC(CJascPalettePreview, CGP2BitmapPreview)

// Constructor
CJascPalettePreview::CJascPalettePreview()
{
}

// Cloning function
CFilePreview* CJascPalettePreview::CreateNewPreview() const
{
	return new CJascPalettePreview;
}

// Destructor
CJascPalettePreview::~CJascPalettePreview()
{
}


/////////////////////////////////////////////////////////////////////////////
// CJascPalettePreview properties

// Function:	GetSupportedFileTypes(lstFileTypes)
// Overview:	Overridden function to fill the given list with the
//				extensions of files that can be previewed by this class.
void CJascPalettePreview::GetSupportedFileTypes(CStringList& lstFileTypes) const
{
	// Just make sure the list's empty first
	lstFileTypes.RemoveAll();

	// Then add our extensions
	lstFileTypes.AddTail(".PAL");
}
// End of function 'GetSupportedFileTypes'


// Function:	GetInvalidFormatText()
// Overview:	Overrideable function to retrieve the text to display
//				when the file format is invalid.
CString CJascPalettePreview::GetInvalidFormatText() const
{
	CString strError;
	strError.LoadString(IDS_INVALID_PALETTE_FORMAT);

	return strError;
}
// End of function 'GetInvalidFormatText'



/////////////////////////////////////////////////////////////////////////////
// CJascPalettePreview file loading/unloading

// Function:	LoadFile(strFilename)
// Overview:	Load the given file.  Return TRUE upon success, or
//				FALSE otherwise.
BOOL CJascPalettePreview::LoadFile(const CString& strFilename)
{
	// Load the palette from the file
	CGP2Palette palette;
	if (!palette.SetPaletteType(CGP2Palette::PALTYPE_CUSTOM, strFilename))
		return FALSE;

	// Now just create a bitmap of 16x16 to show off the palette,
	// if we haven't done so already.
	if (NULL == m_pBitmap)
		m_pBitmap = new CGP2Bitmap;
	if (NULL == m_pBitmap)
		return FALSE;
	BYTE pixelBuffer[GP2_PALETTE_SIZE];
	for (int nPixel = 0; nPixel < GP2_PALETTE_SIZE; nPixel++)
		pixelBuffer[nPixel] = (BYTE)nPixel;
	if (!m_pBitmap->CreateFromJamPixels(16, 16, pixelBuffer))
		return FALSE;

	// Now load the new one
	try
	{
		m_pBitmap->SetPalette(&palette[0]);
	}
	catch (CException* pExc)
	{
		ASSERT(FALSE);
		pExc->Delete();
		return FALSE;
	}

	return TRUE;
}
// End of function 'LoadFile'

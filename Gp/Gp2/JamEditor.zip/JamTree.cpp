// JamTree.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "JamTree.h"

#include "TreeIconDefs.h"
#include "EditableObject.h"
#include "DataEditorDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CJamTree

CJamTree::CJamTree()
{
	// Create the image list
	m_ImageList.Create(IDB_JAM_TREE_ICONS, 16, 0, RGB(255,0,255));
}

CJamTree::~CJamTree()
{
}

BEGIN_MESSAGE_MAP(CJamTree, CEnhancedTreeCtrl)
	//{{AFX_MSG_MAP(CJamTree)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CJamTree message handlers

int CJamTree::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	// Do normal creation first
	if (CTreeCtrl::OnCreate(lpCreateStruct) == -1)
		return -1;

	// Set the image list and create the root node
	SetImageList(&m_ImageList, TVSIL_NORMAL);
	HTREEITEM hRoot = InsertNode(IDS_NODE_ROOT, JTI_ROOT_NODE, NULL, TVI_FIRST);
	Expand(hRoot, TVE_EXPAND);

	return 0;
}

void CJamTree::AddData(CEditableObject* pObject, HTREEITEM hParent)
{
	// safety checks
	ASSERT(pObject);
	ASSERT(hParent);

	if (!hParent || !pObject)
		return;

// because this function is recursive - we want to avoid
// it recursively mucking around with the redraw stuff
	static BOOL sb_AddDataMutex=FALSE;

	BOOL bThisFunctionDidSetRedraw=FALSE;

	if (!sb_AddDataMutex)
	{
		// we're not in the midst of a recursion
		SetRedraw(FALSE);	// SUPPRESS DRAWING FOR SPEED
		
		bThisFunctionDidSetRedraw=TRUE;

		sb_AddDataMutex=TRUE;	// stop others doing this
	}

	// we will now construct a node from the data's editable object
	HTREEITEM hNewNode=InsertNode(pObject->GetFullDescription(), pObject->GetIconID(), hParent, TVI_LAST, (DWORD)pObject);

	ASSERT(hNewNode);	// the node should have been created
	pObject->SetTreeItem(hNewNode);

	// now we check the data item to see if it has any children
	POSITION pos=pObject->GetFirstSubItemPosition();
	while (pos)
	{
		// add children to the tree too
		CEditableObject* pSubItem=pObject->GetNextSubItem(pos);

		if (pSubItem)
			AddData(pSubItem, hNewNode);
	}

	if (bThisFunctionDidSetRedraw)
	{	
		// this function is responsible for the redraw stuff
		SetRedraw(TRUE);	// DRAWING BACK ON

		Invalidate();

		// and unset the mutex to allow this
		// to work again later.
		sb_AddDataMutex=FALSE;	// stop others doing this

	}
}

// this will add the data of the given editable object to the root
// node of the tree (it will become a child of the first node)
void CJamTree::AddDataToAllJams(CEditableObject* pObject)
{
	HTREEITEM hRoot=GetRootItem();
	if (hRoot)
	{
		AddData(pObject, hRoot);

		// and open the root node.
		Expand(hRoot, TVE_EXPAND);

	}
	else
		ASSERT(FALSE);	// we couldn't add, since no root existed
}

// ask the item's data for label editing info
BOOL CJamTree::CanEditLabelOf(HTREEITEM hItem, CString& replacementText)
{
	if (!hItem)
	{
		ASSERT(FALSE);
		return FALSE;
	}

	// get editable object
	CEditableObject* pEditableObject=(CEditableObject*)GetItemData(hItem);
	if (!pEditableObject)
		return FALSE;	// no editable object, no editing

	if (!pEditableObject->CanEdit())
	{
		return FALSE;
	}

	// get the value to edit
	replacementText=pEditableObject->GetValueToEdit();

	return TRUE;	// can edit
}

void CJamTree::HandleLabelChanged(HTREEITEM hItem, CString newLabel)
{
	// the label change complete
	// amend the data of the given item
	ASSERT(hItem);
	if (!hItem)
		return;

	// get editable object
	CEditableObject* pEditableObject=(CEditableObject*)GetItemData(hItem);
	if (!pEditableObject)
		return;	// no editable object, no editing

	// tell the editable object the new data
	if (!pEditableObject->ChangeDataFromEdit(newLabel))
		AfxMessageBox("Invalid value!");

	// get the correct text into our item
	SetItemText(hItem, pEditableObject->GetFullDescription());

}

void CJamTree::HandleLabelChangeCancelled(HTREEITEM hItem)
{
	// the label change cancelled
	// restore the text of the given item
	ASSERT(hItem);
	if (!hItem)
		return;

	// get editable object
	CEditableObject* pEditableObject=(CEditableObject*)GetItemData(hItem);
	if (!pEditableObject)
		return;	// no editable object, no editing

	// get the correct text into our item
	SetItemText(hItem, pEditableObject->GetFullDescription());
}

// when we receive a single click
void CJamTree::HandleSelchanged(HTREEITEM hItem)
{
	ASSERT(hItem);
	if (!hItem)
		return;

	// get editable object
	CEditableObject* pEditableObject=(CEditableObject*)GetItemData(hItem);
	if (!pEditableObject)
		return;	// no editable object, no editing
	
	// ask the editable object to handle the selection
	BOOL bChanged = pEditableObject->HandleSelect();

	// check to see whether we need to update the node
	if (bChanged)
	{
		// Update the tree item text
		CString strNodeText = pEditableObject->GetFullDescription();
		SetItemText(hItem, strNodeText);

		// Update the icon (you never know - it may have changed)
		int nIconID = (int)pEditableObject->GetIconID();
		SetItemImage(hItem, nIconID, nIconID);
	}
}

// when we receive a dblclk - we must launch
// a dialog box to handle it - assuming editing is possible
void CJamTree::HandleDblclk(HTREEITEM hItem)
{
	ASSERT(hItem);
	if (!hItem)
		return;

	// get editable object
	CEditableObject* pEditableObject=(CEditableObject*)GetItemData(hItem);
	if (!pEditableObject)
		return;	// no editable object, no editing
	
	// ask the editable object to handle the double-click
	BOOL bChanged = pEditableObject->HandleDblClk();

	// check to see whether we need to update the node
	if (bChanged)
	{
		// Update the tree item text
		CString strNodeText = pEditableObject->GetFullDescription();
		SetItemText(hItem, strNodeText);

		// Update the icon (you never know - it may have changed)
		int nIconID = (int)pEditableObject->GetIconID();
		SetItemImage(hItem, nIconID, nIconID);
	}
}

// We know that we're deleting a jam doc, but
// we are only interested in it as an EditableObject
// so that is why we get a CEditableObject instead
// of a CDocument!
void CJamTree::RemoveJamDoc(CEditableObject* pObject)
{
	// check we actually got one
	if (pObject)
	{
		if (pObject->GetTreeItem())
		{
			// then we have an HTREEITEM to delete
			DeleteItem(pObject->GetTreeItem());
		}
	}
	else
	{
		ASSERT(FALSE);	// what are you talking about Willis?
	}
}

void CJamTree::RefreshDataDisplay(CEditableObject* pObject)
{
	// validity check
	if (!pObject)
		return;

	// mutex-protect the setting of redraw and invalidation
	static BOOL b_static_redraw_protect=FALSE;

	BOOL bWeOwnRedraw=FALSE;

	if (!b_static_redraw_protect)
	{
		b_static_redraw_protect=TRUE;
		bWeOwnRedraw=TRUE;

		// turn off repainting for efficiency
		SetRedraw(FALSE);
	}

	// do this object
	if (pObject->GetTreeItem())
	{
		SetItemText(pObject->GetTreeItem(), pObject->GetFullDescription());
	}

	// now do its children
	POSITION pos=pObject->GetFirstSubItemPosition();
	while (pos)
	{
		RefreshDataDisplay(pObject->GetNextSubItem(pos));
	}


	// do we need to turn redraws back on?
	if (bWeOwnRedraw)
	{
		// un mutex
		b_static_redraw_protect=FALSE;

		SetRedraw(TRUE);
		Invalidate();
	}
}

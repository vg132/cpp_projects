// JamTextureTracker.cpp: implementation file for the CJamTextureTracker class
//

#include "stdafx.h"

#include "JamTextureTracker.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJamTextureTracker

CJamTextureTracker::CJamTextureTracker()
{
}

CJamTextureTracker::~CJamTextureTracker()
{
}


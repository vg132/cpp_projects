// CJamTextureList
//
// Not to be confused with C Jam Blues - by Duke Ellington!

#ifndef JAM_TEXTURE_LIST_H
#define JAM_TEXTURE_LIST_H

#include "EditableTypedPtrList.h"
#include "JamTexture.h"

class CJamTextureList : public CEditableTypedPtrList
{
public:
	// constructor
	CJamTextureList(CEditableObject* pParent);
	~CJamTextureList() {};

	// overrides of the base class
	virtual UINT	GetIconID();			// return the ID for the icon in the tree for this item
	virtual CString GetFullDescription();	// return name and value


	CJamTexture* GetNext(POSITION& pos) const
	{ return (CJamTexture*)(CEditableTypedPtrList::GetNext(pos)); }

	CJamTexture* GetPrev(POSITION& pos) const
	{ return (CJamTexture*)(CEditableTypedPtrList::GetPrev(pos)); }

	POSITION	AddTail(CJamTexture* pTexture)
	{
		return CEditableTypedPtrList::AddTail( (CEditableObject*)pTexture );
	}

};

#endif
// FilePreviewStatic.h : header file
//

#ifndef _FILE_PREVIEW_STATIC_H
#define _FILE_PREVIEW_STATIC_H

class CFilePreview;

/////////////////////////////////////////////////////////////////////////////
// CFilePreviewStatic window

class CFilePreviewStatic : public CStatic
{
// Construction
public:
	CFilePreviewStatic();

// Attributes
protected:
	// The preview object for the current file
	CFilePreview* m_pPreview;

// Operations
public:
	// Setting a new file to preview
	virtual void SetFilename (const CString& strFilename);

	// Get a pointer to the previewer in case it's needed for
	// other info outside this static
	CFilePreview* GetPreviewer() const { return m_pPreview; }

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFilePreviewStatic)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFilePreviewStatic();

protected:
	// Overrideable function to create a new preview type
	// suitable for the given filename
	virtual CFilePreview* CreatePreviewForFilename(const CString& strFilename);

	// Generated message map functions
protected:
	//{{AFX_MSG(CFilePreviewStatic)
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif	// ~_FILE_PREVIEW_STATIC_H
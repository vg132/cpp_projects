// PixelProfileClusterer.cpp - implementation of the CPixelProfileClusterer class
//

#include "stdafx.h"

#include "PixelProfileClusterer.h"

#include "PixelProfileCluster.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CPixelProfileClusterer construction/destruction

CPixelProfileClusterer::CPixelProfileClusterer(const CTypedProfileList& profileList)
{
	m_nCombinePair1 = -1;
	m_nCombinePair2 = -1;

	// For each of the profiles in the list, create a cluster
	POSITION posProfile = profileList.GetHeadPosition();
	while (NULL != posProfile)
		m_lstClusters.AddTail(new CPixelProfileCluster(profileList.GetNext(posProfile)));

	// Now initialise the cluster match matrix
	InitClusterMatrix();
	CreateAllPotentialClusters();
}

CPixelProfileClusterer::~CPixelProfileClusterer()
{
	// Delete all clusters
	DeleteAllClusters();
}


/////////////////////////////////////////////////////////////////////////////
// Cluster management

// Delete all clusters from both the main list and matrix of
// potential clusters.
void CPixelProfileClusterer::DeleteAllClusters()
{
	// Just keep on deleting the cluster at the head of the list
	// until we've got none left
	while (NULL != m_lstClusters.GetHeadPosition())
		DeleteCluster(0);
}
// End of function 'DeleteAllClusters'


// Delete the cluster at the given index in the m_lstClusters member,
// as well as the related clusters in the matrix.  However, if nException
// is non-negative, do not *delete* the potential cluster created from
// a combination of the nClusterIndex'th and nException'th clusters.
void CPixelProfileClusterer::DeleteCluster(const int nClusterIndex, const int nException /*= -1*/)
{
	// A cluster will never be combined with itself, so it wouldn't make
	// sense to try to maintain a combined cluster produced in this manner.
	ASSERT(nClusterIndex != nException);

	// Remove the first cluster from the list and delete it
	POSITION posCluster = m_lstClusters.FindIndex(nClusterIndex);
	CPixelProfileCluster* pCluster = m_lstClusters.GetAt(posCluster);
	m_lstClusters.RemoveAt(posCluster);
	if (NULL != pCluster)
	{
		delete pCluster;
		pCluster = NULL;
	}

	// Remove related clusters from the matrix, deleting them as
	// we go, too.  However, we must remember that cluster pointers
	// are duplicated in the grid, so we shouldn't delete the same
	// pointer twice!
	for (int nColumn = 0; nColumn < m_Matrix.GetColumnCount(); nColumn++)
	{
		CPixelProfileCluster* pPotentialCluster = m_Matrix.GetAt(nClusterIndex, nColumn);
		if (NULL != pPotentialCluster && nColumn != nException)
		{
			delete pPotentialCluster;
			pPotentialCluster = NULL;
			m_Matrix.SetAt(nClusterIndex, nColumn, NULL);
		}
	}
	m_Matrix.RemoveRow(nClusterIndex);
	m_Matrix.RemoveColumn(nClusterIndex);
}
// End of function 'DeleteCluster'


// Add the given cluster to the main list and update the matrix of
// potential clusters
BOOL CPixelProfileClusterer::AddCluster(CPixelProfileCluster* pAddCluster)
{
	// Make sure we've not been passed a duff pointer
	ASSERT(NULL != pAddCluster);
	if (NULL == pAddCluster)
		return FALSE;

	// Add the cluster to our list and make room for its
	// derived clusters in the matrix of potential clusters
	m_lstClusters.AddTail(pAddCluster);
	m_Matrix.InsertRow(-1);
	m_Matrix.InsertColumn(-1);

	// Now go through the 
	POSITION posCluster = m_lstClusters.GetHeadPosition();
	CPixelProfileCluster* pCombineCluster = NULL;
	int nNewClusterIndex = m_lstClusters.GetCount() - 1;
	int nCombineClusterIndex = 0;	// index of current cluster we're combining with
	while (NULL != posCluster)
	{
		// Get the next cluster in the list
		pCombineCluster = m_lstClusters.GetNext(posCluster);

		// Avoid combining the new cluster with itself(!)
		if (nNewClusterIndex == nCombineClusterIndex)
		{
			// Just initialise the cluster pointer to NULL to indicate
			// the stupidity of combining an existing cluster with itself :)
			m_Matrix.SetAt(nNewClusterIndex, nNewClusterIndex, NULL);
			nCombineClusterIndex++;
			continue;
		}

		// Create the new potential cluster and put it into the matrix
		CPixelProfileCluster* pNewCluster = new CPixelProfileCluster(*pAddCluster, *pCombineCluster);
		m_Matrix.SetAt(nNewClusterIndex, nCombineClusterIndex, pNewCluster);
		m_Matrix.SetAt(nCombineClusterIndex, nNewClusterIndex, pNewCluster);

		nCombineClusterIndex++;
	}

	return TRUE;
}
// End of function 'AddCluster'



/////////////////////////////////////////////////////////////////////////////
// Cluster factor functions

// Function:	InitClusterMatrix()
// Overview:	Initialise the sluter matrix of match factors,
//				making it the right size and setting all match
//				factors as undefined.
void CPixelProfileClusterer::InitClusterMatrix()
{
	// Empty the cluster matrix first
	m_Matrix.RemoveAll();

	// Now set the proper number of rows and columns
	int nNumClusters = m_lstClusters.GetCount();
	m_Matrix.SetRowCount(nNumClusters);
	m_Matrix.SetColumnCount(nNumClusters);

	// Finally, initialise the pointers in the matrix
	for (int nRow = 0; nRow < nNumClusters; nRow++)
		for (int nCol = 0; nCol < nNumClusters; nCol++)
			m_Matrix.SetAt(nRow, nCol, NULL);
}
// End of function 'InitClusterMatrix'


// Function:	CreateAllPotentialClusters()
// Overview:	Given that we've just been given a list of profiles to cluster,
//				create all of the clusters that could possibly be made.  Note
//				that once this has been done, we'll only ever have to update
//				the cluster matrix incrementally using AddCluster().
void CPixelProfileClusterer::CreateAllPotentialClusters()
{
	// We're going to have to match each profile to every other
	// profile to work out all of the match factors.  However,
	// we'll save ourselves the bother of doing each pair twice by
	// only matching the profiles after the one we're currently
	// looking at.
	POSITION posCurrCluster = m_lstClusters.GetHeadPosition();
	int nRow = 0;
	double dHighestClusterFactor = -1.0f;
	while (NULL != posCurrCluster)
	{
		// Get the next texture in the list
		CPixelProfileCluster* pCurrCluster = m_lstClusters.GetNext(posCurrCluster);
		ASSERT(NULL != pCurrCluster);
		if (NULL == pCurrCluster)
		{
			nRow++;
			continue;
		}

		// Match the profile to all profiles after it in the list
		POSITION posTestCluster = posCurrCluster;
		int nCol = nRow+1;
		while (NULL != posTestCluster)
		{
			// Get the next cluster to match to the current one
			CPixelProfileCluster* pTestCluster = m_lstClusters.GetNext(posTestCluster);
			ASSERT(NULL != pTestCluster);
			if (NULL == pTestCluster)
			{
				nCol++;
				continue;
			}

			// Get rid of any existing combined cluster for these two
			// (although there shouldn't really be one)
			CPixelProfileCluster* pExisting = m_Matrix.GetAt(nRow, nCol);
			if (NULL != pExisting)
			{
				delete pExisting;
				pExisting = NULL;
				m_Matrix.SetAt(nRow, nCol, NULL);
			}

			// Calculate the match factor
			CPixelProfileCluster* pPotentialCluster = new CPixelProfileCluster(*pCurrCluster, *pTestCluster);
			double dMatch = pPotentialCluster->GetClusterFactor();
			m_Matrix.SetAt(nRow, nCol, pPotentialCluster);
			m_Matrix.SetAt(nCol, nRow, pPotentialCluster);

			// Test to see whether this is the best match we've got so far
			if (dMatch > dHighestClusterFactor)
			{
				m_nCombinePair1 = nRow;
				m_nCombinePair2 = nCol;
			}

			// Increment the column counter
			nCol++;
		}

		// Increment the row counter
		nRow++;
	}
}
// End of function 'CreateAllPotentialClusters'


// From the current match matrix, find the two clusters which
// combine to the greatest resultant match factor.
void CPixelProfileClusterer::FindClosestClusters()
{
	// Just search through the matrix for the cluster with the
	// highest cluster factor
	m_nCombinePair1 = m_nCombinePair2 = -1;
	double dHighestClusterFactor = -1.0f;
	int nRowCount = m_Matrix.GetRowCount();
	int nColCount = m_Matrix.GetColumnCount();
	for (int nRow = 0; nRow < nRowCount; nRow++)
	{
		for (int nCol = nRow + 1; nCol < nColCount; nCol++)
		{
			CPixelProfileCluster* pCluster = m_Matrix.GetAt(nRow, nCol);
			if (NULL != pCluster)
			{
				double dClusterFactor = pCluster->m_dClusterFactor;
				if (dClusterFactor > dHighestClusterFactor)
				{
					dHighestClusterFactor = dClusterFactor;
					m_nCombinePair1 = nRow;
					m_nCombinePair2 = nCol;
				}
			}
		}
	}
}
// End of function 'FindClosestClusters'


// Combine the closest two clusters in the m_lstClusters list,
// removing their potential clusters from the matrix, but keeping
// the potential cluster made by combining them,  This is then
// added back into the 
BOOL CPixelProfileClusterer::CombineClosestClusters()
{
	// Make sure the closest cluster info is up-to-date
	ASSERT(m_nCombinePair1 >= 0 && m_nCombinePair2 >= 0);
	if (m_nCombinePair1 < 0 || m_nCombinePair2 < 0)
		return FALSE;
	ASSERT(m_nCombinePair1 != m_nCombinePair2);
	if (m_nCombinePair1 == m_nCombinePair2)
		return FALSE;

//	TRACE("\n  about to get down to %d clusters", m_lstClusters.GetCount() - 1);

	// Get the potential cluster that is to become a real
	// cluster in the main list
	CPixelProfileCluster* pCluster = m_Matrix.GetAt(m_nCombinePair1, m_nCombinePair2);

	// Now delete the first of the two parent clusters, making
	// sure we keep the cluster produced by combining it with the
	// second one.
	DeleteCluster(m_nCombinePair1, m_nCombinePair2);
	// Now delete the second one, remembering that a row and column
	// before it may have just been removed
	if (m_nCombinePair1 < m_nCombinePair2)
		m_nCombinePair2--;
	DeleteCluster(m_nCombinePair2);

	// Now add the combined cluster as a new real one and update the
	// record of the closest clusters
	AddCluster(pCluster);
	FindClosestClusters();

	return TRUE;
}




/////////////////////////////////////////////////////////////////////////////
// Storing the cluster info

// Function:	AssignClusterIndexes()
// Overview:	Actually store the information about this cluster in
//				the indexes of each of the profiles.
BOOL CPixelProfileClusterer::AssignClusterIndexes(BYTE& nClusterIndex)
{
	// We can't assign cluster indexes until we can give
	// each cluster a *unique* index and that means we
	// must have at most 256 clusters.
	if (m_lstClusters.GetCount() > 256)
		return FALSE;

	// Just go through all clusters, giving each its unique cluster index and
	// asking it to assign its profiles their relevant indexes.
	POSITION posCluster = m_lstClusters.GetHeadPosition();
	while (NULL != posCluster)
		m_lstClusters.GetNext(posCluster)->AssignClusterInfoToProfiles(nClusterIndex++);

	return TRUE;
}
// End of function 'AssignClusterIndexes'


// FilePreview.h - header file for the CFilePreview class
//

#ifndef __FILE_PREVIEW_H__
#define __FILE_PREVIEW_H__

/////////////////////////////////////////////////////////////////
// Class:	CFilePreview (abstract)
// Base:	CObject
// Created:	26 March 1999 by Mal Ross
// Overview:
//    A class used to display a preview of a file in a given
//  DC.  This is intended for use in an Open / Import dialog
//  box to give the user confirmation that the file they're
//  opening is really the one they want.
//

class CFilePreview : public CObject
{
	DECLARE_DYNAMIC(CFilePreview)

// Construction/destruction
public:
	CFilePreview();
	virtual ~CFilePreview();

	// Function for creating a new instance of the derived class.
	// This function is provided to assist in storage of the
	// class in a Prototype manager (see the Design Patterns
	// book).
	virtual CFilePreview* CreateNewPreview() const = 0;

// Data members
protected:
	// The name of the file to be displayed by this preview
	CString m_strFilename;

	// A flag to indicate whether the file indicated by m_strFilename
	// could be loaded
	BOOL m_bIsValidFile;

// Operations
public:
	// File-type checking
	virtual BOOL IsSupportedFile (const CString& strFilename) const;
	virtual BOOL IsSupportedFileType (const CString& strExtension) const;
	virtual void GetSupportedFileTypes (CStringList& lstFileTypes) const = 0;

	// Setting the file to preview
	virtual BOOL SetFilename (const CString& strFilename);
	CString GetFilename () const;

	// Draw the preview in the given DC
	virtual BOOL DrawPreview(CDC* pDC, const CRect& rctDraw) const = 0;

// Implementation
protected:
	// Stock drawing functions
	virtual BOOL DrawMessage(CDC* pDC, const CRect& rctDraw, const CString& strMessage) const;

	// Loading the file.  Derived classes must override this as
	// they're the only ones who know the format of the file.
	virtual BOOL LoadFile (const CString& strFilename) = 0;
	virtual void UnloadFile ();
};

/////////////////////////////////////////////////////////////////

#endif	// ~__FILE_PREVIEW_H__


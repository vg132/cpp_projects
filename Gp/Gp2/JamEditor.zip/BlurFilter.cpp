// BlurFilter.cpp - implementation of the CBlurFilter class
//

#include "stdafx.h"
#include "resource.h"

#include "BlurFilter.h"

#include "JamTextureFilterIDs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CBlurFilter

// Constructor
CBlurFilter::CBlurFilter()
	: CNeighbourFilter(BLUR_FILTER, IDS_FILTER_NAME_BLUR)
{
}

// Destructor
CBlurFilter::~CBlurFilter()
{
}


// Overridden filtering functions
//

// NOTE: The overridden FilterNeighbourhood function is defined inline
//       in the header file.

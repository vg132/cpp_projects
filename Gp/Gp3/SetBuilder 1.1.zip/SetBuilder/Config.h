// Config.h: interface for the CConfig class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CONFIG_H__1CAEAFD9_F1D1_4EDC_9E1B_864946E963C2__INCLUDED_)
#define AFX_CONFIG_H__1CAEAFD9_F1D1_4EDC_9E1B_864946E963C2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CConfig  
{
public:
	void SetGp3Dir(CString path);
	CString GetGp3Dir();
	void SaveConfig();
	void LoadConfig();
	CString AppPath();
	CConfig();
	virtual ~CConfig();
private:
	CString Gp3Path;
};

#endif // !defined(AFX_CONFIG_H__1CAEAFD9_F1D1_4EDC_9E1B_864946E963C2__INCLUDED_)

// PixelProfileList.h - header file for the CPixelProfileList class
//

#ifndef __PIXEL_PROFILE_LIST_H__
#define __PIXEL_PROFILE_LIST_H__

#include "LocalPaletteArray.h"
#include "PixelProfile.h"

///////////////////////////////////////////////////////////////////
// Class:	CPixelProfileList
// Base:	[none]
// Created:	07Feb99 by Mal Ross
// Overview:
//    This class represents a list of unique pixel profiles.
//

class CPixelProfileList
{
// Construction and destruction
public:
	CPixelProfileList();
	virtual ~CPixelProfileList();

// Attributes
public:
	// A flag to defined how much we try to avoid knacking up areas
	// of total transparency when clustering profiles.
	static int s_nClusterProtection;
	enum eClusterProtection
	{
		PROTECT_NONE,
		PROTECT_PARTIAL_LAYERING,
		PROTECT_TOTAL_LAYERING
	};

protected:
	// The full set of pixel profiles for a given filtered texture
	CTypedProfileList m_lstProfiles;

	// The size of the local palettes to be created from the list
	// of profiles (which may or may not have been clustered)
	int m_nPaletteSize;

// Operations
public:
	// Add the given profile to the list if not already there,
	// and return its index in the list
	int GetProfileIndex(const CPixelProfile& profile);

	// Get the index of the profile that will be used as the
	// index into the local palettes
	BYTE GetPaletteIndex(const int& nProfileIndex);

	// Clustering of profiles to ensure local palettes have no
	// more than 256 indexes.
	BOOL ClusterProfiles(const int nMaxPaletteSize);

	// Extraction of palettes
	BOOL GetPalettes(CLocalPaletteArray& paletteArray, const BOOL bAllowEmptyPalettes = FALSE);

// Implementation
protected:
	// Function to check whether we actually need local palettes
	BOOL ProfilesNeedLocalPalettes();

	// Delete all of the profiles stored in the list
	void DeleteAll();
};


/////////////////////////////////////////////////////////////////////

#endif	// ~__PIXEL_PROFILE_LIST_H__

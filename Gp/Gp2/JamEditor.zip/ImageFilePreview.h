// ImageFilePreview.h - header file for the CImageFilePreview class
//

#ifndef __IMAGE_FILE_PREVIEW_H__
#define __IMAGE_FILE_PREVIEW_H__

#include "FilePreview.h"

/////////////////////////////////////////////////////////////////
// Class:	CImageFilePreview (abstract)
// Base:	CFilePreview (abstract)
// Created:	27 March 1999 by Mal Ross
// Overview:
//    A class used to display a preview of an image file in
//  a given DC.  This is intended for use in Open / Import
//  dialog boxes to give the user confirmation that the file
//  they're opening is really the one they want.
//

class CImageFilePreview : public CFilePreview
{
	DECLARE_DYNAMIC(CImageFilePreview)

// Construction/destruction
public:
	CImageFilePreview();
	virtual ~CImageFilePreview();

// Operations
public:
	// Information retrieval
	virtual UINT GetImageWidth() const = 0;
	virtual UINT GetImageHeight() const = 0;

	// Draw the preview in the given DC
	virtual BOOL DrawPreview(CDC* pDC, const CRect& rctDraw) const;

// Implementation
protected:
	// Draw the image at 1:1 zoom in the given DC (and at its origin)
	virtual BOOL DrawImageOneToOne(CDC* pDC) const = 0;

	// Get the text to display when the file format is invalid
	virtual CString GetInvalidFormatText() const;
};

/////////////////////////////////////////////////////////////////

#endif	// ~__IMAGE_FILE_PREVIEW_H__


// ImportAnimationDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "ImportAnimationDlg.h"

#include "Timers.h"
#include "MRUPathList.h"
#include "JamEditorMRUPaths.h"
#include "ImportBitmapDialog.h"
#include "GP2Bitmap.h"
#include "FilenameParser.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CImportAnimationDlg dialog


CImportAnimationDlg::CImportAnimationDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CImportAnimationDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CImportAnimationDlg)
	m_nCurrentFrameNum = 1;
	//}}AFX_DATA_INIT

	// Note: these are read from INI file in OnInitDialog
	m_nFrameInterval = 250;		// gap between frames in animation
	m_nCycleInterval = 1000;	// gap between animations
}


void CImportAnimationDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CImportAnimationDlg)
	DDX_Control(pDX, IDC_PREVIEW, m_stcPreview);
	DDX_Text(pDX, IDC_FRAME_NUMBER, m_nCurrentFrameNum);
	//}}AFX_DATA_MAP
	DDX_Text(pDX, IDC_EDIT_FRAME1, m_Frames[0].m_strFilename);
	DDX_Text(pDX, IDC_EDIT_FRAME2, m_Frames[1].m_strFilename);
	DDX_Text(pDX, IDC_EDIT_FRAME3, m_Frames[2].m_strFilename);
	DDX_Text(pDX, IDC_EDIT_FRAME4, m_Frames[3].m_strFilename);
}


BEGIN_MESSAGE_MAP(CImportAnimationDlg, CDialog)
	//{{AFX_MSG_MAP(CImportAnimationDlg)
	ON_BN_CLICKED(IDC_SELECT_FRAME1, OnSelectFrame1)
	ON_BN_CLICKED(IDC_SELECT_FRAME2, OnSelectFrame2)
	ON_BN_CLICKED(IDC_SELECT_FRAME3, OnSelectFrame3)
	ON_BN_CLICKED(IDC_SELECT_FRAME4, OnSelectFrame4)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CImportAnimationDlg frame selection

void CImportAnimationDlg::OnSelectFrame1() 
{
	// Just call the generic version
	OnSelectFrame(0);
}

void CImportAnimationDlg::OnSelectFrame2() 
{
	// Just call the generic version
	OnSelectFrame(1);
}

void CImportAnimationDlg::OnSelectFrame3() 
{
	// Just call the generic version
	OnSelectFrame(2);
}

void CImportAnimationDlg::OnSelectFrame4() 
{
	// Just call the generic version
	OnSelectFrame(3);
}

// Function:	OnSelectFrame(nFrameIndex)
// Overview:	Display the Import Bitmap dialog in which the user can
//				select a bitmap to use as the nFrameIndex'th frame.
void CImportAnimationDlg::OnSelectFrame(const int nFrameIndex) 
{
	// Prepare some strings for use in the dialog
	CString strFileName("*.bmp"), strFilter(""), strDlgTitle(""), strDefaultDir("");
	strFilter.LoadString(IDS_IMPORT_EXPORT_BMP_FILTER);
	strDlgTitle.LoadString(IDS_SELECT_ANIMATION_FRAME_DLGTITLE);
	// Use the same path as for Import Texture
	CMRUPathList* pMRUPaths = CMRUPathList::GetPathList();
	if (NULL != pMRUPaths)
		strDefaultDir = pMRUPaths->GetMRUPath(szImportTexturePath);

	// Create the dialog and set it up
	CImportBitmapDialog dlg(TRUE, ".BMP", strFileName, OFN_FILEMUSTEXIST | OFN_HIDEREADONLY, strFilter);
	dlg.m_ofn.lpstrTitle = strDlgTitle;
	dlg.m_ofn.lpstrInitialDir = strDefaultDir;
	dlg.m_nReqWidth = m_nReqWidth;
	dlg.m_nReqHeight = m_nReqHeight;
	dlg.m_bEnableFiltering = FALSE;	// disable the filtering controls

	// Display the dialog
	if (IDOK == dlg.DoModal())
	{
		// Get the name of the new file
		CString strFilename = dlg.GetPathName();

		// Find out the bitmap's height and width
		CGP2Bitmap bitmap;
		if (!bitmap.LoadFile(strFilename))
		{
			// The user knowingly selected an invalid file - arsehole!
			return;
		}

		// Set the new values in our frames record
		m_Frames[nFrameIndex].m_strFilename = strFilename;
		m_Frames[nFrameIndex].m_sizFrame = CSize(bitmap.GetWidth(), bitmap.GetHeight());

		// Save the path as the most recently used for this type
		// of operation.
		CFilenameParser parsedFileName(dlg.GetPathName());
		if (NULL != pMRUPaths)
			pMRUPaths->SetMRUPath(szImportTexturePath, parsedFileName.DriveAndPath(TRUE));

		// Show the new filename in its control
		UpdateData(FALSE);
	}
}
// End of function 'OnSelectFrame'



/////////////////////////////////////////////////////////////////////////////
// CImportAnimationDlg validation

void CImportAnimationDlg::OnOK() 
{
	// Stop trying to show the animation
	KillTimer(TMR_CYCLE_ANIMATION);

	// Save the timings for the animation to the INI file
	CWinApp* pApp = AfxGetApp();
	if (NULL != pApp)
	{
		// Gap between frames in animation
		pApp->WriteProfileInt("Import Animation", "Frame Interval", (int)m_nFrameInterval);

		// Gap between animations
		pApp->WriteProfileInt("Import Animation", "Cycle Interval", (int)m_nCycleInterval);
	}

	CDialog::OnOK();
}

// Function:	GetFilenames(lstFilenames&)
// Overview:	Fill the given list with the filenames of the frame
//				bitmaps selected by the user.  Fill the list in
//				frame order.
void CImportAnimationDlg::GetFilenames(CStringList& lstFilenames) const
{
	// Just copy the filenames from the m_Frames member, but remember
	// that frame #1 == palette #4, so reverse the order for the palettes.
	lstFilenames.RemoveAll();
	for (int nFrameIndex = NUM_LOCAL_PALETTES_PER_TEXTURE - 1; nFrameIndex >= 0; nFrameIndex--)
		lstFilenames.AddTail(m_Frames[nFrameIndex].m_strFilename);
}
// End of function 'GetFilenames'



/////////////////////////////////////////////////////////////////////////////
// CImportAnimationDlg preview-cycling functions

#define DEFAULT_FRAME_INTERVAL		250
#define MIN_FRAME_INTERVAL			25
#define MAX_FRAME_INTERVAL			1000
#define DEFAULT_CYCLE_INTERVAL		1000
#define MIN_CYCLE_INTERVAL			0
#define MAX_CYCLE_INTERVAL			4000

// Function:	OnInitDialog()
// Overview:	
BOOL CImportAnimationDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// Load the timings for the animation from the INI file
	CWinApp* pApp = AfxGetApp();
	if (NULL != pApp)
	{
		// Gap between frames in animation
		m_nFrameInterval = (UINT)pApp->GetProfileInt("Import Animation", "Frame Interval", DEFAULT_FRAME_INTERVAL);
		m_nFrameInterval = min(MAX_FRAME_INTERVAL, max(MIN_FRAME_INTERVAL, m_nFrameInterval));

		// Gap between animations
		m_nCycleInterval = (UINT)pApp->GetProfileInt("Import Animation", "Cycle Interval", DEFAULT_CYCLE_INTERVAL);
		m_nCycleInterval = min(MAX_CYCLE_INTERVAL, max(MIN_CYCLE_INTERVAL, m_nCycleInterval));
	}

	// Begin the animation in the preview static
	SetTimer(TMR_CYCLE_ANIMATION, m_nFrameInterval, NULL);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
// End of function 'OnInitDialog'


void CImportAnimationDlg::OnTimer(UINT nIDEvent) 
{
	// Check to see whether it's time to move the animation
	// onto the next frame in the preview.
	if (TMR_CYCLE_ANIMATION == nIDEvent)
	{
		// Yes, it's time, let's see the next one.
		m_nCurrentFrameNum = (m_nCurrentFrameNum % NUM_LOCAL_PALETTES_PER_TEXTURE) + 1;
		m_stcPreview.SetFilename(m_Frames[m_nCurrentFrameNum-1].m_strFilename);
		m_stcPreview.Invalidate();

		// If it's the final frame (frame 1), take a rest for a while,
		// otherwise keep up the pace
		KillTimer(TMR_CYCLE_ANIMATION);
		UINT nInterval = m_nFrameInterval;
		if (NUM_LOCAL_PALETTES_PER_TEXTURE == m_nCurrentFrameNum)
			nInterval = m_nCycleInterval;
		SetTimer(TMR_CYCLE_ANIMATION, nInterval, NULL);

		// Update the current frame number in the dialog
		UpdateData(FALSE);
	}
	
	CDialog::OnTimer(nIDEvent);
}

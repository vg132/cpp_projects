// Editable Object
// This is the definition for the programming interface
// to every object that we allow editing for via the tree
// and other parts of the program

// classes which can show properties in the tree or
// be edited via the tree, will be derived from this
// and will, thus, provide a common method of access, regardless
// of what they happen to be!


// This class is to be overridden for each sort of data you
// might want to provide a user interface for


#ifndef _EDITABLE_OBJECT_H_
#define _EDITABLE_OBJECT_H_


class CEditableObject
{
public:
	CEditableObject(CEditableObject* pParent=NULL);	// constructor
	virtual ~CEditableObject();						// virtual destructor

	// =0 means pure virtual functions - you must override these in
	// these functions make up the interface to any sort of editable object
	// the tree and the rest of the program need not know much
	// about the actual data this class is presenting - just how to use it.

	virtual UINT	GetIconID() =0;			// return the ID for the icon in the tree for this item
	virtual CString GetFullDescription()=0;	// return name and value
	virtual CString	GetValueToEdit() { return GetFullDescription(); };		// return the text which can be edited by the user in editing
	virtual BOOL	CanEdit() { return FALSE; }	// whether we can enter editing mode for this item
	virtual void	DataHasChanged(CView* pView, LPARAM lHint, CObject* pHint) { if (m_pParent) m_pParent->DataHasChanged(pView, lHint, pHint); }	// by default, just tell parent	- override to update outside world if your subitem tells you of change

	virtual BOOL	ChangeDataFromEdit(CString) { DataHasChanged(NULL, NULL, NULL); return TRUE; };	// after an edit - this gives us chance to take on the new value

	// sub-item access - each data front end may present a list of
	// sub-items of itself. Each sub item will have its own front end.
	// The sub items are accessed via an MFC POSITION data item
	// this POSITION may be anything (array index, pointer, enumeration.. anything)
	// however POSITION==0 means no more to look at
	virtual POSITION GetFirstSubItemPosition() { return NULL;}
	virtual	CEditableObject* GetNextSubItem(POSITION&) { return NULL; } // get the subitem referred to by position and increment position to point to the next sub item

	// Handle various interactions in the tree
	virtual BOOL HandleSelect () { return FALSE; }
	virtual BOOL HandleDblClk ();

public:
	// function to tell this front end which tree item it relates to
	void SetTreeItem(HTREEITEM hItem) { m_hTreeItem=hItem; }
	HTREEITEM GetTreeItem() { return m_hTreeItem; }

	CEditableObject* GetParent() { return m_pParent; }

public:
	// interface for those objects which can be made persistent
	virtual void Serialize(CArchive&) {};

protected:

	// data part-the tree item in the main tree
	HTREEITEM m_hTreeItem;

	CEditableObject* m_pParent;	// the item which this is the sub-item of
};

#endif
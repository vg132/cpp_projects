// JascPalettePreview.h - header file for the CJascPalettePreview class
//

#ifndef __JASC_PALETTE_PREVIEW_H__
#define __JASC_PALETTE_PREVIEW_H__

#include "GP2BitmapPreview.h"

/////////////////////////////////////////////////////////////////
// Class:	CJascPalettePreview
// Base:	CGP2BitmapPreview
// Created:	30 July 2000 by Mal Ross
// Overview:
//    A class used to display a preview of a 256-colour JASC
//  palette.  This is intended for use in the Jam Editor's
//  Custom Palette option.  It's only really derived from
//  CGP2BitmapPreview for convenience - I'll use the base
//  class's bitmap to show my palette.
//

class CJascPalettePreview : public CGP2BitmapPreview
{
	DECLARE_DYNAMIC(CJascPalettePreview)

// Construction/destruction
public:
	CJascPalettePreview();
	virtual ~CJascPalettePreview();

	// Cloning function
	virtual CFilePreview* CreateNewPreview() const;

// Operations
public:
	// Information retrieval
	virtual void GetSupportedFileTypes (CStringList& lstFileTypes) const;

// Implementation
protected:
	// Loading the file.  Derived classes must override this as
	// they're the only ones who know the format of the file.
	virtual BOOL LoadFile (const CString& strFilename);

	// Get the text to display when the file format is invalid
	virtual CString GetInvalidFormatText() const;
};

/////////////////////////////////////////////////////////////////

#endif	// ~__JASC_PALETTE_PREVIEW_H__


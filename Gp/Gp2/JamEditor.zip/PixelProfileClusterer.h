// PixelProfileClusterer.h - header file for the CPixelProfileClusterer class
//

#ifndef __PIXEL_PROFILE_CLUSTERER_H__
#define __PIXEL_PROFILE_CLUSTERER_H__

#include "GridTemplate.h"

#include "PixelProfileCluster.h"

///////////////////////////////////////////////////////////////////
// Class:	CPixelProfileClusterer
// Base:	[none]
// Created:	19Apr99 by Mal Ross
// Overview:
//    This class represents a single cluster of pixel profiles,
//  from which a single profile will be used as the representative
//  profile to go into the local palettes of a jam texture.
//

class CPixelProfileClusterer
{
// Construction and destruction
public:
	CPixelProfileClusterer(const CTypedProfileList& profileList);
	~CPixelProfileClusterer();

// Attributes
protected:
	// The list of pixel profiles clusters to be merged
	CTypedPtrList<CPtrList, CPixelProfileCluster*> m_lstClusters;

	// A matrix of potential clusters, created by combining each cluster in
	// m_lstClusters with each other cluster in the list.  Note that each
	// cluster object contains a match factor, which is used to determine
	// which two clusters are combined in each iteration of clustering.
	// If you followed that, you're a better person than me. :)
	CGrid<CPixelProfileCluster*, CPixelProfileCluster*&> m_Matrix;

	// The indexes in the m_lstClusters list of the clusters which
	// combine to give the greatest combined cluster factor.  The combined
	// cluster will be at (m_nCombinePair1, m_nCombinePair2) in m_Matrix.
	int m_nCombinePair1;
	int m_nCombinePair2;

// Operations
public:
	BOOL IsClusterable() const { return (m_nCombinePair1 != m_nCombinePair2); }
	double GetBestClusterFactor() const
	{
		// NOTE: there's a distinct lack of error checking here, 
		// for the purposes of efficiency.
		return m_Matrix.GetAt(m_nCombinePair1, m_nCombinePair2)->GetClusterFactor();
	}

	// Perform the actual clustering
	BOOL CombineClosestClusters();

	// Finish off the clustering by assigning the profiles in each of
	// the clusters their relevant cluster and palette indexes
	BOOL AssignClusterIndexes(BYTE& nClusterIndex);

// Implementation
protected:
	// Initialise the match matrix, but don't calculate any
	// actual match factors
	void InitClusterMatrix();

	// Create the potential combined clusters in the matrix of said
	// items.
	void CreateAllPotentialClusters();

	// Add a new combined cluster to the list of current clusters
	BOOL AddCluster(CPixelProfileCluster* pAddCluster);

	// From the current match matrix, find the two clusters which
	// combine to the greatest resultant match factor.
	void FindClosestClusters();

	// Deletion of clusters and their corresponding potential clusters
	// in the matrix
	void DeleteAllClusters();
	void DeleteCluster(const int nClusterIndex, const int nException = -1);
};

typedef CTypedPtrList<CPtrList, CPixelProfileClusterer*> CClustererList;

///////////////////////////////////////////////////////////////////

#endif	// ~__PIXEL_PROFILE_CLUSTERER_H__


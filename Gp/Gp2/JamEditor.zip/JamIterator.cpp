// JamIterator.cpp: implementation file for the CJamIterator class
//

#include "stdafx.h"

#include "JamIterator.h"

#include "JamTexture.h"
#include "Jam.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJamIterator

CJamIterator::CJamIterator(const CJam* pParentJam)
{
	// Initialise all members
	ASSERT(NULL != pParentJam);
	m_pJam = pParentJam;
	m_posNextTexture = NULL;
	m_pCurrTexture = NULL;
}

CJamIterator::~CJamIterator()
{
}


/////////////////////////////////////////////////////////////////////////////
// CJamIterator iteration operations

void CJamIterator::FindFirst()
{
	m_posNextTexture = m_pJam->GetFirstTexturePos();
	m_pCurrTexture = m_pJam->GetNextTexture(m_posNextTexture);
}

void CJamIterator::FindNext()
{
	if (!IsValid())
		return;

	if (IsDone())
		return;

	if (NULL == m_posNextTexture)
		m_pCurrTexture = NULL;
	else
		m_pCurrTexture = m_pJam->GetNextTexture(m_posNextTexture);
}

BOOL CJamIterator::IsDone()
{
	if (!IsValid())
		return TRUE;

	return (NULL == m_posNextTexture && NULL == m_pCurrTexture);
}

CJamTexture* CJamIterator::GetCurrent()
{
	if (!IsValid())
		return NULL;

	return m_pCurrTexture;
}

BOOL CJamIterator::IsValid() const
{
	return (NULL != m_pJam);
}



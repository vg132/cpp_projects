// PixelProfile.cpp - implementation of the CPixelProfile class
//

#include "stdafx.h"

#include "PixelProfile.h"
#include "TexturePalette.h"
#include <math.h>
#include "ColorFunctions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CPixelProfile construction/destruction

// Constructor
CPixelProfile::CPixelProfile(const UINT& nNumPalettes)
{
	// Create the array of pixel values
	ASSERT(nNumPalettes > 0);
	m_nNumPalettes = nNumPalettes;
	if (nNumPalettes > 0)
	{
		m_pbPixels = new BYTE[nNumPalettes];
		memset(m_pbPixels, 0, nNumPalettes);
	}
	else
		m_pbPixels = NULL;

	// Initialise the various indexes (to invalid values where poss.)
	m_nProfileIndex = -1;
	m_nClusterIndex = 255;
	m_nMasterIndex = -1;
}

// Copy constructor
CPixelProfile::CPixelProfile(const CPixelProfile& copyProfile)
{
	// Just copy the simple members, then allocate a new 
	// array of pixel values and copy them from the other profile
	m_nProfileIndex = copyProfile.m_nProfileIndex;
	m_nClusterIndex = copyProfile.m_nClusterIndex;
	m_nMasterIndex = copyProfile.m_nMasterIndex;
	m_nNumPalettes = copyProfile.m_nNumPalettes;
	if (m_nNumPalettes > 0)
	{
		m_pbPixels = new BYTE[m_nNumPalettes];
		memcpy(m_pbPixels, copyProfile.m_pbPixels, m_nNumPalettes);
	}
	else
		m_pbPixels = NULL;
}

// Destructor
CPixelProfile::~CPixelProfile()
{
	// Destroy the pixels of the various palettes
	if (NULL != m_pbPixels)
	{
		delete[] m_pbPixels;
		m_pbPixels = NULL;
	}
}


/////////////////////////////////////////////////////////////////////////////
// CPixelProfile comparison functions

// Equality operator (FOR PIXEL VALUES ONLY)
BOOL CPixelProfile::operator== (const CPixelProfile& other) const
{
	// Check to make sure the same number of pixels are
	// stored in the other profile as in this one.
	if (other.m_nNumPalettes != m_nNumPalettes)
		return FALSE;

	// Check each of the pixels
	BOOL bEqual = TRUE;
	for (UINT nPalNum = 0; nPalNum < m_nNumPalettes && bEqual; nPalNum++)
		bEqual = (other.m_pbPixels[nPalNum] == m_pbPixels[nPalNum]);

	// Note: don't compare palette indexes!!

	return bEqual;
}
// End of operator==


// A function to calculate the similarity of this profile to
// another one (0 == opposite, 1 == identical)
double CPixelProfile::GetMatchFactor(const CPixelProfile& other) const
{
	// NOTE: there is debug-checking here ONLY.  This is purely
	// for efficiency purposes - the fewer checks I do, the less
	// time it takes.  HOWEVER, this does mean that I've got to
	// be *damned sure* my calling code has everything set up
	// correctly first!!!
	ASSERT(other.m_nNumPalettes == m_nNumPalettes);
	ASSERT(NULL != other.m_pbPixels && NULL != m_pbPixels);
	ASSERT(s_nCacheMatrixSize > 0);

	// Check to see whether the comparison has already been cached.
	if (s_CacheMatrix[m_nProfileIndex][other.m_nProfileIndex] != PROFILE_MATCH_FACTOR_UNDEFINED)
		return s_CacheMatrix[m_nProfileIndex][other.m_nProfileIndex];

	// Calculate the proximity in the same sort of way as for colors.
	// This means treating the difference between corresponding
	// pixels as a dimension in 'm_nNumPalettes' dimensional space.
	// We then use Pythsgorus' theorem to calculate the overall
	// magnitude of the combined vectors, thereby giving us the 
	// proximity of the two profiles.  Did you follow that? ;-)
	double dTotalProximity = 0.0f;
	double dCurrMatch = 0.0f;
	for (int nPalNum = 0; nPalNum < (int)m_nNumPalettes; nPalNum++)
	{
		dCurrMatch = GetColorMatchFactor(m_pbPixels[nPalNum], other.m_pbPixels[nPalNum]);
		dTotalProximity += (dCurrMatch * dCurrMatch);
	}

	// Cache this result
	s_CacheMatrix[m_nProfileIndex][other.m_nProfileIndex] = dTotalProximity;
	s_CacheMatrix[other.m_nProfileIndex][m_nProfileIndex] = dTotalProximity;

	return dTotalProximity;
}
// End of function 'GetMatchFactor'


/////////////////////////////////////////////////////////////////////////////
// CPixelProfile attributes

// Function:	GetPalettePixel(nPaletteNum)
// Overview:	Get the value of the pixel in the given palette
BYTE CPixelProfile::GetPalettePixel(const UINT& nPaletteNum) const
{
	// Check that the palette number is valid
	ASSERT(nPaletteNum < m_nNumPalettes);
	if (nPaletteNum >= m_nNumPalettes)
		return 0;

	return m_pbPixels[nPaletteNum];
}
// End of function 'GetPalettePixel'


// Function:	SetPalettePixel(nPaletteNum, pixelValue)
// Overview:	Set the value of the pixel in the given palette
BOOL CPixelProfile::SetPalettePixel(const UINT& nPaletteNum, const BYTE& pixelValue)
{
	// Check that the palette number is valid
	ASSERT(nPaletteNum < m_nNumPalettes);
	if (nPaletteNum >= m_nNumPalettes)
		return FALSE;

	m_pbPixels[nPaletteNum] = pixelValue;

	return TRUE;
}
// End of function 'SetPalettePixel'


// Function:	VariesAcrossPalettes()
// Overview:	A test to see whether the pixel colour varies
//				across the palettes.
BOOL CPixelProfile::VariesAcrossPalettes() const
{
	BOOL bEqual = TRUE;
	for (int nPalNum = 1; (nPalNum < (int)m_nNumPalettes) && bEqual; nPalNum++)
		bEqual = (m_pbPixels[nPalNum - 1] == m_pbPixels[nPalNum]);

	return !bEqual;
}
// End of function 'VariesAcrossPalettes'



/////////////////////////////////////////////////////////////////////////////
// Match factor caching

double** CPixelProfile::s_CacheMatrix = NULL;
int CPixelProfile::s_nCacheMatrixSize = 0;

// Cache management functions
void CPixelProfile::ClearCache()
{
	// Make sure the match matrix is not empty
	ASSERT(NULL != s_CacheMatrix);

	// Clear out the profile similarity matrix
	for (int nRow = 0; nRow < s_nCacheMatrixSize; nRow++)
	{
		delete[] s_CacheMatrix[nRow];
	}
	delete[] s_CacheMatrix;
	s_CacheMatrix = NULL;
	s_nCacheMatrixSize = 0;
}

void CPixelProfile::PrepareCache(const int nNumProfiles)
{
	// Make sure the match matrix is empty first
	ASSERT(NULL == s_CacheMatrix);
	ASSERT(0 == s_nCacheMatrixSize);
	ASSERT(nNumProfiles > 256);

	// Finally, initialise the values in the matrix
	s_CacheMatrix = new double*[nNumProfiles];
	for (int nRow = 0; nRow < nNumProfiles; nRow++)
	{
		s_CacheMatrix[nRow] = new double[nNumProfiles];
		for (int nCol = 0; nCol < nNumProfiles; nCol++)
			s_CacheMatrix[nRow][nCol] = PROFILE_MATCH_FACTOR_UNDEFINED;
	}
	s_nCacheMatrixSize = nNumProfiles;
}


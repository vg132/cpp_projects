// NightFilter.h - header file for the CNightFilter class
//

#ifndef __NIGHT_FILTER_H__
#define __NIGHT_FILTER_H__

#include "LocalFilter.h"
class CColor;

///////////////////////////////////////////////////////////////////
// Class:	CNightFilter
// Base:	CLocalFilter
// Created:	06Feb99 by Mal Ross
// Overview:
//    This filter produces 4 decoded textures that gradually
//  darken, thus creating the effect of driving at night with
//  headlights.  Hopefully. :)  This idea is taken from Addie
//  Walti's night-driving version of Bern Grauholz.
//

class CNightFilter : public CLocalFilter
{
// Construction and destruction
public:
	CNightFilter();
	virtual ~CNightFilter();

// Enumerations
public:
	// Values in the range below represent the number of
	// quarter-hours past 7pm that the Night Filter simulates
	enum eTimeIndex
	{
		MIN_TIME_INDEX = 0,
		MAX_TIME_INDEX = 20,
		DEFAULT_TIME_INDEX = 14
	};

// Attributes
private:
	// How much of the luminance of the previous texture should be
	// kept for subsequent textures?
	float m_fLightSavingFactor;

	// The number of quarter-hours past 7pm this filter simulates
	int m_nTimeIndex;

// Operations
public:
	// User-configuration of the filter's parameters
	virtual BOOL IsConfigurable() const { return TRUE; }
	virtual void Configure();

// Implementation
protected:
	// Get the light-saving factor used when filtering colours
	// (see the declaration of m_fLightSavingFactor above)
	float GetLightSavingFactor() const { return m_fLightSavingFactor; }

	// Get/set the time index (see declaration of m_nTimeIndex
	// above for its meaning)
	BOOL SetTimeIndex(const int nTimeIndex);
	int GetTimeIndex() const;

	// Just reduce the luminance of the given colour by
	// the factor in m_fLightSavingFactor
	virtual void FilterColor(CColor& color);
};

/////////////////////////////////////////////////////////////////////

#endif	// ~__NIGHT_FILTER_H__

// CEditableTypedPtrList
// This is a template for a typed ptr list, capable
// of being used as a CEditableObject

#ifndef EDITABLE_TYPED_PTR_LIST_H
#define EDITABLE_TYPED_PTR_LIST_H

#include "EditableObject.h"

// this class will do the list-side automatically!
// you just have to handle the icons and editing of the
// header node!

class CEditableTypedPtrList : public CEditableObject, public CTypedPtrList<CPtrList, CEditableObject*>
{
public:
	CEditableTypedPtrList(CEditableObject* pParent=NULL);
	virtual ~CEditableTypedPtrList();
public:
	// list like stuff!
	CTypedPtrList<CPtrList, CEditableObject*> m_list;

public:
	// overrides
	virtual POSITION GetFirstSubItemPosition() { return GetHeadPosition();}
	virtual	CEditableObject* GetNextSubItem(POSITION& pos) { return		GetNext(pos); } // get the subitem referred to by position and increment position to point to the next sub item

	// for the other things to override - see the
	// base class - CEditableObject


};


#endif


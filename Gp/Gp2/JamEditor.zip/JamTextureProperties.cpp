// the jam texture properties
// this fronts for a texture within the jam file
// it shows and handles editing of the actual ID value
// and it points to the list of texture parameters

#include "stdafx.h"
#include "resource.h"

#include "JamTextureProperties.h"
#include "JamTexture.h"
#include "TreeIconDefs.h"

CJamTextureProperties::CJamTextureProperties(CJamTexture* pTexture, CEditableObject* pParent) : CEditableTypedPtrList(pParent)
{
	// store the texture
	m_pTexture=pTexture;

	// it should not be null
	ASSERT(pTexture);
}

// the destructor of this will delete
// all child items for the purposes of tidy up
CJamTextureProperties::~CJamTextureProperties()
{
}

// get the icon	
UINT	CJamTextureProperties::GetIconID()
{
	return JTI_JAM_TEXTURE;
}

// work out the description for this jam's ID
CString CJamTextureProperties::GetFullDescription()
{
	// gather data
	UINT nTextureID = 0;
	if (NULL != m_pTexture)
	{
		nTextureID = m_pTexture->GetTextureID();
	}

	// format the description
	CString description("");
	description.Format(IDS_NODE_TEXTURE_ID, nTextureID);

	// return it
	return description;
}

// produce a value for editing this jam's ID
CString	CJamTextureProperties::GetValueToEdit()
{
	CString thingToEdit;

	// try and fill this from the Jam ID
	if (m_pTexture)
	{
		thingToEdit.Format("%d", m_pTexture->GetTextureID());
	}

	return thingToEdit;
}

BOOL	CJamTextureProperties::CanEdit()
{
	return TRUE;	// this is an editable one!
}

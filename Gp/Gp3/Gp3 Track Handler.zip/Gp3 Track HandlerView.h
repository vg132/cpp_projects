// Gp3 Track HandlerView.h : interface of the CGp3TrackHandlerView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_GP3TRACKHANDLERVIEW_H__D49ED8CC_64C2_11D4_B4A4_0008C7636E27__INCLUDED_)
#define AFX_GP3TRACKHANDLERVIEW_H__D49ED8CC_64C2_11D4_B4A4_0008C7636E27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Text.h"

class CGp3TrackHandlerView : public CFormView
{
protected: // create from serialization only
	CGp3TrackHandlerView();
	DECLARE_DYNCREATE(CGp3TrackHandlerView)
	CText m_Text;
public:
	//{{AFX_DATA(CGp3TrackHandlerView)
	enum { IDD = IDD_GP3TRACKHANDLER_FORM };
	CListBox	m_List;
	//}}AFX_DATA

// Attributes
public:
	CGp3TrackHandlerDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGp3TrackHandlerView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	void ImportText();
	virtual ~CGp3TrackHandlerView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CGp3TrackHandlerView)
	afx_msg void OnButtonImport();
	afx_msg void OnButtonList();
	afx_msg void OnButtonChange();
	afx_msg void OnButtonSave();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in Gp3 Track HandlerView.cpp
inline CGp3TrackHandlerDoc* CGp3TrackHandlerView::GetDocument()
   { return (CGp3TrackHandlerDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GP3TRACKHANDLERVIEW_H__D49ED8CC_64C2_11D4_B4A4_0008C7636E27__INCLUDED_)

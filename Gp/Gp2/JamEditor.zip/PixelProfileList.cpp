// PixelProfileList.cpp - implementation of the CPixelProfileList class
//

#include "stdafx.h"

#include "PixelProfileList.h"

#include "PixelProfileClusterer.h"
#include "TexturePalette.h"
#include "JamConstants.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CPixelProfileList class
//

// Cluster protection method for transparent areas
int CPixelProfileList::s_nClusterProtection = CPixelProfileList::PROTECT_NONE;

// Constructor
CPixelProfileList::CPixelProfileList() : m_nPaletteSize(0)
{
}

// Destructor
CPixelProfileList::~CPixelProfileList()
{
	// Delete all of the profiles we're storing
	DeleteAll();
}

// Delete all of the profiles stored in the list
void CPixelProfileList::DeleteAll()
{
	while (NULL != m_lstProfiles.GetHeadPosition())
		delete m_lstProfiles.RemoveHead();
}


// Function:	GetProfileIndex(profile)
// Overview:	Get the index of a given profile in the list. If the
//				profile is not in our list, add it to the end of the
//				list and return its index there.
int CPixelProfileList::GetProfileIndex(const CPixelProfile& profile)
{
	// Search through the list for a match to the given profile
	POSITION posProfile = m_lstProfiles.GetHeadPosition();
	BOOL bFound = FALSE;
	int nIndex = 0;
	while (NULL != posProfile && !bFound)
	{
		// Get the next profile
		CPixelProfile* pProfile = m_lstProfiles.GetNext(posProfile);
		if (NULL == pProfile)
		{
			ASSERT(FALSE);
			nIndex++;
			continue;
		}

		bFound = (profile == *pProfile);
		if (!bFound)
			nIndex++;
	}

	// If we didn't find the profile, we may need to add it to the list
	if (!bFound)
	{
		CPixelProfile* pNewProfile = new CPixelProfile(profile);
		ASSERT(NULL != pNewProfile);
		if (NULL != pNewProfile)
		{
			// Set the initial indexes of the profile
			nIndex = m_lstProfiles.GetCount();
			pNewProfile->SetProfileIndex(nIndex);
			pNewProfile->SetMasterIndex(nIndex);
			pNewProfile->SetClusterIndex((BYTE)(nIndex % 256));

			// Add it to the list
			m_lstProfiles.AddTail(pNewProfile);
			m_nPaletteSize++;
		}
		else
			nIndex = -1;
	}

	return nIndex;
}
// End of function 'GetProfileIndex'


// Function:	GetPaletteIndex(nProfileIndex)
// Overview:	Get the index of the profile that will be used as
//				the index into the local palettes
BYTE CPixelProfileList::GetPaletteIndex(const int& nProfileIndex)
{
	// Find the profile in the list
	POSITION posProfile = m_lstProfiles.FindIndex(nProfileIndex);
	if (NULL == posProfile)
	{
		ASSERT(FALSE);
		return 0;
	}
	CPixelProfile* pProfile = m_lstProfiles.GetAt(posProfile);
	if (NULL == pProfile)
	{
		ASSERT(FALSE);
		return 0;
	}

	// The index used as an index into the local palettes is
	// the cluster index
	return pProfile->GetClusterIndex();
}
// End of function 'GetPaletteIndex'


// Function:	GetPalettes(paletteArray&, bAllowEmptyPalettes)
// Overview:	Extraction of palettes for use in a CJamTexture.  Return
//				TRUE upon success, or FALSE if the function fails.
BOOL CPixelProfileList::GetPalettes(CLocalPaletteArray& paletteArray, const BOOL bAllowEmptyPalettes)
{
	// First check to see whether we actually need local palettes
	if (!ProfilesNeedLocalPalettes() && bAllowEmptyPalettes)
	{
		// No need for local palettes
		paletteArray.CreatePalettes(0);
		return TRUE;
	}

	// Create the empty palettes of the size required to hold
	// the relevant value from each of our profiles
	int nPaletteSize = m_nPaletteSize;
	if (!paletteArray.CreatePalettes(nPaletteSize))
		return FALSE;

	// Go through the pixel profiles in our list, putting their values
	// into the appropriate palettes
	int nNumPalettes = paletteArray.GetSize();
	POSITION posProfile = m_lstProfiles.GetHeadPosition();
	while (NULL != posProfile)
	{
		// Get the next pixel profile and its index in the palette
		CPixelProfile* pProfile = m_lstProfiles.GetNext(posProfile);
		ASSERT(NULL != pProfile);
		if (NULL == pProfile)
			continue;

		// When the list of profiles has fewer than 256 profiles,
		// they should be in order anyway.  For lists that have to
		// be clustered, we need to use the cluster index as the
		// palette index and we need to use the colours of the
		// master profile for the colours in the local palettes.
		POSITION posMasterProfile = m_lstProfiles.FindIndex(pProfile->GetMasterIndex());
		CPixelProfile* pMasterProfile = m_lstProfiles.GetAt(posMasterProfile);

		// Set each of the pixel values in the local palettes
		int nPalIndex = pProfile->GetClusterIndex();
		for (int nPalNum = 0; nPalNum < nNumPalettes; nPalNum++)
			paletteArray[nPalNum][nPalIndex] = pMasterProfile->GetPalettePixel(nPalNum);
	}

	return TRUE;
}
// End of function 'GetPalettes'


// Function:	ProfilesNeedLocalPalettes()
// Overview:	Function to check whether we actually need
//				local palettes.
BOOL CPixelProfileList::ProfilesNeedLocalPalettes()
{
	// Loop through the profiles looking for any that have
	// different pixel colours in the different palettes
	BOOL bAllPalettesAreEqual = TRUE;
	POSITION posProfile = m_lstProfiles.GetHeadPosition();
	while (NULL != posProfile && bAllPalettesAreEqual)
	{
		CPixelProfile* pProfile = m_lstProfiles.GetNext(posProfile);
		ASSERT(NULL != pProfile);
		if (NULL != pProfile)
			bAllPalettesAreEqual = !pProfile->VariesAcrossPalettes();
	}

	return !bAllPalettesAreEqual;
}
// End of function 'ProfilesNeedLocalPalettes'


// Function:	ClusterProfiles(nMaxPaletteSize)
// Overview:	Clustering of profiles to ensure local palettes
//				have no more than nMaxPaletteSize indexes.  Note:
//				this is a f*&!ing complicated process, so I'm
//				going to have to try to summarise it here.  However,
//				you'll also have to look inside CPixelProfile-
//				Clusterer to see how it works.  (Sorry the class
//				names are a bit tricky, by the way.)
// Pseudocode:
//  1. Split m_lstProfiles up into a list of lists of profiles,
//     each list containing only profiles that have the same
//     start colour.
//  2. Create a CPixelProfileClusterer object for each of these
//     lists.  These will cluster the profiles within them based
//     upon the similarity between the profiles.
//  3. Sort the list of clusterer objects by the cluster factor
//     of their closest clusters.  Sort them into descending
//     order, so that the clusterer with the closest matching
//     clusters will be at the front of the list.  Don't include
//     clusterers in the sorted list if they contain only a
//     single profile.
//  4. While the total number of clusters remaining is > 256
//     a. Remove the clusterer at the head of the list
//     b. Ask it to combine its closest clusters
//     c. Re-insert it into the sorted list of clusterers at
//        a position determined by the closeness of its next
//        closest clusters, iff it can still be clustered.
//     d. decrement the number of clusters remaining
//     continue
//  5. Once the total number of clusters left is <= 256, assign
//     each cluster a unique cluster index, which will become the
//     local palette index of all profiles within that cluster.
//  6. And... relax!
//
//     If that did your head in, just think what it was like for me
//     writing it!!!
BOOL CPixelProfileList::ClusterProfiles(const int nMaxPaletteSize)
{
	// Check to see whether we actually need to cluster the
	// profiles first
	int nNumProfiles = m_lstProfiles.GetCount();
	if (nNumProfiles <= nMaxPaletteSize)
		return TRUE;

	// Set up the pixelprofile match-factor cache
	CPixelProfile::PrepareCache(nNumProfiles);

	// Let the user know we're about to cluster things...
	CFrameWnd* pFrameWnd = (CFrameWnd *)AfxGetMainWnd();
	if (NULL != pFrameWnd)
	{
		CString strPrompt("");
		strPrompt.Format("Preparing to cluster %d profiles...", nNumProfiles);
		pFrameWnd->SetMessageText(strPrompt);
	}

	// STEP 1
	// Sort the pixel profiles out into separate lists where each
	// profile in a given list has the same start pixel colour.
	CSeparatedProfileList lstProfileLists;
	POSITION posProfile = m_lstProfiles.GetHeadPosition();
	CPixelProfile* pProfile = NULL;
	CTypedProfileList* pTransparentProfiles = NULL;
	while (NULL != posProfile)
	{
		// Get the next profile and add it to the list of
		// profiles with the same first pixel (or create a
		// new list if this is the first one with that first
		// pixel colour).  Note that the list of profile-lists
		// is kept sorted by the first palette index in the
		// profile too.
		pProfile = m_lstProfiles.GetNext(posProfile);
		BYTE byPixelIndex = pProfile->GetPalettePixel(0);
		BOOL bAddedProfile = FALSE;
		POSITION posProfileList = lstProfileLists.GetHeadPosition();
		while (NULL != posProfileList && !bAddedProfile)
		{
			CTypedProfileList* pProfileList = lstProfileLists.GetAt(posProfileList);
			BYTE byCurrPixelIndex = pProfileList->GetHead()->GetPalettePixel(0);
			if (byPixelIndex == byCurrPixelIndex)
			{
				pProfileList->AddTail(pProfile);
				bAddedProfile = TRUE;
			}
			else if (byPixelIndex < byCurrPixelIndex)
			{
				CTypedProfileList* pProfileList = new CTypedProfileList;
				pProfileList->AddTail(pProfile);
				lstProfileLists.InsertBefore(posProfileList, pProfileList);	// keep the list sorted
				if (GP2_TRANSPARENT_PALETTE_INDEX == byPixelIndex)
					pTransparentProfiles = pProfileList;
				bAddedProfile = TRUE;
			}
			else
				lstProfileLists.GetNext(posProfileList);
		}
		if (!bAddedProfile)
		{
			// This must either be the first profile list we've created,
			// or the profile's first pixel index comes after all other
			// indexes so far, so just add the profile list to the end
			// of lstProfileLists.
			CTypedProfileList* pProfileList = new CTypedProfileList;
			pProfileList->AddTail(pProfile);
			lstProfileLists.AddTail(pProfileList);
			if (GP2_TRANSPARENT_PALETTE_INDEX == byPixelIndex)
				pTransparentProfiles = pProfileList;
		}
	}

	// There is a problem with unprotected transparency when clustering
	// is required.  The problem is that the transparent areas usually
	// get clustered with the blurred bits around their edges and end
	// up not being transparent throughout the profile.  Cluster protection
	// is a poorly-named attempt to prevent this happening by separating
	// areas of full transparency from the clustering process.  Sadly,
	// it doesn't really seem to work, hence the need to support a number
	// of different algorithms during development. :(
	switch (s_nClusterProtection)
	{
	case PROTECT_NONE:
		{
			// Nothing to do - just carry on as per usual
		}
		break;
	case PROTECT_PARTIAL_LAYERING:
		{
			// In order to protect large areas that are transparent in all
			// local palettes, remove the fully-transparent profile from the
			// rest of the profiles that have transparency in only part of
			// them.  Note: if there's only one profile containing transparency
			// we can skip anything that involves splitting the list, of course. :)
			if ((NULL != pTransparentProfiles) && (pTransparentProfiles->GetCount() > 1))
			{
				// Go through the transparent profiles looking for the fully
				// transparent one
				POSITION posProfile = pTransparentProfiles->GetHeadPosition();
				BOOL bFoundTransparentProfile = FALSE;
				CPixelProfile* pProfile = NULL;
				while ((NULL != posProfile) && !bFoundTransparentProfile)
				{
					// Get the next profile from the list
					pProfile = pTransparentProfiles->GetAt(posProfile);
					ASSERT(NULL != pProfile);
					if (NULL != pProfile)
					{
						// Check to see whether all local palettes use the transparent colour
						BOOL bTrans = TRUE;
						for (int nPalNum = 0; nPalNum < NUM_LOCAL_PALETTES_PER_TEXTURE && bTrans; nPalNum++)
							bTrans = (GP2_TRANSPARENT_PALETTE_INDEX == pProfile->GetPalettePixel(nPalNum));

						// Set the loop-terminating condition if we've found the one
						// profile that's transparent all the way through.
						if (bTrans)
							bFoundTransparentProfile = TRUE;
						else
							pTransparentProfiles->GetNext(posProfile);
					}
					else
						pTransparentProfiles->GetNext(posProfile);
				}

				// If we've found the transparent profile, remove it from the list
				// and put it into the transparent-only list.  Then put the new
				// list into the list of lists.
				if (bFoundTransparentProfile)
				{
					// Remove the fully-transparent profile from the list of
					// transparent profiles.
					pTransparentProfiles->RemoveAt(posProfile);

					// Add it to a new list and add that list to the list of lists
					CTypedProfileList* pFullyTransparentList = new CTypedProfileList;
					pFullyTransparentList->AddTail(pProfile);
					lstProfileLists.AddHead(pFullyTransparentList);
				}
			}
		}
		break;
	case PROTECT_TOTAL_LAYERING:
		{
			// Now also split the list of profiles starting with transparency
			// into lists of profiles with transparency in these palettes:
			// (1), (1&2), (1&2&3), (1&2&3&4).  This is done to ensure that
			// large areas of the texture that should be transparent in all
			// palettes do not get approximated to a profile that is
			// transparent in e.g. only the first two palettes.  Understand?
			// No, I barely understand it myself. ;-)
			if (NULL != pTransparentProfiles)
			{
				// Move each of the profiles in pTransparentProfiles into one
				// of the lists described in the big comment above.
				CTypedProfileList** pTransparentLists = new CTypedProfileList*[NUM_LOCAL_PALETTES_PER_TEXTURE];
				memset(pTransparentLists, 0, sizeof(CTypedProfileList*) * NUM_LOCAL_PALETTES_PER_TEXTURE);
				while (NULL != pTransparentProfiles->GetHeadPosition())
				{
					// Remove the next profile from the list
					CPixelProfile* pProfileToTransfer = pTransparentProfiles->RemoveHead();
					ASSERT(NULL != pProfileToTransfer);
					if (NULL == pProfileToTransfer)
						continue;

					// Figure out which of the new lists it has to go in
					int nDestinationIndex = INT_MAX;
					for (int nPalNum = NUM_LOCAL_PALETTES_PER_TEXTURE - 1;
						 (nDestinationIndex == INT_MAX) && (nPalNum >= 0);
						 nPalNum--)
					{
						// Check whether the transparency extends into the nPalNum'th palette
						if (GP2_TRANSPARENT_PALETTE_INDEX == pProfileToTransfer->GetPalettePixel(nPalNum))
							nDestinationIndex = nPalNum;
					}

					// This profile needs to go into the nDestinationIndex'th list
					if (NULL == pTransparentLists[nDestinationIndex])
						pTransparentLists[nDestinationIndex] = new CTypedProfileList;
					pTransparentLists[nDestinationIndex]->AddTail(pProfileToTransfer);
				}

				// Now put the new list(s) we've created into lstProfileLists, replacing
				// the profile list we just split up...

				// Remove the original profile list...
				POSITION posExistingTransparentProfiles = lstProfileLists.Find(pTransparentProfiles);
				ASSERT(NULL != posExistingTransparentProfiles);
				if (NULL != posExistingTransparentProfiles)
					lstProfileLists.RemoveAt(posExistingTransparentProfiles);
				delete pTransparentProfiles;
				pTransparentProfiles = NULL;

				// ... and replace it with the new ones
				for (int nPalNum = NUM_LOCAL_PALETTES_PER_TEXTURE - 1; nPalNum >= 0; nPalNum--)
				{
					// Remember, we may not have needed a complete set of new lists
					// if the only profiles with transparency had it right through them
					if (NULL != pTransparentLists[nPalNum])
						lstProfileLists.AddHead(pTransparentLists[nPalNum]);
				}
				delete[] pTransparentLists;
				pTransparentLists = NULL;
			}
		}
		break;
	}

	// STEP 2
	// Now create a clustering object for each of the profile lists
	CClustererList lstAllClusterers;
	POSITION posProfileList = lstProfileLists.GetHeadPosition();
	while (NULL != posProfileList)
	{
		CTypedProfileList* pProfileList = lstProfileLists.GetNext(posProfileList);
		lstAllClusterers.AddTail(new CPixelProfileClusterer(*pProfileList));
	}

	// STEP 3
	// Sort the list of clusterers by their highest cluster factors,
	// in descending order.  As we combine clusters, we'll keep this
	// list sorted, so enabling us to quickly find the next clusterer
	// to ask to combine its closest clusters.
	//
	// Note that we create a second list of clustering objects for
	// the sorted list.  This is because we don't really want it to
	// include objects that can't be clustered anyway (i.e. they have
	// only one pixel-profile in them).  Plus, it allows us to use an
	// insertion sort. :)
	CClustererList lstClusterables;
	POSITION posClusterer = lstAllClusterers.GetHeadPosition();
	CPixelProfileClusterer* pClusterer = NULL;
	while (NULL != posClusterer)
	{
		pClusterer = lstAllClusterers.GetNext(posClusterer);
		if (pClusterer->IsClusterable())	// skip unclusterable clusterers
		{
			// Insert this cluster into the list of clusterable
			// clustering objects
			double dCurrentBestCluster = pClusterer->GetBestClusterFactor();
			BOOL bInserted = FALSE;
			POSITION posInsertBefore = lstClusterables.GetHeadPosition();
			CPixelProfileClusterer* pInsertBefore = NULL;
			while (NULL != posInsertBefore && !bInserted)
			{
				// If the clusterer we're looking to insert has a
				// better cluster factor than the current one, insert
				// it before it.  Otherwise, just move onto the next.
				pInsertBefore = lstClusterables.GetAt(posInsertBefore);
				if (dCurrentBestCluster > pInsertBefore->GetBestClusterFactor())
				{
					lstClusterables.InsertBefore(posInsertBefore, pClusterer);
					bInserted = TRUE;
				}
				else
				{
					lstClusterables.GetNext(posInsertBefore);
				}
			}
			// The clusterer we're looking to insert has the lowest
			// cluster factor we've seen yet, so add it to the tail
			// of the list
			if (!bInserted)
				lstClusterables.AddTail(pClusterer);
		}
	}

	// STEP 4
	CString strPrompt("");
	CString strPromptFormat("");
	strPromptFormat.Format("Clustering %d profiles: %%d clusters remaining... (press Esc to cancel)", nNumProfiles);

	// Whittle down the number of clusters by repeatedly
	// combining the closest two clusters
	int nNumClustersLeft = nNumProfiles;
	CPixelProfileClusterer* pBestClusterer = NULL;
	BOOL bCanceled = FALSE;
	while (nNumClustersLeft	> nMaxPaletteSize && !lstClusterables.IsEmpty() && !bCanceled)
	{
		// Tell the user how many clusters we've got
		if (NULL != pFrameWnd)
		{
			strPrompt.Format(strPromptFormat, nNumClustersLeft);
			pFrameWnd->SetMessageText(strPrompt);
		}

		// STEP 4a
		pBestClusterer = lstClusterables.RemoveHead();
		ASSERT(pBestClusterer->IsClusterable());

		// STEP 4b
		pBestClusterer->CombineClosestClusters();

		// STEP 4c
		if (pBestClusterer->IsClusterable())
		{
			// Insert this cluster back into the list of clusterable
			// clustering objects
			double dCurrentBestCluster = pBestClusterer->GetBestClusterFactor();
			BOOL bInserted = FALSE;
			POSITION posInsertBefore = lstClusterables.GetHeadPosition();
			CPixelProfileClusterer* pInsertBefore = NULL;
			while (NULL != posInsertBefore && !bInserted)
			{
				// If the clusterer we're looking to insert has a
				// better cluster factor than the current one, insert
				// it before it.  Otherwise, just move onto the next.
				pInsertBefore = lstClusterables.GetAt(posInsertBefore);
				if (dCurrentBestCluster > pInsertBefore->GetBestClusterFactor())
				{
					lstClusterables.InsertBefore(posInsertBefore, pBestClusterer);
					bInserted = TRUE;
				}
				else
				{
					lstClusterables.GetNext(posInsertBefore);
				}
			}
			// The clusterer we're looking to insert has the lowest
			// cluster factor we've seen yet, so add it to the tail
			// of the list
			if (!bInserted)
				lstClusterables.AddTail(pBestClusterer);
		}

		// STEP 4d
		nNumClustersLeft--;
		m_nPaletteSize--;

		// Before we continue, check to see whether the user has
		// tried to cancel the operation
		MSG peekMSG;
		if (::PeekMessage(&peekMSG, pFrameWnd->m_hWnd, WM_KEYDOWN, WM_KEYDOWN, PM_REMOVE))
		{
			if (VK_ESCAPE == peekMSG.wParam)
			{
				bCanceled = TRUE;
				pFrameWnd->SetMessageText("Canceled - tidying up...");
			}
		}
	}

	// Tell the user we've finished clustering
	if (NULL != pFrameWnd && !bCanceled)
		pFrameWnd->SetMessageText("Finished clustering!");

	// STEP 5
	// Assign all cluster and master profile indexes to the pixel
	// profiles now that clustering is over.
	if (!bCanceled)
	{
		BYTE nClusterIndex = 0;
		POSITION posAssignClusterer = lstAllClusterers.GetHeadPosition();
		while (NULL != posAssignClusterer)
		{
			CPixelProfileClusterer* pClusterer = lstAllClusterers.GetNext(posAssignClusterer);
			pClusterer->AssignClusterIndexes(nClusterIndex);
		}
	}

	// STEP 6 - tidy up and relax!
	lstClusterables.RemoveAll();
	while (NULL != lstAllClusterers.GetHeadPosition())
		delete lstAllClusterers.RemoveHead();
	while (NULL != lstProfileLists.GetHeadPosition())
		delete lstProfileLists.RemoveHead();

	// Clear out the pixelprofile match-factor cache
	CPixelProfile::ClearCache();

	return !bCanceled;
}
// End of function 'ClusterProfiles'



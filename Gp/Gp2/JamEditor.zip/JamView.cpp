// JamView.cpp : implementation of the CJamView class
//

#include "stdafx.h"
#include "JamEditor.h"

#include "JamEditorDoc.h"
#include "JamView.h"

#include "Jam.h"
#include "JamTexture.h"
#include "JamPixelInfo.h"
#include "TexturePropertiesDlg.h"
#include "Hints.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJamView

IMPLEMENT_DYNCREATE(CJamView, CScrollView)

BEGIN_MESSAGE_MAP(CJamView, CScrollView)
	//{{AFX_MSG_MAP(CJamView)
	ON_COMMAND(ID_VIEW_ZOOM_IN, OnZoomIn)
	ON_COMMAND(ID_VIEW_ZOOM_OUT, OnZoomOut)
	ON_COMMAND(ID_VIEW_ZOOM_ONETOONE, OnZoomOneToOne)
	ON_WM_ERASEBKGND()
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_LBUTTONDOWN()
	ON_COMMAND(ID_EDIT_TEXTURE_PROPERTIES, OnEditTextureProperties)
	ON_UPDATE_COMMAND_UI(ID_EDIT_TEXTURE_PROPERTIES, OnUpdateEditTextureProperties)
	ON_WM_RBUTTONDOWN()
	ON_WM_CONTEXTMENU()
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, OnUpdateEditCopyCut)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, OnUpdateEditPaste)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CUT, OnUpdateEditCopyCut)
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
	// Jam Editor commands
	ON_NOTIFY_EX(TTN_NEEDTEXT, 0, OnGetTooltipText)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJamView construction/destruction

CJamView::CJamView()
{
	// Set the zooming limits to 10:1 and 1:10
	m_ZoomFactor.SetLimits(10,10);
	// and start at 1:1
	m_ZoomFactor.MagnifyTo(1);

	// Set the last tooltip used as empty
	m_strLastToolTip = "";

	// Register a format for putting jam textures onto the
	// clipboard.  If this has already been done by another
	// view, we'll just be returned the ID of the previously
	// registered format.
	m_nClipboardFormat = ::RegisterClipboardFormat(_T("CF_JAM_TEXTURE"));
}

CJamView::~CJamView()
{
}

BOOL CJamView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CJamView drawing (and related functions)

void CJamView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	switch (lHint)
	{
	case HINT_TEXTURE_PROPERTIES_CHANGED:
	case HINT_CHANGED_LOW_DETAIL_COLOUR:
	case HINT_IMPORTED_CANVAS_BITMAP:
	case HINT_IMPORTED_TEXTURE_BITMAP:
	case HINT_SELECTED_TEXTURE:
	case HINT_DESELECTED_TEXTURE:
	case HINT_SELECTED_PALETTE:
	case HINT_ADDED_TEXTURE:
	case HINT_DELETED_TEXTURE:
	case HINT_EDITED_LOCAL_PALETTE:
	case HINT_AUTOFIXED_TEXTURE_PIXELS:
	case HINT_CHANGED_GLOBAL_PALETTE:
		// All of the above hints require a redraw
		Invalidate();
		break;
	default:
		CScrollView::OnUpdate(pSender, lHint, pHint);
		break;
	}
}


void CJamView::OnDraw(CDC* pDC)
{
	CJamEditorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	CRect rctClient;
	GetClientRect(rctClient);

	// The drawing will be done to an appropriate memory dc
	// provided that we're not printing
	CDC* pDCToDrawOn=pDC;

	// Create a memory dc, which we may be about to use (depending upon printing)
	CDC memDC;
	memDC.CreateCompatibleDC(pDC);
	CBitmap bitmapForMemDC;
	bitmapForMemDC.CreateCompatibleBitmap(pDC, rctClient.Width(), rctClient.Height());
	
	// Select bitmap into memDC and blank it
	CBitmap* pOldMemDCBmp=memDC.SelectObject(&bitmapForMemDC);
	memDC.PatBlt(0,0,rctClient.Width(), rctClient.Height(), WHITENESS);

	// If we're not printing, draw the hatched background
	CPoint scrollPos=GetScrollPosition();
	if (! pDC->IsPrinting())
	{
		// We're not printing, so make sure we are going to draw on the
		// memory DC, which was created above
		pDCToDrawOn=&memDC;

		// And set an appropriate viewport for this memDC so that the
		// drawing code does not get confused
		memDC.SetViewportOrg(-scrollPos);
	}

	////////////// The drawing starts here

	// Draw the hatched background
	CBrush hatchedBrush;
	hatchedBrush.CreateHatchBrush(HS_DIAGCROSS, RGB(192,192,192));	// xxxx sort of thing

	// We have our brush - now we will simply draw this onto the
	// dc (if we're not printing) at the current scroll position
	// and at the full size of the window
	CRect hatchRect(scrollPos, rctClient.Size());
	if (!pDC->IsPrinting())
		pDCToDrawOn->FillRect(hatchRect, &hatchedBrush);

	// Tidy up
	hatchedBrush.DeleteObject();

	CJam* pJam = pDoc->GetJam();
	if (NULL != pJam)
		pJam->Draw(pDCToDrawOn, GetPaletteNum(), GetZoomFactor());

	/////////// the drawing ends here

	// If we have just drawn on a memory DC, we'll need to blt to screen
	if (! pDC->IsPrinting() )
	{
		// Draw from the memDC to the screen (both devices are using the same coordinate system)
		pDC->BitBlt(scrollPos.x, scrollPos.y, rctClient.Width(), rctClient.Height(), &memDC, scrollPos.x, scrollPos.y, SRCCOPY);
	}

	// Tidy up the memoryDC
	memDC.SelectObject(pOldMemDCBmp);
	bitmapForMemDC.DeleteObject();
}

void CJamView::OnInitialUpdate()
{
	CScrollView::OnInitialUpdate();

	// Update the scroll sizes for default zoom factor
	UpdateScrollSizes();

	// Enable the DataTip for texture info
    EnableToolTips(TRUE);
    m_ToolTip.Create(this, TTS_ALWAYSTIP);
    m_ToolTip.AddTool(this);
#if _MFC_VER > 0x0410
	m_ToolTip.SendMessage(TTM_SETMAXTIPWIDTH, 0, SHRT_MAX);
#endif
    m_ToolTip.SendMessage(TTM_SETDELAYTIME, TTDT_AUTOPOP, SHRT_MAX);
    m_ToolTip.SendMessage(TTM_SETDELAYTIME, TTDT_INITIAL, 750);
    m_ToolTip.SendMessage(TTM_SETDELAYTIME, TTDT_RESHOW, 0);
}

BOOL CJamView::OnEraseBkgnd(CDC* pDC) 
{
	UNUSED_ALWAYS(pDC);
	return TRUE;	// our drawing code will handle the drawing of the background so report the erase as done
}


////////////////////////////////////////////////////////////////////////////
// CJamView scrolling functions

// Function:	OnKeyDown(nChar, nRepCnt, nFlags)
// Overview:	Respond to the user pressing a key in the view.
//				Handled here to catch keyboard scroll requests.
void CJamView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	UNUSED_ALWAYS(nRepCnt);	// one at a time please
	UNUSED_ALWAYS(nFlags);	// huh?

	// Check which key is being pressed and decide how
	// to scroll based upon it.
	UINT nScrollMsg = 0;
	WPARAM wScrollDir = 0;
	switch (nChar)
	{
	case VK_PRIOR:	// Page Up
		nScrollMsg = WM_VSCROLL;
		wScrollDir = SB_PAGEUP;
		break;
	case VK_NEXT:	// Page Down
		nScrollMsg = WM_VSCROLL;
		wScrollDir = SB_PAGEDOWN;
		break;
	case VK_HOME:	// Home
		nScrollMsg = WM_HSCROLL;
		wScrollDir = SB_PAGEUP;
		break;
	case VK_END:	// End
		nScrollMsg = WM_HSCROLL;
		wScrollDir = SB_PAGEDOWN;
		break;
	}

	// Do the scrolling if that keystroke was a scrolling one.
	if (0 != nScrollMsg)
		SendMessage(nScrollMsg, wScrollDir, NULL);

	CScrollView::OnKeyDown(nChar, nRepCnt, nFlags);
}
// End of function 'OnKeyDown'


// Function:	OnHScroll(nSBCode, nPos, pScrollBar)
// Overview:	Respond to a horizontal scroll.  Overridden to invalidate
//				*everything*, thus ensuring that the hatched background
//				is drawn correctly.
void CJamView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// ensure all view gets redrawn on scroll
	InvalidateRect(NULL, FALSE);

	// use base class to do normal scroll stuff.

	CScrollView::OnHScroll(nSBCode, nPos, pScrollBar);
}
// End of function 'OnHScroll'


// Function:	OnVScroll(nSBCode, nPos, pScrollBar)
// Overview:	Respond to a vertical scroll.  Overridden to invalidate
//				*everything*, thus ensuring that the hatched background
//				is drawn correctly.
void CJamView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// ensure all view gets redrawn on scroll
	InvalidateRect(NULL, FALSE);

	// use base class to do normal scroll stuff.
	CScrollView::OnVScroll(nSBCode, nPos, pScrollBar);
}
// End of function 'OnVScroll'



/////////////////////////////////////////////////////////////////////////////
// CJamView printing

BOOL CJamView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CJamView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CJamView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CJamView diagnostics

#ifdef _DEBUG
void CJamView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CJamView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CJamEditorDoc* CJamView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CJamEditorDoc)));
	return (CJamEditorDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CJamView message handlers

// Get the jam being displayed
CJam* CJamView::GetJam() const
{
	CJamEditorDoc* pDoc = GetDocument();
	if (NULL == pDoc)
		return NULL;

	return pDoc->GetJam();
}

// Get the palette number to use in displaying the Jam
int CJamView::GetPaletteNum() const
{
	CJamEditorDoc* pDoc = GetDocument();
	if (NULL == pDoc)
		return 1;

	return pDoc->GetPaletteNum();
}


/////////////////////////////////////////////////////////////////////////////
// Zooming functions

double CJamView::GetZoomFactor() const
{
	// Get the zoom factor from the CZoomFactor member
	return (double)m_ZoomFactor.GetFactor();
}

void CJamView::OnZoomIn() 
{
	// Increase the zoom factor
	m_ZoomFactor.Magnify();
	UpdateScrollSizes();
	Invalidate();
}

void CJamView::OnZoomOut() 
{
	// Decrease the zoom factor
	m_ZoomFactor.Shrink();
	UpdateScrollSizes();
	Invalidate();
}

void CJamView::OnZoomOneToOne() 
{
	// Return to a 1:1 zoom factor
	m_ZoomFactor.MagnifyTo(1);
	UpdateScrollSizes();
	Invalidate();
}

void CJamView::UpdateScrollSizes()
{
	CJam* pJam = GetJam();
	if (NULL == pJam)
		SetScrollSizes(MM_TEXT, CSize(0,0));
	else
	{
		// Scale up the size of the jam to get the size
		// of this view's contents
		CSize sizScroll = pJam->GetSize();
		sizScroll.cx = int(sizScroll.cx * GetZoomFactor());
		sizScroll.cy = int(sizScroll.cy * GetZoomFactor());
		SetScrollSizes(MM_TEXT, sizScroll);
	}
}



/////////////////////////////////////////////////////////////////////////////
// Mouse handlers

// Function:	OnMouseMove(nFlags, point)
// Overview:	Respond to the user moving the mouse over the view
void CJamView::OnMouseMove(UINT nFlags, CPoint point) 
{
	// Show pixel information in the status bar
	CJam* pJam = GetJam();
	CFrameWnd* pMainFrame = (CFrameWnd *)AfxGetMainWnd();
	if (NULL != pJam && NULL != pMainFrame)
	{
		// Convert the point to be in Jam coordinates
		CPoint ptInJam(point);
		ClientToJam(ptInJam);

		// Hit-test the current Jam
		CJamPixelInfo pixelInfo(ptInJam);
		if (pJam->HitTest(pixelInfo))
		{
			// The cursor *is* in a texture, so show the info
			// in the status bar
			pMainFrame->SetMessageText(pixelInfo.Format(""));
		}
		else
		{
			// Not over any texture's pixel, so reset the status bar
			CString strIdle("");
			strIdle.LoadString(AFX_IDS_IDLEMESSAGE);
			pMainFrame->SetMessageText(strIdle);
		}
	}

	// Activate/deactive the tooltip
	if (NULL == GetTextureAtPoint(point))
	{
		// Deactivate the tooltip, as the mouse pointer is
		// *not* over a texture
		m_ToolTip.Activate(FALSE);
	}
	else
	{
		// Activate the tooltip, as the mouse pointer *is*
		// over a texture
		m_ToolTip.Activate(TRUE);
	}

	// Call the base class
	CScrollView::OnMouseMove(nFlags, point);
}
// End of function 'OnMouseMove'


// Function:	OnLButtonDown(nFlags, point)
// Overview:	Respond to the user pressing the left mouse button
void CJamView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// Select the texture under the mouse
	SelectTextureOnClick(nFlags, point);

#ifdef _DEBUG
	CJamTexture* pTexture = GetSelectedTexture();
	if (NULL != pTexture)
	{
		CRectTracker tracker(pTexture->GetRect(), CRectTracker::solidLine | CRectTracker::resizeInside);
		if (tracker.Track(this, point))
		{
			pTexture->SetTop(BYTE(tracker.m_rect.top));
			pTexture->SetLeft(BYTE(tracker.m_rect.left));
			pTexture->SetSize(WORD(tracker.m_rect.Width()), WORD(tracker.m_rect.Height()));
			Invalidate();
		}
	}
	else
#endif
	{
		// Call the base, too, for any normal handling
		CScrollView::OnLButtonDown(nFlags, point);
	}
}
// End of function 'OnLButtonDown'


// Function:	OnLButtonDblClk(nFlags, point)
// Overview:	Respond to the user double-clicking in the view.
void CJamView::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	if (NULL != GetSelectedTexture())
	{
		// Just do the same as if the user had selected the
		// Texture Properties command
		OnEditTextureProperties();
	}
	else
	{
		// Just do the same as if the user had selected the
		// Add New Texture command
		CWnd* pMainFrame = AfxGetMainWnd();
		if (NULL != pMainFrame)
			pMainFrame->SendMessage(WM_COMMAND, ID_EDIT_ADD_NEW_TEXTURE);
	}

	// Then perform any base class handling
	CScrollView::OnLButtonDblClk(nFlags, point);
}
// End of function 'OnLButtonDblClk'


// Function:	OnRButtonDown(nFlags, point)
// Overview:	Respond to the user pressing the right mouse button
void CJamView::OnRButtonDown(UINT nFlags, CPoint point) 
{
	// Select the texture under the mouse.  Let the OnContextMenu
	// handler see to the context menu.
	SelectTextureOnClick(nFlags, point);

	// Call the base, too, for any normal handling
	CScrollView::OnRButtonDown(nFlags, point);
}
// End of function 'OnRButtonDown'


// Function:	SelectTextureOnClick(nFlags, point)
// Overview:	Select the texture at the given point (used by
//				both left and right mouse button handlers)
void CJamView::SelectTextureOnClick(UINT nFlags, CPoint point) 
{
	// You can forget about multiple selection - it's a
	// real pain in the arse.
	UNUSED_ALWAYS(nFlags);

	// Check to see whether the texture under the mouse is already
	// selected
	CJamTexture* pHitTexture = GetTextureAtPoint(point);
	CJamTexture* pCurrentTexture = GetSelectedTexture();

	// Change the selection if the mouse was not over the
	// currently selected texture
	if (pCurrentTexture != pHitTexture)
	{
		// Deselect the current texture first (if there is
		// a current texture)
		if (NULL != pCurrentTexture)
			pCurrentTexture->m_bSelected = FALSE;

		// Now select the new current texture (if we hit one)
		if (NULL != pHitTexture)
			pHitTexture->m_bSelected = TRUE;

		// Cause a redraw of the JAM in this view
		Invalidate();

		// Update any other views of the document
		LPARAM lHintType = (NULL == pHitTexture) ?
			HINT_DESELECTED_TEXTURE : HINT_SELECTED_TEXTURE;
		CJamEditorDoc* pDoc = GetDocument();
		if (NULL != pDoc)
			pDoc->UpdateAllViews(this, lHintType, NULL);
	}
}
// End of function 'SelectTextureOnClick'


// Function:	OnContextMenu(pWnd, point)
// Overview:	Respond to the user releasing the right mouse button
//				or hitting the context menu key (or Shift+F10)
void CJamView::OnContextMenu(CWnd* pWnd, CPoint point) 
{
	// Make sure the window that's been hit is this view!
	if (pWnd != this)
		return;

	// Get a pointer to the texture for which we're going to
	// show the context menu.  If there is no selected texture,
	// we'll show the context menu for the JAM instead.
	CJamTexture* pTexture = GetSelectedTexture();

	// If the point that's been passed to this function is
	// CPoint(-1,-1), we know that the user hit the Context
	// menu key on a Win95 keyboard.  In which case, we'd
	// better position the context menu at the centre of
	// the selected texture (or as close to its centre as
	// we can currently see in the view)
	CPoint ptMenu(point);
	if (ptMenu == CPoint(-1,-1))
	{
		if (NULL == pTexture)
		{
			// There's no texture selected, so we should show the
			// context menu at the top-left of the client area
			ptMenu = CPoint(0,0);
			ClientToScreen(&ptMenu);
		}
		else
		{
			// There is a texture selected.  However, we may need
			// to scroll the view to make it visible, so see to
			// that first...
			ScrollToTexture(pTexture);

			// Now find the centre point of what we can see of
			// texture, and that's where we'll show the menu
			CRect rctTexture = pTexture->GetRect();
			JamToClient(rctTexture.TopLeft());
			JamToClient(rctTexture.BottomRight());
			CRect rctClient(0,0,0,0);
			GetClientRect(&rctClient);

			// If we still can't see the texture at all, just
			// put the menu at the top left of the client area
			CRect rctIntersect;
			if (!rctIntersect.IntersectRect(rctClient, rctTexture))
			{
				// Something may have gone wrong in ScrollToTexture()
				ASSERT(FALSE);

				ptMenu = CPoint(0,0);
				ClientToScreen(&ptMenu);
			}
			else
			{
				// Centre the menu in what we can see of the texture
				ptMenu = rctIntersect.CenterPoint();
				ClientToScreen(&ptMenu);
			}
		}
	}

	// Phew!  Now that we've sorted that out, it's time to load
	// the menu and display it.
	CMenu menuWhole;
	if (!menuWhole.LoadMenu(IDR_POPUP_MENU))
		return;

	// Get a pointer to either the Texture or Jam submenu
	BOOL bTextureMenu = (NULL != pTexture);
	CMenu* pMenu = menuWhole.GetSubMenu(bTextureMenu ? 0 : 1);

	// We'll have to set the menus up differently according to
	// which type it is, of course
	if (bTextureMenu)
	{
		// TEXTURE menu

		// Set the Properties command as the default
		::SetMenuDefaultItem(pMenu->m_hMenu, ID_EDIT_TEXTURE_PROPERTIES, FALSE);

		// Enable/disable the Edit Local Palettes command
		// according to whether or not the texture has any
		CJamEditorDoc* pDoc = (CJamEditorDoc *)GetDocument();
		if (NULL != pDoc)
		{
			BOOL bEnabled = pDoc->CanEditLocalPalettes();
			UINT nMenuStyle = MF_BYCOMMAND | ((bEnabled) ? MF_ENABLED : MF_GRAYED);
			pMenu->EnableMenuItem(ID_EDIT_LOCAL_PALETTES, nMenuStyle);
		}
	}
	else
	{
		// JAM menu

		// Enable/disable the Paste command as appropriate
		BOOL bCanPaste = ::IsClipboardFormatAvailable(m_nClipboardFormat);
		UINT nMenuStyle = MF_BYCOMMAND | ((bCanPaste) ? MF_ENABLED : MF_GRAYED);
		pMenu->EnableMenuItem(ID_EDIT_PASTE, nMenuStyle);

		// Set the Properties command as the default
		::SetMenuDefaultItem(pMenu->m_hMenu, ID_EDIT_ADD_NEW_TEXTURE, FALSE);
	}

	// Finally, just show it at the point we decided upon earlier
	pMenu->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, ptMenu.x, ptMenu.y, this);
}
// End of function 'OnContextMenu'


// Function:	ScrollToTexture(pTexture)
// Overview:	Make sure at least part of the given texture
//				can be seen in the view.  Return TRUE upon success,
//				or FALSE if unable to do so.
BOOL CJamView::ScrollToTexture(CJamTexture* pTexture)
{
	// Check that we've been given a valid pointer
	ASSERT(NULL != pTexture);
	if (NULL == pTexture)
		return FALSE;

	// First, find out whether we can see the texture at all
	CRect rctTexture = pTexture->GetRect();
	JamToClient(rctTexture.TopLeft());
	JamToClient(rctTexture.BottomRight());

	CRect rctClient;
	GetClientRect(&rctClient);

	// If we can't see the texture at all, scroll to put
	// it as close the top-left of the view as possible
	CRect rctIntersect;
	if (!rctIntersect.IntersectRect(rctClient, rctTexture))
		ScrollToPosition(rctTexture.TopLeft());

	return TRUE;
}
// End of function 'ScrollToTexture'



/////////////////////////////////////////////////////////////////////////////
// Coordinate conversion functions

// Function:	ClientToJam(point&)
// Overview:	Convert the point from view coordinates to
//				Jam coordinates
void CJamView::ClientToJam(CPoint& point) const
{
	// Very simple conversion
	point += GetScrollPosition();
	if (GetZoomFactor() != 0.0f)	// avoid divide-by-zero
	{
		point.x = int(point.x / GetZoomFactor());
		point.y = int(point.y / GetZoomFactor());
	}
}
// End of function 'ClientToJam'


// Function:	JamToClient(point&)
// Overview:	Convert the point from Jam coordinates to
//				view coordinates
void CJamView::JamToClient(CPoint& point) const
{
	// Very simple conversion
	point.x = int(point.x * GetZoomFactor());
	point.y = int(point.y * GetZoomFactor());
	point -= GetScrollPosition();
}
// End of function 'JamToClient'



/////////////////////////////////////////////////////////////////////////////
// Texture Data-Tip functions

// Function:	OnToolHitTest(point, pTI)
// Overview:	This function determines whether the data-tip should
//				be displayed.  Return the ID of the texture at the
//				given point.
int CJamView::OnToolHitTest(CPoint point, TOOLINFO* pTI) const
{
	// Check to see whether there's a Jam first
	CJam* pJam = GetJam();
	if (NULL == pJam)
		return -1;

    // If no texture has been hit, indicate this in
	// the return value
	int nHit = TEXTURE_ID_NONE;
	CJamTexture* pTexture = GetTextureAtPoint(point);
    if (NULL == pTexture)
    {
		// Indicate that we've nothing
		nHit = TEXTURE_ID_NONE;
    }
	else
	{
		// Set the return value
		nHit = pTexture->GetTextureID();

		// Fill the TOOLINFO structure with information about the
		// texture over which the mouse is hovering
		CRect rctTexture = pTexture->GetRect();
		JamToClient(rctTexture.TopLeft());
		JamToClient(rctTexture.BottomRight());
		pTI->rect = rctTexture;
		pTI->uFlags |= TTF_NOTBUTTON;
		pTI->hwnd = m_hWnd;

		// This causes the NeedTooltipText message to be sent
		// Don't try to just set the text here - it won't work.
		pTI->lpszText = LPSTR_TEXTCALLBACK;
	}

	pTI->uId = (UINT)nHit;
    return nHit;
}
// End of function 'OnToolHitTest'


// Function:	OnGetTooltipText(id, pNMHDR, pRes)
// Overview:	Change the text of the tooltip if we're over a
//				different texture to last time.
BOOL CJamView::OnGetTooltipText(UINT id, NMHDR* pNMHDR, LRESULT* pRes)
{
	UNUSED_ALWAYS(id);
	UNUSED_ALWAYS(pNMHDR);
	UNUSED_ALWAYS(pRes);

	// Check to see whether there's a Jam first
	CJam* pJam = GetJam();
	if (NULL == pJam)
		return FALSE;

	// Get the position of the cursor when this notification
	// was sent.  This allows us to make sure that we're not
	// 'stealing' another window's notification as we can check
	// to see that the mouse actually was inside the client
	// area.
	DWORD dwMousePt = ::GetMessagePos();
	CPoint ptCursor(LOWORD(dwMousePt), HIWORD(dwMousePt));
	ScreenToClient(&ptCursor);

	CRect rctClient(0,0,0,0);
	GetClientRect(rctClient);
	BOOL bChangedTooltip = FALSE;
	if (rctClient.PtInRect(ptCursor))
	{
		// Get the information relating to the texture
		// at the current mouse position
		CString strToolTip("");
		CJamTexture* pTexture = GetTextureAtPoint(ptCursor);
		ASSERT(NULL != pTexture);
		if (NULL != pTexture)
		{
			// Text indicates texture ID, location, and size
			CRect rctTexture = pTexture->GetRect();
#if _MFC_VER > 0x0410
			strToolTip.Format(IDS_TEXTURE_TOOLTIP_MULTILINE,
				pTexture->GetTextureID(),
				rctTexture.left, rctTexture.top,
				rctTexture.Width(), rctTexture.Height());
#else
			strToolTip.Format(IDS_TEXTURE_TOOLTIP_SIMPLE, pTexture->GetTextureID());
#endif
		}

		// Set the new tooltip, but only if it's different to
		// the current one.  If we don't do this check, the tooltip
		// will 'chase' the mouse around the view.
		if (m_strLastToolTip != strToolTip)
		{
			m_ToolTip.UpdateTipText(strToolTip, this);
			m_strLastToolTip = strToolTip;
			bChangedTooltip = TRUE;
		}
	}

	return bChangedTooltip;
}
// End of function 'OnGetTooltipText'


// Function:	PreTranslateMessage(pMsg)
// Overview:	Overridden to pass messages onto the tooltip in
//				case it needs to react to them
BOOL CJamView::PreTranslateMessage(MSG* pMsg) 
{
	// If the tooltip exists and the message relates
	// to this view, pass it on to the tooltip
	if (::IsWindow(m_ToolTip.m_hWnd) && pMsg->hwnd == m_hWnd)
	{
		switch (pMsg->message)
		{
		case WM_LBUTTONDOWN:
		case WM_MOUSEMOVE:
		case WM_LBUTTONUP:
		case WM_RBUTTONDOWN:
		case WM_MBUTTONDOWN:
		case WM_RBUTTONUP:
		case WM_MBUTTONUP:
			m_ToolTip.RelayEvent(pMsg);
			break;
		}
	}

	return CScrollView::PreTranslateMessage(pMsg);
}
// End of function 'PreTranslateMessage'



/////////////////////////////////////////////////////////////////////////////
// Texture retrieval

// Function:	GetTextureAtPoint(point)
// Overview:	Return a pointer to the texture at the given
//				point (in client coords)
CJamTexture* CJamView::GetTextureAtPoint(const CPoint& point) const
{
	// Check to see whether there's a Jam first
	CJam* pJam = GetJam();
	if (NULL == pJam)
		return NULL;

	// Convert the point to be in Jam coordinates
	CPoint ptInJam(point);
	ClientToJam(ptInJam);

	// Hit-test the current Jam
	CJamPixelInfo pixelInfo(ptInJam);
	if (!pJam->HitTest(pixelInfo))
		return NULL;	// not over a texture
	else
		return pixelInfo.GetTexture();
}
// End of function 'GetTextureAtPoint'


// Function:	GetSelectedTexture()
// Overview:	Return a pointer to the selected texture, if there
//				is one (or NULL otherwise)
CJamTexture* CJamView::GetSelectedTexture() const
{
	// Check to see whether there's a Jam first
	CJam* pJam = GetJam();
	if (NULL == pJam)
		return NULL;

	// Just ask the Jam for its selected texture
	return pJam->GetSelectedTexture();
}
// End of function 'GetSelectedTexture'



/////////////////////////////////////////////////////////////////////////////
// Texture and JAM properties

// Function:	OnEditTextureProperties()
// Overview:	Display the Texture Properties dialog box
void CJamView::OnEditTextureProperties() 
{
	// We need to get the selected texture before we
	// can carry on
	CJamTexture* pTexture = GetSelectedTexture();
	if (NULL == pTexture)
		return;

	// Display the dialog in which the user can edit the
	// texture's ID (and other info, when programmed)
	CTexturePropertiesDlg dlgTextureProperties(pTexture);
	if (IDOK == dlgTextureProperties.DoModal())
	{
		// Make sure the framework realises the Jam has
		// been changed since it was last saved. Also,
		// update any other views of the document
		CJamEditorDoc* pDoc = GetDocument();
		if (NULL != pDoc)
		{

// update all views will now do this!
//			pDoc->SetModifiedFlag();

			pDoc->UpdateAllViews(this, HINT_TEXTURE_PROPERTIES_CHANGED);
			Invalidate();
		}
	}
}
// End of function 'OnEditTextureProperties'


// Function:	OnUpdateEditTextureProperties()
// Overview:	Update the appearance of the Texture Properties
//				command.
void CJamView::OnUpdateEditTextureProperties(CCmdUI* pCmdUI) 
{
	// Only enable the Texture Properties command if there is
	// a selected texture
	pCmdUI->Enable(NULL != GetSelectedTexture());
}
// End of function 'OnUpdateEditTextureProperties'



////////////////////////////////////////////////////////////////////////////////
// Clipboarding commands and related functions

// Function:	OnUpdateEditCopyCut(pCmdUI)
// Overview:	UI update handler for the ID_EDIT_COPY and ID_EDIT_CUT
//				commands.
void CJamView::OnUpdateEditCopyCut(CCmdUI* pCmdUI)
{
	// Check to see if there is a current texture, which
	// may be cut/copied
	pCmdUI->Enable(NULL != GetSelectedTexture());
}
// End of function 'OnUpdateEditCopyCut'


// Function:	OnUpdateEditPaste(pCmdUI)
// Overview:	UI update handler for the ID_EDIT_PASTE command.
void CJamView::OnUpdateEditPaste(CCmdUI* pCmdUI)
{
	// Enable pasting if the data on the clipboard is of the
	// correct format
	CJamEditorDoc* pDoc = (CJamEditorDoc *)GetDocument();
	pCmdUI->Enable(NULL != pDoc &&
		::IsClipboardFormatAvailable(m_nClipboardFormat));
}
// End of function 'OnUpdateEditPaste'


// Function:	OnEditCopy()
// Overview:	Command handler for the ID_EDIT_COPY command - puts
//				a copy of the selected texture onto the clipboard,
//				but leaves it in the current JAM, too.
void CJamView::OnEditCopy()
{
	// Create an archive into which we can save the selection
	CSharedFile	memFile;
	CArchive ar(&memFile, CArchive::store|CArchive::bNoFlushOnDelete);

	// Serialize data to archive object
	DoCutCopyPaste(ar, FALSE);

	ar.Flush();

	HGLOBAL hData = memFile.Detach();
	if (OpenClipboard())
	{
		EmptyClipboard();
		::SetClipboardData(m_nClipboardFormat, hData);
		CloseClipboard();
	}
	else
		AfxMessageBox(IDS_ERR_CANNOT_OPEN_CLIPBOARD);
}
// End of function 'OnEditCopy'


// Function:	OnEditCut()
// Overview:	Command handler for the ID_EDIT_CUT command - puts
//				a copy of the selected texture onto the clipboard,
//				and also deletes it from the current JAM.
void CJamView::OnEditCut()
{
	// Create an archive into which we can save the selection
	CSharedFile	memFile;
	CArchive ar(&memFile, CArchive::store|CArchive::bNoFlushOnDelete);

	// Serialize selection from document to clipboard archive object
	DoCutCopyPaste(ar, TRUE);

	ar.Flush();

	HGLOBAL hData = memFile.Detach();
	if (OpenClipboard())
	{
		EmptyClipboard();
		::SetClipboardData(m_nClipboardFormat, hData);
		CloseClipboard();
	}
	else
		AfxMessageBox(IDS_ERR_CANNOT_OPEN_CLIPBOARD);
}
// End of function 'OnEditCut'


// Function:	OnEditPaste()
// Overview:	Command handler for the ID_EDIT_PASTE command - 
//				loads a new texture into the jam from the clipboard.
//				This does not affect the currently selected texture
//				except that the selection is changed to the new
//				texture.
void CJamView::OnEditPaste()
{
	// Paste any Jam Editor data from the clipboard
	if (OpenClipboard())
	{
		HANDLE hData = ::GetClipboardData(m_nClipboardFormat);
		if (hData != NULL)
		{
			CSharedFile memFile;
			memFile.SetHandle(hData,FALSE);
			CArchive ar(&memFile, CArchive::load);

			// Serialize data into document from clipboard
			DoCutCopyPaste(ar, FALSE);
			CloseClipboard();
		}
		else
			AfxMessageBox(IDS_ERR_CANNOT_GET_CLIPBOARD_DATA);
	}
	else
		AfxMessageBox(IDS_ERR_CANNOT_OPEN_CLIPBOARD);
}
// End of function 'OnEditPaste'


// Function:	DoCutCopyPaste()
// Overview:	Serialization function for storing/loading the
//				selected texture to/from the clipboard.  If bCut is
//				TRUE, the current selection should be deleted after
//				the serialization has been done.
void CJamView::DoCutCopyPaste(CArchive &ar, BOOL bCut)
{
	// Get a pointer tot the document containing the selected item(s)
	CJamEditorDoc* pDoc = (CJamEditorDoc *)GetDocument();
	if (NULL == pDoc)
		return;

	// Save/load data to/from the clipboard
	try
	{
		pDoc->SerializeSelection(ar);
	}
	catch (CException* pExc)
	{
		pExc->ReportError();
		pExc->Delete();

		return;
	}

	// Delete the current selection if cutting
	if (bCut)
		pDoc->DeleteCurrentTexture();
}
// End of function 'DoCutCopyPaste'


// Config.cpp: implementation of the CConfig class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SetBuilder.h"
#include "Config.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CConfig::CConfig()
{

}

CConfig::~CConfig()
{

}

CString CConfig::AppPath()
{
	TCHAR szModule[260];
	GetModuleFileName(NULL, szModule, 260);
	CString sTemp=szModule;
	int iPos=sTemp.GetLength();
	for(int i=iPos;i>=1;i--)
	{
		if (sTemp.Mid(i,1)=="\\")
		{
			return(sTemp.Left(i+1));
		}
	}
	return("");
}

void CConfig::LoadConfig()
{
char buf[255];
CFile file;
CString szFile(AppPath());
	szFile+="\\Config.dat";
	GetPrivateProfileString("SetBuilder","Gp3Path","",buf,255,szFile);
}

void CConfig::SaveConfig()
{
CFile file;
CString szFile(AppPath());
	szFile+="\\Config.dat";
	WritePrivateProfileString("SetBuilder","Gp3Path",Gp3Path,szFile);
}

CString CConfig::GetGp3Dir()
{
	return(Gp3Path);
}

void CConfig::SetGp3Dir(CString path)
{
	Gp3Path = path;
}

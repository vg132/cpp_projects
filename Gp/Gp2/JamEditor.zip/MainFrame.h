// MainFrame.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#ifndef __MAINFRAME_H__
#define __MAINFRAME_H__

#include "JamControlBar.h"
#include "JamPixelInfoBar.h"

class CEditableObject;

class CMainFrame : public CMDIFrameWnd
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();

// Attributes
public:

// Operations
public:
	void UpdateTreeAfterOpenDocument(CEditableObject* pObject);
	void UpdateTreeForCloseDocument(CEditableObject* pObject);
	void UpdateTreeDataDisplay(CEditableObject* pObject);
	void UpdateTreeAfterAddNewTexture(CEditableObject* pObject);
	void UpdateTreeAfterSelectTexture(CEditableObject* pObject);
	void UpdateTreeForDeleteTexture(CEditableObject* pObject);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CJamControlBar		m_wndJamBar;
	CJamPixelInfoBar	m_wndStatusBar;
	CToolBar			m_wndToolBar;

// Generated message map functions
protected:
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnVKReturn();
	afx_msg void OnVKEscape();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	// A function to make sure Enter and Escape keypresses go to
	// the window in focus (needed for the Jam Tree)
	void OnVirtualKey(const UINT& vkCode);
};

/////////////////////////////////////////////////////////////////////////////

#endif	// ~__MAINFRAME_H__

// JamPixelInfo.h - header file for the CJamPixelInfo class
//

#ifndef __JAM_PIXEL_INFO_H__
#define __JAM_PIXEL_INFO_H__

#include "JamConstants.h"

/////////////////////////////////////////////////////////////////
// Class:	CJamPixelInfo
// Base:	[none]
// Created:	24 Jan 1999 by Mal Ross
// Overview:
//    This class is designed for use in reporting hit-testing
//  information.  For example, when the mouse hovers over the
//  image, the CJam object can be asked for the pixel info at
//  that point and this can then be shown in the status bar.
//

class CJamPixelInfo
{
// Construction/destruction
public:
	CJamPixelInfo(const CPoint& ptPixelInJam);
	CJamPixelInfo(const CJamPixelInfo& pixelInfo);
	virtual ~CJamPixelInfo();

	friend class CJamTexture;

// Data members
protected:
	// The point in the image to which this pixel
	// information relates, relative to the whole JAM
	CPoint m_ptPixelInJam;
	// The position of the pixel relative to the top-left
	// of its texture
	CPoint m_ptPixelInTexture;

	// The texture in which this pixel lies (NULL to indicate
	// the pixel is outside all textures)
	const CJamTexture* m_pTexture;

	// Pixel values - raw, and decoded (the index into the
	// array is the number of the local palette used)
	BYTE m_rawPixelValue;
	BYTE m_decPixelValues[NUM_LOCAL_PALETTES_PER_TEXTURE];

// Operations
public:
	// Simple retrieval of attributes - any class can see what these
	// values are, but only CJamTexture can set the values as it's a
	// friend.
	CPoint GetPointInJam() const { return m_ptPixelInJam; }
	CPoint GetPointInTexture() const { return m_ptPixelInTexture; }
	BOOL IsInsideTexture() const { return (NULL != m_pTexture); }
	int GetTextureID() const;
	CJamTexture* GetTexture() const { return (CJamTexture *)m_pTexture; }
	BYTE GetRawPixelValue() const { return m_rawPixelValue; }

	// Retrieval of the colour used to display the pixel using
	// the given palette number
	COLORREF GetColor(const int& nPaletteNum) const;
	BYTE GetDecodedPixelValue(const int& nPaletteNum) const;

	// Format a string using the values in members of this object
	CString Format(const UINT& nFormatStringID) const;
	CString Format(const CString& strFormat) const;

	// Assignment
	CJamPixelInfo& operator= (const CJamPixelInfo& pixelInfo);
	// Equality comparison
	BOOL operator== (const CJamPixelInfo& pixelInfo) const;

// Implementation
protected:
	// Formatting
	CString TranslateFormatTag(const char chTag) const;
};

/////////////////////////////////////////////////////////////////
#endif	// ~__JAM_PIXEL_INFO_H__


// EnhancedTreeCtrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEnhancedTreeCtrl window

class CEnhancedTreeCtrl : public CTreeCtrl
{
// Construction
public:
	CEnhancedTreeCtrl();

// Attributes
public:

// Operations
public:

protected:
	// My own variants of InsertItem (note, I've renamed the function to avoid
	// accidentally 'hiding' with the base class versions)
	HTREEITEM InsertNode(UINT nStringID, UINT nIconID, HTREEITEM hParent = TVI_ROOT, HTREEITEM hInsertAfter = TVI_LAST, DWORD dwItemData = NULL);
	HTREEITEM InsertNode(const CString& strItemText, UINT nIconID, HTREEITEM hParent = TVI_ROOT, HTREEITEM hInsertAfter = TVI_LAST, DWORD dwItemData = NULL);

	// to be overridden by clever tree controls

	//NOTE: a tree must have the edit-labels style set in its window style to be editable
	virtual BOOL CanEditLabelOf(HTREEITEM hItem, CString& replacementText);	// do you want to allow editing of hItem, if so you may specify a different bit of text than the existing one to be edited
	virtual void HandleLabelChanged(HTREEITEM hItem, CString newLabel);		// we've changed the label for the given tree item - you must validate and replace label in item if you like it
	virtual void HandleLabelChangeCancelled(HTREEITEM hItem);				// the in-place edit on hItem was cancelled - deal with it

	// interaction virtual function - makes the ctreectrl notifications simpler to use
	virtual void HandleSelchanged(HTREEITEM hItem);
	virtual void HandleDblclk(HTREEITEM hItem);

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEnhancedTreeCtrl)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CEnhancedTreeCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CEnhancedTreeCtrl)
	afx_msg void OnBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDblclk(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

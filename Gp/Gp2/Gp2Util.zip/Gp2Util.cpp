// Gp2Util.cpp : Defines the entry point for the DLL application.
//
/*
The functions in the file is for use with Gp2 Track Handler (Visual Basic)
---
CheckSum: calculates and writes a new checksum to Gp1 and 2 files
---
ConvertFile: Convert a Gp2 texture file (jam) to a jad file, when ziped it takes less space
it can also convert back from jad to jam.
---
*/

#include "stdafx.h"
#include "fstream.h"
#include "string.h"
#include "io.h"

struct structgp2data
{
	char laps;
	unsigned short len;
	unsigned short ware;
	char country[30];
	char adjective[30];
	char name[30];
};

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}

bool _stdcall CheckSum(char* file)
{

long datasize;
unsigned short sum=0,cycle=0;
unsigned char c;

ifstream f;
ofstream of;

	//open track file for reading
	f.open(file,ios::in|ios::out|ios::binary);

	//seek to end-4
	f.seekg(-4,ios::end);
	
	//get pos end-4
	datasize=f.tellg();
	
	//seek to begin of file
	f.seekg(0,ios::beg);

	//loop and calculate checksum
	while (datasize--) 
	{
		f.read((char*)&c,sizeof(c));
		sum += c;
		cycle = (cycle<<3)+(cycle>>13);
		cycle += c;
	}
	//close file
	f.close();

	//open file for writing
	of.open(file,ios::in|ios::out);
	//seek to end-4
	of.seekp(-4,ios::end);
	
	//write checksum at curpos
	of.write((char*)&sum,sizeof(sum));
	of.write((char*)&cycle,sizeof(cycle));
	//close file
	of.close();
	//return true
	return(true);
}

bool _stdcall ConvertFile(char* cFileName/*, bool bDelete*/)
{
// Decryption variables
unsigned long pattern = 0xB082F165;
unsigned long value = 0;
int nNumBytes;
int bSuccess = 1;
int iLen=1;
int i;

ifstream fInput;
ofstream fOutput;  

	// Work out the filename to which we're going to save
	
	cFileName=_strlwr(cFileName);	

	//If jam file then new file will be a jad file
	iLen=strlen(cFileName);
	char cNewFile[255];

	if(cFileName[iLen-1]=='m') //jam
	{
		for(i=0;i<iLen-1;i++)
			cNewFile[i]=cFileName[i];
		cNewFile[i]='d';
	}
	else //jad
	{
		for(i=0;i<iLen-1;i++)
			cNewFile[i]=cFileName[i];
		cNewFile[i]='m';
	}

	cNewFile[iLen]='\0';

	fInput.open(cFileName,ios::in|ios::binary);
	fOutput.open(cNewFile,ios::out|ios::trunc|ios::binary);


	// Loop through the file, 4 bytes at a time, en/decrypting the
	// contents into the output file as we go.

	fInput.seekg(0,ios::end);
	nNumBytes = fInput.tellg();

	fInput.seekg(0,ios::beg);
	fOutput.seekp(0,ios::beg);

	for (int nNumBlocks = nNumBytes / 4; nNumBlocks > 0;nNumBlocks--)
	{
		fInput.read((char*)&value,4);
		// Jams use a simple XOR encryption method, with the encryption key
		// changing for each subsequent 4 bytes.  Thus, the same process can
		// be repeated to encrypt/decrypt the files.
		value ^= pattern;
		pattern *= 5;

		// Output the en/decrypted value
		fOutput.write((char *) &value,4);
	}
	// Tidy up by closing the files
	fOutput.close();
	fInput.close();
	// Finally, if the conversion was a success, delete the input file
/*	if (bDelete==true)
		remove(cFileName);*/
	return(true);
}

// RedMistFilter.h - header file for the CRedMistFilter class
//

#ifndef __RED_MIST_FILTER_H__
#define __RED_MIST_FILTER_H__

#include "TintedFilter.h"

///////////////////////////////////////////////////////////////////
// Class:	CRedMistFilter
// Base:	CTintedFilter
// Created:	25 May 99 by Mal Ross
// Overview:
//    This filter produces 4 decoded textures whose colours
//  gradually fade to a slightly redder colour, giving the
//  impression of driving in a rage!  Well, ok, maybe not
//  - it was just for a laugh.
//

class CRedMistFilter : public CTintedFilter
{
// Construction and destruction
public:
	CRedMistFilter();
	virtual ~CRedMistFilter();

// Attributes
protected:

// Operations
public:
};

/////////////////////////////////////////////////////////////////////

#endif	// ~__RED_MIST_FILTER_H__

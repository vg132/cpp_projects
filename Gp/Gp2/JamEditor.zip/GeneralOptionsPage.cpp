// GeneralOptionsPage.cpp : implementation file
//

#include "stdafx.h"
#include "JamEditor.h"

#include "GeneralOptionsPage.h"

#include "PreviewFileDialog.h"
#include "FilenameParser.h"
#include "GP2Bitmap.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGeneralOptionsPage property page

IMPLEMENT_DYNCREATE(CGeneralOptionsPage, CPropertyPage)

CGeneralOptionsPage::CGeneralOptionsPage() : CPropertyPage(CGeneralOptionsPage::IDD)
{
	//{{AFX_DATA_INIT(CGeneralOptionsPage)
	m_nMRULength = _AFX_MRU_COUNT;
	m_bIgnoreInvalidPalettes = FALSE;
	m_strPaletteFilename = _T("");
	m_nPaletteType = -1;
	//}}AFX_DATA_INIT

	m_bCreated = FALSE;
}

CGeneralOptionsPage::~CGeneralOptionsPage()
{
}

void CGeneralOptionsPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGeneralOptionsPage)
	DDX_Control(pDX, IDC_RECENT_FILES_SPIN, m_spnMRUSize);
	DDX_Text(pDX, IDC_RECENT_FILES_EDIT, m_nMRULength);
	DDV_MinMaxUInt(pDX, m_nMRULength, 1, 16);
	DDX_Check(pDX, IDC_IGNORE_INVALID_PALETTES, m_bIgnoreInvalidPalettes);
	DDX_Text(pDX, IDC_PALETTE_FILENAME, m_strPaletteFilename);
	DDX_Radio(pDX, IDC_PALETTE_GP2, m_nPaletteType);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGeneralOptionsPage, CPropertyPage)
	//{{AFX_MSG_MAP(CGeneralOptionsPage)
	ON_BN_CLICKED(IDC_PALETTE_GP2, OnStandardPalette)
	ON_BN_CLICKED(IDC_PALETTE_CUSTOM, OnCustomPalette)
	ON_BN_CLICKED(IDC_FIND_PALETTE, OnFindPalette)
	ON_EN_CHANGE(IDC_PALETTE_FILENAME, OnChangeOption)
	ON_BN_CLICKED(IDC_PALETTE_GP3, OnStandardPalette)
	ON_EN_CHANGE(IDC_RECENT_FILES_EDIT, OnChangeOption)
	ON_BN_CLICKED(IDC_IGNORE_INVALID_PALETTES, OnChangeOption)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGeneralOptionsPage message handlers

BOOL CGeneralOptionsPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// Get the current max length of the MRU list
	CJamEditorApp* pApp = (CJamEditorApp *)AfxGetApp();
	if (NULL != pApp)
		m_nMRULength = pApp->GetMRULength();

	// Set the valid range for the MRU length
	m_spnMRUSize.SetRange(1,16);	// defined by MFC

	// Get the palette type values from the global palette
	m_strPaletteFilename = g_jamPalette.GetCustomPalette();
	m_nPaletteType = (int)g_jamPalette.GetPaletteType();

	// Get the palette-loading options from CGP2Bitmap
	m_bIgnoreInvalidPalettes = CGP2Bitmap::s_bIgnoreInvalidPalettes;

	// Enable or diable the custom palette controls
	EnableCustomPaletteOptions(CGP2Palette::PALTYPE_CUSTOM == m_nPaletteType);

	// Put the values into the dialog box
	UpdateData(FALSE);

	m_bCreated = TRUE;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CGeneralOptionsPage::OnOK() 
{
	// Update the values from the dialog, but watch out for invalid
	// values in the controls.
	if (!UpdateData(TRUE))
		return;

	// Set the palette type in the global palette
	if (!g_jamPalette.SetPaletteType(m_nPaletteType, m_strPaletteFilename))
		return;

	// Set the palette-loading options in CGP2Bitmap
	CGP2Bitmap::s_bIgnoreInvalidPalettes = m_bIgnoreInvalidPalettes;

	// Set the MRU length in the app (it will be effective immediately)
	CJamEditorApp* pApp = (CJamEditorApp *)AfxGetApp();
	if (NULL != pApp)
		pApp->SetMRULength(m_nMRULength);

	CPropertyPage::OnOK();
}


// Function:	OnStandardPalette()
// Overview:	React to user selecting either the GP2 or GP3
//				palette.
void CGeneralOptionsPage::OnStandardPalette() 
{
	// Enable the custom palette controls
	EnableCustomPaletteOptions(FALSE);

	// Enable the Apply button
	OnChangeOption();
}
// End of function 'OnStandardPalette'


// Function:	OnCustomPalette()
// Overview:	React to user selecting the custom palette
//				option.
void CGeneralOptionsPage::OnCustomPalette() 
{
	// Enable the custom palette controls
	EnableCustomPaletteOptions(TRUE);

	// Enable the Apply button
	OnChangeOption();
}
// End of function 'OnCustomPalette'


// Function:	EnableCustomPaletteOptions(bEnable)
// Overview:	Enable or disable the palette file controls according
//				to whether or not the custom palette option is selected.
//				At least, that's how it *should* be called.
void CGeneralOptionsPage::EnableCustomPaletteOptions(const BOOL bEnable)
{
	// Enable/disable the edit box.
	if (NULL != GetDlgItem(IDC_PALETTE_FILENAME))
		GetDlgItem(IDC_PALETTE_FILENAME)->EnableWindow(bEnable);

	// Enable/disable the Browse... button.
	if (NULL != GetDlgItem(IDC_FIND_PALETTE))
		GetDlgItem(IDC_FIND_PALETTE)->EnableWindow(bEnable);
}
// End of function 'EnableCustomPaletteOptions'


// Function:	OnFindPalette()
// Overview:	User clicked the Browse... button in the hope
//				that it would let them search for the file they
//				want to use as the palette,  Naive fools. ;)
void CGeneralOptionsPage::OnFindPalette() 
{
	// Show a standard file open dialog in which the user can
	// browse for the desired file
	CString strFilter(""), strDlgTitle("");
	strFilter.LoadString(IDS_CUSTOM_PALETTE_FILTER);
	strDlgTitle.LoadString(IDS_BROWSE_FOR_PALETTE_DLGTITLE);
	CFilenameParser defaultFile(m_strPaletteFilename);
	CString strFilename = defaultFile.GetFileNameEx();
	CString strDefaultDir = defaultFile.DriveAndPath(TRUE);

	// Create the dialog and set it up
	CPreviewFileDialog dlg(TRUE, ".PAL", strFilename, OFN_FILEMUSTEXIST | OFN_HIDEREADONLY, strFilter);
	dlg.m_ofn.lpstrTitle = strDlgTitle;
	dlg.m_ofn.lpstrInitialDir = strDefaultDir;

	// Display the dialog
	if (IDOK == dlg.DoModal())
	{
		// Get the path of the new palette file...
		m_strPaletteFilename = dlg.GetPathName();

		// ...and make sure it's seen in the dialog
		CDataExchange dx(this, FALSE);
		DDX_Text(&dx, IDC_PALETTE_FILENAME, m_strPaletteFilename);

		// Enable the Apply button
		OnChangeOption();
	}
}
// End of function 'OnFindPalette'


// Function:	OnChangedOption()
// Overview:	Handler for most data-changing events in the dialog, this
//				just enables the Apply button.
void CGeneralOptionsPage::OnChangeOption() 
{
	// Only enable the Apply button if we've been triggered
	// by a *user's* action.
	if (m_bCreated)
		SetModified(TRUE);
}
// End of function 'OnChangedOption'


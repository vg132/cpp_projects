// CJamTextureList.cpp
// the definition of the jamtexture list

#include "stdafx.h"
#include "resource.h"

#include "JamTextureList.h"
#include "TreeIconDefs.h"

CJamTextureList::CJamTextureList(CEditableObject* pParent) : CEditableTypedPtrList(pParent)
{
}

// overrides of the base class
UINT CJamTextureList::GetIconID()
{
	// return the ID for the icon in the tree for this item
	return JTI_JAM_TEXTURE_LIST;
}

CString CJamTextureList::GetFullDescription()
{
	// return name and value
	CString result;
	int numItems=0;
	
	// get number of items from list
	numItems=GetCount();

	// Format the string accordingly
	result.Format(IDS_NODE_TEXTURE_LIST, numItems);

	return result;
}

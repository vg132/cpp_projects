// JamPixelInfo.cpp - implementation of the CJamPixelInfo class
//

#include "stdafx.h"

#include "JamPixelInfo.h"
#include "JamTexture.h"
#include "TexturePalette.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CJamPixelInfo

// Normal constructor
CJamPixelInfo::CJamPixelInfo (const CPoint& ptPixelInJam)
: m_ptPixelInJam(ptPixelInJam), m_ptPixelInTexture(-1,-1)
{
	// Indicate that the info doesn't represent a 'hit' in
	// any texture
	m_pTexture = NULL;

	// Initialise all pixel values
	m_rawPixelValue = 0;
	memset(m_decPixelValues, 0, NUM_LOCAL_PALETTES_PER_TEXTURE);
}

// Copy constructor
CJamPixelInfo::CJamPixelInfo(const CJamPixelInfo& pixelInfo)
{
	// Just use the assignment operator
	*this = pixelInfo;
}

// Assignment operator
CJamPixelInfo& CJamPixelInfo::operator= (const CJamPixelInfo& pixelInfo)
{
	// Just perform a straight copy of the members
	m_pTexture = pixelInfo.m_pTexture;
	m_ptPixelInJam = pixelInfo.m_ptPixelInJam;
	m_ptPixelInTexture = pixelInfo.m_ptPixelInTexture;
	m_rawPixelValue = pixelInfo.m_rawPixelValue;
	memcpy(m_decPixelValues, pixelInfo.m_decPixelValues, NUM_LOCAL_PALETTES_PER_TEXTURE);

	return *this;
}

// Equality operator
BOOL CJamPixelInfo::operator== (const CJamPixelInfo& pixelInfo) const
{
	// Test the simple values...
	if (m_pTexture != pixelInfo.m_pTexture ||
		m_ptPixelInJam != pixelInfo.m_ptPixelInJam ||
		m_ptPixelInTexture != pixelInfo.m_ptPixelInTexture ||
		m_rawPixelValue != pixelInfo.m_rawPixelValue)
		return FALSE;

	// ...then test each of the decoded pixel values
	BOOL bEqual = TRUE;
	for (int nPaletteNum = 0; nPaletteNum < NUM_LOCAL_PALETTES_PER_TEXTURE && bEqual; nPaletteNum++)
		bEqual = (m_decPixelValues[nPaletteNum] == pixelInfo.m_decPixelValues[nPaletteNum]);

	return bEqual;
}

// Destructor
CJamPixelInfo::~CJamPixelInfo()
{
}


/////////////////////////////////////////////////////////////////////////////
// CJamPixelInfo attributes

// Function:	GetTextureID()
// Overview:	Get the ID of the texture in which this pixel lies
int CJamPixelInfo::GetTextureID() const
{
	if (NULL == m_pTexture)
		return TEXTURE_ID_NONE;
	else
		return m_pTexture->GetTextureID();
}
// End of function 'GetTextureID'


// Function:	GetDecodedPixelValue(nPaletteNum)
// Overview:	Get the colour used to display the pixel using
//				the given palette number.
BYTE CJamPixelInfo::GetDecodedPixelValue(const int& nPaletteNum) const
{
	// Check to see whether or not this info represents a pixel
	// in a texture.  If not, return the transparent colour index.
	if (NULL == m_pTexture)
		return GP2_TRANSPARENT_PALETTE_INDEX;

	// Check to make sure the given palette number is valid
	ASSERT(nPaletteNum >= 1 && nPaletteNum <= NUM_LOCAL_PALETTES_PER_TEXTURE);
	if (nPaletteNum < 1 || nPaletteNum > NUM_LOCAL_PALETTES_PER_TEXTURE)
		return GP2_TRANSPARENT_PALETTE_INDEX;

	// Return the palette index of the pixel when decoded
	// using the given local palette
	return m_decPixelValues[nPaletteNum];
}
// End of function 'GetDecodedPixelValue'


// Function:	GetColor(nPaletteNum)
// Overview:	Get the colour used to display the pixel using
//				the given palette number.
COLORREF CJamPixelInfo::GetColor(const int& nPaletteNum) const
{
	// Check to see whether or not this info represents a pixel
	// in a texture.  If not, return the transparent colour.
	if (NULL == m_pTexture)
		return g_jamPalette.GetTransparentColor();

	// Check to make sure the given palette number is valid
	ASSERT(nPaletteNum >= 1 && nPaletteNum <= NUM_LOCAL_PALETTES_PER_TEXTURE);
	if (nPaletteNum < 1 || nPaletteNum > NUM_LOCAL_PALETTES_PER_TEXTURE)
		return g_jamPalette.GetTransparentColor();

	// Return the colour using the given palette by simply decoding
	// the raw pixel value we're storing
	ASSERT(m_decPixelValues[nPaletteNum] >= 0 &&
		   m_decPixelValues[nPaletteNum] < GP2_PALETTE_SIZE);
	return RGB(g_jamPalette[m_decPixelValues[nPaletteNum]].rgbRed,
			   g_jamPalette[m_decPixelValues[nPaletteNum]].rgbGreen,
			   g_jamPalette[m_decPixelValues[nPaletteNum]].rgbBlue);
}
// End of function 'GetColor'



/////////////////////////////////////////////////////////////////////////////
// Formatting for output

// The following (overloaded) function will allow us to report the
// results of hit-testing stored in this object.  The format string
// passed to the function may contain a mixture of normal text and
// tagged expressions, which represent members of this class.  The
// tagged expressions are to replaced with the values in the members
// they represent.
// For example, each tag may be of the form:
//
//  %tagtype%
//
// where 'tagtype' is actually just a single character, which is to
// be translated by the TranslateFormatTag() function.

// Format a string using the values in members of this object
CString CJamPixelInfo::Format(const UINT& nFormatStringID) const
{
	// Load the string from resources, then use the other overload
	CString strFormat("");
	if (!strFormat.LoadString(nFormatStringID))
		return "";

	return Format(strFormat);
}

// Format a string using the values in members of this object
CString CJamPixelInfo::Format(const CString& strFormat) const
{
	UNUSED_ALWAYS(strFormat);
	CString strFormatted("");

	// TODO: Parse the string, looking for and replacing tags
	// that represent particular members of this class.  Make
	// use of the TranslateFormatTag function to convert each
	// tag.
	

	// Until this is coded, we'll just return a default format
	if (NULL != m_pTexture && m_pTexture->GetPaletteSize() == 0)
	{
		// No local palettes, so use simplified string
		strFormatted.Format("Global palette index %d", m_rawPixelValue);
	}
	else
	{
		// Texture has local palettes, so show the values this pixel
		// takes across the palettes
		strFormatted.Format("Local palette index %d = {%d, %d, %d, %d}",
			m_rawPixelValue,
			m_decPixelValues[0],
			m_decPixelValues[1],
			m_decPixelValues[2],
			m_decPixelValues[3]);
	}

	return strFormatted;
}

CString CJamPixelInfo::TranslateFormatTag(const char chTag) const
{
	UNUSED_ALWAYS(chTag);
	// TODO: code this function, possibly using a switch on the
	// value in chTag.  For example, if passed in a tag
	// representing the raw pixel value, return the result of a
	// call to CString::Format("%d", m_rawPixelValue).
	

	return "";
}


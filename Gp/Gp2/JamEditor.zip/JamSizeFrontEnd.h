#ifndef JAM_SIZE_FRONT_END_H
#define JAM_SIZE_FRONT_END_H

#include "EditableObject.h"

class CJam;	// fwd decl - needs to know the jame to which it relates

class CJamSizeFrontEnd : public CEditableObject
{
public:
	CJamSizeFrontEnd(CJam* pJam, CEditableObject* pParent);
	~CJamSizeFrontEnd() {};

	// overrides
	virtual UINT	GetIconID();
	virtual CString GetFullDescription();

protected:
	CJam* m_pJam;	// the jam we're fronting the size of
};

#endif

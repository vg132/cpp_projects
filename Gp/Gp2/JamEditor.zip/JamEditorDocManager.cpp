// JamEditorDocManager.cpp - implementation of the CJamEditorDocManager
//							 class

#include "stdafx.h"

#include "JamEditorDocManager.h"

#include "MRUPathList.h"
#include "JamEditorMRUPaths.h"
#include "FilenameParser.h"
#include <direct.h>

#include "JamFileDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


////////////////////////////////////////////////////////////
// CJamEditorDocManager construction/destruction
////////////////////////////////////////////////////////////

IMPLEMENT_DYNAMIC(CJamEditorDocManager, CDocManager)

CJamEditorDocManager::CJamEditorDocManager ()
{
}

CJamEditorDocManager::~CJamEditorDocManager ()
{
	m_lstOpenFilenames.RemoveAll();
}


////////////////////////////////////////////////////////////
// CJamEditorDocManager overrides


// Copied from DOCMGR.CPP for use in DoPromptFileName
//
static void AppendFilterSuffix(CString& filter, OPENFILENAME& ofn,
	CDocTemplate* pTemplate, CString* pstrDefaultExt)
{
	ASSERT_VALID(pTemplate);
	ASSERT_KINDOF(CDocTemplate, pTemplate);

	CString strFilterExt, strFilterName;
	if (pTemplate->GetDocString(strFilterExt, CDocTemplate::filterExt) &&
		!strFilterExt.IsEmpty() &&
		pTemplate->GetDocString(strFilterName, CDocTemplate::filterName) &&
		!strFilterName.IsEmpty())
	{
		// a file based document template - add to filter list
		ASSERT(strFilterExt[0] == '.');
		if (pstrDefaultExt != NULL)
		{
			// set the default extension
			*pstrDefaultExt = ((LPCTSTR)strFilterExt) + 1;  // skip the '.'
			ofn.lpstrDefExt = (LPTSTR)(LPCTSTR)(*pstrDefaultExt);
			ofn.nFilterIndex = ofn.nMaxCustFilter + 1;  // 1 based number
		}

		// add to filter
		filter += strFilterName;
		ASSERT(!filter.IsEmpty());  // must have a file type name
		filter += (TCHAR)'\0';  // next string please
		filter += (TCHAR)'*';
		filter += strFilterExt;
		filter += (TCHAR)'\0';  // next string please
		ofn.nMaxCustFilter++;
	}
}



// Function:	DoPromptFileName(fileName, nIDSTitle, lFlags, bOpenFileDialog, pTemplate)
// Overview:	Helper function for standard commdlg dialogs
BOOL CJamEditorDocManager::DoPromptFileName(CString& fileName, UINT nIDSTitle, DWORD lFlags,
											BOOL bOpenFileDialog, CDocTemplate* pTemplate)
{
	// Never use the document template provided as that would restrict
	// the file filters to being of that type only.  We want to offer
	// the user the ability to save as any document type we support.
	// Well, JAMs and decrypted JAMs, anyway. :)
	pTemplate = NULL;

	// Work out whether this is a multi-select open dialog
	BOOL bOpenMulti = bOpenFileDialog && (lFlags & OFN_ALLOWMULTISELECT);

	// Change directory to either the Open Jam or Save Jam path
	CString strPath("");
	CMRUPathList* pMRUPaths = CMRUPathList::GetPathList();
	if (bOpenFileDialog)
	{
		// Changing directory is enough when opening files...
		strPath = pMRUPaths->GetMRUPath(szOpenJamPath);
		_chdir(strPath);
	}
	else
	{
		// But for saving it's a little more awkward.  We've actually
		// got to change the path in this function's fileName parameter.
		strPath = pMRUPaths->GetMRUPath(szSaveJamPath);
		CFilenameParser parsedNewName(fileName), parsedPath(strPath);
		parsedNewName.Drive() = parsedPath.Drive();
		parsedNewName.Path() = parsedPath.Path();
		fileName = parsedNewName.GetFullSpec();
	}

	// Now's the time to prompt the user...

	// This code is copied directly from the MFC source for
	// CDocManager::DoPromptFileName, except that any Mac
	// stuff has been stripped out and the dialog type has
	// been replaced with the previewing dialog
	CJamFileDialog dlgFile(bOpenFileDialog);

	CString title;
	VERIFY(title.LoadString(nIDSTitle));

	dlgFile.m_ofn.Flags |= lFlags;

	// The AppendFilterSuffix function had to be copied out
	// of DOCMGR.CPP, too
	CString strFilter;
	CString strDefault;
	if (pTemplate != NULL)
	{
		// This branch is executed only when the user is saving a
		// particular type of document and the program is not allowing
		// them to save in a different format.  That should never be
		// the case in the Jam Editor, as you can always save as .JAM
		// or .JAD, but we'll leave the code here anyway.
		ASSERT_VALID(pTemplate);
		AppendFilterSuffix(strFilter, dlgFile.m_ofn, pTemplate, &strDefault);
	}
	else
	{
		// Put the "All Jam Editor files" filter at the top of the list.
		// We'll need to build a combined filter as we go through the
		// individual filters.
		CString strCombinedFilter("");

		// do for all doc template
		POSITION pos = m_templateList.GetHeadPosition();
		BOOL bFirst = TRUE;
		while (pos != NULL)
		{
			// Do the usual processing to get the individual filter appended
			// to strFilter.
			CDocTemplate* pTemplate = (CDocTemplate*)m_templateList.GetNext(pos);
			AppendFilterSuffix(strFilter, dlgFile.m_ofn, pTemplate,
				bFirst ? &strDefault : NULL);

			// Now make sure we put this filter into the combined one
			CString strThisFilter("");
			CString strFilterExt("");
			VERIFY(pTemplate->GetDocString(strFilterExt, CDocTemplate::filterExt));
			strThisFilter.Format((bFirst ? "*%s" : ";*%s"), strFilterExt);
			strCombinedFilter += strThisFilter;

			// Avoid setting the default filter extension again
			bFirst = FALSE;
		}

		// Finish off the work we've done to make the combined filter...
		CString strAppFilter("");
		strCombinedFilter.MakeLower();
		strAppFilter.Format("All %s files (%s)", AfxGetAppName(), strCombinedFilter);
		strAppFilter += (TCHAR)'\0';
		strAppFilter += strCombinedFilter;
		strAppFilter += (TCHAR)'\0';

		// ...and put it on the front of the other filters
		strFilter = strAppFilter + strFilter;
		dlgFile.m_ofn.nMaxCustFilter++;
	}

	// append the "*.*" all files filter
	CString allFilter;
	VERIFY(allFilter.LoadString(AFX_IDS_ALLFILTER));
	strFilter += allFilter;
	strFilter += (TCHAR)'\0';   // next string please
	strFilter += _T("*.*");
	strFilter += (TCHAR)'\0';   // last string
	dlgFile.m_ofn.nMaxCustFilter++;

	dlgFile.m_ofn.lpstrFilter = strFilter;
	dlgFile.m_ofn.lpstrTitle = title;
	if (bOpenMulti)
	{
		// NB: the size of string used here is arbitrarily chosen, but
		// needs to be large to be able to contain many filenames.
		dlgFile.m_ofn.nMaxFile = 32767;
		dlgFile.m_ofn.lpstrFile = fileName.GetBuffer(32767);
	}
	else
	{
		dlgFile.m_ofn.lpstrFile = fileName.GetBuffer(_MAX_PATH);
	}

	BOOL bResult = dlgFile.DoModal() == IDOK ? TRUE : FALSE;

	// Fill the list-of-filenames member if we may have opened
	// multiple files
	if (bOpenMulti && bResult)
	{
		m_lstOpenFilenames.RemoveAll();
		POSITION posFilename = dlgFile.GetStartPosition();
		while (NULL != posFilename)
			m_lstOpenFilenames.AddTail(dlgFile.GetNextPathName(posFilename));
	}
	fileName.ReleaseBuffer();

	return bResult;
}
// End of function 'DoPromptFileName'


// Function:	OnFileOpen()
// Overview:	Overridden top-level function for opening files.  The
//				change to the default behaviour here is that multiple
//				files can now be opened.
void CJamEditorDocManager::OnFileOpen()
{
	// prompt the user (with all document templates)
	CString newName;
	DWORD dwFlags = OFN_HIDEREADONLY | OFN_FILEMUSTEXIST | OFN_ALLOWMULTISELECT;
	if (!DoPromptFileName(newName, AFX_IDS_OPENFILE,
	  dwFlags, TRUE, NULL))
		return; // open cancelled

	// Cycle through the filenames, opening each in turn
	POSITION posFilename = m_lstOpenFilenames.GetHeadPosition();
	while (NULL != posFilename)
		AfxGetApp()->OpenDocumentFile(m_lstOpenFilenames.GetNext(posFilename));
		// if returns NULL, the user has already been alerted
	m_lstOpenFilenames.RemoveAll();
}
// End of function 'OnFileOpen'


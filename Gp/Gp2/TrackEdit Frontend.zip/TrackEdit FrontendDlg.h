// TrackEdit FrontendDlg.h : header file
//

#if !defined(AFX_TRACKEDITFRONTENDDLG_H__0E9AD1C5_C527_11D3_999B_0008C7636E27__INCLUDED_)
#define AFX_TRACKEDITFRONTENDDLG_H__0E9AD1C5_C527_11D3_999B_0008C7636E27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTrackEditFrontendDlg dialog

class CTrackEditFrontendDlg : public CDialog
{
// Construction
public:
	void GetListItems();
	void GetPath();
	void AddDrivers();
	void ListDrivers();
	void UpdateList(CString Dir);
	CString cPath;
	HANDLE hFile;
	CString cEditPath;
	CString cEditFile;
	CTrackEditFrontendDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTrackEditFrontendDlg)
	enum { IDD = IDD_TRACKEDITFRONTEND_DIALOG };
	CListCtrl	m_SortItems;
	CButton	m_Icon;
	CButton	m_List;
	CButton	m_ListEx;
	CComboBoxEx	m_Drive;
	CComboBoxEx	m_ImgCombo;
	CButton	m_UpOneLevel;
	CListCtrl	m_FileList;
	CString	m_Author;
	CString	m_Country;
	CString	m_Event;
	CString	m_Laps;
	CString	m_Len;
	CString	m_Name;
	CString	m_Misc;
	CString	m_Slot;
	CString	m_Tyre;
	CString	m_Year;
	CString	m_Status;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTrackEditFrontendDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	CImageList * m_pImageList;
	CImageList * m_pLargeList;
	// Generated message map functions
	//{{AFX_MSG(CTrackEditFrontendDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnUpOneLevel();
	afx_msg void OnDblclkExplorer(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchangeDrive();
	afx_msg void OnClickExplorer(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnOdstatechangedExplorer(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnStart();
	afx_msg void OnSetTrackPath();
	afx_msg void OnSetTrackEdit();
	afx_msg void OnList();
	afx_msg void OnListEx();
	afx_msg void OnIcon();
	afx_msg void OnMenuExit();
	afx_msg void OnItemclickExplorer(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnItemchangedExplorer(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnMenuAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void EditTrack();
	CString BrowseForFolders(CString szTitle);
	void RegSaveValue(CString cKey,CString cValue,CString cData);
	CString RegGetValue(CString cKey,CString cValue);
	void ReadGP2Info(CString FilePath);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRACKEDITFRONTENDDLG_H__0E9AD1C5_C527_11D3_999B_0008C7636E27__INCLUDED_)

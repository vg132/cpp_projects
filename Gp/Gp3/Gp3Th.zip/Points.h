#if !defined(AFX_POINTS_H__2EFE2BC5_85AE_11D4_8FC7_0008C7636E27__INCLUDED_)
#define AFX_POINTS_H__2EFE2BC5_85AE_11D4_8FC7_0008C7636E27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Points.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPoints dialog

class CPoints : public CDialog
{
// Construction
public:
	void SetSpin();
	CPoints(CWnd* pParent = NULL);   // standard constructor
	CString m_TempFile;
// Dialog Data
	//{{AFX_DATA(CPoints)
	enum { IDD = IDD_POINT };
	CSpinButtonCtrl	m_Spin9;
	CSpinButtonCtrl	m_Spin8;
	CSpinButtonCtrl	m_Spin7;
	CSpinButtonCtrl	m_Spin6;
	CSpinButtonCtrl	m_Spin5;
	CSpinButtonCtrl	m_Spin4;
	CSpinButtonCtrl	m_Spin3;
	CSpinButtonCtrl	m_Spin26;
	CSpinButtonCtrl	m_Spin25;
	CSpinButtonCtrl	m_Spin24;
	CSpinButtonCtrl	m_Spin23;
	CSpinButtonCtrl	m_Spin22;
	CSpinButtonCtrl	m_Spin21;
	CSpinButtonCtrl	m_Spin20;
	CSpinButtonCtrl	m_Spin2;
	CSpinButtonCtrl	m_Spin19;
	CSpinButtonCtrl	m_Spin18;
	CSpinButtonCtrl	m_Spin17;
	CSpinButtonCtrl	m_Spin16;
	CSpinButtonCtrl	m_Spin15;
	CSpinButtonCtrl	m_Spin14;
	CSpinButtonCtrl	m_Spin13;
	CSpinButtonCtrl	m_Spin12;
	CSpinButtonCtrl	m_Spin11;
	CSpinButtonCtrl	m_Spin1;
	CSpinButtonCtrl	m_Spin10;
	int		m_Edit1;
	int		m_Edit10;
	int		m_Edit11;
	int		m_Edit12;
	int		m_Edit13;
	int		m_Edit9;
	int		m_Edit8;
	int		m_Edit7;
	int		m_Edit6;
	int		m_Edit5;
	int		m_Edit4;
	int		m_Edit26;
	int		m_Edit3;
	int		m_Edit21;
	int		m_Edit22;
	int		m_Edit23;
	int		m_Edit24;
	int		m_Edit25;
	int		m_Edit20;
	int		m_Edit2;
	int		m_Edit16;
	int		m_Edit15;
	int		m_Edit14;
	int		m_Edit17;
	int		m_Edit18;
	int		m_Edit19;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPoints)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPoints)
	virtual BOOL OnInitDialog();
	afx_msg void OnCart();
	afx_msg void OnFormulaone();
	virtual void OnOK();
	afx_msg void OnAll();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_POINTS_H__2EFE2BC5_85AE_11D4_8FC7_0008C7636E27__INCLUDED_)

// CheckListBoxEx.cpp : implementation file
//

#include "stdafx.h"

#include "CheckListBoxEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCheckListBoxEx

CCheckListBoxEx::CCheckListBoxEx()
{
}

CCheckListBoxEx::~CCheckListBoxEx()
{
}


BEGIN_MESSAGE_MAP(CCheckListBoxEx, CCheckListBox)
	//{{AFX_MSG_MAP(CCheckListBoxEx)
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCheckListBoxEx message handlers

// NOTE: This code is NOT intended to be general.  I can't be
// bothered to write it properly.  It seems the same was true
// of whoever at MS wrote CCheckListBox - they rarely use the
// virtual functions they provided (such as OnGetCheckPosition)
// and certainly didn't support multi-column checklists
void CCheckListBoxEx::OnLButtonDown(UINT nFlags, CPoint point) 
{
	SetFocus();

	// This is the only bit I'm interested in overriding
	if (GetStyle() & LBS_OWNERDRAWFIXED)
	{
		// Check to see whether the user clicked inside a checkbox
		BOOL bOutsideList = FALSE;
		UINT nIndex = ItemFromPoint(point, bOutsideList);
		if (nIndex == -1 || bOutsideList)
		{
			CCheckListBox::OnLButtonDown(nFlags, point);
			return;
		}
		CRect rctItem;
		if (LB_ERR == GetItemRect(nIndex, rctItem))
		{
			CCheckListBox::OnLButtonDown(nFlags, point);
			return;
		}

		if (IsEnabled(nIndex))
		{
			if (m_nStyle != BS_CHECKBOX && m_nStyle != BS_3STATE)
			{
				if (point.x < rctItem.left + 13)	// default checkbox size is 11
				{
					CWnd*   pParent = GetParent();
					ASSERT_VALID(pParent);

					int nModulo = (m_nStyle == BS_AUTO3STATE) ? 3 : 2;
					int nCheck = GetCheck(nIndex);
					nCheck = (nCheck == nModulo) ? nCheck - 1 : nCheck;
					SetCheck(nIndex, (nCheck + 1) % nModulo);

					InvalidateCheck(nIndex);

					CListBox::OnLButtonDown(nFlags, point);

					// Inform of check
					pParent->SendMessage(WM_COMMAND,
						MAKEWPARAM(GetDlgCtrlID(), CLBN_CHKCHANGE),
						(LPARAM)m_hWnd);
					return;
				}
			}
		}
		else
			return; // Swallow LButtons for disabled items
	}
	else
	{
		CCheckListBox::OnLButtonDown(nFlags, point);
	}

	CListBox::OnLButtonDown(nFlags, point);
}

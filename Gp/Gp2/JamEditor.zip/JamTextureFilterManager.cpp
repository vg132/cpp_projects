// JamTextureFilterManager.cpp: implementation file for the CJamTextureFilterManager class
//

#include "stdafx.h"

#include "JamTextureFilterManager.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJamTextureFilterManager

// The only instance of the class that should ever exist.
CJamTextureFilterManager* CJamTextureFilterManager::m_pUniqueInstance = NULL;

CJamTextureFilterManager::CJamTextureFilterManager()
{
	// You should not need to create a CJamTextureFilterManager
	// directly - just use GetManager()
	VERIFY(m_pUniqueInstance == NULL);
}

CJamTextureFilterManager::~CJamTextureFilterManager()
{
	// Just delete all filters from our list
	while (NULL != m_lstFilters.GetHeadPosition())
		delete m_lstFilters.RemoveHead();
}


// Singleton-related static operations
//

CJamTextureFilterManager* CJamTextureFilterManager::GetManager()
{
	// If the manager hasn't been created yet, do it now
	if (NULL == m_pUniqueInstance)
		m_pUniqueInstance = new CJamTextureFilterManager;

	return m_pUniqueInstance;
}

void CJamTextureFilterManager::DestroyManager()
{
	if (NULL != m_pUniqueInstance)
	{
		delete m_pUniqueInstance;
		m_pUniqueInstance = NULL;
	}
}


// List management functions
//

// Add file types your application supports using this function:
BOOL CJamTextureFilterManager::AddFilter(CJamTextureFilter* pFilter)
{
	// Make sure the calling function's not being daft - we
	// can't add a null pointer to the list
	if (NULL == pFilter)
		return FALSE;

	// Add the preview type to the list
	m_lstFilters.AddTail(pFilter);

	return TRUE;
}

// Creation of new preview objects based on a filename
CJamTextureFilter* CJamTextureFilterManager::GetFilter (const UINT nFilterID)
{
	// Just return the filter from our list that has the given ID
	POSITION posFilter = GetFirstFilterPos();
	CJamTextureFilter* pFilter = NULL;
	BOOL bFound = FALSE;
	while (NULL != posFilter && !bFound)
	{
		pFilter = GetNextFilter(posFilter);
		if (NULL != pFilter && pFilter->GetFilterID() == nFilterID)
			bFound = TRUE;
	}

	if (bFound)
		return pFilter;
	else
		return NULL;
}


// Iteration through the filters
POSITION CJamTextureFilterManager::GetFirstFilterPos() const
{
	return m_lstFilters.GetHeadPosition();
}

CJamTextureFilter* CJamTextureFilterManager::GetNextFilter(POSITION& posFilter) const
{
	return m_lstFilters.GetNext(posFilter);
}



// JamTree.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "JamControlBar.h"

#include "JamTree.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CJamControlBar

CJamControlBar::CJamControlBar()
{
}

CJamControlBar::~CJamControlBar()
{
}

BEGIN_MESSAGE_MAP(CJamControlBar, CSizingControlBar)
	//{{AFX_MSG_MAP(CJamControlBar)
	ON_WM_SIZE()
	ON_WM_CREATE()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CJamControlBar message handlers

void CJamControlBar::OnSize(UINT nType, int cx, int cy) 
{
	// Call base class resizing first
	CSizingControlBar::OnSize(nType, cx, cy);

	// Now adjust the jam tree to fit within the 
	CRect rctClient(0,0,0,0);
    GetClientRect(rctClient);
	RepositionTree(rctClient);
}

void CJamControlBar::RepositionTree(const CRect& rctClient)
{
	// The tree must exist!
	if (NULL == m_pJamTree)
		return;

	// Leave a 5-pixel border around the tree
	CRect rctJamTree(rctClient);
	rctJamTree.DeflateRect(5,5);

	// For some reason, when the control bar is docked vertically,
	// the tree goes down further than we want, so stop it doing so.
	if (!IsHorz() && !IsFloating())
		rctJamTree.bottom -= 4;	// the equivalent of 2 client edges

	// Move the jam tree window
    m_pJamTree->MoveWindow(rctJamTree);
}

int CJamControlBar::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	// Do default creation first
	if (CSizingControlBar::OnCreate(lpCreateStruct) == -1)
		return -1;

	// Set this window's caption in case it is floated
	CString strTitle;
	strTitle.LoadString(IDC_JAMTREE);
	SetWindowText(strTitle);

	// Create the jam tree object
	m_pJamTree = new CJamTree;
	if (NULL == m_pJamTree)
		return -1;

	// Now create it as a window
	DWORD dwStyles = TVS_HASLINES  |		// dotted lines around the place
		TVS_HASBUTTONS |					// little +/- buttons
		TVS_SHOWSELALWAYS |					// show selection even when lost focus
		TVS_EDITLABELS |					// we can do in place editing
		TVS_DISABLEDRAGDROP |				// tree items not to be dragged/dropped
		WS_VISIBLE | WS_CHILD | WS_BORDER;	// general windows styles

	if (!m_pJamTree->CreateEx(WS_EX_CLIENTEDGE, "SysTreeView32", "", dwStyles,
		0,0,100,100, GetSafeHwnd(), (HMENU)IDC_JAMTREE))
       return -1;

	return 0;
}

void CJamControlBar::OnDestroy() 
{
	// Call the base class stuff first
	CSizingControlBar::OnDestroy();
	
	// Get rid of the Jam tree
	if (NULL != m_pJamTree)
	{
		m_pJamTree->DestroyWindow();
		delete m_pJamTree;
		m_pJamTree = NULL;
	}
}

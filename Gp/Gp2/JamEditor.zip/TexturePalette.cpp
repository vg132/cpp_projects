// TexturePalette.cpp - implementation for the CGP2Palette class
//

#include "stdafx.h"
#include "JamEditor.h"

#include "TexturePalette.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// Definitions of the default GP2 and GP3 palettes

// NOTE: RGBQUAD's members are in the BGR order
//       rather than RGB.  The final number is
//       reserved and must be zero.

// The default palette used for GP2's JAM files
static RGBQUAD gp2Palette[] =
{
	{127,171,151,0},  // Color 0
	{19,19,19,0},     // Color 1
	{27,27,27,0},     // Color 2
	{35,35,35,0},     // Color 3
	{43,43,43,0},     // Color 4
	{51,51,51,0},     // Color 5
	{59,59,59,0},     // Color 6
	{67,67,67,0},     // Color 7
	{75,75,75,0},     // Color 8
	{83,83,83,0},     // Color 9
	{91,91,91,0},     // Color 10
	{99,99,99,0},     // Color 11
	{107,107,107,0},  // Color 12
	{115,115,115,0},  // Color 13
	{123,123,123,0},  // Color 14
	{131,131,131,0},  // Color 15
	{139,139,139,0},  // Color 16
	{147,147,147,0},  // Color 17
	{155,155,155,0},  // Color 18
	{163,163,163,0},  // Color 19
	{167,167,167,0},  // Color 20
	{175,175,175,0},  // Color 21
	{183,183,183,0},  // Color 22
	{191,191,191,0},  // Color 23
	{199,199,199,0},  // Color 24
	{207,207,207,0},  // Color 25
	{215,215,215,0},  // Color 26
	{223,223,223,0},  // Color 27
	{231,231,231,0},  // Color 28
	{239,239,239,0},  // Color 29
	{247,247,247,0},  // Color 30
	{255,255,255,0},  // Color 31
	{11,15,75,0},     // Color 32
	{11,15,87,0},     // Color 33
	{15,19,99,0},     // Color 34
	{15,19,107,0},    // Color 35
	{19,23,119,0},    // Color 36
	{23,27,131,0},    // Color 37
	{27,27,143,0},    // Color 38
	{31,31,155,0},    // Color 39
	{39,35,163,0},    // Color 40
	{43,43,175,0},    // Color 41
	{51,47,187,0},    // Color 42
	{59,51,199,0},    // Color 43
	{67,59,211,0},    // Color 44
	{75,63,223,0},    // Color 45
	{83,71,231,0},    // Color 46
	{95,79,243,0},    // Color 47
	{7,143,139,0},    // Color 48
	{7,151,151,0},    // Color 49
	{7,159,159,0},    // Color 50
	{7,163,167,0},    // Color 51
	{7,167,175,0},    // Color 52
	{7,175,179,0},    // Color 53
	{7,179,187,0},    // Color 54
	{7,183,195,0},    // Color 55
	{7,187,203,0},    // Color 56
	{7,191,211,0},    // Color 57
	{7,199,219,0},    // Color 58
	{7,203,227,0},    // Color 59
	{7,207,235,0},    // Color 60
	{7,211,239,0},    // Color 61
	{7,215,247,0},    // Color 62
	{7,215,255,0},    // Color 63
	{15,15,83,0},     // Color 64
	{19,19,91,0},     // Color 65
	{23,23,99,0},     // Color 66
	{27,27,107,0},    // Color 67
	{35,35,115,0},    // Color 68
	{39,39,123,0},    // Color 69
	{47,47,127,0},    // Color 70
	{51,51,135,0},    // Color 71
	{59,59,143,0},    // Color 72
	{67,67,151,0},    // Color 73
	{75,75,159,0},    // Color 74
	{83,83,167,0},    // Color 75
	{91,91,175,0},    // Color 76
	{99,99,183,0},    // Color 77
	{111,111,191,0},  // Color 78
	{119,119,199,0},  // Color 79
	{131,131,203,0},  // Color 80
	{143,143,211,0},  // Color 81
	{151,151,219,0},  // Color 82
	{163,163,227,0},  // Color 83
	{59,79,83,0},     // Color 84
	{63,87,87,0},     // Color 85
	{71,91,95,0},     // Color 86
	{75,99,99,0},     // Color 87
	{79,103,107,0},   // Color 88
	{83,111,111,0},   // Color 89
	{91,115,119,0},   // Color 90
	{95,123,123,0},   // Color 91
	{99,127,131,0},   // Color 92
	{103,135,135,0},  // Color 93
	{111,139,143,0},  // Color 94
	{115,147,147,0},  // Color 95
	{119,151,155,0},  // Color 96
	{127,159,159,0},  // Color 97
	{131,163,167,0},  // Color 98
	{135,171,171,0},  // Color 99
	{143,175,179,0},  // Color 100
	{147,183,183,0},  // Color 101
	{155,187,191,0},  // Color 102
	{159,195,195,0},  // Color 103
	{47,111,63,0},    // Color 104
	{51,115,67,0},    // Color 105
	{55,119,71,0},    // Color 106
	{63,123,75,0},    // Color 107
	{67,127,79,0},    // Color 108
	{71,131,83,0},    // Color 109
	{79,135,87,0},    // Color 110
	{83,139,91,0},    // Color 111
	{91,143,99,0},    // Color 112
	{95,147,103,0},   // Color 113
	{103,151,107,0},  // Color 114
	{107,155,115,0},  // Color 115
	{115,155,119,0},  // Color 116
	{123,159,127,0},  // Color 117
	{131,163,131,0},  // Color 118
	{139,167,139,0},  // Color 119
	{147,171,147,0},  // Color 120
	{151,175,155,0},  // Color 121
	{163,179,163,0},  // Color 122
	{171,183,171,0},  // Color 123
	{179,123,91,0},   // Color 124
	{183,127,95,0},   // Color 125
	{187,131,103,0},  // Color 126
	{191,135,107,0},  // Color 127
	{195,139,111,0},  // Color 128
	{199,143,115,0},  // Color 129
	{203,147,123,0},  // Color 130
	{207,151,127,0},  // Color 131
	{211,155,135,0},  // Color 132
	{215,159,139,0},  // Color 133
	{219,163,147,0},  // Color 134
	{223,167,151,0},  // Color 135
	{223,171,159,0},  // Color 136
	{227,179,163,0},  // Color 137
	{231,183,171,0},  // Color 138
	{235,187,179,0},  // Color 139
	{239,195,183,0},  // Color 140
	{243,199,191,0},  // Color 141
	{247,203,199,0},  // Color 142
	{251,211,203,0},  // Color 143
	{83,19,15,0},     // Color 144
	{91,23,19,0},     // Color 145
	{99,27,23,0},     // Color 146
	{107,35,27,0},    // Color 147
	{115,39,35,0},    // Color 148
	{123,43,39,0},    // Color 149
	{127,51,47,0},    // Color 150
	{135,55,51,0},    // Color 151
	{143,63,59,0},    // Color 152
	{151,71,67,0},    // Color 153
	{159,79,75,0},    // Color 154
	{167,87,83,0},    // Color 155
	{175,95,91,0},    // Color 156
	{183,103,99,0},   // Color 157
	{191,115,111,0},  // Color 158
	{199,123,119,0},  // Color 159
	{203,135,131,0},  // Color 160
	{211,147,143,0},  // Color 161
	{219,155,151,0},  // Color 162
	{227,167,163,0},  // Color 163
	{23,59,47,0},     // Color 164
	{27,67,55,0},     // Color 165
	{31,75,67,0},     // Color 166
	{39,83,75,0},     // Color 167
	{43,91,83,0},     // Color 168
	{51,99,95,0},     // Color 169
	{55,107,103,0},   // Color 170
	{63,115,115,0},   // Color 171
	{71,123,123,0},   // Color 172
	{79,127,131,0},   // Color 173
	{87,135,139,0},   // Color 174
	{99,139,147,0},   // Color 175
	{63,83,83,0},     // Color 176
	{75,95,95,0},     // Color 177
	{87,107,111,0},   // Color 178
	{99,123,127,0},   // Color 179
	{111,135,139,0},  // Color 180
	{123,147,155,0},  // Color 181
	{139,163,167,0},  // Color 182
	{151,175,183,0},  // Color 183
	{163,187,199,0},  // Color 184
	{179,199,211,0},  // Color 185
	{127,135,135,0},  // Color 186
	{131,139,139,0},  // Color 187
	{135,143,143,0},  // Color 188
	{143,147,147,0},  // Color 189
	{147,147,151,0},  // Color 190
	{151,151,151,0},  // Color 191
	{155,155,155,0},  // Color 192
	{159,159,159,0},  // Color 193
	{23,59,31,0},     // Color 194
	{23,67,35,0},     // Color 195
	{27,71,35,0},     // Color 196
	{31,79,39,0},     // Color 197
	{35,83,47,0},     // Color 198
	{39,87,51,0},     // Color 199
	{47,95,55,0},     // Color 200
	{51,99,59,0},     // Color 201
	{59,103,67,0},    // Color 202
	{63,111,71,0},    // Color 203
	{71,115,79,0},    // Color 204
	{79,119,83,0},    // Color 205
	{87,127,91,0},    // Color 206
	{95,131,99,0},    // Color 207
	{103,135,107,0},  // Color 208
	{111,143,115,0},  // Color 209
	{123,147,123,0},  // Color 210
	{131,151,131,0},  // Color 211
	{139,159,143,0},  // Color 212
	{151,163,151,0},  // Color 213
	{7,90,65,0},      // Color 214
	{7,99,68,0},      // Color 215
	{11,104,65,0},    // Color 216
	{15,105,67,0},    // Color 217
	{19,113,73,0},    // Color 218
	{23,122,76,0},    // Color 219
	{27,129,79,0},    // Color 220
	{31,137,82,0},    // Color 221
	{35,139,88,0},    // Color 222
	{39,147,91,0},    // Color 223
	{47,149,97,0},    // Color 224
	{51,157,101,0},   // Color 225
	{59,160,107,0},   // Color 226
	{63,168,115,0},   // Color 227
	{71,171,122,0},   // Color 228
	{79,180,130,0},   // Color 229
	{87,182,136,0},   // Color 230
	{95,189,143,0},   // Color 231
	{103,196,154,0},  // Color 232
	{111,199,161,0},  // Color 233
	{147,39,19,0},    // Color 234
	{207,127,99,0},   // Color 235
	{103,143,143,0},  // Color 236
	{95,135,135,0},   // Color 237
	{71,119,123,0},   // Color 238
	{35,51,51,0},     // Color 239
	{0,203,7,0},      // Color 240
	{0,115,7,0},      // Color 241
	{0,63,255,0},     // Color 242
	{0,0,199,0},      // Color 243
	{7,167,255,0},    // Color 244
	{7,107,219,0},    // Color 245
	{163,0,163,0},    // Color 246
	{163,0,163,0},    // Color 247
	{163,0,163,0},    // Color 248
	{163,0,163,0},    // Color 249
	{163,0,163,0},    // Color 250
	{163,0,163,0},    // Color 251
	{163,0,163,0},    // Color 252
	{163,0,163,0},    // Color 253
	{163,0,163,0},    // Color 254
	{255,255,255,0}   // Color 255
};

// The default palette used for GP3's JAM files.  Note: I've indented
// these one tab extra so that I can quickly tell which palette I'm
// looking at.
static RGBQUAD gp3Palette[] =
{
		{103,103,63,0},		// Color 0
		{0,0,0,0},			// Color 1
		{16,16,16,0},		// Color 2
		{24,24,24,0},		// Color 3
		{32,32,32,0},		// Color 4
		{40,40,40,0},		// Color 5
		{48,48,48,0},		// Color 6
		{56,56,56,0},		// Color 7
		{64,64,64,0},		// Color 8
		{72,72,72,0},		// Color 9
		{76,76,76,0},		// Color 10
		{80,80,80,0},		// Color 11
		{84,84,84,0},		// Color 12
		{88,88,88,0},		// Color 13
		{92,92,92,0},		// Color 14
		{96,96,96,0},		// Color 15
		{100,100,100,0},	// Color 16
		{104,104,104,0},	// Color 17
		{108,108,108,0},	// Color 18
		{112,112,112,0},	// Color 19
		{116,116,116,0},	// Color 20
		{120,120,120,0},	// Color 21
		{124,124,124,0},	// Color 22
		{128,128,128,0},	// Color 23
		{132,132,132,0},	// Color 24
		{140,140,140,0},	// Color 25
		{148,148,148,0},	// Color 26
		{156,156,156,0},	// Color 27
		{164,164,164,0},	// Color 28
		{172,172,172,0},	// Color 29
		{180,180,180,0},	// Color 30
		{188,188,188,0},	// Color 31
		{196,196,196,0},	// Color 32
		{204,204,204,0},	// Color 33
		{212,212,212,0},	// Color 34
		{220,220,220,0},	// Color 35
		{228,228,228,0},	// Color 36
		{236,236,236,0},	// Color 37
		{244,244,244,0},	// Color 38
		{252,252,252,0},	// Color 39
		{48,64,64,0},		// Color 40
		{65,84,85,0},		// Color 41
		{82,103,105,0},		// Color 42
		{99,122,126,0},		// Color 43
		{118,141,146,0},	// Color 44
		{136,160,167,0},	// Color 45
		{156,178,187,0},	// Color 46
		{175,197,208,0},	// Color 47
		{4,9,60,0},			// Color 48
		{5,10,72,0},		// Color 49
		{6,11,84,0},		// Color 50
		{7,12,96,0},		// Color 51
		{9,13,108,0},		// Color 52
		{10,13,120,0},		// Color 53
		{12,14,132,0},		// Color 54
		{13,14,144,0},		// Color 55
		{16,15,156,0},		// Color 56
		{20,17,168,0},		// Color 57
		{24,19,180,0},		// Color 58
		{28,21,192,0},		// Color 59
		{33,23,204,0},		// Color 60
		{38,25,216,0},		// Color 61
		{44,27,228,0},		// Color 62
		{49,30,240,0},		// Color 63
		{1,84,81,0},		// Color 64
		{2,95,93,0},		// Color 65
		{3,106,105,0},		// Color 66
		{4,118,117,0},		// Color 67
		{6,128,129,0},		// Color 68
		{7,138,140,0},		// Color 69
		{9,148,151,0},		// Color 70
		{11,157,162,0},		// Color 71
		{13,167,174,0},		// Color 72
		{15,176,185,0},		// Color 73
		{17,185,196,0},		// Color 74
		{20,194,207,0},		// Color 75
		{22,202,218,0},		// Color 76
		{25,211,229,0},		// Color 77
		{28,219,241,0},		// Color 78
		{31,228,252,0},		// Color 79
		{22,108,55,0},		// Color 80
		{26,115,62,0},		// Color 81
		{31,122,69,0},		// Color 82
		{36,129,77,0},		// Color 83
		{41,135,85,0},		// Color 84
		{46,142,93,0},		// Color 85
		{52,149,101,0},		// Color 86
		{58,156,109,0},		// Color 87
		{50,69,104,0},		// Color 88
		{61,84,122,0},		// Color 89
		{72,99,139,0},		// Color 90
		{83,115,157,0},		// Color 91
		{96,131,175,0},		// Color 92
		{108,148,193,0},	// Color 93
		{122,165,210,0},	// Color 94
		{135,183,228,0},	// Color 95
		{72,13,9,0},		// Color 96
		{82,19,13,0},		// Color 97
		{92,25,17,0},		// Color 98
		{102,33,22,0},		// Color 99
		{113,41,28,0},		// Color 100
		{123,50,34,0},		// Color 101
		{133,60,41,0},		// Color 102
		{143,70,49,0},		// Color 103
		{153,81,57,0},		// Color 104
		{163,93,66,0},		// Color 105
		{173,105,76,0},		// Color 106
		{183,117,86,0},		// Color 107
		{194,130,97,0},		// Color 108
		{204,143,108,0},	// Color 109
		{214,157,120,0},	// Color 110
		{224,171,133,0},	// Color 111
		{224,173,137,0},	// Color 112
		{224,175,140,0},	// Color 113
		{224,177,144,0},	// Color 114
		{224,179,147,0},	// Color 115
		{224,181,151,0},	// Color 116
		{224,183,155,0},	// Color 117
		{224,186,158,0},	// Color 118
		{224,188,162,0},	// Color 119
		{224,190,166,0},	// Color 120
		{224,192,169,0},	// Color 121
		{224,194,173,0},	// Color 122
		{224,196,177,0},	// Color 123
		{224,198,180,0},	// Color 124
		{224,201,184,0},	// Color 125
		{224,203,188,0},	// Color 126
		{224,205,191,0},	// Color 127
		{224,207,195,0},	// Color 128
		{224,209,199,0},	// Color 129
		{224,211,202,0},	// Color 130
		{224,213,206,0},	// Color 131
		{224,216,210,0},	// Color 132
		{224,218,213,0},	// Color 133
		{224,220,217,0},	// Color 134
		{224,222,220,0},	// Color 135
		{21,24,14,0},		// Color 136
		{31,38,20,0},		// Color 137
		{40,51,24,0},		// Color 138
		{45,65,27,0},		// Color 139
		{48,79,28,0},		// Color 140
		{48,93,28,0},		// Color 141
		{44,106,26,0},		// Color 142
		{35,120,22,0},		// Color 143
		{26,56,38,0},		// Color 144
		{30,81,51,0},		// Color 145
		{28,107,60,0},		// Color 146
		{21,132,66,0},		// Color 147
		{12,20,12,0},		// Color 148
		{26,51,27,0},		// Color 149
		{37,81,37,0},		// Color 150
		{46,112,44,0},		// Color 151
		{17,72,44,0},		// Color 152
		{31,94,57,0},		// Color 153
		{49,115,71,0},		// Color 154
		{71,137,88,0},		// Color 155
		{97,158,108,0},		// Color 156
		{127,180,132,0},	// Color 157
		{26,60,40,0},		// Color 158
		{36,75,51,0},		// Color 159
		{47,89,63,0},		// Color 160
		{60,104,76,0},		// Color 161
		{105,160,139,0},	// Color 162
		{118,168,152,0},	// Color 163
		{132,176,165,0},	// Color 164
		{147,184,178,0},	// Color 165
		{162,192,189,0},	// Color 166
		{178,200,199,0},	// Color 167
		{20,26,81,0},		// Color 168
		{26,30,100,0},		// Color 169
		{32,35,119,0},		// Color 170
		{38,39,138,0},		// Color 171
		{45,44,158,0},		// Color 172
		{55,50,177,0},		// Color 173
		{66,57,196,0},		// Color 174
		{77,64,215,0},		// Color 175
		{21,100,98,0},		// Color 176
		{27,118,117,0},		// Color 177
		{32,134,135,0},		// Color 178
		{38,150,153,0},		// Color 179
		{45,165,171,0},		// Color 180
		{52,180,189,0},		// Color 181
		{59,194,207,0},		// Color 182
		{67,208,225,0},		// Color 183
		{44,117,72,0},		// Color 184
		{53,128,85,0},		// Color 185
		{63,139,99,0},		// Color 186
		{74,150,113,0},		// Color 187
		{70,88,118,0},		// Color 188
		{91,114,147,0},		// Color 189
		{113,141,175,0},	// Color 190
		{136,170,203,0},	// Color 191
		{90,33,28,0},		// Color 192
		{106,47,38,0},		// Color 193
		{122,62,50,0},		// Color 194
		{138,80,64,0},		// Color 195
		{154,99,79,0},		// Color 196
		{171,119,96,0},		// Color 197
		{187,140,114,0},	// Color 198
		{203,162,135,0},	// Color 199
		{45,50,103,0},		// Color 200
		{59,61,132,0},		// Color 201
		{76,74,160,0},		// Color 202
		{97,89,189,0},		// Color 203
		{48,116,115,0},		// Color 204
		{62,142,143,0},		// Color 205
		{77,165,170,0},		// Color 206
		{92,187,197,0},		// Color 207
		{69,127,93,0},		// Color 208
		{86,143,115,0},		// Color 209
		{95,110,134,0},		// Color 210
		{131,153,177,0},	// Color 211
		{108,60,54,0},		// Color 212
		{133,87,77,0},		// Color 213
		{157,118,102,0},	// Color 214
		{181,151,132,0},	// Color 215
		{72,76,115,0},		// Color 216
		{85,86,134,0},		// Color 217
		{100,98,154,0},		// Color 218
		{116,112,173,0},	// Color 219
		{76,124,123,0},		// Color 220
		{88,141,142,0},		// Color 221
		{101,157,160,0},	// Color 222
		{115,172,178,0},	// Color 223
		{91,131,108,0},		// Color 224
		{105,142,123,0},	// Color 225
		{109,120,136,0},	// Color 226
		{136,150,165,0},	// Color 227
		{119,83,79,0},		// Color 228
		{135,104,97,0},		// Color 229
		{151,126,116,0},	// Color 230
		{167,149,137,0},	// Color 231
		{108,109,132,0},	// Color 232
		{126,125,152,0},	// Color 233
		{110,137,137,0},	// Color 234
		{127,152,155,0},	// Color 235
		{119,138,128,0},	// Color 236
		{132,138,145,0},	// Color 237
		{133,116,113,0},	// Color 238
		{150,139,134,0},	// Color 239
		{35,72,72,0},		// Color 240
		{43,88,88,0},		// Color 241
		{0,59,252,0},		// Color 242
		{0,0,176,0},		// Color 243
		{0,207,252,0},		// Color 244
		{10,97,216,0},		// Color 245
		{148,43,23,0},		// Color 246
		{204,128,99,0},		// Color 247
		{98,140,140,0},		// Color 248
		{93,132,132,0},		// Color 249
		{69,114,120,0},		// Color 250
		{48,100,92,0},		// Color 251
		{0,208,7,0},		// Color 252
		{0,140,4,0},		// Color 253
		{160,0,159,0},		// Color 254
		{255,255,255,0}		// Color 255
};


/////////////////////////////////////////////////////////////////////////////
// CGP2Palette construction / destruction

CGP2Palette CGP2Palette::thePalette;

CGP2Palette::CGP2Palette() : m_nPaletteType(PALTYPE_GP3), m_strPaletteFilename("")
{
	// Initialise the palette to be the GP2 palette
	memset(&m_Palette[0], 0, GP2_PALETTE_SIZE * sizeof(RGBQUAD));
	SetPaletteType(PALTYPE_GP2);
}

CGP2Palette::~CGP2Palette()
{
}



/////////////////////////////////////////////////////////////////////////////
// CGP2Palette operations

// Function:	SetPaletteType(nPalType, strPaletteFilename="")
// Overview:	Set the palette type.  Also, if the palette type
//				is being set to use a custom palette, load it from
//				the given filename.  If a filename is not supplied
//				when switching to a custom palette, the current
//				filename will be used instead.  However, even if
//				you pass the filename when setting to a different
//				palette type, we'll still store that filename for
//				future use.
BOOL CGP2Palette::SetPaletteType(const int nPalType, CString strPaletteFilename)
{
	// Make sure the palette type is valid
	ASSERT(nPalType >= PALTYPE_FIRST && nPalType <= PALTYPE_FINAL);
	if (nPalType < PALTYPE_FIRST || nPalType > PALTYPE_FINAL)
		return FALSE;

	BOOL bSuccess = FALSE;
	switch (nPalType)
	{
	case PALTYPE_GP2:
		bSuccess = LoadStandardPalette(gp2Palette);
		if (!strPaletteFilename.IsEmpty())
			m_strPaletteFilename = strPaletteFilename;
		break;
	case PALTYPE_GP3:
		bSuccess = LoadStandardPalette(gp3Palette);
		if (!strPaletteFilename.IsEmpty())
			m_strPaletteFilename = strPaletteFilename;
		break;
	case PALTYPE_CUSTOM:
		if (strPaletteFilename.IsEmpty())
			strPaletteFilename = m_strPaletteFilename;
		if (!strPaletteFilename.IsEmpty())
		{
			bSuccess = LoadCustomPalette(strPaletteFilename);
			if (bSuccess)
				m_strPaletteFilename = strPaletteFilename;
		}
		break;
	}

	// Store the new palette type regardless
	m_nPaletteType = (ePaletteType)nPalType;

	// Get the app to update all views
	CJamEditorApp* pApp = (CJamEditorApp *)AfxGetApp();
	if (NULL != pApp)
		pApp->OnChangedGlobalPalette();

	return bSuccess;
}
// End of function 'SetPaletteType'


// Function:	LoadStandardPalette(palette[])
// Overview:	Load the given palette into our m_Palette member.
BOOL CGP2Palette::LoadStandardPalette(const RGBQUAD palette[])
{
	for (int nIndex = 0; nIndex <= GP2_PALETTE_SIZE; nIndex++)
	{
		m_Palette[nIndex].rgbRed = palette[nIndex].rgbRed;
		m_Palette[nIndex].rgbGreen = palette[nIndex].rgbGreen;
		m_Palette[nIndex].rgbBlue = palette[nIndex].rgbBlue;
	}

	return TRUE;
}
// End of function 'LoadStandardPalette'


// Function:	LoadCustomPalette(strFilename)
// Overview:	Load the file containing a custom global palette,
//				which is in the JASC palette file format.
BOOL CGP2Palette::LoadCustomPalette(const CString& strFilename)
{
	// Open the file and make sure it's a JASC palette by skipping
	// through the first few (unwanted) lines
	CStdioFile file;
	CFileException fe;
	if (!file.Open(strFilename, CFile::modeRead | CFile::shareDenyWrite | CFile::typeText, &fe))
	{
		// Get a report of the error from the exception and tell the
		// user that we're going to keep the current palette.
		TCHAR szCause[255];
		fe.GetErrorMessage(szCause, 255);
		CString strAlert = "";
		strAlert.Format(IDS_CANT_OPEN_EXTERNAL_PALETTE, szCause);
		AfxMessageBox(strAlert);
		return FALSE;
	}
	CString strHeaderLine = "";
	if ((!file.ReadString(strHeaderLine) || strHeaderLine != "JASC-PAL") ||	// make sure it's a JASC palette file
		(!file.ReadString(strHeaderLine)) ||								// ditch this "0100" line
		(!file.ReadString(strHeaderLine) || strHeaderLine != "256"))		// make sure it's a 256-colour palette
	{
		// Tell the user that the palette file is of an invalid format
		// and that we're keeping the current palette
		CString strAlert("");
		strAlert.Format(IDS_INVALID_EXTERNAL_PALETTE, strFilename);
		AfxMessageBox(strAlert);
		return FALSE;
	}

	// Load the global palette with the values in the file
	CString strPaletteValues = "";
	int nRed = 0, nGreen = 0, nBlue = 0;
	BOOL bSuccess = TRUE;
	for (int nPalIndex = 0; nPalIndex <= 255 && bSuccess; nPalIndex++)
	{
		// Read the next palette entry
		bSuccess = file.ReadString(strPaletteValues);
		if (!bSuccess)
			continue;

		// Parse the numbers out of it
		int nResult = sscanf(strPaletteValues, "%d %d %d", &nRed, &nGreen, &nBlue);
		if (3 == nResult)
		{
			m_Palette[nPalIndex].rgbRed = (BYTE)nRed;
			m_Palette[nPalIndex].rgbGreen = (BYTE)nGreen;
			m_Palette[nPalIndex].rgbBlue = (BYTE)nBlue;
		}
		else
		{
			bSuccess = FALSE;
		}
	}
	if (!bSuccess)
	{
		// Tell the user that the palette file is of an invalid format
		// and that we're going to revert to the default GP2 palette.
		CString strAlert("");
		strAlert.Format(IDS_INSUFFICIENT_EXTERNAL_PALETTE, strFilename);
		AfxMessageBox(strAlert);

		// Revert to one of the standard palettes, even if we
		// maintain our internal palette type
		LoadStandardPalette(gp2Palette);

		return FALSE;
	}

	return TRUE;
}
// End of function 'LoadCustomPalette'


// Function:	GetTransparentColor()
// Overview:	Get the colour to use when displaying transparent areas
COLORREF CGP2Palette::GetTransparentColor()
{
	return RGB(m_Palette[GP2_TRANSPARENT_PALETTE_INDEX].rgbRed,
			   m_Palette[GP2_TRANSPARENT_PALETTE_INDEX].rgbGreen,
			   m_Palette[GP2_TRANSPARENT_PALETTE_INDEX].rgbBlue);
}
// End of function 'GetTransparentColor'

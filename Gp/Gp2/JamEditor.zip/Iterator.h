// Iterator.h: interface for the CIterator class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ITERATOR_H__970C9043_77B3_11D2_8689_00A0243862D7__INCLUDED_)
#define AFX_ITERATOR_H__970C9043_77B3_11D2_8689_00A0243862D7__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// Class:	CIterator [abstract]
// Base:	[none]
// Overview:
//    This class is a template base class for iteration operations


template <class Item>
class CIterator  
{
// Construction/destruction
public:
	CIterator() {};
	virtual ~CIterator() {};

// Iteration ops
public:
	virtual void FindFirst() = 0;
	virtual void FindNext() = 0;
	virtual BOOL IsDone() = 0;
	virtual Item GetCurrent() = 0;
};

#endif // !defined(AFX_ITERATOR_H__970C9043_77B3_11D2_8689_00A0243862D7__INCLUDED_)

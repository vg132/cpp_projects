// RedMistFilter.cpp - implementation of the CRedMistFilter class
//

#include "stdafx.h"
#include "resource.h"

#include "RedMistFilter.h"
#include "JamTextureFilterIDs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CRedMistFilter

// Constructor
CRedMistFilter::CRedMistFilter()
	: CTintedFilter(RED_MIST_FILTER, IDS_FILTER_NAME_RED_MIST)
{
	SetTintColor(RGB(199,51,59));	// light-ish red
	SetTintFactor(60);				// keep 60% of original colour between palettes
}

// Destructor
CRedMistFilter::~CRedMistFilter()
{
}


// Gp3MenuText.h: interface for the CGp3MenuText class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GP3MENUTEXT_H__D65D3E80_7F85_11D4_8FC7_0008C7636E27__INCLUDED_)
#define AFX_GP3MENUTEXT_H__D65D3E80_7F85_11D4_8FC7_0008C7636E27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CGp3MenuText  
{
public:
	void SetLanguageDiff(int diff);
	int GetTextSize();
	bool SetTrackCountry(CString NewString, int TrackNr);
	bool SetTrackAdjective(CString NewString, int TrackNr);
	bool SetTrackName(CString NewString, int TrackNr);
	CString GetTrackCountry(int TrackNr);
	CString GetTrackAdjective(int TrackNr);
	CString GetTrackName(int TrackNr);
	bool SaveText(CString sFile);
	bool LoadText(CString sFile);
	CGp3MenuText();
	virtual ~CGp3MenuText();

private:
	CStringArray sText;
	int LDiff;
};

#endif // !defined(AFX_GP3MENUTEXT_H__D65D3E80_7F85_11D4_8FC7_0008C7636E27__INCLUDED_)

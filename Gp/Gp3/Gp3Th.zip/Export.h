#if !defined(AFX_EXPORT_H__3E7DC980_82A6_11D4_8FC7_0008C7636E27__INCLUDED_)
#define AFX_EXPORT_H__3E7DC980_82A6_11D4_8FC7_0008C7636E27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Export.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CExport dialog

class CExport : public CDialog
{
// Construction
public:
	CExport(CWnd* pParent = NULL);   // standard constructor
	CString m_TempFile;
	CString m_Gp3Path;
	CString m_StrFile;
	int m_Checked[16];
// Dialog Data
	//{{AFX_DATA(CExport)
	enum { IDD = IDD_EXPORT };
	BOOL	m_Gp3Edit;
	BOOL	m_Lap;
	BOOL	m_LapTimes;
	BOOL	m_Len;
	BOOL	m_MenuPic;
	BOOL	m_Misc;
	BOOL	m_Name;
	BOOL	m_Points;
	BOOL	m_QualSetup;
	BOOL	m_RaceSetup;
	BOOL	m_Track;
	BOOL	m_Track1;
	BOOL	m_Track11;
	BOOL	m_Track10;
	BOOL	m_Track12;
	BOOL	m_Track13;
	BOOL	m_Track14;
	BOOL	m_Track15;
	BOOL	m_Track16;
	BOOL	m_Track2;
	BOOL	m_Track3;
	BOOL	m_Track4;
	BOOL	m_Track5;
	BOOL	m_Track6;
	BOOL	m_Track7;
	BOOL	m_Track8;
	BOOL	m_Track9;
	BOOL	m_Ware;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CExport)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CExport)
	afx_msg void OnTrack1();
	afx_msg void OnTrack2();
	afx_msg void OnTrack();
	afx_msg void OnTrack10();
	afx_msg void OnTrack11();
	afx_msg void OnTrack12();
	afx_msg void OnTrack13();
	afx_msg void OnTrack14();
	afx_msg void OnTrack15();
	afx_msg void OnTrack16();
	afx_msg void OnTrack3();
	afx_msg void OnTrack4();
	afx_msg void OnTrack5();
	afx_msg void OnTrack6();
	afx_msg void OnTrack7();
	afx_msg void OnTrack8();
	afx_msg void OnTrack9();
	afx_msg void OnWare();
	afx_msg void OnRacesetup();
	afx_msg void OnQualsetup();
	afx_msg void OnPoints();
	afx_msg void OnName();
	afx_msg void OnMisc();
	afx_msg void OnMenupic();
	afx_msg void OnLen();
	afx_msg void OnLaptimes();
	afx_msg void OnLap();
	afx_msg void OnGp3edit();
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EXPORT_H__3E7DC980_82A6_11D4_8FC7_0008C7636E27__INCLUDED_)

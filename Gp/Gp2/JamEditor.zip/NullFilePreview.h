// NullFilePreview.h - header file for the CNullFilePreview class
//

#ifndef __NULL_FILE_PREVIEW_H__
#define __NULL_FILE_PREVIEW_H__

#include "FilePreview.h"

/////////////////////////////////////////////////////////////////
// Class:	CNullFilePreview
// Base:	CFilePreview (abstract)
// Created:	28 March 1999 by Mal Ross
// Overview:
//    A class used to display an empty preview in a preview
//  file dialog.  This type of preview is to be used when no
//  suitable preview is available for the type of the selected
//  file.  It is the only CFilePreview-derived class that the
//  CFilePreviewManager class knows about.
//

class CNullFilePreview : public CFilePreview
{
	DECLARE_DYNAMIC(CNullFilePreview)

// Construction/destruction
public:
	CNullFilePreview();
	virtual ~CNullFilePreview();

	// Function for creating a new instance of the derived class.
	// This function is provided to assist in storage of the
	// class in a Prototype manager (see the Design Patterns
	// book).
	virtual CFilePreview* CreateNewPreview() const;

// Operations
public:
	// File-type checking - overridden to support all file types
	virtual BOOL IsSupportedFile (const CString& strFilename) const;
	virtual BOOL IsSupportedFileType (const CString& strExtension) const;
	virtual void GetSupportedFileTypes (CStringList& lstFileTypes) const;

	// Draw the preview in the given DC
	virtual BOOL DrawPreview(CDC* pDC, const CRect& rctDraw) const;

// Implementation
protected:
	// Loading the file.  Derived classes must override this as
	// they're the only ones who know the format of the file.
	virtual BOOL LoadFile (const CString& strFilename);
};

/////////////////////////////////////////////////////////////////

#endif	// ~__NULL_FILE_PREVIEW_H__


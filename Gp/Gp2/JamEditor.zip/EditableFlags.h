// EditableFlags.h - contains template class CEditableFlags

#ifndef __EDITABLE_FLAGS_H__
#define __EDITABLE_FLAGS_H__

#include "EditableNumber.h"
#include "TreeIconDefs.h"
#include "FlagsDialog.h"

//////////////////////////////////////////////////////////////////
// Class:	CEditableFlags
// Base:	CEditableNumber
// Overview:
//    A simple extension of a CEditableNumber, allowing us to
//  display a more meaningful dialog than the simple Data Editor
//  for values that represent a number of different flags.
//

template <class NUMTYPE>
class CEditableFlags : public CEditableNumber<NUMTYPE>
{
// Construction/Destruction
public:
	CEditableFlags(NUMTYPE* pFlags, const CString& strName, const int nFirstFlagNameID, CEditableObject* pParent)
		: CEditableNumber<NUMTYPE>(pFlags, TRUE, strName, pParent, JTI_TEXTURE_FLAGS)
	{
		m_nFirstFlagNameID = nFirstFlagNameID;
	}

	virtual ~CEditableFlags()
	{
	}

// Data members
private:
	int m_nFirstFlagNameID;

// Overrides
public:
	// Handle a double-click to display a flag-based dialog
	virtual BOOL HandleDblClk();
};



// Handle double-clicking interaction in the tree.  Return TRUE to
// indicate that the value of this object has been changed, or FALSE
// if not.
template <class NUMTYPE>
BOOL CEditableFlags<NUMTYPE>::HandleDblClk()
{
	// Check to see whether we can actually double-click edit
	if (!CanEdit())
		return FALSE;

	// By default, edit the value as a string
	CFlagsDialog<NUMTYPE> dlg;
	dlg.m_nFlags = GetNumber();	// set the initial value
	dlg.m_nFirstFlagNameID = m_nFirstFlagNameID;	// set the flag names
	BOOL bChanged = FALSE;
	if (IDOK == dlg.DoModal())
	{
		// deal with accepting the changes
		SetNumber(dlg.m_nFlags);
		DataHasChanged(NULL, HINT_TEXTURE_PROPERTIES_CHANGED, NULL); 

		bChanged = TRUE;
	}

	return bChanged;
}

//////////////////////////////////////////////////////////////////

#endif	// ~__EDITABLE_FLAGS_H__
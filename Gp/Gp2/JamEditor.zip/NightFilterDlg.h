// NightFilterDlg.h : header file
//

#ifndef __NIGHT_FILTER_DLG_H__
#define __NIGHT_FILTER_DLG_H__

/////////////////////////////////////////////////////////////////////////////
// CNightFilterDlg dialog

class CNightFilterDlg : public CDialog
{
// Construction
public:
	CNightFilterDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CNightFilterDlg)
	enum { IDD = IDD_NIGHT_FILTER };
	CSliderCtrl	m_sdrTimeSlider;
	CString	m_strCurrentTime;
	//}}AFX_DATA

	// Get/set the time index
	BOOL SetTimeIndex(const int nTimeIndex);
	int GetTimeIndex() const;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNightFilterDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// The value representing the number of quarter-hours
	// past 7pm that the Night Filter simulates
	int m_nTimeIndex;

	void UpdateCurrentTimeText();

	// Generated message map functions
	//{{AFX_MSG(CNightFilterDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

#endif	// ~__NIGHT_FILTER_DLG_H__

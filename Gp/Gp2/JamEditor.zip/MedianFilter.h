// MedianFilter.h - header file for the CMedianFilter class
//

#ifndef __MEDIAN_FILTER_H__
#define __MEDIAN_FILTER_H__

#include "NeighbourFilter.h"

#include "TexturePalette.h"

///////////////////////////////////////////////////////////////////
// Class:	CMedianFilter
// Base:	CNeighbourFilter (abstract)
// Created:	06Feb99 by Mal Ross
// Overview:
//    This filter performs a median cut on the pixels within a
//  given neighbourhood of each pixel in the pre-filtered iamge.
//

class CMedianFilter : public CNeighbourFilter
{
// Construction and destruction
public:
	CMedianFilter();
	virtual ~CMedianFilter();

// Data members
protected:
	// Different methods of obtaining the median value
	enum eMedianMethod
	{
		MEDIAN_PALETTE_INDEX,				// poor results as palette is not ordered
		MEDIAN_RGB_THEN_NEAREST_COLOR,		// not really a median, as it can return value not in neighbourhood
		MEDIAN_RGB_THEN_NEAREST_NEIGHBOUR	// true median, but perhaps no better looking than above method
	};
	eMedianMethod m_nMedianMethod;

// Implementation
protected:
	// Median-filtering functions
	virtual BYTE FilterNeighbourhood(BYTE* pbNeighbourArray, int nNumNeighbours);
	BYTE GetMedian(BYTE* pbMedianArray, int nNumValues);
};



// Function:	GetMedian(pbMedianArray, nNumValues)
// Overview:	Find the median value in the given array of values
//				and return its value (not its index)
inline BYTE CMedianFilter::GetMedian(BYTE* pbMedianArray, int nNumValues)
{
	// Quicksort the values in the array, then take the middle value
	int i = 0, j = 0;
	BYTE t = 0, v = 0;
	int nMedianIndex = nNumValues / 2; // the eventual index of the median value
	int nLeft = 0;
	int nRight = nNumValues-1;
	while (nRight>nLeft)
	{
		v = pbMedianArray[nRight];
		i = nLeft-1;
		j = nRight;
		do
		{
			do i++; while (pbMedianArray[i] < v);
			do j--; while (pbMedianArray[j] > v);
			t = pbMedianArray[i];
			pbMedianArray[i] = pbMedianArray[j];
			pbMedianArray[j] = t;
		}
		while (j > i);
		pbMedianArray[j] = pbMedianArray[i];
		pbMedianArray[i] = pbMedianArray[nRight];
		pbMedianArray[nRight] = t;
		if (i >= nMedianIndex) nRight = i-1;
		if (i <= nMedianIndex) nLeft = i+1;
	}

	// Return the median value
	return pbMedianArray[nMedianIndex];
}
// End of function 'GetMedian'


/////////////////////////////////////////////////////////////////////

#endif	// ~__MEDIAN_FILTER_H__

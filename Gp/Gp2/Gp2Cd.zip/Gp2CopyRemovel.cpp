// Gp2CopyRemovel.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "fstream.h"

void Gp2NoCd(void);
void Gp2Cd(void);
void Status();
void Help();
void WriteToFile(unsigned char, int, int);

unsigned char ch;
ofstream fout;

int main(int argc, char* argv[])
{
	if(argc!=1)
	{
		if(*argv[1]=='d'||*argv[1]=='D')
			Gp2NoCd();
		if(*argv[1]=='e'||*argv[1]=='E')
			Gp2Cd();
		if(*argv[1]=='?')
			Help();
		if(*argv[1]=='s'||*argv[1]=='S')
			Status();
	}
	else
	{
		Help();
	}
	return(0);
}

void Gp2NoCd()
{
	fout.open("gp2.exe",ios::in|ios::out);

	WriteToFile(144,995927,1);

	WriteToFile(144,997166,3);

	WriteToFile(144,997170,6);

	WriteToFile(144,997188,1);

	WriteToFile(144,997412,1);

	WriteToFile(144,997446,1);

	WriteToFile(235,997452,0);

	WriteToFile(144,1097778,4);

	WriteToFile(144,1097843,4);

	WriteToFile(144,1098112,1);

	WriteToFile(144,1108715,1);
	
	
	fout.close();
	Status();
}

void Gp2Cd()
{
	fout.open("gp2.exe",ios::in|ios::out);

	WriteToFile(116,995927,0);
	WriteToFile(5,995928,0);

	WriteToFile(232,997166,0);
	WriteToFile(159,997167,0);
	WriteToFile(135,997168,0);
	WriteToFile(1,997169,0);

	WriteToFile(0,997170,0);
	WriteToFile(15,997171,0);
	WriteToFile(130,997172,0);
	WriteToFile(185,997173,0);
	WriteToFile(0,997174,2);

	WriteToFile(114,997188,0);
	WriteToFile(11,997189,0);

	WriteToFile(116,997412,0);
	WriteToFile(40,997413,0);

	WriteToFile(117,997446,0);
	WriteToFile(6,997447,0);

	WriteToFile(117,997452,0);

	WriteToFile(232,1097778,0);
	WriteToFile(155,1097779,0);
	WriteToFile(254,1097780,0);
	WriteToFile(255,1097781,1);

	WriteToFile(232,1097843,0);
	WriteToFile(74,1097844,0);
	WriteToFile(0,1097845,2);

	WriteToFile(117,1098112,0);
	WriteToFile(11,1098113,0);

	WriteToFile(117,1108715,0);
	WriteToFile(157,1108716,0);

	fout.close();
	Status();
}

void Status()
{
ifstream fin;
	fin.open("gp2.exe",ios::in|ios::binary);
	fin.seekg(1098113,ios::beg);
	fin.read((char*)&ch,sizeof(ch));
	if(ch==11)
		cout << "\nGp2 Cd-Check system Enabled\n";
	else
		cout << "\nGp2 Cd-Check system Disabled\n";
}

void Help()
{
	cout <<"\nGp2Cd v1.0\n";
	cout <<"(C) 2000 by NOE - made on request by Teemu Puumala <hakkisfani84@hotmail.com>\n";
	cout <<"Type Gp2Cd <parameter>\n";
	cout <<"<s>tatus of Gp2.exe\n";
	cout <<"<e>nable Gp2 Cd-Check system (restore gp2.exe)\n";
	cout <<"<d>isable Gp2 Cd-Check system\n";
	cout <<"<?> show this help text\n";
	Status();
}

void WriteToFile(unsigned char c, int pos, int nr)
{
	fout.seekp(pos,ios::beg);
	for(int i=0;i<nr+1;i++)
		fout.write((char*)&c,sizeof(c));
}
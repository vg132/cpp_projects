// ColorFunctions.cpp : implementation of the jam colour related functions
//

#include "stdafx.h"

#include "ColorFunctions.h"

#include <math.h>
#include "TexturePalette.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////

const double dMaxDifference = sqrt(3 * (pow(255.0f, 2.0f)));

// A function to determine the closeness of two colours.  The return
// value is between 0 (opposite colours) and 1 (identical colours).
double GetColorMatchFactor(RGBQUAD quadFirst, RGBQUAD quadSecond)
{
	// Just do a quick check for identical colours
	if (quadFirst.rgbRed == quadSecond.rgbRed &&
		quadFirst.rgbGreen == quadSecond.rgbGreen &&
		quadFirst.rgbBlue == quadSecond.rgbBlue)
	{
		// return the value to say that the colours are identical
		return 1.0f;
	}
	else
	{
		// Actually work out how close the colours are
		return 1.0f - (sqrt(pow(quadFirst.rgbRed - quadSecond.rgbRed, 2.0f) +
							pow(quadFirst.rgbGreen - quadSecond.rgbGreen, 2.0f) +
							pow(quadFirst.rgbBlue - quadSecond.rgbBlue, 2.0f)) / dMaxDifference);
	}
}
// End of function 'GetColorMatchFactor'

// A function to find the palette index of the jam colour that's
// the closest match to the given colour
BYTE GetNearestColorIndex(RGBQUAD quadColor)
{
	// Check through all colours in the palette for the closest match
	// to the one we've been given.
	int nNearIndex = 0;
	double dNearest = -1.0f;
	double dMatchFactor = dNearest;
	for (int nPalIndex = 0; nPalIndex < GP2_PALETTE_SIZE; nPalIndex++)
	{
		dMatchFactor = GetColorMatchFactor(quadColor, g_jamPalette[nPalIndex]);
		if (dMatchFactor > dNearest)
		{
			dNearest = dMatchFactor;
			nNearIndex = nPalIndex;
		}
	}

	return (BYTE)nNearIndex;
}
// End of function 'GetNearestColorIndex'


// Store any match factors we calculate between GP2 colours in
// a matrix for efficiency
static double ppdMatchMatrix[GP2_PALETTE_SIZE][GP2_PALETTE_SIZE];
static BOOL bInitialisedMatrix = FALSE;
#define UNDEFINED_MATCH_FACTOR	-1.0f

// A function to determine the closeness of two colours *from the
// ones in the GP2 palette*.  The return value is between 0
// (opposite colours) and 1 (identical colours).
double GetColorMatchFactor(int idxFirst, int idxSecond)
{
	// Initialise the match matrix if it hasn't been done already
	if (!bInitialisedMatrix)
	{
		// Initialise all values
		for (int nFirstColor = 0; nFirstColor < GP2_PALETTE_SIZE; nFirstColor++)
			for (int nSecondColor = 0; nSecondColor < GP2_PALETTE_SIZE; nSecondColor++)
				ppdMatchMatrix[nFirstColor][nSecondColor] = UNDEFINED_MATCH_FACTOR;
		bInitialisedMatrix = TRUE;
	}

	// If the match factor between these colours has not yet
	// been calculated, do it now.
	if (ppdMatchMatrix[idxFirst][idxSecond] == UNDEFINED_MATCH_FACTOR)
	{
		// Calculate the match factor for these two colours
		double dMatchFactor = GetColorMatchFactor(g_jamPalette[idxFirst], g_jamPalette[idxSecond]);
		ppdMatchMatrix[idxFirst][idxSecond] = dMatchFactor;
		ppdMatchMatrix[idxSecond][idxFirst] = dMatchFactor;
	}

	// Return the match factor from the matrix
	return ppdMatchMatrix[idxFirst][idxSecond];
}
// End of function 'GetColorMatchFactor'

// A function to find the palette index of the jam colour that's
// the closest match to the given colour
BYTE GetNearestColorIndex(int nColorIndex)
{
	// Check through all colours in the palette for the closest match
	// to colour at the index we've been given.
	int nNearIndex = 0;
	double dNearest = -1.0f;
	double dMatchFactor = 0.0f;
	for (int nPalIndex = 0; nPalIndex < GP2_PALETTE_SIZE; nPalIndex++)
	{
		dMatchFactor = GetColorMatchFactor(nColorIndex, nPalIndex);
		if (dMatchFactor > dNearest)
		{
			dNearest = dMatchFactor;
			nNearIndex = nPalIndex;
		}
	}

	return (BYTE)nNearIndex;
}
// End of function 'GetNearestColorIndex'


// Function:	GetNearestNeighbourIndex(quadColor, pbNeighbourArray, nNumNeighbours)
// Overview:	Get the palette index of the pixel from pbNeighbourArray
//				that is the closest match to the given colour.
BYTE GetNearestNeighbourIndex(RGBQUAD quadColor, BYTE* pbNeighbourArray, int nNumNeighbours)
{
	// Check through all colours in the given array for the
	// closest match to the colour we've been given.
	int nNearIndex = 0;
	double dNearest = -1.0f;
	double dMatchFactor = 0.0f;
	for (int nNeighbourIndex = 0; nNeighbourIndex < nNumNeighbours; nNeighbourIndex++)
	{
		dMatchFactor = GetColorMatchFactor(quadColor, g_jamPalette[pbNeighbourArray[nNeighbourIndex]]);
		if (dMatchFactor > dNearest)
		{
			dNearest = dMatchFactor;
			nNearIndex = nNeighbourIndex;
		}
	}

	return pbNeighbourArray[nNearIndex];
}
// End of function 'GetNearestNeighbourIndex'


// NightFilter.cpp - implementation of the CNightFilter class
//

#include "stdafx.h"
#include "resource.h"

#include "NightFilter.h"

#include "Color.h"
#include "JamTextureFilterIDs.h"
#include "NightFilterDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CNightFilter

// Constructor
CNightFilter::CNightFilter()
	: CLocalFilter(NIGHT_FILTER, IDS_FILTER_NAME_NIGHTDRIVING)
{
	// This will set both m_nTimeIndex and m_fLightSavingFactor
	SetTimeIndex(DEFAULT_TIME_INDEX);
}

// Destructor
CNightFilter::~CNightFilter()
{
}


// Overridden filtering functions
//

// Function:	FilterColor(color&)
// Overview:	Just reduce the luminance of the given colour by
//				the factor in m_fLightSavingFactor
void CNightFilter::FilterColor(CColor& color)
{
	// Get, reduce, and set the luminance.
	float fLuminance = color.GetLuminance();
	fLuminance *= GetLightSavingFactor();
	color.SetLuminance(fLuminance);
}
// End of function 'FilterColor'


// Overridden configuration functions
//

// Function:	Configure()
// Overview:	Show a dialog box allowing the user to configure
//				this filter.
void CNightFilter::Configure()
{
	// Set up the options dialog with the current information
	CNightFilterDlg dlg;
	dlg.SetTimeIndex(GetTimeIndex());

	// Show the dialog
	if (IDOK == dlg.DoModal())
	{
		// Get the new options from the dialog
		SetTimeIndex(dlg.GetTimeIndex());
	}
}
// End of function 'Configure'


// Function:	GetTimeIndex()
// Overview:	Get the integer value representing the number of
//				quarter-hours past 7pm that this filter simulates.
int CNightFilter::GetTimeIndex() const
{
	return m_nTimeIndex;
}
// End of function 'GetTimeIndex'


#define MIN_USABLE_LIGHT_SAVING_FACTOR		0.45f
#define MAX_USABLE_LIGHT_SAVING_FACTOR		0.95f

// Function:	SetTimeIndex()
// Overview:	Set the integer value representing the number of
//				quarter-hours past 7pm that this filter simulates.
BOOL CNightFilter::SetTimeIndex(const int nTimeIndex)
{
	// Just a quick dumb-programmer test first to catch
	// a potential divide-by-zero.
	ASSERT(MAX_TIME_INDEX != MIN_TIME_INDEX);
	ASSERT(MAX_USABLE_LIGHT_SAVING_FACTOR != MIN_USABLE_LIGHT_SAVING_FACTOR);

	// Make sure the new value's in the valid range
	if (nTimeIndex < MIN_TIME_INDEX ||
		nTimeIndex > MAX_TIME_INDEX)
		return FALSE;

	// If we're not actually changing the value, just skip
	// out now (it allows us to keep the colour mappings
	// already cached in CLocalFilter)
	if (nTimeIndex == m_nTimeIndex)
		return TRUE;

	// Store the new time index and clear out the old
	// colour mappings
	m_nTimeIndex = nTimeIndex;
	InitialiseMappings();

	// Convert the value the user chose between MIN_TIME_INDEX
	// and MAX_TIME_INDEX to a fraction (between 0 and 1) that
	// represents what percentage of the pixels' luminance should
	// be preserved during each application of the filter.
	float fInterimFactor = float(nTimeIndex - MIN_TIME_INDEX) /
						   float(MAX_TIME_INDEX - MIN_TIME_INDEX);
	fInterimFactor = 1.0f - fInterimFactor;	// higher time index <=> lower light preservation
	m_fLightSavingFactor = MIN_USABLE_LIGHT_SAVING_FACTOR +
		(fInterimFactor * (MAX_USABLE_LIGHT_SAVING_FACTOR - MIN_USABLE_LIGHT_SAVING_FACTOR));

	return TRUE;
}
// End of function 'SetTimeIndex'

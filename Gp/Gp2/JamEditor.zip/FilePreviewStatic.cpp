// FilePreviewStatic.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "FilePreviewStatic.h"

#include "FilePreview.h"
#include "FilePreviewManager.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFilePreviewStatic

CFilePreviewStatic::CFilePreviewStatic()
{
	// Default to having no preview
	m_pPreview = NULL;
}

CFilePreviewStatic::~CFilePreviewStatic()
{
	if (NULL != m_pPreview)
	{
		delete m_pPreview;
		m_pPreview = NULL;
	}
}


BEGIN_MESSAGE_MAP(CFilePreviewStatic, CStatic)
	//{{AFX_MSG_MAP(CFilePreviewStatic)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CFilePreviewStatic operations

// Setting a new file to preview
void CFilePreviewStatic::SetFilename (const CString& strFilename)
{
	// Check the filename to see whether it has actually changed
	if (NULL != m_pPreview)
	{
		if (strFilename.CompareNoCase(m_pPreview->GetFilename()) == 0)
			return;	// it is the same file, so no update needed
	}

	// *Don't* try to be clever by checking to see whether we
	// can continue to use the current previewer - it may be the
	// null previewer (CNullFilePreview) and so would accept 
	// anything.  Instead, we must get rid of the current preview
	// and make a new one.
	if (NULL != m_pPreview)
	{
		delete m_pPreview;
		m_pPreview = NULL;
	}

	// Create a new previewer for the new file.
	m_pPreview = CreatePreviewForFilename(strFilename);
	ASSERT(NULL != m_pPreview);	// running out of memory?
	if (NULL != m_pPreview)
		m_pPreview->SetFilename(strFilename);

	// NOTE: Relevant previews should be defined on an app-to-app
	// basis.  Therefore, you should create the preview types in
	// your app's InitInstance, adding them to the manager so that
	// they can be replicated for display in this window.  However,
	// the manager is a Singleton (see book on Design Patterns), so
	// don't forget to delete it in your ExitInstance.
}

// Overrideable function to create a new preview type
// suitable for the given filename
CFilePreview* CFilePreviewStatic::CreatePreviewForFilename(const CString& strFilename)
{
	// Create a new previewer for the new file.  Or, rather,
	// get one from the preview manager.  Even if the filetype
	// isn't supported for previewing, we should at least
	// receive a null previewer from the manager.
	CFilePreviewManager* pManager = CFilePreviewManager::GetManager();
	ASSERT(NULL != pManager);
	if (NULL == pManager)
		return NULL;
	return pManager->CreateFilePreview(strFilename);
}



/////////////////////////////////////////////////////////////////////////////
// CFilePreviewStatic message handlers

void CFilePreviewStatic::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// If there's a preview for the current file, draw it now
	if (NULL != m_pPreview)
	{
		// Find out where to draw
		CRect rctClient;
		GetClientRect(rctClient);

		// Ask the preview to draw itself
		m_pPreview->DrawPreview(&dc, rctClient);
	}
}

// Jam Editor.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "JamEditor.h"

#include "MainFrame.h"
#include "JamEditorDoc.h"
#include "JamEditorDocManager.h"
#include "JamFrame.h"
#include "JamView.h"

#include "HyperLink.h"

#include "Splash.h"

#include "GP2Bitmap.h"

#include "MRUPathList.h"
#include "JamEditorMRUPaths.h"
#include "FilenameParser.h"

#include "FilePreviewManager.h"
#include "GP2BitmapPreview.h"
#include "JamFilePreview.h"
#include "JascPalettePreview.h"

#include "PaletteImageCombiner.h"
#include "JamTextureFilterManager.h"
#include "BlurFilter.h"
#include "MedianFilter.h"
#include "NullFilter.h"
#include "DullFilter.h"
#include "NightFilter.h"
#include "FogFilter.h"
#include "RedMistFilter.h"
#include "UnderwaterFilter.h"

#include "GeneralOptionsPage.h"
#include "AdvancedOptionsPage.h"

#include "TipDlg.h"
#include "JamTexture.h"
#include "Jam.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CJamEditorApp

BEGIN_MESSAGE_MAP(CJamEditorApp, CWinApp)
	//{{AFX_MSG_MAP(CJamEditorApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_HELP_TIPOFTHEDAY, OnTipOfTheDay)
	ON_COMMAND(ID_FILE_SAVE_ALL, OnFileSaveAll)
	ON_COMMAND(ID_FILE_SAVE_ALL_AS_JAM, OnFileSaveAllAsJAM)
	ON_COMMAND(ID_FILE_SAVE_ALL_AS_JAD, OnFileSaveAllAsJAD)
	ON_COMMAND(ID_VIEW_OPTIONS, OnViewOptions)
	ON_COMMAND(ID_EDIT_FIND_FLAGS, OnFindFlags)
	//}}AFX_MSG_MAP
	// Global palette options
	ON_COMMAND_RANGE(ID_GLOBALPAL_GP2, ID_GLOBALPAL_CUSTOM, OnSelectGlobalPalette)
	ON_UPDATE_COMMAND_UI_RANGE(ID_GLOBALPAL_GP2, ID_GLOBALPAL_CUSTOM, OnUpdateSelectGlobalPalette)
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
	// Standard Help menu commands
	ON_COMMAND(ID_HELP_FINDER, CWinApp::OnHelpFinder)
	ON_COMMAND(ID_HELP_USING, CWinApp::OnHelpUsing)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CJamEditorApp construction

CJamEditorApp::CJamEditorApp() : m_nMRULength(_AFX_MRU_COUNT)
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CJamEditorApp object

CJamEditorApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CJamEditorApp initialization

BOOL CJamEditorApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Set all opening/saving paths to the application's
	// path by default
	TCHAR path[_MAX_PATH];
	GetModuleFileName(NULL, path, sizeof(path));
	CFilenameParser parsedAppModule(path);
	CMRUPathList* pMRUPaths = CMRUPathList::GetPathList();
	pMRUPaths->SetMRUPath(szOpenJamPath, parsedAppModule.DriveAndPath(TRUE));
	pMRUPaths->SetMRUPath(szSaveJamPath, parsedAppModule.DriveAndPath(TRUE));
	pMRUPaths->SetMRUPath(szImportCanvasPath, parsedAppModule.DriveAndPath(TRUE));
	pMRUPaths->SetMRUPath(szExportCanvasPath, parsedAppModule.DriveAndPath(TRUE));
	pMRUPaths->SetMRUPath(szImportTexturePath, parsedAppModule.DriveAndPath(TRUE));
	pMRUPaths->SetMRUPath(szExportTexturePath, parsedAppModule.DriveAndPath(TRUE));

	// Now load in the program settings including any load/save paths
	LoadProfileSettings();

	// Check to see that the current setup uses at least 16-bit
	// colour.  If not, the user will be warned about images not
	// displaying correctly.
	CheckColourCapability();

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Display the splash screen if appropriate
	CSplashWnd::EnableSplashScreen(cmdInfo.m_bShowSplash);

	// Create a custom document manager as we need to override
	// CDocManager::DoPromptFileName to make sure that even when
	// saving, both JAM and JAD filename extensions are offered.
	ASSERT(m_pDocManager == NULL);
	m_pDocManager = new CJamEditorDocManager;

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CMultiDocTemplate* pDocTemplate;
	// Create the JAM (encrypted) document type
	pDocTemplate = new CMultiDocTemplate(
		IDR_JAMTYPE,
		RUNTIME_CLASS(CJamEditorDoc),
		RUNTIME_CLASS(CJamFrame), // custom MDI child frame
		RUNTIME_CLASS(CJamView));
	AddDocTemplate(pDocTemplate);

	// Create the JAD (decrypted) document type
	pDocTemplate = new CMultiDocTemplate(
		IDR_JADTYPE,
		RUNTIME_CLASS(CJamEditorDoc),
		RUNTIME_CLASS(CJamFrame), // custom MDI child frame
		RUNTIME_CLASS(CJamView));
	AddDocTemplate(pDocTemplate);

	// Create the JIP (scaled) document type
	pDocTemplate = new CMultiDocTemplate(
		IDR_JIPTYPE,
		RUNTIME_CLASS(CJamEditorDoc),
		RUNTIME_CLASS(CJamFrame), // custom MDI child frame
		RUNTIME_CLASS(CJamView));
	AddDocTemplate(pDocTemplate);

	// Add the file preview types
	CFilePreviewManager* pPreviewMgr = CFilePreviewManager::GetManager();
	if (NULL != pPreviewMgr)
	{
		// Support BMP and JAM/JAD previews
		pPreviewMgr->AddFilePreview(new CGP2BitmapPreview);
		pPreviewMgr->AddFilePreview(new CJamFilePreview);
		pPreviewMgr->AddFilePreview(new CJascPalettePreview);
	}

	// Add the import filter types
	CJamTextureFilterManager* pFilterMgr = CJamTextureFilterManager::GetManager();
	if (NULL != pFilterMgr)
	{
		pFilterMgr->AddFilter(new CNullFilter);
		pFilterMgr->AddFilter(new CMedianFilter);
		pFilterMgr->AddFilter(new CBlurFilter);
		pFilterMgr->AddFilter(new CFogFilter);
		pFilterMgr->AddFilter(new CNightFilter);
		pFilterMgr->AddFilter(new CDullFilter);
#ifdef _DEBUG
		pFilterMgr->AddFilter(new CUnderwaterFilter);
#endif
		pFilterMgr->AddFilter(new CRedMistFilter);
	}

	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;

	// Enable drag/drop open
	m_pMainWnd->DragAcceptFiles();

	// Enable DDE Execute open
	EnableShellOpen();
	RegisterShellFileTypes(TRUE);

	// Prevent the 'new' window appearing upon default startup
	if (cmdInfo.m_nShellCommand == CCommandLineInfo::FileNew)
		cmdInfo.m_nShellCommand = CCommandLineInfo::FileNothing;

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The main window has been initialized, so show and update it.
	pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->UpdateWindow();
	pMainFrame->RecalcLayout();

	// Possibly show the Tip of the Day
	ShowTipAtStartup();

	return TRUE;
}

// Overridden application-exiting function to destroy any Singleton classes
int CJamEditorApp::ExitInstance() 
{
	// Save any extra profile settings.
	SaveProfileSettings();

	// Destroy any Singleton classes (see the design pattern for
	// more information)
	CMRUPathList::DestroyPathList();
	CFilePreviewManager::DestroyManager();
	CJamTextureFilterManager::DestroyManager();

	// Do the base class stuff
	return CWinApp::ExitInstance();
}


const TCHAR _afxFileSection[] = _T("Recent File List");
const TCHAR _afxFileEntry[] = _T("File%d");

// Function:	LoadProfileSettings()
// Overview:	Loading profile settings.  Why on earth doesn't
//				CWinApp have this function?!
void CJamEditorApp::LoadProfileSettings()
{
	// Load the value from the INI file that says how many files
	// are in the MRU list.
	m_nMRULength = GetProfileInt("Settings", "Recent file count", _AFX_MRU_COUNT);
	m_nMRULength = max(1, min(16, m_nMRULength));

	// Load standard INI file options (including MRU)
	LoadStdProfileSettings(m_nMRULength);

	// Now load the file open/save paths if they're in the INI
	CMRUPathList* pMRUPaths = CMRUPathList::GetPathList();
	pMRUPaths->LoadProfileSettings();

	// Load the flag to say whether or not transparent areas of
	// a texture should be protected from filtering.
	CJamTextureFilter::s_bProtectTransparency = (BOOL)GetProfileInt("Driving Conditions", "Protect Transparency", 1);

	// Load the spread factor to use when the Protect Transparency
	// option is turned off.
	CNeighbourFilter::SetSpreadFactor(GetProfileInt("Driving Conditions", "Texture Spread Factor", CNeighbourFilter::DEFAULT_SPREAD_FACTOR));

	// Load the flag to say whether the null filter should be allowed to create
	// textures with no local palettes
	int nPalPres = (int)GetProfileInt("Driving Conditions", "Palette Preservation", CNullFilter::MAINTAIN_PALETTE);
	nPalPres = max(CNullFilter::PALETTE_PRESERVATION_MIN, min(CNullFilter::PALETTE_PRESERVATION_MAX, nPalPres));
	CNullFilter::s_nPalettePreservation = (CNullFilter::ePalettePreservation)nPalPres;

	// Load the flag to say whether the program should attempt to
	// guess the transparency of a texture when imported from a
	// bitmap.
	CJamTexture::s_bGuessTransparency = (BOOL)GetProfileInt("Automatic Flagging", "Guess Transparency", 0);

	// Load the flag to say whether the program should attempt to
	// guess flags 9 & 10 (whose meanings aren't certain, but are
	// thought to relate to avoidance of pixellation).
	CJamTexture::s_bGuessNonStandardSizeFlags = (BOOL)GetProfileInt("Automatic Flagging", "Guess Non-standard Sizes", 1);

	// Load the flag to say whether the program should attempt to
	// guess flag 8, which is believed to indicate that the texture
	// has no local palettes
	CJamTexture::s_bGuessNoPalettes = (BOOL)GetProfileInt("Automatic Flagging", "Guess No Local Palettes", 1);

	// Load the flag to say whether we should automatically fix
	// any textures containing invalid raw pixel values
	CJam::s_bFixInvalidPixels = (BOOL)GetProfileInt("Sanity Checks", "AutoCorrect Invalid Pixels", 0);

	// Load the colours used to outline textures
	CColor clrConverter;
	// Selected textures
	clrConverter.SetString(GetProfileString("Display settings", "Selected colour", "FF0000"));
	CJamTexture::s_clrSelected = (COLORREF)clrConverter;
	// Non-selected textures
	clrConverter.SetString(GetProfileString("Display settings", "Not Selected colour", "FFFF00"));
	CJamTexture::s_clrNotSelected = (COLORREF)clrConverter;
	// Textures containing invalid pixels
	clrConverter.SetString(GetProfileString("Display settings", "Invalid Pixels colour", "00FFFF"));
	CJamTexture::s_clrInvalidPixels = (COLORREF)clrConverter;

	// Load the flag that says whether or not we should be displaying textures
	// differently if they contain invalid pixels.
	CJamTexture::s_bShowInvalidPixels = (BOOL)GetProfileInt("Display settings", "Show Invalid Pixels", 0);

	// Load the type of palette we're using and the filename from which we
	// should be taking our palette information when using a custom palette.
	int nPalType = (int)GetProfileInt("Display settings", "Palette type", CGP2Palette::PALTYPE_GP2);
	CString strPaletteFilename = GetProfileString("Display settings", "Palette file", "");
	g_jamPalette.SetPaletteType(nPalType, strPaletteFilename);

	// Load the flag to say whether or not we should whinge about invalid
	// colours in the palettes of bitmaps the user imports.
	CGP2Bitmap::s_bIgnoreInvalidPalettes = (BOOL)GetProfileInt("Sanity Checks", "Ignore Invalid Palettes", 1);
}
// End of function 'LoadProfileSettings'


// Function:	SaveProfileSettings()
// Overview:	Saving profile settings.  Why on earth doesn't
//				CWinApp have this function?!
void CJamEditorApp::SaveProfileSettings()
{
	// For some reason beyond my understanding, Microsoft saw fit to
	// save the standard profile settings in CWinApp::ExitInstance,
	// but they don't load them in InitInstance.  Anyway, this means
	// I don't have to save them here, so we'll just save JE settings.

	// Save the number of files allowed in the MRU
	WriteProfileInt("Settings", "Recent file count", (int)m_nMRULength);

	// Save the file open/save paths to the INI
	CMRUPathList* pMRUPaths = CMRUPathList::GetPathList();
	pMRUPaths->StoreProfileSettings();

	// Save the flag to say whether or not transparent areas of
	// a texture should be protected from filtering.
	WriteProfileInt("Driving Conditions", "Protect Transparency", (int)CJamTextureFilter::s_bProtectTransparency);

	// Save the spread factor to use when the Protect Transparency
	// option is turned off.
	WriteProfileInt("Driving Conditions", "Texture Spread Factor", CNeighbourFilter::GetSpreadFactor());

	// Save the flag to say whether the null filter should be allowed to create
	// textures with no local palettes
	WriteProfileInt("Driving Conditions", "Palette Preservation", (int)CNullFilter::s_nPalettePreservation);

	// Save the flag to say whether the program should attempt to
	// guess the transparency of a texture when imported from a
	// bitmap.
	WriteProfileInt("Automatic Flagging", "Guess Transparency", (int)CJamTexture::s_bGuessTransparency);

	// Save the flag to say whether the program should attempt to
	// guess flags 9 & 10 (whose meanings aren't certain, but are
	// thought to relate to avoidance of pixellation).
	WriteProfileInt("Automatic Flagging", "Guess Non-standard Sizes", (int)CJamTexture::s_bGuessNonStandardSizeFlags);

	// Save the flag to say whether the program should attempt to
	// guess flag 8, which is believed to indicate that the texture
	// has no local palettes
	WriteProfileInt("Automatic Flagging", "Guess No Local Palettes", (int)CJamTexture::s_bGuessNoPalettes);

	// Save the flag to say whether we should automatically fix
	// any textures containing invalid raw pixel values
	WriteProfileInt("Sanity Checks", "AutoCorrect Invalid Pixels", (int)CJam::s_bFixInvalidPixels);

	// Save the colours used to outline textures
	// Selected textures
	CColor clrSelected(CJamTexture::s_clrSelected);
	WriteProfileString("Display settings", "Selected colour", clrSelected.GetString());
	// Non-selected textures
	CColor clrNotSelected(CJamTexture::s_clrNotSelected);
	WriteProfileString("Display settings", "Not Selected colour", clrNotSelected.GetString());
	// Textures containing invalid pixels
	CColor clrInvalidPixels(CJamTexture::s_clrInvalidPixels);
	WriteProfileString("Display settings", "Invalid Pixels colour", clrInvalidPixels.GetString());

	// Save the flag that says whether or not we should be displaying textures
	// differently if they contain invalid pixels.
	WriteProfileInt("Display settings", "Show Invalid Pixels", (int)CJamTexture::s_bShowInvalidPixels);

	// Save the type of palette we're using and the filename from which we
	// should be taking our palette information when using a custom palette.
	WriteProfileInt("Display settings", "Palette type", (int)g_jamPalette.GetPaletteType());
	WriteProfileString("Display settings", "Palette file", g_jamPalette.GetCustomPalette());

	// Save the flag to say whether or not we should whinge about invalid
	// colours in the palettes of bitmaps the user imports.
	WriteProfileInt("Sanity Checks", "Ignore Invalid Palettes", (int)CGP2Bitmap::s_bIgnoreInvalidPalettes);
}
// End of function 'SaveProfileSettings'


// Function:	SetMRULength(nMaxMRU)
// Overview:	Set the length of MRU list to appear in the File menu.
//				Return TRUE upon success, or FALSE otherwise.
BOOL CJamEditorApp::SetMRULength(const int nMaxMRU)
{
	// This function should only ever be called after MFC
	// has had its chance to load the MRU list.
	ASSERT(NULL != m_pRecentFileList);
	if (NULL == m_pRecentFileList)
		return FALSE;

	// Make sure the length is within the maximum allowed
	// size (as determined by the menu resource IDs).
	ASSERT((nMaxMRU >= 1) && (nMaxMRU <= 16));
	if ((nMaxMRU < 1) || (nMaxMRU > 16))
		return FALSE;

	// To be able to change the length of the MRU, we have to
	// create a new MRU object, as the constructor's the only
	// place we can do it.  However, we must make sure we keep
	// a record of what we've got in there already, so we'd
	// best save it first
	m_pRecentFileList->WriteList();
	delete m_pRecentFileList;
	m_pRecentFileList = new CRecentFileList(0, _afxFileSection, _afxFileEntry, nMaxMRU);
	m_pRecentFileList->ReadList();
	m_nMRULength = nMaxMRU;

	return TRUE;
}
// End of function 'SetMRULength'


// Function:	CheckColourCapability()
// Overview:	Warn the user about a setup using too low
//				a colour depth
void CJamEditorApp::CheckColourCapability()
{
	// Get an appropriate DC from the desktop
	CWnd* pDesktopWnd = CWnd::GetDesktopWindow();
	ASSERT(NULL != pDesktopWnd);
	if (NULL == pDesktopWnd)
		return;
	CDC* pDC = pDesktopWnd->GetDC();
	ASSERT(NULL != pDC);
	if (NULL == pDC)
		return;

	// Check the number of colours being used and warn the
	// user about not being able to draw correctly if the
	// colour depth is less than 16-bit.
	int nBitsPerPixel = pDC->GetDeviceCaps(BITSPIXEL);
	if (nBitsPerPixel < 16)
		AfxMessageBox(IDS_MSG_COLOUR_DEPTH_WARNING, MB_ICONINFORMATION);

	// Release the DC of the desktop window
	pDesktopWnd->ReleaseDC(pDC);
}
// End of function 'CheckColourCapability'


// Function:	OnChangedGlobalPalette()
// Overview:	Get all of the views to update themselves in response to
//				a change in the global palette.
void CJamEditorApp::OnChangedGlobalPalette()
{
	// Tell all of the program's views about the change - we need
	// to cycle through all document templates and all documents
	// stored within them, telling each to update itself.
	POSITION posTemplate = GetFirstDocTemplatePosition();
	CDocTemplate* pTemplate = NULL;
	while (NULL != posTemplate)
	{
		// Get a pointer to the next document template
		pTemplate = GetNextDocTemplate(posTemplate);
		ASSERT(NULL != pTemplate);
		if (NULL == pTemplate)
			continue;

		// Loop through the documents held by this template,
		// asking each to save with the given extension.
		POSITION posDoc = pTemplate->GetFirstDocPosition();
		CJamEditorDoc* pDoc = NULL;
		while (NULL != posDoc)
		{
			// Get a pointer to the next document and tell it
			// about the change
			pDoc = (CJamEditorDoc *)pTemplate->GetNextDoc(posDoc);
			ASSERT(NULL != pDoc);
			if (NULL == pDoc)
				continue;
			pDoc->OnChangedGlobalPalette();
		}
	}
}
// End of function 'OnChangedGlobalPalette'



/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CHyperLink m_hypProjectURL;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_PROJECT_HYPERLINK, m_hypProjectURL);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// Use mouse-hover colouring for the hyperlink
	DWORD dwAdd = CHyperLink::StyleUseHover;
	m_hypProjectURL.ModifyLinkStyle(0L, dwAdd);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

// App command to run the dialog
void CJamEditorApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}


/////////////////////////////////////////////////////////////////////////////
// CJamEditorApp commands

BOOL CJamEditorApp::PreTranslateMessage(MSG* pMsg)
{
	// CG: The following lines were added by the Splash Screen component.
	if (CSplashWnd::PreTranslateAppMessage(pMsg))
		return TRUE;

	return CWinApp::PreTranslateMessage(pMsg);
}


/////////////////////////////////////////////////////////////////////////////
// CJamEditorApp Tip of the Day commands

void CJamEditorApp::ShowTipAtStartup()
{
	// Check the command line info to see whether we need to
	// display the Tip of the Day dialog at startup (don't
	// show it if we're not showing the splash screen, as
	// that's an indication that we've been fired up with a
	// file to show pronto)
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);
	if (cmdInfo.m_bShowSplash)
	{
		CTipDlg dlg;
		if (dlg.m_bStartup)
			dlg.DoModal();
	}
}

void CJamEditorApp::OnTipOfTheDay()
{
	// Just create and show the dialog.  It will handle everything
	// else itself.
	CTipDlg dlg;
	dlg.DoModal();
}


/////////////////////////////////////////////////////////////////////////////
// CJamEditorApp multiple file saving

void CJamEditorApp::OnFileSaveAll() 
{
	// Just save all files in their current form - CWinApp provides
	// a handy function for this
	SaveAllModified();
}

void CJamEditorApp::OnFileSaveAllAsJAM() 
{
	// Just call the SaveAllFilesAs function, defined below
	SaveAllFilesAs(".jam");
}

void CJamEditorApp::OnFileSaveAllAsJAD() 
{
	// Just call the SaveAllFilesAs function, defined below
	SaveAllFilesAs(".jad");
}

BOOL CJamEditorApp::SaveAllFilesAs(CString strExtension) 
{
	// Just check to see that the extension passed in is valid
	strExtension.MakeLower();
	if (strExtension != ".jam" && strExtension != ".jad")
		return FALSE;

	// Keep track of which files the user skips
	CStringList lstNotSaved;
	UINT nNumDocuments = 0;

	// We need to cycle through all document templates and
	// all documents stored within them, asking each to save
	// in the given form.
	POSITION posTemplate = GetFirstDocTemplatePosition();
	CDocTemplate* pTemplate = NULL;
	while (NULL != posTemplate)
	{
		// Get a pointer to the next document template
		pTemplate = GetNextDocTemplate(posTemplate);
		ASSERT(NULL != pTemplate);
		if (NULL == pTemplate)
			continue;

		// Loop through the documents held by this template,
		// asking each to save with the given extension.
		POSITION posDoc = pTemplate->GetFirstDocPosition();
		CDocument* pDoc = NULL;
		while (NULL != posDoc)
		{
			// Get a pointer to the next document
			pDoc = pTemplate->GetNextDoc(posDoc);
			ASSERT(NULL != pDoc);
			if (NULL == pDoc)
				continue;

			// Increment our count of the number of documents processed
			nNumDocuments++;

			// Check to see whether we need to change the filename
			// of the doc
			CFilenameParser fnCurrDoc(pDoc->GetPathName());
			if (!fnCurrDoc.IsOfType(strExtension))
			{
				// This document is going to require conversion,
				// so we'd best check that we're not going to
				// overwrite another file in the process...
				fnCurrDoc.Extension() = strExtension;
				if (fnCurrDoc.Exists())
				{
					// Check to see whether the existing file's read-only
					if ((GetFileAttributes(fnCurrDoc.GetFullSpec())
						& FILE_ATTRIBUTE_READONLY) == FILE_ATTRIBUTE_READONLY)
					{
						// Tell the user we can't overwrite the
						// existing read-only file
						CString strPrompt;
						strPrompt.Format(IDS_CANT_SAVE_AS_FORMAT_READONLY, fnCurrDoc.GetFullSpec());
						AfxMessageBox(strPrompt, MB_ICONEXCLAMATION);

						lstNotSaved.AddTail(pDoc->GetPathName());
						continue;
					}
					else
					{
						// Ask the user whether they want to overwrite
						// the existing file
						CString strPrompt;
						strPrompt.Format(IDS_CANT_SAVE_AS_FORMAT_OVERWRITE, fnCurrDoc.GetFullSpec());
						if (IDYES != AfxMessageBox(strPrompt, MB_YESNO | MB_ICONQUESTION | MB_DEFBUTTON2))
						{
							lstNotSaved.AddTail(pDoc->GetPathName());
							continue;
						}
					}
				}
			}

			// Ask the document to save with the new name
			pDoc->DoSave(fnCurrDoc.GetFullSpec(), TRUE);
		}
	}

	// All done!  Report success to the user
	if (lstNotSaved.GetCount() == 0)
	{
		// Report a complete success to the user
		CString strPrompt;
		strPrompt.Format(IDS_SAVE_ALL_AS_TOTALSUCCESS, strExtension);
		AfxMessageBox(strPrompt);
	}
	else if ((int)nNumDocuments == lstNotSaved.GetCount())
	{
		// What a total failure!
		CString strPrompt;
		strPrompt.Format(IDS_SAVE_ALL_AS_TOTALFAILURE, nNumDocuments);
		AfxMessageBox(strPrompt);

		// Empty the list
		lstNotSaved.RemoveAll();
	}
	else
	{
		// Report partial success to the user...

		// The report head includes the first file in the list of
		// files not saved.
		CString strPrompt;
		strPrompt.Format(IDS_SAVE_ALL_AS_PARTIALSUCCESS,
			nNumDocuments - lstNotSaved.GetCount(), nNumDocuments, strExtension, lstNotSaved.GetHead());

		// Now add the others to the end.
		POSITION posFilename = lstNotSaved.GetHeadPosition();
		lstNotSaved.GetNext(posFilename);
		while (NULL != posFilename)
		{
			CString strFileReport;
			strFileReport.Format("\n%s", lstNotSaved.GetNext(posFilename));
			strPrompt += strFileReport;
		}

		// At last we can tell the user about the problem
		AfxMessageBox(strPrompt);

		// Empty the list
		lstNotSaved.RemoveAll();
	}

	return TRUE;
}
// End of function 'SaveAllFilesAs'


// Function:	OnViewOptions()
// Overview:	Handler for the View -> Options... command, allowing the
//				user to set a number of application-level options in the
//				Options dialog.
void CJamEditorApp::OnViewOptions() 
{
	// Create the Options dialog as a property sheet and let it
	// do the rest.
	CPropertySheet dlg("Options");

	// Add the General page to the dialog
	CGeneralOptionsPage pgeGeneral;
	dlg.AddPage(&pgeGeneral);

	// Add the Advanced page to the dialog
	CAdvancedOptionsPage pgeAdvanced;
	dlg.AddPage(&pgeAdvanced);

	// Show the Options dialog
	dlg.DoModal();
}
// End of function 'OnViewOptions'


void CJamEditorApp::OnFindFlags() 
{
	AfxMessageBox("Sorry, this feature has not been coded yet.");
	return;

	// TODO: Show the user a dialog box in which they can
	// choose which flag(s) they're looking for.
/*	CTextureFlagsDlg dlgFind;
	if (IDOK != dlgFind.DoModal())
		return;
	WORD wFlagsToFind = dlgFind.m_wFlags;
	BOOL bFindAll = FALSE; // dlgFind.m_bFindAll;

	// Go through all of the document templates' lists
	// of documents, picking out the JAM or JAD documents
	CTypedPtrList<CObList, CJamEditorDoc*> lstDocuments;
	POSITION posTemplate = GetFirstDocTemplatePosition();
	while (NULL != posTemplate)
	{
		CDocTemplate* pTemplate = GetNextDocTemplate();
		POSITION posDocument = pTemplate->GetFirstDocPosition();
		while (NULL != posDocument)
		{
			CDocument* pDocument = pTemplate->GetNextDoc(posDocument);
			if (pDocument->IsKindOf(RUNTIME_CLASS(CJamEditorDoc)))
				lstDocuments.AddTail(pDocument);
		}
	}

	// Now loop through the documents, looking for ones
	// that contain textures with the given flags
	CTypedPtrList<CObList, CJamEditorDoc*> lstDocuments;
	POSITION posDoc = lstDocuments.GetHeadPosition();
	CFindFlagsSearchResult lstMatchingTextures;
	while (NULL != posDoc)
	{
		// Get the Jam from the next document
		CJamEditorDoc* pDoc = lstDocuments.GetNext(posDoc);
		if (NULL == pDoc)
			continue;
		CJam* pJam = pDoc->GetJam();
		if (NULL == pJam)
			continue;

		// Find the textures in this jam with the chosen flags
		CJamIterator iterator(pJam);
		for (iterator.FindFirst(); !iterator.IsDone(); iterator.FindNext())
		{
			CJamTexture* pTexture = iterator.GetCurrent();
			if (NULL == pTexture)
				continue;

			WORD wFlags = pTexture->GetFlags();
			if ((bFindAll && ((wFlagsToFind & wFlags) == wFlagsToFind)) ||
				((wFlagsToFind & wFlags) != 0))
				lstMatchingTextures.AddMatch(pDoc, pTexture);
		}
	}

	// Finally, present the results to the user
	CFindFlagsResultDlg dlgResult(&lstMatchingTextures);
	dlgResult.DoModal();*/
}



/////////////////////////////////////////////////////////////////////////////
// Global palette functions

// Function:	OnSelectGlobalPalette(nID)
// Overview:	Command-range handler for the global palette options
//				on the toolbar.
void CJamEditorApp::OnSelectGlobalPalette(UINT nID)
{
	// Set the new global palette.  This call will also take
	// care of updating the rest of the program.
	g_jamPalette.SetPaletteType(CommandIDToGlobalPaletteType(nID));
}
// End of function 'OnSelectGlobalPalette'


// Function:	OnUpdateSelectGlobalPalette()
// Overview:	Command-range update-handler for the global palette
//				options on the toolbar.
void CJamEditorApp::OnUpdateSelectGlobalPalette(CCmdUI* pCmdUI)
{
	// Show which palette is currently selected with a radio option
	const int nUIPaletteNum = CommandIDToGlobalPaletteType(pCmdUI->m_nID);
	pCmdUI->SetRadio(nUIPaletteNum == g_jamPalette.GetPaletteType());
}
// End of function 'OnUpdateSelectGlobalPalette'


// Function:	CommandIDToGlobalPaletteType(nCommandID)
// Overview:	Convert the command ID of one of the ID_GLOBALPAL_*
//				commands to an equivalent palette number
int CJamEditorApp::CommandIDToGlobalPaletteType(const int nCommandID) const
{
	return (nCommandID - ID_GLOBALPAL_GP2);
}
// End of function 'CommandIDToGlobalPaletteType'


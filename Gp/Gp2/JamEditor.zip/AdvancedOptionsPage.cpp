// AdvancedOptionsPage.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "AdvancedOptionsPage.h"

// Classes whose static members are the options we set here
#include "JamTexture.h"
#include "JamTextureFilter.h"
#include "NeighbourFilter.h"
#include "PixelProfileList.h"
#include "PaletteImageCombiner.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAdvancedOptionsPage property page

IMPLEMENT_DYNCREATE(CAdvancedOptionsPage, CPropertyPage)

CAdvancedOptionsPage::CAdvancedOptionsPage() : CPropertyPage(CAdvancedOptionsPage::IDD)
{
	//{{AFX_DATA_INIT(CAdvancedOptionsPage)
	m_strSpreadFactor = _T("");
	m_bProtectTransparency = TRUE;
	m_bGuessTransparency = TRUE;
	m_bGuessNonStandardSizeFlags = TRUE;
	m_nClusterProtection = 0;
	m_bGuessNoPalettes = TRUE;
	//}}AFX_DATA_INIT

	m_nSpreadFactor = CNeighbourFilter::DEFAULT_SPREAD_FACTOR;
}

CAdvancedOptionsPage::~CAdvancedOptionsPage()
{
}

void CAdvancedOptionsPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAdvancedOptionsPage)
	DDX_Control(pDX, IDC_SPREAD_SLIDER, m_sdrSpreadFactor);
	DDX_Text(pDX, IDC_SPREAD_TEXT, m_strSpreadFactor);
	DDX_Check(pDX, IDC_PROTECT_TRANSPARENCY, m_bProtectTransparency);
	DDX_Check(pDX, IDC_GUESS_TRANSPARENCY, m_bGuessTransparency);
	DDX_Check(pDX, IDC_GUESS_OPTIMISATION_FLAGS, m_bGuessNonStandardSizeFlags);
	DDX_CBIndex(pDX, IDC_CLUSTER_PROTECTION, m_nClusterProtection);
	DDX_Check(pDX, IDC_GUESS_NO_PALETTES, m_bGuessNoPalettes);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAdvancedOptionsPage, CPropertyPage)
	//{{AFX_MSG_MAP(CAdvancedOptionsPage)
	ON_BN_CLICKED(IDC_PROTECT_TRANSPARENCY, OnProtectTransparency)
	ON_WM_HSCROLL()
	ON_CBN_SELCHANGE(IDC_CLUSTER_PROTECTION, OnChangeOption)
	ON_BN_CLICKED(IDC_GUESS_NO_PALETTES, OnChangeOption)
	ON_BN_CLICKED(IDC_GUESS_OPTIMISATION_FLAGS, OnChangeOption)
	ON_BN_CLICKED(IDC_GUESS_TRANSPARENCY, OnChangeOption)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAdvancedOptionsPage message handlers

BOOL CAdvancedOptionsPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// Initialise all values for use in the dialog
	m_bProtectTransparency = CJamTextureFilter::s_bProtectTransparency;
	m_nClusterProtection = CPixelProfileList::s_nClusterProtection;
	m_nSpreadFactor = CNeighbourFilter::GetSpreadFactor();
	m_bGuessTransparency = CJamTexture::s_bGuessTransparency;
	m_bGuessNonStandardSizeFlags = CJamTexture::s_bGuessNonStandardSizeFlags;
	m_bGuessNoPalettes = CJamTexture::s_bGuessNoPalettes;

	// Set the valid range for the slider
	m_sdrSpreadFactor.SetRange(CNeighbourFilter::MIN_SPREAD_FACTOR,
							   CNeighbourFilter::MAX_SPREAD_FACTOR);

#ifdef _DEBUG
	GetDlgItem(IDC_CLUSTER_PROTECTION)->ShowWindow(SW_SHOW);
#endif

	// Put the values into the dialog box
	m_sdrSpreadFactor.SetPos(m_nSpreadFactor);
	UpdateSpreadFactorText();
	EnableSpreadFactor(!m_bProtectTransparency);
	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CAdvancedOptionsPage::OnOK() 
{
	// Update the values from the dialog, but watch out for invalid
	// values in the controls.
	if (!UpdateData(TRUE))
		return;

	// Set all of the static stuff
	CJamTextureFilter::s_bProtectTransparency = m_bProtectTransparency;
	CPixelProfileList::s_nClusterProtection = m_nClusterProtection;
	CNeighbourFilter::SetSpreadFactor(m_nSpreadFactor);
	CJamTexture::s_bGuessTransparency = m_bGuessTransparency;
	CJamTexture::s_bGuessNonStandardSizeFlags = m_bGuessNonStandardSizeFlags;
	CJamTexture::s_bGuessNoPalettes = m_bGuessNoPalettes;

	CPropertyPage::OnOK();
}


void CAdvancedOptionsPage::OnProtectTransparency() 
{
	// Enable/disable the spread factor controls according to
	// the new setting of the Protect Transparency option.
	if (!UpdateData(TRUE))
		return;

	// Update the text indicator to show the current spread factor.
	EnableSpreadFactor(!m_bProtectTransparency);

	// Enable the Apply button via the gift of...
	OnChangeOption();
}


// Spread factor functions
//

// Function:	EnableSpreadFactor(bEnable)
// Overview:	Enable or disable the controls used to set the
//				spread factor for uninhibited blurring.
void CAdvancedOptionsPage::EnableSpreadFactor(const BOOL bEnable /*= TRUE*/)
{
	// There's only the slider to change! :)
	m_sdrSpreadFactor.EnableWindow(bEnable);
	UpdateData(FALSE);
}
// End of function 'EnableSpreadFactor'


// Function:	UpdateSpreadFactorText()
// Overview:	Enable or disable the controls used to set the
//				spread factor for uninhibited blurring.
void CAdvancedOptionsPage::UpdateSpreadFactorText()
{
	// Just show the current slider position in the
	// label alongside it
	m_strSpreadFactor.Format("%d", m_nSpreadFactor);
	CDataExchange dx(this, FALSE);
	try
	{
		DDX_Text(&dx, IDC_SPREAD_TEXT, m_strSpreadFactor);
	}
	catch (CException* pExc)
	{
		// Somehow the exchange of data to the text control failed! :(
		ASSERT(FALSE);

		// Never mind - just get on with things as best we can.
		pExc->Delete();
	}
}
// End of function 'UpdateSpreadFactorText'


// Function:	OnHScroll(nSBCode, nPos, pScrollBar)
// Overview:	Horizontal scrollbar handler, used to intercept messages
//				from the spread factor slider.
void CAdvancedOptionsPage::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// Make sure it's the slider we're after
	if (NULL != pScrollBar &&
		pScrollBar->GetSafeHwnd() == m_sdrSpreadFactor.GetSafeHwnd())
	{
		// Figure out where the slider's position currently is
		if (SB_THUMBPOSITION == nSBCode || SB_THUMBTRACK == nSBCode)
			m_nSpreadFactor = (int)nPos;
		else
			m_nSpreadFactor = ((CSliderCtrl *)pScrollBar)->GetPos();

		// Update the text indicator to say what the current spread
		// factor is.
		UpdateSpreadFactorText();

		// Enable the Apply button via the gift of...
		OnChangeOption();
	}

	CPropertyPage::OnHScroll(nSBCode, nPos, pScrollBar);
}
// End of function 'OnHScroll'


// Function:	OnChangedOption()
// Overview:	Handler for most data-changing events in the dialog, this
//				just enables the Apply button.
void CAdvancedOptionsPage::OnChangeOption() 
{
	SetModified(TRUE);
}
// End of function 'OnChangedOption'


// EditableTypedPtrList.cpp
//
// a class which is both a list of editable objects and 
// an editable object (as parent)

#include "stdafx.h"
#include "EditableTypedPtrList.h"

CEditableTypedPtrList::CEditableTypedPtrList(CEditableObject* pParent) : CEditableObject(pParent)
{
}

CEditableTypedPtrList::~CEditableTypedPtrList()
{
	POSITION pos=GetHeadPosition();
	while (pos)
	{
		delete GetNext(pos);
	}

	// empty list - for the sake of it... it would happen
	// anyway.. but I like to know what's going on!
	RemoveAll();
}
// JamTexture.h - header file for the CJamTexture class
//

#ifndef __JAM_TEXTURE_H__
#define __JAM_TEXTURE_H__

#include "JamPixelInfo.h"
#include "JamTextureProperties.h"

class CJamTextureFilter;
class CJamTextureAnimation;
class CPaletteImageSource;

// Each JAM file comprises a header detailing the number of textures
// in the file and its total size, followed by an array of texture
// entries, their palettes, and finally the full image's pixels.

/////////////////////////////////////////////////////////////////////
// Struct:	JAM_TEXTURE
// Overview:
//   This structure defines the data that comprises a single JAM file
//   texture definition.
//

typedef signed char SBYTE;

#pragma pack(1)

typedef struct
{
	BYTE m_byLeft;				// Left of texture within image
	WORD m_wTop;				// Top of texture within image
	BYTE m_byUnk03;				// Unk. (unused)
	WORD m_wWidth;				// Width of texture within image
	WORD m_wHeight;				// Height of texture within image
	SBYTE m_byID5HorzShift;		// Horizontal shift when used as id5 object
	SBYTE m_byID5VertShift;		// Vertical shift when used as id5 object
	BYTE m_byID5ScaleFlags;		// Scaling flags to affect use as id5 object(?)
	BYTE m_byID5ScaleFactor;	// Scale factor when used as id5 object
	WORD m_wPalettePos;			// Offset to palette data at end of all headers
	WORD m_wUnk0E;				// Unk.
	WORD m_wLocalPaletteSize;	// Size of the local palettes
	WORD m_wTextureID;			// The all-important texture ID
	WORD m_wFlags;				// Various flags, including transparency(0x08)
	BYTE m_byLowDetailColour1;	// Colour used when textures are turned off
	BYTE m_byLowDetailColour2;	// Secondary colour used when textures are turned off?
	BYTE m_byUnk18[8];			// Unk.
} JAM_TEXTURE;

#pragma pack()

// The meaning of the flags stored in m_wFlags above:
enum eTextureFlagIDs
{
	TF_UNK1	= 1,
	TF_UNK2,
	TF_UNK3,
	TF_TRANSPARENT,
	TF_UNK5,
	TF_UNK6,
	TF_USE_PIT_CREW_COLOURS,
	TF_NO_LOCAL_PALETTES,
	TF_NON_STANDARD_HEIGHT,
	TF_NON_STANDARD_WIDTH,
	TF_UNK11,
	TF_UNK12,
	TF_UNK13,
	TF_UNK14,
	TF_UNK15,
	TF_UNK16,
	TF_FIRST_FLAG = TF_UNK1,
	TF_LAST_FLAG = TF_UNK16
};


/////////////////////////////////////////////////////////////////////
// Class:	CJamTexture
// Base:	[none]
// Created:	29Dec98 by M.Ross
// Overview:
//   A class to represent a single texture in a JAM file.  The
//   class makes for a much nicer interface to the JAM_TEXTURE
//   structure it holds, and provides functions for extracting
//   the texture from the main JAM data.
//

class CJamTextureList;	// fwd decl

// Palette numbers
#define PAL_REBUILD_TEXTURE		-1
#define PAL_LOW_DETAIL_COLOR	0

class CJamTexture : public CJamTextureProperties
{
// Construction/destruction
private:
	CJamTexture();	// hide the default constructor
public:
	CJamTexture(CJamTextureList* pParent);
	CJamTexture(const CSize& sizTexture, CJamTextureList* pParent);
	virtual ~CJamTexture();

	// Loading/saving (not intended to CObject-type of Serialize -
	// just a general load/save from/to archive)
	void Serialize(CArchive& ar);
	void SerializePalettes(CArchive& ar);
	void SerializePixels(CArchive& ar);	// used for cut/copy/paste

// Data members
public:
	// Is the texture selected in the view and/or tree?
	BOOL m_bSelected;

	// Should we guess and set the transparency of the texture
	// when importing a new bitmap?
	static BOOL s_bGuessTransparency;

	// Should we guess and set the non-standard size flags when the
	// user changes the height and/or width of the texture?
	static BOOL s_bGuessNonStandardSizeFlags;

	// Should we guess the no-palettes flag when the texture is
	// filtered?
	static BOOL s_bGuessNoPalettes;

	// Should textures with 'invalid pixels' (see m_bInvalidPixels below)
	// be drawn with different-coloured outlines?
	static BOOL s_bShowInvalidPixels;

	// Colours used to draw the texture's outline
	static COLORREF s_clrSelected;
	static COLORREF s_clrNotSelected;
	static COLORREF s_clrInvalidPixels;

protected:
	// The structure containing all information about this texture
	// (apart from the palettes and pixels)
	JAM_TEXTURE* m_pTextureInfo;

	// The texture's four local palettes
	BYTE* m_pPalette1;
	BYTE* m_pPalette2;
	BYTE* m_pPalette3;
	BYTE* m_pPalette4;

	// Two arrays containing the pixels of the texture.  The first,
	// m_pbRawTexturePixels, contains the pixels before they've been
	// decoded using one of the four local palettes.  The second
	// contains the last version of the pixels, with the pixel values
	// shifted to contain indices into the global GP2 palette.
	// The m_nLastPaletteUsed member indicates which of the local
	// palettes was used to produce those pixels.
	BYTE* m_pbRawTexturePixels;
	BYTE* m_pbDecodedTexturePixels;
	int m_nLastPaletteUsed;

	// Flag to indicate whether there are any raw pixels attempting
	// to access local palette indexes that are outside the bounds
	// of our local palettes i.e. index > palettesize
	BOOL m_bInvalidPixels;

// Operations
public:
	// Get/set various attributes
	UINT GetTextureID() const;
	void SetTextureID(const UINT& nID);
	UINT GetPaletteSize() const;
	UINT GetNumTextureBytes() const;
	BOOL SetPalettePos(const UINT& nPalettePos);
	BYTE*& GetPalette(const int nPaletteNumber);
	void InvalidatePalette() { m_nLastPaletteUsed = PAL_REBUILD_TEXTURE; }

	// Get/set size of texture
	CRect GetRect() const;
	WORD GetWidth() const;
	WORD GetHeight() const;
	BOOL SetWidth(const WORD& wWidth);
	BOOL SetHeight(const WORD& wHeight);
	BOOL SetSize(const WORD wWidth, const WORD wHeight);

	// Get/set location of the texture
	WORD GetTop() const;
	BYTE GetLeft() const;
	void SetTop(const WORD nTop);
	void SetLeft(const BYTE nLeft);

	// access to front end
	CEditableObject* GetProperties() { return (CEditableObject*)((CJamTextureProperties*)this); };

	// Texture property flags
	BOOL IsFlagSet(const int& nFlagID) const;
	void SetFlag(const int& nFlagID, const BOOL bOn = TRUE);
	WORD GetFlags() const;
	void SetFlags(const WORD& wFlags);
	static UINT FlagNumToMask(const int& nFlagID);

	// A check to test the validity of this object
	BOOL IsValid() const;

	// Various drawing functions
	BOOL DrawTexture(CDC* pDC, const int& nPaletteNum);	// 1:1 drawing of texture
	BOOL DrawOutline(CDC* pDC, const double& dZoomFactor);

	// Hit-testing
	BOOL HitTest(CJamPixelInfo& pixelInfo) const;

	// Get/set the raw pixels from/into the JAM's pixels
	BOOL ExtractRawPixelsFromCanvas(BYTE* pbCanvasPixels, const CSize& sizCanvas);
	BOOL InsertRawPixelsIntoCanvas(BYTE* pbCanvasPixels, const CSize& sizCanvas);

	// Import/export pixels from/to a bitmap
	BOOL ImportPixelsFromTextureBitmap(BYTE* pbBitmapPixels, CJamTextureFilter* pFilter);
	BOOL ImportPixelsFromCanvasBitmap(BYTE* pbBitmapPixels, CJamTextureFilter* pFilter);
	BOOL ExportPixelsToTextureBitmap(BYTE* pbBitmapPixels);
	BOOL ExportPixelsToCanvasBitmap(BYTE* pbBitmapPixels);

	// Re-filtering and animating
	BOOL ApplyFilter(CJamTextureFilter* pFilter);
	BOOL ImportAnimation(CJamTextureAnimation& animation);

	// Pixel and palette-checking
	BOOL AreRawPixelsValid() const { return !m_bInvalidPixels; }

// Implementation
protected:
	// Destruction of all dynamically-allocated data
	virtual void Destroy();
	void DestroyPalettes();

	// Drawing routines
	COLORREF GetOutlineColor() const;

	// Copying pixels from one location in a byte buffer to
	// another location in a separate byte buffer.
	BOOL CopyTexturePixels(BYTE* pbSrc, BOOL bSrcIsCanvas, BYTE* pbDest, BOOL bDestIsCanvas);

	// Image and palette editing/import
	BOOL DecodePixels(const int& nCurrPalEntry);

	// Filtering and flag-guessing
	BOOL FilterPixels(BYTE* pbBitmapPixels, CJamTextureFilter* pFilter);
	BOOL CombinePaletteImages(CPaletteImageSource* pSource, const BOOL bEmptyPalettesIfPoss = FALSE);
	void GuessTransparency();
	void GuessNonStandardSizeFlags();
	BOOL IsNonStandardSize(WORD wSize) const;

	// Pixel and palette-checking
	void CheckForInvalidPixels();

protected:
	void CreateEditableObjects();
	enum eJamTextureVersions
	{
		JAMTEXTURE_PIXELS_CLIPBRD_VERSION = 1
	};

	// overrides of CEditableObject
	virtual BOOL ChangeDataFromEdit(CString newData);
	virtual BOOL HandleSelect ();
	virtual void DataHasChanged(CView* pView, LPARAM lHint, CObject* pHint);
};

/////////////////////////////////////////////////////////////////////

#endif	// ~__JAM_TEXTURE_H__


#if !defined(AFX_IMPORT_H__3E7DC981_82A6_11D4_8FC7_0008C7636E27__INCLUDED_)
#define AFX_IMPORT_H__3E7DC981_82A6_11D4_8FC7_0008C7636E27__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Import.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CImport dialog

class CImport : public CDialog
{
// Construction
public:
	CImport(CWnd* pParent = NULL);   // standard constructor
	CString m_TempFile;
	int m_Checked[16];
	CString m_Gp3Path;
	CString m_StrFile;
// Dialog Data
	//{{AFX_DATA(CImport)
	enum { IDD = IDD_IMPORT };
	BOOL	m_Laps;
	BOOL	m_LapTime;
	BOOL	m_Len;
	BOOL	m_Misc;
	BOOL	m_Name;
	BOOL	m_Points;
	BOOL	m_Track1;
	BOOL	m_Track10;
	BOOL	m_Track11;
	BOOL	m_Track12;
	BOOL	m_Track13;
	BOOL	m_Track14;
	BOOL	m_Track15;
	BOOL	m_Track16;
	BOOL	m_Track2;
	BOOL	m_Track3;
	BOOL	m_Track4;
	BOOL	m_Track5;
	BOOL	m_Track6;
	BOOL	m_Track7;
	BOOL	m_Track8;
	BOOL	m_Track9;
	BOOL	m_Ware;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CImport)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CImport)
	virtual void OnOK();
	afx_msg void OnTrack1();
	afx_msg void OnTrack10();
	afx_msg void OnTrack11();
	afx_msg void OnTrack12();
	afx_msg void OnTrack13();
	afx_msg void OnTrack14();
	afx_msg void OnTrack15();
	afx_msg void OnTrack16();
	afx_msg void OnTrack2();
	afx_msg void OnTrack3();
	afx_msg void OnTrack4();
	afx_msg void OnTrack5();
	afx_msg void OnTrack6();
	afx_msg void OnTrack7();
	afx_msg void OnTrack8();
	afx_msg void OnTrack9();
	virtual BOOL OnInitDialog();
	afx_msg void OnLap();
	afx_msg void OnLen();
	afx_msg void OnPoints();
	afx_msg void OnName();
	afx_msg void OnLaptimes();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IMPORT_H__3E7DC981_82A6_11D4_8FC7_0008C7636E27__INCLUDED_)

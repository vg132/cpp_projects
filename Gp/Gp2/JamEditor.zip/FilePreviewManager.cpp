// FilePreviewManager.cpp : implementation file for the CFilePreviewManager class
//

#include "stdafx.h"

#include "FilePreviewManager.h"

#include "NullFilePreview.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFilePreviewManager

// The only instance of the class that should ever exist.
CFilePreviewManager* CFilePreviewManager::m_pUniqueInstance = NULL;

CFilePreviewManager::CFilePreviewManager()
{
	// You should not need to create a CFilePreviewManager
	// directly - just use GetManager()
	VERIFY(m_pUniqueInstance == NULL);
}

CFilePreviewManager::~CFilePreviewManager()
{
	// Just delete all preview types from our list
	while (NULL != m_lstPreviewTypes.GetHeadPosition())
		delete m_lstPreviewTypes.RemoveHead();
}


// Singleton-related static operations
//

CFilePreviewManager* CFilePreviewManager::GetManager()
{
	// If the manager hasn't been created yet, do it now
	if (NULL == m_pUniqueInstance)
		m_pUniqueInstance = new CFilePreviewManager;

	return m_pUniqueInstance;
}

void CFilePreviewManager::DestroyManager()
{
	if (NULL != m_pUniqueInstance)
	{
		delete m_pUniqueInstance;
		m_pUniqueInstance = NULL;
	}
}


// List management functions
//

// Add file types your application supports using this function:
BOOL CFilePreviewManager::AddFilePreview(CFilePreview* pPreviewType)
{
	// TODO: We should probably have some checking here to make sure
	// that we don't have more than one CFilePreview-derived class
	// wanting to preview the same file type.  However, for the moment,
	// I'm just going to rely on the code using this being sensible.
	if (NULL == pPreviewType)
		return FALSE;

	// Add the preview type to the list
	m_lstPreviewTypes.AddTail(pPreviewType);

	return TRUE;
}

// Creation of new preview objects based on a filename
CFilePreview* CFilePreviewManager::CreateFilePreview (const CString& strFilename)
{
	// Find the preview to be used for this file and
	// return a new instance of it.
	CFilePreview* pPreview = FindPreviewForFile(strFilename);
	if (NULL == pPreview)
		return new CNullFilePreview;
	else
		return pPreview->CreateNewPreview();
}

// Preview-type retrieval
CFilePreview* CFilePreviewManager::FindPreviewForFile (const CString& strFilename)
{
	// Just return the first preview type in our list that
	// will be able to show the file
	POSITION posPreview = m_lstPreviewTypes.GetHeadPosition();
	CFilePreview* pPreview = NULL;
	BOOL bFound = FALSE;
	while (NULL != posPreview && !bFound)
	{
		pPreview = m_lstPreviewTypes.GetNext(posPreview);
		if (NULL != pPreview && pPreview->IsSupportedFile(strFilename))
			bFound = TRUE;
	}

	if (bFound)
		return pPreview;
	else
		return NULL;
}

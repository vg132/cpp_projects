// DrivingConditionsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"

#include "DrivingConditionsDlg.h"

#include "JamTextureFilterManager.h"
#include "JamTextureFilter.h"
#include "JamTextureFilterIDs.h"
#include "PaletteImageCombiner.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDrivingConditionsDlg dialog


CDrivingConditionsDlg::CDrivingConditionsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDrivingConditionsDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDrivingConditionsDlg)
	m_nFilterIndex = -1;
	m_bApplyToAll = FALSE;
	m_bProtectTransparency = TRUE;
	//}}AFX_DATA_INIT
}


void CDrivingConditionsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDrivingConditionsDlg)
	DDX_CBIndex(pDX, IDC_FILTER_LIST, m_nFilterIndex);
	DDX_Check(pDX, IDC_APPLY_TO_ALL, m_bApplyToAll);
	DDX_Check(pDX, IDC_PROTECT_TRANSPARENCY, m_bProtectTransparency);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDrivingConditionsDlg, CDialog)
	//{{AFX_MSG_MAP(CDrivingConditionsDlg)
	ON_BN_CLICKED(IDC_OPTIONS, OnOptions)
	ON_CBN_SELCHANGE(IDC_FILTER_LIST, OnSelectFilter)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDrivingConditionsDlg initialisation

// Function:	OnInitDialog()
// Overview:	Overridden to fill the filter list with the filters
//				in the filter manager.
BOOL CDrivingConditionsDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// Get the default filter ID from the INI file, ready to
	// select its entry when added to the list
	int nDefaultFilterID = AfxGetApp()->GetProfileInt("Driving Conditions", "Reapply Filter", -1);
	m_bApplyToAll = (BOOL)AfxGetApp()->GetProfileInt("Driving Conditions", "Reapply To All", 0);
	m_bProtectTransparency = CJamTextureFilter::s_bProtectTransparency;

	// Now add all filter
	CComboBox* pFilterCombo = (CComboBox *)GetDlgItem(IDC_FILTER_LIST);
	pFilterCombo->ResetContent();
	CJamTextureFilterManager* pFilterMgr = CJamTextureFilterManager::GetManager();
	if (NULL != pFilterMgr)
	{
		// Cycle through the filters in the filter manager,
		// getting their names and IDs
		POSITION posFilter = pFilterMgr->GetFirstFilterPos();
		while (NULL != posFilter)
		{
			// Get the next filter in the manager
			CJamTextureFilter* pFilter = pFilterMgr->GetNextFilter(posFilter);
			ASSERT(NULL != pFilter);
			if (NULL == pFilter)
				continue;

			// Add this filter to the list and set its ID as the
			// item's data
			CString strFilterName = pFilter->GetFilterName();
			int nFilterID = pFilter->GetFilterID();
			int nNewIndex = pFilterCombo->AddString(strFilterName);
			if (-1 != nNewIndex)
			{
				pFilterCombo->SetItemData(nNewIndex, (DWORD)nFilterID);

				// If this is the default filter, select it now
				if (nFilterID == nDefaultFilterID)
				{
					m_nFilterIndex = nNewIndex;
					m_nFilterID = nDefaultFilterID;
				}
			}
		}
	}

	// If we didn't find the default filter in the filter manager,
	// just select the first in the list
	if (-1 == m_nFilterIndex)
	{
		m_nFilterIndex = 0;
		m_nFilterID = pFilterCombo->GetItemData(m_nFilterIndex);
	}

	// Allow the user to configure the selected filter, if it
	// supports that.
	UpdateOptionsButton();

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
// End of function 'OnInitDialog'


// Function:	DoModal()
// Overview:	Overridden to store the selected driving conditions in
//				the app's INI file.  Why I didn't just do this in OnOK
//				is beyond me now.
int CDrivingConditionsDlg::DoModal() 
{
	// Let the base class do all of the usual stuff...
	int nResult = CDialog::DoModal();

	// ...then store the selected filter as the default,
	// provided the user hasn't just canceled it.
	if ((IDOK == nResult))
	{
		AfxGetApp()->WriteProfileInt("Driving Conditions", "Reapply Filter", m_nFilterID);
		AfxGetApp()->WriteProfileInt("Driving Conditions", "Reapply To All", (int)m_bApplyToAll);
		CJamTextureFilter::s_bProtectTransparency = m_bProtectTransparency;
	}

	return nResult;
}
// End of function 'DoModal'



/////////////////////////////////////////////////////////////////////////////
// Filter selection

// Function:	OnSelectFilter()
// Overview:	Handle a change in the selection of the filter
//				to keep track of the filter's internal ID.
void CDrivingConditionsDlg::OnSelectFilter()
{
	// Make sure this class's data is up-to-date
	UpdateData(TRUE);

	if (m_nFilterIndex == -1)
	{
		// It should be impossible to deselect all in a combo
		ASSERT(FALSE);
		m_nFilterID = NULL_FILTER;
	}
	else
	{
		// Extract the ID of the chosen filter from the item
		// data for the selected item,
		CComboBox* pFilterCombo = (CComboBox *)GetDlgItem(IDC_FILTER_LIST);
		m_nFilterID = (int)pFilterCombo->GetItemData(m_nFilterIndex);
	}

	UpdateOptionsButton();
}
// End of function 'OnSelectFilter'


// Function:	GetSelectedFilter()
// Overview:	Reporting of the chosen import filter using its filter ID.
CJamTextureFilter* CDrivingConditionsDlg::GetSelectedFilter()
{
	CJamTextureFilterManager* pFilterMgr = CJamTextureFilterManager::GetManager();
	if (NULL == pFilterMgr)
		return NULL;

	return pFilterMgr->GetFilter(m_nFilterID);
}
// End of function 'GetSelectedFilter'



/////////////////////////////////////////////////////////////////////////////
// Filter options

// Function:	OnOptions()
// Overview:	Display the Options dialog for the selected filter
void CDrivingConditionsDlg::OnOptions() 
{
	// Get the selected filter to make sure it has
	// user-configurable options...
	CJamTextureFilter* pFilter = GetSelectedFilter();
	if (NULL == pFilter || !pFilter->IsConfigurable())
	{
		ASSERT(FALSE);
		return;
	}

	// Ask the filter to see about configuring itself
	pFilter->Configure();
}
// End of function 'OnOptions'


// Function:	UpdateOptionsButton()
// Overview:	Enable or disable the Options button according to whether
//				 or not the current filter supports setting various
//				filtering options.
void CDrivingConditionsDlg::UpdateOptionsButton() 
{
	// Get a pointer to the button we're going to update
	CWnd* pOptionsBtn = GetDlgItem(IDC_OPTIONS);
	ASSERT(NULL != pOptionsBtn);
	if (NULL == pOptionsBtn)
		return;

	// Get the selected filter to see whether it has user-configurable
	// options...
	CJamTextureFilter* pFilter = GetSelectedFilter();
	BOOL bEnableOptions = FALSE;
	if (NULL != pFilter)
		bEnableOptions = pFilter->IsConfigurable();

	// Update the button accordingly
	pOptionsBtn->EnableWindow(bEnableOptions);
}
// End of function 'UpdateOptionsButton'


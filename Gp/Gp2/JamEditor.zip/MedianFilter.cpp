// MedianFilter.cpp - implementation of the CMedianFilter class
//

#include "stdafx.h"
#include "resource.h"

#include "MedianFilter.h"

#include "JamTextureFilterIDs.h"
#include "ColorFunctions.h"
#include "TexturePalette.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CMedianFilter

// Constructor
CMedianFilter::CMedianFilter()
	: CNeighbourFilter(MEDIAN_FILTER, IDS_FILTER_NAME_MEDIAN),
	  m_nMedianMethod(MEDIAN_RGB_THEN_NEAREST_NEIGHBOUR)
{
}

// Destructor
CMedianFilter::~CMedianFilter()
{
}


// NOTE: The GetMedian function is defined inline in the header file.

// Overridden filtering functions
//

// Function:	FilterNeighbourhood(pbNeighbourArray, nNumNeighbours)
// Overview:	Inline sorting function for determining median value in an
//				array of palette indexes.  Do this by finding the median of
//				each of R, G, and B values.
BYTE CMedianFilter::FilterNeighbourhood(BYTE* pbNeighbourArray, int nNumNeighbours)
{
	// A couple of quick checks for simple cases
	if (nNumNeighbours < 1)
		return GP2_TRANSPARENT_PALETTE_INDEX;
	else if (1 == nNumNeighbours)
		return *pbNeighbourArray;

	// Check to see whether we can quickly return an answer
	if (MEDIAN_PALETTE_INDEX == m_nMedianMethod)
		return GetMedian(pbNeighbourArray, nNumNeighbours);

	// Convert the array of palette indexes into 3 arrays of R,
	// G, and B values.  NOTE: there is NO checking code here to
	// see whether or not the memory allocations fail.  This is
	// VERY bad practice, but until someone complains that it has
	// crashed on their computer, I'm going to leave it like this
	// for efficiency purposes.
	BYTE* pbRedValues = new BYTE[nNumNeighbours];
	BYTE* pbGreenValues = new BYTE[nNumNeighbours];
	BYTE* pbBlueValues = new BYTE[nNumNeighbours];
	for (int nIndex = 0; nIndex < nNumNeighbours; nIndex++)
	{
		pbRedValues[nIndex] = g_jamPalette[pbNeighbourArray[nIndex]].rgbRed;
		pbGreenValues[nIndex] = g_jamPalette[pbNeighbourArray[nIndex]].rgbGreen;
		pbBlueValues[nIndex] = g_jamPalette[pbNeighbourArray[nIndex]].rgbBlue;
	}

	// Now find the median of each of R, G, and B values and bung them
	// into an RGBQUAD
	RGBQUAD rgbMedian =
	{
		GetMedian(pbBlueValues, nNumNeighbours),
		GetMedian(pbGreenValues, nNumNeighbours),
		GetMedian(pbRedValues, nNumNeighbours),
		0	// reserved
	};

	// Check to see which type of median we need to return.  If
	// it's one that doesn't have to be a value from the array we
	// we given, we can get it over with now.
	BYTE nMedian = 0;
	if (MEDIAN_RGB_THEN_NEAREST_COLOR == m_nMedianMethod)
		nMedian = GetNearestColorIndex(rgbMedian);
	else
		nMedian = GetNearestNeighbourIndex(rgbMedian, pbNeighbourArray, nNumNeighbours);

	// Tidy up
	delete[] pbRedValues;
	delete[] pbGreenValues;
	delete[] pbBlueValues;

	return nMedian;
}
// End of function 'FilterNeighbourhood'



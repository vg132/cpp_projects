// Text.cpp: implementation of the CText class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Gp3 Track Handler.h"
#include "Text.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CText::CText()
{

}

CText::~CText()
{

}

bool CText::LoadText(CString sFile)
{
HANDLE hFile;
DWORD dwSize;
DWORD dwReadSize;
CString sTmp;
char ch;
int i;
	hFile=CreateFile(sFile,
					GENERIC_READ,
					FILE_SHARE_READ,
					NULL,OPEN_EXISTING,
					FILE_ATTRIBUTE_NORMAL,
					NULL);

	dwSize=GetFileSize(hFile,NULL);

	char * lpBuffer = (char*)GlobalAlloc(GMEM_FIXED,dwSize );
	ReadFile(hFile,(LPVOID)lpBuffer,dwSize,&dwReadSize,NULL);

	CloseHandle(hFile);

	for(i=0;i<dwSize;i++)
	{
		ch=lpBuffer[i];
		if(ch!=NULL)
		{
			sTmp+=lpBuffer[i];
		}
		else
		{
			sText.Add(sTmp);
			sTmp="";
		}
	}
	GlobalFree(lpBuffer);
	return(true);
}

bool CText::SaveText(CString sFile)
{
CFile file;
char ch='\0';

	DeleteFile(sFile);
	file.Open(sFile,CFile::modeWrite|CFile::modeCreate,NULL);
	for(int i=0;i<sText.GetUpperBound()+1;i++)
	{
		file.Write(sText.GetAt(i),strlen(sText.GetAt(i)));
		file.Write((char*)&ch,sizeof(char));
	}
	file.Close();
	return(true);
}

CString CText::GetTrackName(int TrackNr)
{
	// Track Nr=1-16
	return(sText.GetAt(1782+TrackNr));
}

bool CText::SetTrackName(CString NewString, int TrackNr)
{
	sText.RemoveAt(1878+TrackNr);
	sText.SetAt(1782+TrackNr,NewString);
	return(true);
}

CString CText::GetTrackCountry(int TrackNr)
{
	// Track Nr=1-16
	return(sText.GetAt(1798+TrackNr));
}

bool CText::SetTrackCountry(CString NewString, int TrackNr)
{
	sText.RemoveAt(1878+TrackNr);
	for(int i=0;i<6;i++)
		sText.SetAt(1798+(i*16)+TrackNr,NewString);
	return(true);
}

CString CText::GetTrackAdjective(int TrackNr)
{
	// Track Nr=1-16
	return(sText.GetAt(1878+TrackNr));
}

bool CText::SetTrackAdjective(CString NewString, int TrackNr)
{
	sText.RemoveAt(1878+TrackNr);
	sText.SetAt(1878+TrackNr,NewString);
	return(true);
}

int CText::GetTextSize()
{
	return(sText.GetUpperBound());
}

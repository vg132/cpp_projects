// JamIterator.h: interface for the CJamIterator class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _JAM_ITERATOR_H_
#define _JAM_ITERATOR_H_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "Iterator.h"
class CJam;
class CJamTexture;

//////////////////////////////////////////////////////////////////////
// Class:	CJamIterator
// Base:	CIterator
// Overview:
//    This class is for use in iterating through the textures in
//  a single JAM.
//

class CJamIterator : public CIterator<CJamTexture*>
{
// Construction/destruction
public:
	CJamIterator(const CJam* pParentJam);
	virtual ~CJamIterator();

// Attributes
protected:
	// The jam whose textures we're iterating through
	const CJam* m_pJam;

	// The position of the current texture in the jam and that
	// current texture
	POSITION m_posNextTexture;
	CJamTexture* m_pCurrTexture;

// Iteration ops
public:
	virtual void FindFirst();
	virtual void FindNext();
	virtual BOOL IsDone();
	virtual CJamTexture* GetCurrent();

// Implementation
protected:
	BOOL IsValid() const;
};

//////////////////////////////////////////////////////////////////////

#endif	// ~_JAM_ITERATOR_H_

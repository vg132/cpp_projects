// BlurFilter.h - header file for the CBlurFilter class
//

#ifndef __BLUR_FILTER_H__
#define __BLUR_FILTER_H__

#include "NeighbourFilter.h"
#include "TexturePalette.h"
#include "ColorFunctions.h"

///////////////////////////////////////////////////////////////////
// Class:	CBlurFilter
// Base:	CNeighbourFilter (abstract)
// Created:	10May99 by Mal Ross
// Overview:
//    This filter performs a simple smoothing operation on the
//  pixels within a given neighbourhood of each pixel in the
//  pre-filtered image.
//

class CBlurFilter : public CNeighbourFilter
{
// Construction and destruction
public:
	CBlurFilter();
	virtual ~CBlurFilter();

// Data members
protected:

// Implementation
protected:
	// Median-filtering functions
	virtual BYTE FilterNeighbourhood(BYTE* pbNeighbourArray, int nNumNeighbours);
};


// Function:	FilterNeighbourhood(pbNeighbourArray, nNumNeighbours)
// Overview:	Inline function for determining blurred pixel value in an
//				array.  This will be so slow, it might be unbearable.
inline BYTE CBlurFilter::FilterNeighbourhood(BYTE* pbNeighbourArray, int nNumNeighbours)
{
	// A couple of quick checks for simple cases
	if (nNumNeighbours < 1)
		return GP2_TRANSPARENT_PALETTE_INDEX;
	else if (1 == nNumNeighbours)
		return *pbNeighbourArray;

	// Sum the colours and take an average at the end.
	LONG lRed = 0, lGreen = 0, lBlue = 0;
	BYTE byPixel = 0;
	for (int nPixelNum = 0; nPixelNum < nNumNeighbours; nPixelNum++)
	{
		byPixel = pbNeighbourArray[nPixelNum];
		lRed += (LONG)g_jamPalette[byPixel].rgbRed;
		lGreen += (LONG)g_jamPalette[byPixel].rgbGreen;
		lBlue += (LONG)g_jamPalette[byPixel].rgbBlue;
	}

	// Calculate the average colour
	RGBQUAD quadResult = {BYTE(lBlue/nNumNeighbours),
						  BYTE(lGreen/nNumNeighbours),
						  BYTE(lRed/nNumNeighbours),
						  (BYTE)0};

	// Return the index of the closest match in the GP2 palette
	return GetNearestColorIndex(quadResult);
}
// End of function 'FilterNeighbourhood'


/////////////////////////////////////////////////////////////////////

#endif	// ~__BLUR_FILTER_H__

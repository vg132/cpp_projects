// JamView.h : interface of the CJamView class
//
/////////////////////////////////////////////////////////////////////////////

#ifndef __JAM_VIEW_H__
#define __JAM_VIEW_H__

#include "ZoomFactor.h"

class CJam;
class CJamTexture;

class CJamView : public CScrollView
{
protected: // create from serialization only
	CJamView();
	DECLARE_DYNCREATE(CJamView)

// Attributes
public:
	// The cliboard format for jam textures
	UINT m_nClipboardFormat;

// Operations
public:
	CJamEditorDoc* GetDocument() const;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CJamView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual int OnToolHitTest(CPoint pt, TOOLINFO* pTI) const;
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CJamView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	// The zoom factor for displaying the JAM
	CZoomFactor m_ZoomFactor;
	double GetZoomFactor() const;
	void UpdateScrollSizes();

	// Retrieval of palette number
	int GetPaletteNum() const;

	// Simple coordinate conversion and hit-testing
	void JamToClient(CPoint& point) const;
	void ClientToJam(CPoint& point) const;
	CJamTexture* GetTextureAtPoint(const CPoint& point) const;
	CJamTexture* GetSelectedTexture() const;
	BOOL ScrollToTexture(CJamTexture* pTexture);

	// The DataTip for showing texture info
	CToolTipCtrl m_ToolTip;
	CString m_strLastToolTip;

	// Get the jam being displayed
	CJam* GetJam() const;

	// Clipboarding
	void DoCutCopyPaste(CArchive &ar, BOOL bCut);

// Generated message map functions
protected:
	//{{AFX_MSG(CJamView)
	afx_msg void OnZoomIn();
	afx_msg void OnZoomOut();
	afx_msg void OnZoomOneToOne();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnEditTextureProperties();
	afx_msg void OnUpdateEditTextureProperties(CCmdUI* pCmdUI);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnUpdateEditCopyCut(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditPaste(CCmdUI* pCmdUI);
	afx_msg void OnEditCopy();
	afx_msg void OnEditCut();
	afx_msg void OnEditPaste();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
    afx_msg BOOL OnGetTooltipText(UINT id, NMHDR* pNMHDR, LRESULT* pRes);
	DECLARE_MESSAGE_MAP()

	// Assistant to the OnLButtonDown and OnRButtonDown handlers
	void SelectTextureOnClick(UINT nFlags, CPoint point);
};

#ifndef _DEBUG  // debug version in JamView.cpp
inline CJamEditorDoc* CJamView::GetDocument() const
   { return (CJamEditorDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
#endif	//~__JAM_VIEW_H__

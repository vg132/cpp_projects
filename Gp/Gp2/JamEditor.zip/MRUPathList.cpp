// MRUPathList.cpp - implementation of the CMRUPathList class
//

#include "stdafx.h"

#include "MRUPathList.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CMRUPathList

// Constructor
CMRUPathList::CMRUPathList()
{
	VERIFY(NULL == m_pUniqueInstance);
}

// Destructor
CMRUPathList::~CMRUPathList()
{
}

// The only instance of this class allowed
CMRUPathList* CMRUPathList::m_pUniqueInstance = NULL;

// Creation of the single instance
CMRUPathList* CMRUPathList::GetPathList()
{
	// Create the single instance if we need to.
	if (NULL == m_pUniqueInstance)
		m_pUniqueInstance = new CMRUPathList;

	return m_pUniqueInstance;
}

// Destruction of the single instance
void CMRUPathList::DestroyPathList()
{
	if (NULL != m_pUniqueInstance)
	{
		delete m_pUniqueInstance;
		m_pUniqueInstance = NULL;
	}
}


/////////////////////////////////////////////////////////////////////////////
// CMRUPathList operations

// Set the MRU path for the given operation type
void CMRUPathList::SetMRUPath(const CString& strOperationType, const CString& strPath)
{
	// Dead simple stuff - just set the mapping
	m_MRUPaths.SetAt(strOperationType, strPath);
}

// Get the MRU path for the given operation type
CString CMRUPathList::GetMRUPath(const CString& strOperationType) const
{
	// Just get the path from the lookup
	CString strPath("");
	m_MRUPaths.Lookup(strOperationType, strPath);

	return strPath;
}

static const TCHAR szMRUPathSection[] = _T("Recent Path List");

// Save the paths to the INI file
void CMRUPathList::StoreProfileSettings() const
{
	// Get a pointer to the app, used for storing things in
	// the INI file
	CWinApp* pApp = AfxGetApp();
	if (NULL == pApp)
		return;

	// Loop through the paths in the lookup, saving each in
	// the INI file
	POSITION posPath = m_MRUPaths.GetStartPosition();
	while (NULL != posPath)
	{
		// Get the next operation-path pair
		CString strOpType(""), strPath("");
		m_MRUPaths.GetNextAssoc(posPath, strOpType, strPath);

		// Save it in the INI file
		pApp->WriteProfileString(szMRUPathSection, strOpType, strPath);
	}
}

// Load the paths from the INI file
void CMRUPathList::LoadProfileSettings()
{
	// Get a pointer to the app, used for storing things in
	// the INI file
	CWinApp* pApp = AfxGetApp();
	if (NULL == pApp)
		return;

	// Loop through the paths in the lookup, saving each in
	// the INI file
	POSITION posPath = m_MRUPaths.GetStartPosition();
	while (NULL != posPath)
	{
		// Get the next operation-path pair
		CString strOpType(""), strPath("");
		m_MRUPaths.GetNextAssoc(posPath, strOpType, strPath);

		// Load it from the INI file
		strPath = pApp->GetProfileString(szMRUPathSection, strOpType, strPath);

		// Now set it in the lookup
		m_MRUPaths.SetAt(strOpType, strPath);
	}
}

